const {chromium}=require('playwright');
const {spawnSync}=require('node:child_process');const path=require('node:path');const fs=require('node:fs');const assert=require('node:assert/strict');
(async()=>{
 const env=process.env,base=env.AHDA_WP_E2E_URL,out=env.AHDA_WP_E2E_OUTPUT;assert(new URL(base).hostname==='127.0.0.1');
 let checks=0,external=0;const externalTargets=[];function ck(v,m){assert(v,m);checks++;}
 function control(command,...args){const php=[env.AHDA_WP_E2E_PHP,'-n'];for(const mod of ['ctype','iconv','fileinfo','dom','mysqlnd','mysqli']){php.push('-d','extension='+path.join(env.AHDA_WP_E2E_EXTENSION_DIR,mod+'.so'));}const r=spawnSync(php[0],php.slice(1).concat([env.AHDA_WP_E2E_CONTROL,command,...args.map(String)]),{env,encoding:'utf8'});assert(r.status===0,'Isolated control failed: '+r.stderr);return JSON.parse(r.stdout);}
 const browser=await chromium.launch({headless:true,executablePath:env.AHDA_UI_BROWSER_PATH||'/usr/bin/chromium'});const contexts=[];
 async function context(){const c=await browser.newContext({viewport:{width:1280,height:900}});contexts.push(c);await c.route('**/*',r=>{if(new URL(r.request().url()).origin===base){return r.continue();}external++;const u=new URL(r.request().url());externalTargets.push({origin:u.origin,path:u.pathname,type:r.request().resourceType()});return r.abort();});return c;}
 async function login(c,user,password){const p=await c.newPage();await p.goto(base+'/wp-login.php?redirect_to='+encodeURIComponent(base+'/wp-admin/admin.php?page=ahda-discovery-candidates'));await p.locator('#user_login').fill(user);await p.locator('#user_pass').fill(password);await p.locator('#wp-submit').click();try{await p.waitForURL(/\/wp-admin\//);}catch(error){const url=new URL(p.url());const loginError=await p.locator('#login_error').innerText().catch(()=>null);fs.writeFileSync(path.join(out,'login-failure.json'),JSON.stringify({user,path:url.pathname,origin:url.origin,error_text:loginError},null,2));throw error;}return p;}
 const before=control('snapshot');ck(before.wordpress==='7.1.4'&&before.preflight,'real WP/preflight ready');ck(!before.negative_enabled,'default write gate OFF');
 try{
  const anonymous=await context();const a=await anonymous.newPage();await a.goto(base+'/wp-admin/admin.php?page=ahda-discovery-candidates');ck(a.url().includes('wp-login.php'),'Core auth redirects anonymous visitor');
  const admin=await context();const page=await login(admin,'ahda_e2e_admin',env.AHDA_WP_E2E_ADMIN_PASSWORD);
  await page.goto(base+'/wp-admin/admin.php?page=ahda-discovery-candidates&npsn=20268071');ck(await page.getByRole('link',{name:'Lihat nilai dan evidence'}).count()===3,'actual WordPress submenu/list renders3candidates');
  const ids=before.candidates.map(c=>Number(c.id));const detail=id=>base+'/wp-admin/admin.php?page=ahda-discovery-candidates&npsn=20268071&candidate='+id;
  await page.goto(detail(ids[0]));ck(await page.locator('form[method="post"]').count()===0,'default actual WP view has no write form');
  const postOff=await admin.request.post(base+'/wp-admin/admin-post.php',{form:{action:'ade_negative_review'},maxRedirects:0});ck(postOff.status()===400,'Core write hook unregistered by default');
  control('enable');await page.goto(detail(ids[0]));ck(await page.locator('form[method="post"]').count()===2,'enabled test request registers two negative forms');
  ck(await page.getByText('Review negatif manual aktif.',{exact:true}).count()===1,'actual enabled mode banner');
  async function form(decision){return page.locator('form').filter({has:page.locator('input[name="decision"][value="'+decision+'"]')}).evaluate(el=>Object.fromEntries(Array.from(el.elements).filter(e=>e.name).map(e=>[e.name,e.value])));}
  const req=await form('defer');req.note=String.raw`Synthetic O'Reilly; DROP TABLE schools; -- C:\fixture`;req.backup_confirmed='YES';req.confirm='SAVE_NEGATIVE_REVIEW';
  ck(req.nonce.length===10&&/^[a-f0-9]+$/.test(req.nonce),'real WordPress nonce generated');
  async function post(body,c=admin){return c.request.post(base+'/wp-admin/admin-post.php',{form:body,maxRedirects:0});}
  let res=await post(req,anonymous);ck(res.status()===400&&control('snapshot').audit_count===0,'real anonymous POST has no handler or audit');
  res=await post({...req,nonce:'bad'});ck(res.status()===403,'real invalid nonce blocked');
  res=await post({...req,backup_confirmed:'NO'});ck(res.status()===403,'real backup acknowledgment required');
  res=await post({...req,decision:'reject',reason:'WRONG_INFORMATION'});ck(res.status()===403,'real nonce is decision scoped');
  res=await post({...req,decision:'approve'});ck(res.status()===403,'real approve path unavailable');
  let state=control('snapshot');ck(state.audit_count===0&&state.receipt_count===0,'invalid real POSTs have no review mutations');
  const editor=await context();const editorPage=await login(editor,'ahda_e2e_editor',env.AHDA_WP_E2E_EDITOR_PASSWORD);
  const denied=await editorPage.goto(detail(ids[0]));ck(denied.status()===403,'real editor capability denies panel');
  res=await post(req,editor);ck(res.status()===403&&control('snapshot').audit_count===0,'editor cannot reuse admin nonce/decision');
  const secondAdmin=await context();await login(secondAdmin,'ahda_e2e_admin',env.AHDA_WP_E2E_ADMIN_PASSWORD);res=await post(req,secondAdmin);ck(res.status()===403&&control('snapshot').audit_count===0,'real nonce bound to original login session');
  res=await post({...req,redirect_to:'https://untrusted.example/'});ck(res.status()===302,'real controller successful safe redirect');ck(new URL(res.headers().location).origin===base&&res.headers().location.includes('page=ahda-discovery-candidates'),'safe redirect ignores untrusted referer and preserves inspector target');
  state=control('snapshot');ck(state.audit_count===1&&state.receipt_count===1&&state.candidates[0].review_status==='deferred','real wpdb persists exact decision/audit/receipt');ck(state.last_note===req.note,'real wp_magic_quotes/unslash preserves apostrophe');
  res=await post(req);ck(res.status()===302&&control('snapshot').audit_count===1,'real HTTP replay no duplicate audit');
  await page.goto(detail(ids[0]));ck(await page.getByText(req.note,{exact:true}).count()===1,'real audit history displays stored note');
  const reject=await form('reject');reject.reason='WRONG_INFORMATION';reject.note='Synthetic rejected after review';reject.backup_confirmed='YES';reject.confirm='SAVE_NEGATIVE_REVIEW';res=await post(reject);ck(res.status()===302,'real deferred to rejected');
  state=control('snapshot');ck(state.audit_count===2&&state.candidates[0].review_status==='rejected','real rejected state/audit');
  await page.goto(detail(ids[0]));ck(await page.locator('form[method="post"]').count()===0,'terminal rejection has no further negative forms');
  await page.goto(detail(ids[1]));const stale=await form('defer');stale.backup_confirmed='YES';stale.confirm='SAVE_NEGATIVE_REVIEW';stale.note='Synthetic stale form';control('bump',ids[1]);res=await post(stale);ck(res.status()===409&&control('snapshot').audit_count===2,'real stale version returns409 and no audit');
  const cross=await page.goto(base+'/wp-admin/admin.php?page=ahda-discovery-candidates&npsn=20268073&candidate='+ids[2]);ck((await page.locator('body').innerText()).includes('M3_CANDIDATE_NOT_FOUND'),'real cross-school IDOR blocked');
  control('poison',ids[2]);await page.goto(detail(ids[2]));ck(await page.locator('img[src*="untrusted.example"]').count()===0,'real WP escapes untrusted image markup');ck(await page.evaluate(()=>typeof window.__AHDA_XSS==='undefined'),'real WP stored proposal/quote script nonexecution');control('restore');
  await page.goto(detail(ids[2]));await page.screenshot({path:path.join(out,'wordpress-admin-desktop.png'),fullPage:true});
  await page.setViewportSize({width:390,height:844});await page.screenshot({path:path.join(out,'wordpress-admin-mobile.png'),fullPage:true});
  ck(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+3),'real WordPress mobile no document overflow');
  state=control('snapshot');ck(JSON.stringify(before.hashes)===JSON.stringify(state.hashes),'real AHDA legacy/source/evidence/link row hashes unchanged');
  ck(state.candidates.every(c=>c.approved_value===null&&c.publish_status==='not_ready'),'real approved/publication fields untouched');
  ck(Object.keys(before.legacy_hashes).length>=25,'actual Directory full legacy schema created only in synthetic DB');ck(JSON.stringify(before.legacy_hashes)===JSON.stringify(state.legacy_hashes),'all synthetic AHDA legacy table row hashes unchanged');
  control('disable');await page.goto(detail(ids[2]));ck(await page.locator('form[method="post"]').count()===0,'actual write switch OFF restores read-only forms');res=await post(req);ck(res.status()===400&&control('snapshot').audit_count===2,'OFF disables handler even for old valid replay');fs.writeFileSync(path.join(out,'blocked-browser-targets.json'),JSON.stringify(externalTargets,null,2));ck(external===0,'no external browser request attempted');
  const bridge=control('bridge_pipeline');ck(bridge.status==='PASS'&&bridge.database_adapter==='wpdb','bridge service integration uses actual WordPress/wpdb');
  await page.setViewportSize({width:1280,height:900});await page.goto(detail(bridge.visible_candidate_id));
  ck((await page.locator('body').innerText()).includes('Referensi arsip raw #'),'actual WordPress admin displays archive provenance');
  ck((await page.locator('body').innerText()).includes('belum diperiksa ulang pada halaman ini'),'actual WordPress shows raw revalidation limit');
  ck(await page.locator('form[method="post"]').count()===0,'service test opt-ins do not enable HTTP mutation forms');
  await page.screenshot({path:path.join(out,'wordpress-archive-desktop.png'),fullPage:true});
  await page.setViewportSize({width:390,height:844});await page.screenshot({path:path.join(out,'wordpress-archive-mobile.png'),fullPage:true});
  ck(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+3),'actual WordPress archive hashes wrap on mobile');
  const afterBridge=control('snapshot');ck(JSON.stringify(before.legacy_hashes)===JSON.stringify(afterBridge.legacy_hashes),'all actual Directory synthetic legacy tables preserved after raw bridge');
  ck(afterBridge.candidates.every(c=>c.approved_value===null&&c.publish_status==='not_ready'),'all bridge proposals remain unapproved/unpublished');
  ck(external===0,'bridge view performs no external browser request');
  fs.writeFileSync(path.join(out,'wordpress-browser-result.json'),JSON.stringify({status:'PASS',checks,external_requests:external,legacy_tables_checked:Object.keys(before.legacy_hashes).length,wordpress:'7.1.4',scope:'Real WordPress login/cookies/roles/nonces/wpdb/admin-post routing and both actual plugins; owned synthetic MySQL and custom test wp-load bootstrap/home alias. No wp-config file or user LocalWP.'},null,2));
  console.log('PASS: '+checks+' real WordPress7.1.4 integration checks (owned synthetic site; custom test bootstrap).');
 }finally{await browser.close();}
})().catch(e=>{console.error(e.message);process.exitCode=1;});
