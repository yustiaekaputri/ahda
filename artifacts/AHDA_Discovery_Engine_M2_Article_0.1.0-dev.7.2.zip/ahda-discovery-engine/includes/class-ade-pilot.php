<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Frozen pilot selection and bounded READ-ONLY source planning on existing R3. */
final class ADE_Pilot {
    private const FORMS = array( 'SMP', 'MTS', 'MA', 'SMA', 'SMK', 'SMAK' );
    public static function parse( string $input ): array {
        if ( strlen( $input ) > 4096 ) { throw new InvalidArgumentException( 'PILOT_TOO_LARGE' ); }
        $lines = preg_split( '/\r\n|\n|\r/', trim( $input ) );
        if ( ! $lines || count( $lines ) > 200 ) { throw new InvalidArgumentException( 'PILOT_COUNT_INVALID' ); }
        $out = array();
        foreach ( $lines as $line ) {
            // One NPSN per line. Preserve leading zeroes; reject CSV formulas/header.
            $npsn = ADE_Identity::validate_npsn( $line );
            if ( isset( $out[$npsn] ) ) { throw new InvalidArgumentException( 'PILOT_DUPLICATE' ); }
            $out[$npsn] = $npsn;
        }
        return array_values( $out );
    }

    public static function freeze( array $npsns, ?string $scope = null ): array {
        if ( null !== $scope && $scope !== ADE_Pilot_Scope::NAME ) { throw new InvalidArgumentException( 'PILOT_SCOPE_UNKNOWN' ); }
        if ( ! $npsns || count( $npsns ) > 200 ) { throw new InvalidArgumentException( 'PILOT_COUNT_INVALID' ); }
        $rows = array(); $seen = array();
        foreach ( $npsns as $npsn ) {
            if ( ! is_string( $npsn ) ) { throw new InvalidArgumentException( 'PILOT_NPSN_TYPE' ); }
            $npsn = ADE_Identity::validate_npsn( $npsn );
            if ( isset( $seen[$npsn] ) ) { throw new InvalidArgumentException( 'PILOT_DUPLICATE' ); }
            $seen[$npsn] = true;
            if ( null !== $scope && ! ADE_Pilot_Scope::contains( $npsn ) ) { throw new InvalidArgumentException( 'PILOT_NPSN_OUTSIDE_FROZEN_SELECTION' ); }
            $school = null === $scope ? ADE_Identity::lookup( $npsn ) : ADE_Identity::lookup_pilot( $npsn );
            if ( null !== $scope ) { ADE_Pilot_Scope::assert_school( $school ); }
            if ( (string) $school['npsn'] !== $npsn || ! in_array( strtoupper( trim( (string) $school['school_form'] ) ), self::FORMS, true ) || $school['visibility'] !== 'publish' ) {
                throw new InvalidArgumentException( 'PILOT_SCHOOL_INELIGIBLE' );
            }
            $rows[] = array( 'school_id' => (int) $school['id'], 'npsn' => (string) $school['npsn'] );
        }
        usort( $rows, static function ( $a, $b ) { return $a['school_id'] <=> $b['school_id']; } );
        $ids = array_column( $rows, 'school_id' );
        if ( count( array_unique( $ids ) ) !== count( $ids ) ) { throw new InvalidArgumentException( 'PILOT_ID_CONFLICT' ); }
        if ( null === $scope ) {
            // Legacy v1 API remains for interpreting pre-existing jobs only.
            return array( 'version' => 1, 'schools' => $rows, 'hash' => hash( 'sha256', json_encode( $rows, JSON_THROW_ON_ERROR ) ) );
        }
        $payload = array( 'scope' => $scope, 'scope_hash' => ADE_Pilot_Scope::SHA256, 'schools' => $rows );
        return array_merge( array( 'version' => 2 ), $payload, array( 'hash' => hash( 'sha256', json_encode( $payload, JSON_THROW_ON_ERROR ) ) ) );
    }

    /** Bounded read-only audit; does not freeze a DB manifest, enqueue or fetch. */
    public static function audit_selection( array $npsns ): array {
        if ( count( $npsns ) !== 200 || count( array_unique( $npsns ) ) !== 200 ) { throw new InvalidArgumentException( 'PILOT_REQUIRES_EXACT_FROZEN_200' ); }
        foreach ( $npsns as $npsn ) {
            if ( ! is_string( $npsn ) || ! ADE_Pilot_Scope::contains( ADE_Identity::validate_npsn( $npsn ) ) ) {
                throw new InvalidArgumentException( 'PILOT_NPSN_OUTSIDE_FROZEN_SELECTION' );
            }
        }
        $checked = 0; $passed = 0; $issues = array(); $ids = array(); $start = microtime( true );
        foreach ( $npsns as $npsn ) {
            if ( microtime( true ) - $start >= 15 || memory_get_usage( true ) >= 64 * 1024 * 1024 ) { break; }
            ++$checked;
            try {
                $school = ADE_Identity::lookup_pilot( $npsn );
                if ( (string) $school['npsn'] !== $npsn || isset( $ids[(int) $school['id']] ) ) {
                    throw new RuntimeException( 'PILOT_ID_CONFLICT' );
                }
                $ids[(int) $school['id']] = true;
                ADE_Pilot_Scope::assert_school( $school );
                ++$passed;
            } catch ( Throwable $e ) {
                // Stable reason codes only; never copy SQL errors/source HTML into reports.
                $allowed = array( 'PILOT_CLASSIFICATION_CONFLICT_SCHOOL_FORM', 'PILOT_CLASSIFICATION_CONFLICT_OWNERSHIP_STATUS',
                    'PILOT_CLASSIFICATION_CONFLICT_REGENCY_RAW', 'PILOT_NOT_PUBLISHED', 'PILOT_ID_CONFLICT', 'PILOT_NPSN_OUTSIDE_FROZEN_SELECTION' );
                $code = in_array( $e->getMessage(), $allowed, true ) ? $e->getMessage() : 'PILOT_LOOKUP_FAILED';
                $issues[] = array( 'npsn' => $npsn, 'code' => $code );
            }
        }
        return array( 'scope' => ADE_Pilot_Scope::NAME, 'scope_hash' => ADE_Pilot_Scope::SHA256,
            'all_valid' => $passed === 200, 'checked' => $checked, 'passed' => $passed,
            'failed' => count( $issues ), 'unrun' => 200 - $checked, 'issues' => $issues,
            'mode' => 'READ_ONLY_NO_FETCH', 'network_requests' => 0, 'database_writes' => 0 );
    }

    public static function validate_manifest( array $manifest ): void {
        $version = $manifest['version'] ?? null;
        $scoped = $version === 2;
        $keys = $scoped ? array( 'version', 'scope', 'scope_hash', 'schools', 'hash' ) : array( 'version', 'schools', 'hash' );
        if ( ! in_array( $version, array(1,2), true ) || array_diff( array_keys( $manifest ), $keys ) ||
            ! is_array( $manifest['schools'] ?? null ) || ! $manifest['schools'] || count( $manifest['schools'] ) > 200 ||
            ! is_string( $manifest['hash'] ?? null ) ) { throw new InvalidArgumentException( 'MANIFEST_INVALID' ); }
        if ( $scoped && ( ( $manifest['scope'] ?? null ) !== ADE_Pilot_Scope::NAME ||
            ( $manifest['scope_hash'] ?? null ) !== ADE_Pilot_Scope::SHA256 ) ) { throw new InvalidArgumentException( 'MANIFEST_SCOPE_CHANGED' ); }
        $previous = 0; $seen = array();
        foreach ( $manifest['schools'] as $row ) {
            if ( ! is_array( $row ) || array_diff( array_keys( $row ), array( 'school_id', 'npsn' ) ) || ! is_int( $row['school_id'] ?? null ) || $row['school_id'] <= $previous ||
                ! is_string( $row['npsn'] ?? null ) || ADE_Identity::validate_npsn( $row['npsn'] ) !== $row['npsn'] || isset( $seen[$row['npsn']] ) ) {
                throw new InvalidArgumentException( 'MANIFEST_INVALID' );
            }
            if ( $scoped && ! ADE_Pilot_Scope::contains( $row['npsn'] ) ) { throw new InvalidArgumentException( 'MANIFEST_NPSN_OUTSIDE_SCOPE' ); }
            $previous = $row['school_id']; $seen[$row['npsn']] = true;
        }
        $payload = $scoped ? array( 'scope' => $manifest['scope'], 'scope_hash' => $manifest['scope_hash'], 'schools' => $manifest['schools'] ) : $manifest['schools'];
        if ( ! hash_equals( $manifest['hash'], hash( 'sha256', json_encode( $payload, JSON_THROW_ON_ERROR ) ) ) ) {
            throw new InvalidArgumentException( 'MANIFEST_HASH_MISMATCH' );
        }
    }

    /** No DNS, HTTP, inserts, updates, approval, or identity promotion. */
    public static function batch( array $manifest, int $after = 0, int $size = 10 ): array {
        self::validate_manifest( $manifest );
        $ids = array_column( $manifest['schools'], 'school_id' );
        if ( $size < 1 || $size > 20 || $after < 0 || ( $after !== 0 && ! in_array( $after, $ids, true ) ) ) {
            throw new InvalidArgumentException( 'BATCH_CURSOR_OR_SIZE_INVALID' );
        }
        $results = array(); $cursor = $after; $start = microtime( true );
        foreach ( $manifest['schools'] as $row ) {
            if ( $row['school_id'] <= $after ) { continue; }
            if ( count( $results ) >= $size || microtime( true ) - $start >= 15 || memory_get_usage( true ) >= 64 * 1024 * 1024 ) { break; }
            $current = $manifest['version'] === 2 ? ADE_Identity::lookup_pilot( $row['npsn'] ) : ADE_Identity::lookup( $row['npsn'] );
            if ( $manifest['version'] === 2 ) { ADE_Pilot_Scope::assert_school( $current ); }
            if ( (int) $current['id'] !== $row['school_id'] || (string) $current['npsn'] !== $row['npsn'] || ! in_array( strtoupper( trim( (string) $current['school_form'] ) ), self::FORMS, true ) || $current['visibility'] !== 'publish' ) {
                throw new RuntimeException( 'PILOT_IDENTITY_OR_ELIGIBILITY_CHANGED' );
            }
            $sources = ADE_Sources::list_for_school( $row['npsn'], 5 );
            $results[] = array( 'school_id' => $row['school_id'], 'npsn' => $row['npsn'],
                'source_count_capped_at_5' => count( $sources['rows'] ),
                'outcome' => $sources['rows'] ? 'operator_source_review_required' : 'needs_source',
                'network_requests' => 0 );
            $cursor = $row['school_id'];
        }
        return array( 'manifest_hash' => $manifest['hash'], 'after' => $after, 'cursor' => $cursor,
            'complete' => $cursor === end( $ids ), 'results' => $results, 'network_requests' => 0 );
    }
}
