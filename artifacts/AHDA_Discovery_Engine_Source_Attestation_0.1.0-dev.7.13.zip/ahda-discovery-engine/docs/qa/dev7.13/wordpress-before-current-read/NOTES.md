Initial116service/47browser PASS before final locking-current-read hardening and added two-session RR regression. Preserved historical scope; final report is in wordpress/.
