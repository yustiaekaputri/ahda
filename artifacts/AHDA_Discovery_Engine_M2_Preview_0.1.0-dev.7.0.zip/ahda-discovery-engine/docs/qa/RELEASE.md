# dev.7.0 — M2 structured preview foundation

Adds one new class, fixture JSON, focused tests and the `extract` CLI handler.
No HTML/CSV parser, M2 DB persistence, extraction worker, review UI or publisher
is claimed. No schema changes, network fetches, real DB mutations or production.
The source catalog policy is still blocked; no repeat probes were made this turn.

14 standalone suites PASS on PHP8.2.32/8.4.24,580 checks each.43 PHP files lint
per runtime. All84 original baseline files and6 original regression suites remain
byte-identical. New M2 suite60 checks covers schema/UTF8/size/key constraints,
escaped duplicate JSON keys, scope/hard NPSN mismatch, literal quote containment,
protected fields, conflicting values, URL credentials/tokens/schemes, future/stale
dates, dedupe, fixture/unverified status, instruction text as data, snapshot hash,
no-change, oversized/error snapshot, local/capability/dry-run and CLI demo.

Snapshot SQL is prepared, reads only3 verified target fields, limits rows and
returned value sizes. All M2 evidence/candidates are in-memory previews, no DB IDs
claimed, no approved value. Fresh source authenticity/permissions still unverified.

Tests use synthetic content and fake IDs/DB, not actual school programs or native
WordPress/MySQL. Native LocalWP M2 handler and parser integration NOT TESTED.
Prior operator LocalWP dev6.1 scope/preflight and dev6.2 source_preview first10
results remain valid evidence for those specific checks only. CLI hyphen aliases
from hotfix retained; new command `extract` has no hyphen/underscore ambiguity.

Fixture is clearly synthetic, example.org URL and old date; never school facts.
No language model/generative provider is called. Free-form instructions in source
are treated only as untrusted strings and cannot approve/publish or trigger I/O.
