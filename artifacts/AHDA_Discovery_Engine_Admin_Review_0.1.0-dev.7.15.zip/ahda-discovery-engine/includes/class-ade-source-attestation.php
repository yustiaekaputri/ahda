<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Operator declarations for one claim, not independent verification or approval. */
final class ADE_Source_Attestation {
    public const GRANT = 'm3_source_attestation';
    public const REVOKE = 'm3_source_revoke';
    public static function enabled(): bool { return defined( 'ADE_LOCAL_SOURCE_ATTESTATION_ENABLED' ) && ADE_LOCAL_SOURCE_ATTESTATION_ENABLED === true; }
    private static function guard( bool $cli = false ): int {
        if ( ! ADE_Schema::is_allowed_local() || ! current_user_can( 'ade_review_candidates' ) || (int) get_current_user_id() < 1 || ! ADE_Jobs::preflight()['ready'] ) { throw new RuntimeException( 'ATTEST_REVIEW_GATE_BLOCKED' ); }
        if ( $cli ) { ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' ); }
        return (int) get_current_user_id();
    }
    private static function text( $value, int $min, int $max ): string {
        if ( ! is_string( $value ) || strlen( trim( $value ) ) < $min || strlen( $value ) > $max || ! preg_match( '//u', $value ) || preg_match( '/[<>\x00-\x1f\x7f\x{200B}-\x{200F}\x{202A}-\x{202E}\x{2060}-\x{206F}\x{FEFF}]/u', $value ) ) { throw new InvalidArgumentException( 'ATTEST_TEXT_INVALID' ); }
        return trim( $value );
    }
    private static function reference( $value ): string {
        $value = self::text( $value, 3, 1000 );
        if ( preg_match( '/^[a-zA-Z0-9_-]{3,80}$/D', $value ) ) { return $value; }
        ADE_Local_Archive::document( 'reference', 'csv', $value, '2026-01-01T00:00:00Z', 'reference-hygiene' );
        return $value;
    }
    public static function request( string $raw ): array {
        $r = ADE_Strict_JSON::decode( $raw, 16384 );
        $keys = array( 'npsn', 'candidate_id', 'evidence_id', 'identity_basis', 'identity_reference', 'identity_note', 'permission_basis', 'permission_reference', 'permission_note', 'valid_until', 'identity_checked', 'permission_checked', 'privacy_checked' );
        ADE_Local_Archive::keys( $r, $keys ); $out = array(); foreach ( $keys as $key ) { $out[$key] = $r[$key]; } $r = $out;
        if ( ! is_string( $r['npsn'] ) || ! ADE_Pilot_Scope::contains( $r['npsn'] ) || ! is_int( $r['candidate_id'] ) || $r['candidate_id'] < 1 || ! is_int( $r['evidence_id'] ) || $r['evidence_id'] < 1 || ! in_array( $r['identity_basis'], array( 'registry_crosscheck', 'school_confirmation' ), true ) || ! in_array( $r['permission_basis'], array( 'explicit_permission', 'open_license' ), true ) || $r['identity_checked'] !== true || $r['permission_checked'] !== true || $r['privacy_checked'] !== true ) { throw new InvalidArgumentException( 'ATTEST_REQUEST_INVALID' ); }
        foreach ( array( 'identity_reference', 'permission_reference' ) as $key ) { $r[$key] = self::reference( $r[$key] ); }
        foreach ( array( 'identity_note', 'permission_note' ) as $key ) { $r[$key] = self::text( $r[$key], 40, 500 ); }
        if ( $r['identity_basis'] === 'registry_crosscheck' && ! in_array( parse_url( $r['identity_reference'], PHP_URL_HOST ), array( 'referensi.data.kemendikdasmen.go.id', 'referensi.data.kemdikbud.go.id' ), true ) ) { throw new InvalidArgumentException( 'ATTEST_REGISTRY_REFERENCE_REQUIRED' ); }
        if ( ! is_string( $r['valid_until'] ) ) { throw new InvalidArgumentException( 'ATTEST_EXPIRY_INVALID' ); }
        $date = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i:s\Z', $r['valid_until'], new DateTimeZone( 'UTC' ) );
        if ( ! $date || $date->format( 'Y-m-d\TH:i:s\Z' ) !== $r['valid_until'] ) { throw new InvalidArgumentException( 'ATTEST_EXPIRY_INVALID' ); }
        return $r;
    }
    private static function rows( string $sql, array $args ): array {
        global $wpdb; $wpdb->last_error = ''; $rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
        if ( ! is_array( $rows ) || $wpdb->last_error ) { throw new RuntimeException( 'ATTEST_READ_FAILED' ); }
        return $rows;
    }
    private static function one( string $sql, array $args ): ?array { $rows = self::rows( $sql, $args ); if ( count( $rows ) > 1 ) { throw new RuntimeException( 'ATTEST_ROW_NOT_UNIQUE' ); } return $rows[0] ?? null; }
    private static function transaction( string $sql ): void {
        global $wpdb; $wpdb->last_error = '';
        if ( ! in_array( $sql, array( 'START TRANSACTION', 'COMMIT', 'ROLLBACK' ), true ) || false === $wpdb->query( $sql ) || $wpdb->last_error ) { throw new RuntimeException( 'ATTEST_TRANSACTION_FAILED' ); }
    }
    private static function event( string $where, array $args, string $type, bool $lock = false ): ?array {
        if ( ! in_array( $where, array( 'id=%d', 'job_key=%s' ), true ) || ! in_array( $type, array( self::GRANT, self::REVOKE ), true ) ) { throw new RuntimeException( 'ATTEST_QUERY_INVALID' ); }
        $table = ADE_Schema::table_name( 'jobs' ); $args[] = $type; $end = $lock ? ' FOR UPDATE NOWAIT' : '';
        $row = self::one( "SELECT id,job_key,status,LEFT(scope_filter,16385) AS scope_filter,OCTET_LENGTH(scope_filter) AS scope_bytes,LEFT(stats_payload,16385) AS stats_payload,OCTET_LENGTH(stats_payload) AS stats_bytes FROM {$table} WHERE {$where} AND job_type=%s LIMIT 1{$end}", $args );
        if ( ! $row ) { return null; }
        if ( $row['status'] !== 'completed' || (int) $row['scope_bytes'] > 16384 || (int) $row['stats_bytes'] > 16384 ) { throw new RuntimeException( 'ATTEST_EVENT_INVALID' ); }
        $meta = ADE_Strict_JSON::decode( $row['scope_filter'], 16384 ); $result = ADE_Strict_JSON::decode( $row['stats_payload'], 16384 );
        if ( ( $meta['schema_version'] ?? null ) !== 1 || ( $meta['type'] ?? null ) !== $type || ! is_int( $meta['actor_user_id'] ?? null ) || $meta['actor_user_id'] < 1 || ( $meta['result_sha256'] ?? null ) !== ADE_Local_Archive::digest( $result ) || ( $result['operation_key'] ?? null ) !== $row['job_key'] || ( $result['candidate_approved'] ?? null ) !== false || ( $result['independently_verified'] ?? null ) !== false || ( $result['publication_enabled'] ?? null ) !== false || ! is_array( $meta['request'] ?? null ) || ! is_array( $meta['context'] ?? null ) || ! is_string( $meta['preview_token'] ?? null ) || ! preg_match( '/^[a-f0-9]{64}$/D', $meta['preview_token'] ) ) { throw new RuntimeException( 'ATTEST_EVENT_INVALID' ); }
        $operation = $type === self::GRANT ? ADE_Local_Archive::digest( array( self::GRANT, self::request( json_encode( $meta['request'], JSON_THROW_ON_ERROR ) ), $meta['actor_user_id'], $meta['context']['binding_sha256'] ?? null ) ) : self::revoke_key( (int) ( $meta['request']['attestation_id'] ?? 0 ), (string) ( $meta['context']['grant_operation'] ?? '' ) );
        if ( $type === self::GRANT ) {
            $c = $meta['context'];
            if ( ! is_array( $c['verification'] ?? null ) || ! is_array( $c['source_state'] ?? null ) || ! is_string( $c['binding_sha256'] ?? null ) || $c['binding_sha256'] !== ADE_Local_Archive::digest( array( 'attestation-claim-binding-v1', $c['verification'], $c['source_state'] ) ) || $result !== self::summary( $operation, $meta['request'], $c, $meta['actor_user_id'], 'operator_attested' ) ) { throw new RuntimeException( 'ATTEST_EVENT_INVALID' ); }
        } elseif ( ( $result['attestation_id'] ?? null ) !== ( $meta['request']['attestation_id'] ?? null ) || ( $result['actor_user_id'] ?? null ) !== $meta['actor_user_id'] ) { throw new RuntimeException( 'ATTEST_EVENT_INVALID' ); }
        if ( ! hash_equals( $operation, $row['job_key'] ) || ( $result['state'] ?? null ) !== ( $type === self::GRANT ? 'operator_attested' : 'revoked' ) ) { throw new RuntimeException( 'ATTEST_EVENT_INVALID' ); }
        return array( 'id' => (int) $row['id'], 'meta' => $meta, 'result' => $result );
    }
    private static function context( array $r, bool $lock = false ): array {
        // Locked mode uses CURRENT reads from the first candidate/evidence SELECT,
        // not an older REPEATABLE READ snapshot established by another query.
        $v = ADE_Archive_Verifier::verify( $r['npsn'], $r['candidate_id'], $r['evidence_id'], $lock );
        if ( $v['current_value_conflict'] || in_array( 'STALE_EVIDENCE', $v['blocking_reasons'], true ) ) { throw new RuntimeException( 'ATTEST_RAW_NOT_CURRENT' ); }
        $st = ADE_Schema::table_name( 'sources' ); $rt = ADE_Schema::table_name( 'school_sources' ); $end = $lock ? ' FOR UPDATE NOWAIT' : '';
        $source = self::one( "SELECT s.id AS source_id,l.id AS relation_id,s.canonical_url,s.normalized_host,s.source_type,s.access_state,s.source_status,l.identity_status,l.relationship_type FROM {$st} s INNER JOIN {$rt} l ON l.source_id=s.id WHERE s.id=%d AND l.school_id=%d LIMIT 2{$end}", array( $v['source_id'], $v['school_id'] ) );
        if ( ! $source || ! is_string( $source['normalized_host'] ?? null ) || strpos( $r['identity_note'], $r['npsn'] ) === false || stripos( $r['identity_note'], $source['normalized_host'] ) === false ) { throw new RuntimeException( 'ATTEST_IDENTITY_NOTE_CONTEXT_REQUIRED' ); }
        unset( $v['checked_at'] ); $version = $v['candidate_version']; unset( $v['candidate_version'] );
        return array( 'verification' => $v, 'candidate_version' => $version, 'source_state' => $source, 'binding_sha256' => ADE_Local_Archive::digest( array( 'attestation-claim-binding-v1', $v, $source ) ) );
    }
    private static function expiry( array $r ): void { $time = ( new DateTimeImmutable( $r['valid_until'] ) )->getTimestamp(); if ( $time <= time() + 60 || $time > time() + 90 * 86400 ) { throw new RuntimeException( 'ATTEST_EXPIRY_OUT_OF_RANGE' ); } }
    private static function operation( array $r, int $actor, array $c ): string { return ADE_Local_Archive::digest( array( self::GRANT, $r, $actor, $c['binding_sha256'] ) ); }
    private static function token( string $op, array $r, array $c, int $actor ): string { return ADE_Local_Archive::digest( array( 'source-attestation-plan-v1', $op, $r, $c, $actor ) ); }
    private static function summary( string $op, array $r, array $c, int $actor, string $state ): array {
        return array( 'operation_key' => $op, 'state' => $state, 'actor_user_id' => $actor, 'npsn' => $r['npsn'], 'school_id' => $c['verification']['school_id'], 'candidate_id' => $r['candidate_id'], 'evidence_id' => $r['evidence_id'], 'source_id' => $c['verification']['source_id'], 'binding_sha256' => $c['binding_sha256'], 'valid_until' => $r['valid_until'], 'permission_scope' => 'one_short_factual_claim_with_attribution', 'candidate_approved' => false, 'independently_verified' => false, 'publication_enabled' => false );
    }
    public static function plan( string $raw ): array {
        $actor = self::guard( true ); $r = self::request( $raw ); self::expiry( $r ); $c = self::context( $r ); $op = self::operation( $r, $actor, $c ); $existing = self::event( 'job_key=%s', array( $op ), self::GRANT );
        return array( 'mode' => 'READ_ONLY_SOURCE_ATTESTATION_PLAN', 'request' => $r, 'binding_sha256' => $c['binding_sha256'], 'candidate_version' => $c['candidate_version'], 'preview_token' => $existing ? $existing['meta']['preview_token'] : self::token( $op, $r, $c, $actor ), 'already_recorded' => null !== $existing, 'attestation_id' => $existing['id'] ?? null, 'estimated_jobs_inserts' => $existing ? 0 : 1, 'write_enabled' => self::enabled(), 'independently_verified' => false, 'candidate_approved' => false, 'database_writes' => 0, 'network_requests' => 0, 'publication_enabled' => false );
    }
    private static function insert( string $type, string $op, array $r, array $c, int $actor, string $token, array $result ): int {
        $meta = array( 'schema_version' => 1, 'type' => $type, 'actor_user_id' => $actor, 'request' => $r, 'context' => $c, 'preview_token' => $token, 'result_sha256' => ADE_Local_Archive::digest( $result ) );
        $m = json_encode( $meta, JSON_THROW_ON_ERROR ); $s = json_encode( $result, JSON_THROW_ON_ERROR ); if ( strlen( $m ) > 16384 || strlen( $s ) > 16384 ) { throw new RuntimeException( 'ATTEST_EVENT_TOO_LARGE' ); }
        global $wpdb; $wpdb->last_error = ''; $now = current_time( 'mysql', true );
        $ok = $wpdb->insert( ADE_Schema::table_name( 'jobs' ), array( 'job_key' => $op, 'job_type' => $type, 'scope_level' => 'TASIK_NEGERI_200', 'scope_filter' => $m, 'status' => 'completed', 'attempt_count' => 1, 'max_attempts' => 1, 'cursor_school_id' => $result['school_id'], 'batch_size' => 1, 'stats_payload' => $s, 'created_at' => $now, 'updated_at' => $now, 'started_at' => $now, 'finished_at' => $now ) );
        if ( false === $ok || $wpdb->last_error || (int) $wpdb->insert_id < 1 ) { throw new RuntimeException( 'ATTEST_INSERT_FAILED' ); } return (int) $wpdb->insert_id;
    }
    private static function lock( int $school ): string { $name = 'ade_m2_' . substr( ADE_Local_Archive::digest( array( ADE_Schema::table_name( 'candidates' ), $school ) ), 0, 48 ); $row = self::one( 'SELECT GET_LOCK(%s,0) AS acquired', array( $name ) ); if ( (int) ( $row['acquired'] ?? 0 ) !== 1 ) { throw new RuntimeException( 'ATTEST_WRITER_BUSY' ); } return $name; }
    private static function consent( string $confirm, string $expected, string $backup, string $token ): void { if ( ! self::enabled() ) { throw new RuntimeException( 'ATTEST_WRITES_DISABLED' ); } if ( $confirm !== $expected || $backup !== 'YES' || ! preg_match( '/^[a-f0-9]{64}$/D', $token ) ) { throw new RuntimeException( 'ATTEST_EXPLICIT_CONFIRMATION_REQUIRED' ); } }
    public static function record( string $raw, string $token, string $confirm, string $backup ): array {
        self::consent( $confirm, 'RECORD_SOURCE_ATTESTATION', $backup, $token ); $actor = self::guard( true ); $r = self::request( $raw ); self::expiry( $r ); $initial = self::context( $r ); $name = self::lock( $initial['verification']['school_id'] ); $transaction = false;
        try {
            self::transaction( 'START TRANSACTION' ); $transaction = true; $c = self::context( $r, true ); $op = self::operation( $r, $actor, $c ); $existing = self::event( 'job_key=%s', array( $op ), self::GRANT, true );
            $expected = $existing ? $existing['meta']['preview_token'] : self::token( $op, $r, $c, $actor ); if ( ! hash_equals( $expected, $token ) ) { throw new RuntimeException( 'ATTEST_PLAN_STALE' ); }
            if ( $existing ) { self::transaction( 'COMMIT' ); $transaction = false; return array( 'attestation_id' => $existing['id'], 'replayed' => true, 'historical' => true, 'database_writes' => 0, 'publication_enabled' => false ); }
            $result = self::summary( $op, $r, $c, $actor, 'operator_attested' ); $id = self::insert( self::GRANT, $op, $r, $c, $actor, $token, $result ); self::transaction( 'COMMIT' ); $transaction = false;
            return array( 'attestation_id' => $id, 'replayed' => false, 'database_writes' => 1, 'result' => $result, 'publication_enabled' => false );
        } catch ( Throwable $e ) { if ( $transaction ) { self::transaction( 'ROLLBACK' ); } throw $e; }
        finally { self::rows( 'SELECT RELEASE_LOCK(%s) AS released', array( $name ) ); }
    }
    private static function revoke_key( int $id, string $op ): string { return ADE_Local_Archive::digest( array( self::REVOKE, $id, $op ) ); }
    private static function grant( int $id, bool $lock = false ): array { if ( $id < 1 ) { throw new InvalidArgumentException( 'ATTEST_ID_INVALID' ); } $g = self::event( 'id=%d', array( $id ), self::GRANT, $lock ); if ( ! $g ) { throw new RuntimeException( 'ATTEST_NOT_FOUND' ); } return $g; }
    public static function current( int $id ): array {
        self::guard(); $g = self::grant( $id ); $r = $g['meta']['request']; $revoke = self::event( 'job_key=%s', array( self::revoke_key( $id, $g['result']['operation_key'] ) ), self::REVOKE ); $reasons = array();
        if ( $revoke ) { $reasons[] = 'ATTEST_REVOKED'; } if ( ( new DateTimeImmutable( $r['valid_until'] ) )->getTimestamp() <= time() ) { $reasons[] = 'ATTEST_EXPIRED'; }
        if ( ! $reasons ) { try { $c = self::context( $r ); if ( ! hash_equals( $g['result']['binding_sha256'], $c['binding_sha256'] ) ) { $reasons[] = 'ATTEST_BINDING_CHANGED'; } } catch ( Throwable $e ) { $reasons[] = 'ATTEST_FRESH_CHECK_BLOCKED'; } }
        return array( 'mode' => 'READ_ONLY_SOURCE_ATTESTATION_STATUS', 'attestation_id' => $id, 'operator_statement_current' => ! $reasons, 'blocking_reasons' => $reasons, 'statement' => $r, 'actor_user_id' => $g['meta']['actor_user_id'], 'result' => $g['result'], 'candidate_approved' => false, 'independently_verified' => false, 'must_revalidate_for_approval' => true, 'database_writes' => 0, 'network_requests' => 0, 'publication_enabled' => false );
    }
    /** Cheap metadata for explicit review only; not a current-validity or approval check. */
    public static function declaration_for_review( int $id, string $npsn, int $candidate, int $evidence ): array {
        self::guard(); $g = self::grant( $id ); $r = $g['meta']['request'];
        if ( $r['npsn'] !== $npsn || $r['candidate_id'] !== $candidate || $r['evidence_id'] !== $evidence ) { throw new RuntimeException( 'ATTEST_APPROVAL_SCOPE_MISMATCH' ); }
        return array_intersect_key( $r, array_flip( array( 'identity_basis', 'identity_reference', 'identity_note', 'permission_basis', 'permission_reference', 'permission_note', 'valid_until' ) ) ) + array( 'actor_user_id' => $g['meta']['actor_user_id'] );
    }
    /** Internal approval precondition; lock=true requires caller-owned transaction and school mutex.
     * Never authorizes publication; read mode remains a transient preview only.
     */
    public static function approval_context( int $id, string $npsn, int $candidate, int $evidence, bool $lock = false ): array {
        self::guard(); $g = self::grant( $id, $lock ); $r = $g['meta']['request'];
        if ( $r['npsn'] !== $npsn || $r['candidate_id'] !== $candidate || $r['evidence_id'] !== $evidence ) { throw new RuntimeException( 'ATTEST_APPROVAL_SCOPE_MISMATCH' ); }
        if ( self::event( 'job_key=%s', array( self::revoke_key( $id, $g['result']['operation_key'] ) ), self::REVOKE, $lock ) ) { throw new RuntimeException( 'ATTEST_REVOKED' ); }
        $c = self::context( $r, $lock );
        if ( ! hash_equals( $g['result']['binding_sha256'], $c['binding_sha256'] ) ) { throw new RuntimeException( 'ATTEST_BINDING_CHANGED' ); }
        if ( ( new DateTimeImmutable( $r['valid_until'] ) )->getTimestamp() <= time() + 5 ) { throw new RuntimeException( 'ATTEST_EXPIRED_OR_EXPIRING' ); }
        return array( 'attestation_id' => $id, 'grant_operation' => $g['result']['operation_key'], 'binding_sha256' => $c['binding_sha256'], 'candidate_version' => $c['candidate_version'], 'school_id' => $c['verification']['school_id'], 'target_key' => $c['verification']['target_key'], 'valid_until' => $r['valid_until'], 'permission_scope' => $g['result']['permission_scope'], 'independently_verified' => false );
    }
    private static function revocation( int $id, string $reason, string $note ): array { if ( ! in_array( $reason, array( 'WITHDRAWN_PERMISSION', 'IDENTITY_DOUBT', 'OPERATOR_CORRECTION' ), true ) ) { throw new InvalidArgumentException( 'ATTEST_REVOKE_REASON_INVALID' ); } return array( 'attestation_id' => $id, 'reason' => $reason, 'note' => self::text( $note, 10, 500 ) ); }
    public static function revoke_plan( int $id, string $reason, string $note ): array {
        $actor = self::guard( true ); $r = self::revocation( $id, $reason, $note ); $g = self::grant( $id ); $op = self::revoke_key( $id, $g['result']['operation_key'] ); $existing = self::event( 'job_key=%s', array( $op ), self::REVOKE );
        return array( 'mode' => 'READ_ONLY_SOURCE_REVOCATION_PLAN', 'attestation_id' => $id, 'already_revoked' => null !== $existing, 'preview_token' => ADE_Local_Archive::digest( array( 'source-revocation-plan-v1', $actor, $r, $g['meta'] ) ), 'estimated_jobs_inserts' => $existing ? 0 : 1, 'write_enabled' => self::enabled(), 'database_writes' => 0, 'publication_enabled' => false );
    }
    public static function revoke( int $id, string $reason, string $note, string $token, string $confirm, string $backup ): array {
        self::consent( $confirm, 'REVOKE_SOURCE_ATTESTATION', $backup, $token ); $actor = self::guard( true ); $r = self::revocation( $id, $reason, $note ); $g = self::grant( $id ); $name = self::lock( $g['result']['school_id'] ); $transaction = false;
        try {
            self::transaction( 'START TRANSACTION' ); $transaction = true; $g = self::grant( $id, true ); $expected = ADE_Local_Archive::digest( array( 'source-revocation-plan-v1', $actor, $r, $g['meta'] ) ); if ( ! hash_equals( $expected, $token ) ) { throw new RuntimeException( 'ATTEST_PLAN_STALE' ); }
            $op = self::revoke_key( $id, $g['result']['operation_key'] ); $old = self::event( 'job_key=%s', array( $op ), self::REVOKE, true );
            if ( $old ) { if ( $old['meta']['request'] !== $r || $old['meta']['actor_user_id'] !== $actor ) { throw new RuntimeException( 'ATTEST_ALREADY_REVOKED' ); } self::transaction( 'COMMIT' ); $transaction = false; return array( 'revocation_id' => $old['id'], 'replayed' => true, 'database_writes' => 0, 'publication_enabled' => false ); }
            $result = $g['result']; $result['operation_key'] = $op; $result['state'] = 'revoked'; $result['actor_user_id'] = $actor; $result['attestation_id'] = $id;
            $rid = self::insert( self::REVOKE, $op, $r, array( 'grant_operation' => $g['result']['operation_key'] ), $actor, $token, $result ); self::transaction( 'COMMIT' ); $transaction = false;
            return array( 'revocation_id' => $rid, 'replayed' => false, 'database_writes' => 1, 'publication_enabled' => false );
        } catch ( Throwable $e ) { if ( $transaction ) { self::transaction( 'ROLLBACK' ); } throw $e; }
        finally { self::rows( 'SELECT RELEASE_LOCK(%s) AS released', array( $name ) ); }
    }
}
