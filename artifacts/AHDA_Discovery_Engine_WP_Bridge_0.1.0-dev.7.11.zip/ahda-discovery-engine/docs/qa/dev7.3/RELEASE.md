# dev.7.3

Offline CSV/DOM HTML extraction adapters for three supported profile fields.
No fetch/write/export/approval/publication; exact scope and normalized-record
provenance.945checks/18suites each PHP8.2+8.4 WITH DOM;892checks without DOM,
HTML extraction NOT RUN in no-DOM mode.60PHPfiles lint each.88native MySQL8.4.13
checks under WP/wpdb stubs; both own disposable containers/storage removed.
84baseline hashes/6original regression suites unchanged. Full LocalWP parser,
real sources, worker/review/publisher/SEO frontend incomplete or NOT TESTED.
See SECURITY_REVIEW.md and M2_DOCUMENT_PARSER.md.
