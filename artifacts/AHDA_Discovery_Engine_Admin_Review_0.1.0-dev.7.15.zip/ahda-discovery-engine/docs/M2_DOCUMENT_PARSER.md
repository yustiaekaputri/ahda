# Saved-document adapters — dev.7.3

This is offline extraction from an operator-supplied local document. No website
fetch, DNS, browser, external model, export file, database write or publication.
Only profile_programs/profile_curriculum/profile_hours supported; no extension of
store/publisher targets. Output structured_document uses existing M2 schema and
preview remains pending/unverified. Scope stays frozen200Tasikmalaya negeri.

## Demo commands (synthetic, read-only)

```
wp --user="admin" ade pilot parse --format=csv --demo --dry-run
wp --user="admin" ade pilot parse --format=html --demo --dry-run
```

Expected mode LOCAL_DOCUMENT_PARSE_PREVIEW,3candidate previews, fixture_only true,
network_requests0/database_writes0/publication_enabled false. Demo has fixed
example.org URL/2020time and blocks for fixture/staleness; not school facts. Demo
cannot mix with document/identity/source metadata options. HTML needs PHP DOM;
missing extension returns M2_HTML_DOM_EXTENSION_REQUIRED without partial writes.
CSV continues to work without DOM. Plugin activation/other CLI/frontend unaffected.

## Operator file, only when a lawful source is available

Example syntax (replace with actual observed source/document/permission):

```
wp --user="admin" ade pilot parse --format=csv --document-file="C:/AHDA/source.csv" --npsn=20268071 --source-url="https://sekolah.example/document" --checked-at="2026-11-10T00:00:00Z" --permission-reference=operator-log-reference --dry-run
```

This illustrative URL/reference is not a real authorized source. Use .csv for CSV,
.html/.htm for HTML. File must be local, readable and within cap. NPSN must equal
all extracted identities and belong to frozen pilot. Existing school classification
and current verified meta snapshots rechecked read-only by the native preview.
No files automatically saved; this is not a batch worker or import. Do not run
store against demo, or use CSV/HTML path as an evidence-file for store. A future
explicit export/stage workflow must preserve raw provenance and separate approval.

## CSV contract

UTF-8, optional BOM, comma separator, exact ordered header:

```
npsn,target_key,value
20268071,profile_programs,PROGRAM CONTOH UJI
```

Data above is synthetic. Max64KiB,20records,500bytes/value. Strict quoted fields
support commas, doubled double-quotes and multiline values; LF or CRLF records.
Malformed/unclosed quotes, extra columns, mixed schools, unsupported keys, missing
values, markup/control/bidi and formula-leading values (=,+,-,@ after whitespace)
are rejected. Different values for same target conflict; identical candidates
dedupe. No guessing columns, Excel formulas, separators or target mappings.
CSV adapter is for this explicit interchange contract, not arbitrary government
CSV formats. Actual catalog-specific schemas need adapters and permission review.

## HTML contract

Max256KiB UTF-8,10000elements,depth32,20tables,64rows/table,20claims. One unambiguous
non-nested two-column table must contain exactly one NPSN row with expected8digits
and recognized label/value rows. Optional thead/tbody/tfoot supported. Rowspan/
colspan other than1, multiple matched profiles and conflicting values are blocked.
Labels (case/whitespace/colon normalized): Program/Program pendidikan/Program
keahlian; Kurikulum; Jam layanan/Jam operasional. NPSN must be in same table;
matching text elsewhere is insufficient. Unmapped rows counted but not included
in source text; facilities/admissions/etc not automatically converted into facts.

DOM parsing uses LIBXML_NONET without NOENT/DTDLOAD. Only inert HTML5 doctype
allowed; DTD/ENTITY/XML/processing declarations rejected before parsing. Scripts,
styles, noscript, template, iframe/object/embed/svg/math and explicitly hidden/
aria-hidden nodes removed. Literal display:none/visibility:hidden/collapse inline
styles ignored. Assets/links are never fetched, scripts never executed. Decoded
text/whitespace normalized with block separators. Visible other named NPSN blocks
whole extraction. Quotes/values still go through original M2 literal validation.

Limitations: CSS stylesheets/classes, JS rendering and complex layouts are not
computed; inline CSS obfuscation and template-specific visibility require manual
review. DOM may repair HTML markup. This is a narrow table-text adapter, not a
universal website or official-source verifier. Pending status is mandatory even
if source URL looks official. Retain/check original document visually before
review. Missing/unsupported structure produces a blocking error, never generated
facts. No claim of automatic extraction of every school field.

## Provenance and quality

raw_document_sha256 hashes original bytes including BOM/line endings. Quotes
refer to normalized decoded CSV records or DOM table text, not literal byte slices
in raw HTML. Normalization version reported; structured source text/fingerprint
and original hash are distinct. Keep the raw saved file and parse report together.
The raw hash is currently in preview/report only, NOT persisted as a new DB field
or permission proof. No change to M2 database schema/provenance contract. Parser
output never independently verifies source origin, identity, permission or claims.

Timestamp/reference supplied by operator; presence does not establish factual
freshness or source authority. Demo labels/blocks remain. No auto approval,
profile_description generation/write, head hooks or production operations.
M3 review, raw-document archive binding, broader fields, HTML adapters per source,
resumable extraction worker and M4 publisher remain outstanding.

## Tests and rollback

Actual DOM/strict CSV offline checks + official WP-CLI dispatcher exact commands.
Native parser->pending writer replay tested on isolated MySQL under WordPress/
wpdb stubs (see latest NATIVE_MYSQL.md/qa). Not full LocalWP/WordPress PASS.
Offline runner accepts optional PHP_DOM_EXTENSION local path to load DOM with -n;
without it HTML extraction is explicitly NOT RUN while missing-extension guard is
tested. Production plugin relies on site's PHP DOM extension, not this env var.
Rollback Discovery files to7.2 without schema migration; preserve all data.
