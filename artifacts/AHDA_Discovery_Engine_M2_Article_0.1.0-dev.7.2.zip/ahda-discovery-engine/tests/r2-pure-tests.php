<?php
/** Run with PHP CLI: php tests/r2-pure-tests.php. No WordPress or DB needed. */
if ( PHP_SAPI !== 'cli' ) { exit( 2 ); }
define( 'ABSPATH', __DIR__ . '/' );
require_once dirname( __DIR__ ) . '/includes/class-ade-jobs.php';
$tests = 0;
$assert = static function ( $ok, $message ) use ( &$tests ) {
    ++$tests;
    if ( ! $ok ) { fwrite( STDERR, 'FAIL: ' . $message . "\n" ); exit( 1 ); }
};
$assert( strlen( ADE_Jobs::job_key( 'smoke-a' ) ) === 64, 'SHA-256 key length' );
$assert( ADE_Jobs::job_key( 'smoke-a' ) === ADE_Jobs::job_key( 'smoke-a' ), 'deterministic dedupe' );
$assert( ADE_Jobs::job_key( 'smoke-a' ) !== ADE_Jobs::job_key( 'smoke-b' ), 'distinct test IDs' );
foreach ( array( 'x', 'UPPER', '../abc', 'a/b', 'x y', 'ab', str_repeat('a',41), 'ééé' ) as $bad ) {
    try { ADE_Jobs::validate_test_key( $bad ); $assert( false, 'invalid test key ' . $bad ); }
    catch ( InvalidArgumentException $e ) { $assert( true, 'reject malformed key' ); }
}
foreach ( array( 1 => 15, 2 => 30, 3 => 60, 4 => 120, 5 => 240, 6 => 300, 12 => 300 ) as $attempt => $seconds ) {
    $assert( ADE_Jobs::retry_delay_seconds( $attempt ) === $seconds, 'bounded retry attempt ' . $attempt );
}
$assert( ADE_Jobs::TEST_TYPE === 'r2_smoke_test', 'test-only job type' );
echo 'PASS: ' . $tests . " pure R2 tests (no WordPress / SQL).\n";
