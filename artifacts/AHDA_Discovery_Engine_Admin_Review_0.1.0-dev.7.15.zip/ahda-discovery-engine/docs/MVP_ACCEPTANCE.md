# Status MVP dan ukuran keberhasilan

Perkiraan kepada operator 2026-11-10: **sekitar 55% fondasi kode MVP**. Angka ini
penilaian teknis kasar berdasarkan milestone, bukan persentase hasil tes atau
pengukuran otomatis. Jangan menaikkan persentase hanya karena jumlah tes bertambah.
Belum ada profil nyata dari 200 pilot yang diperkaya oleh mesin ini: **0/200**.
Preflight identitas200/200 dan demo sintetis bukan pengayaan fakta sekolah.

| Bagian | Kondisi saat ini |
| --- | --- |
| Baseline/daftar200 Tasikmalaya | Dipertahankan; preflight pengguna pernah200/200, hash source asli diuji |
| Crawler sumber diizinkan | Adapter/policy/fake transport ada; sumber nyata belum diperoleh, cloud host dibatasi |
| Ekstraksi/raw/evidence/kandidat | CSV/HTML/JSON sempit, raw terikat hash, pending writer atomik defaultOFF; hanya3field literal |
| Worker batch | Planning/resume lokal ada; durable extraction dengan lease/fencing/commitcheckpoint belum selesai |
| Review admin | Inspector/reject/defer ada defaultOFF; approval/edit positif dan verifikasi sumber/raw penuh belum selesai |
| Publisher lokal/rollback | Belum diimplementasikan; produksi dilarang |
| WordPress/keamanan/tes | Offline, nativeSQL, fixturebrowser dan sebagian actualWP terbukti; tiap hasil harus menyebut scope/stubs/versi |
| Konten/SEO/sumberAI | Draf bercitation/gap; public content update, kualitas sumber nyata, frontend/load acceptance belum terbukti |
| Pilot200 faktual | Belum berjalan pada sumber nyata; tidak ada klaim200profil lengkap |

## Pintu kelulusan

1. Baseline data lama terjaga tanpa import/rebuild/delete; selection tetap sesuai
   operator dan identitas/klasifikasi diperiksa ulang saat setiap operasi nyata.
2. Akses sumber benar-benar berizin, robots/ToS/rate/SSRF teruji, provenance dan
   izin/identitas dibedakan; tidak menganggap URL/label DB sebagai otoritas.
3. Evidence berasal dari raw yang dapat diperiksa, stale/conflict/IDOR diblokir,
   field allowlist dan nilai lama vs kandidat jelas. Tidak mengarang info untuk
   mengisi9topik yang masih belum dinilai. Perluasan field mengikuti reader lama.
4. Batch tahan partial failure, dedupe, retry, lease/fencing, checkpoint setelah
   commit; dapat dihentikan. Tidak auto-network/cron/publish saat bootstrap.
5. Approval positif hanya reviewer berwenang, nonce/capability/version/hash,
   audit append-only dan pemeriksaan raw/source lengkap; negative review terjaga.
6. Publisher defaultOFF dengan backup, preview, freshbasehash, transaksi/idempotensi
   dan undo teruji. Izin konkret1sekolah test lokal dahulu, lalu20lokal. Tidak VPS.
7. WordPress nyata dan database sesuai target lulus scope integrasi relevan;
   frontend/canonical/structured data/no duplicate meta/XSS dan resource budget
   diperiksa. Raw privacy/retention/export/encryption/quota perlu keputusan sebelum
   penyimpanan data nyata. Tidak menyebut semua aman100%.
8. Laporan200 pilot mengungkap kandidat berbukti, alasan blocked/needs_source,
   keputusan operator dan hasil publisher terpisah. Alasan needs_source sah untuk
   melaporkan kekurangan; tetap belum berarti artikel sekolah itu lengkap.

Peringkat Google dan rekomendasi platform AI tidak dapat dijanjikan sebagai hasil
pasti. Target yang dapat diuji: informasi membantu, faktual/bersumber, halaman
cepat, aksesibel, mudah dirayapi, metadata/schema sesuai isi, tanpa klaim palsu.
Semua operasi sumber/database nyata memerlukan persetujuan sesuai AGENTS.md.
