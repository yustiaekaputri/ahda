<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Bounded JSON decode plus duplicate-key scan, without large PCRE token arrays. */
final class ADE_Strict_JSON {
    private static function whitespace( string $raw, int &$i, int $length ): void {
        while ( $i < $length && false !== strpos( " \t\r\n", $raw[$i] ) ) { ++$i; }
    }
    private static function quoted( string $raw, int &$i, int $length ): string {
        $start = $i++;
        while ( $i < $length ) {
            if ( '\\' === $raw[$i] ) { $i += 2; continue; }
            if ( '"' === $raw[$i++] ) { return substr( $raw, $start, $i - $start ); }
        }
        throw new InvalidArgumentException( 'M2_JSON_TOKENS_INVALID' );
    }
    private static function scan( string $raw, int &$i, int $length, int $depth ): void {
        if ( $depth > 16 ) { throw new InvalidArgumentException( 'M2_JSON_DEPTH_INVALID' ); }
        self::whitespace( $raw, $i, $length ); $type = $raw[$i] ?? '';
        if ( '{' === $type || '[' === $type ) {
            $object = '{' === $type; $end = $object ? '}' : ']'; ++$i; $seen = array();
            self::whitespace( $raw, $i, $length );
            if ( ( $raw[$i] ?? '' ) === $end ) { ++$i; return; }
            while ( $i < $length ) {
                if ( $object ) {
                    $key = json_decode( self::quoted( $raw, $i, $length ), true, 2, JSON_THROW_ON_ERROR );
                    if ( isset( $seen[$key] ) ) { throw new InvalidArgumentException( 'M2_DUPLICATE_JSON_KEY' ); }
                    $seen[$key] = true; self::whitespace( $raw, $i, $length ); ++$i; // Validated colon.
                }
                self::scan( $raw, $i, $length, $depth + 1 ); self::whitespace( $raw, $i, $length );
                if ( ( $raw[$i] ?? '' ) === $end ) { ++$i; return; }
                ++$i; self::whitespace( $raw, $i, $length ); // Validated comma.
            }
            throw new InvalidArgumentException( 'M2_JSON_TOKENS_INVALID' );
        }
        if ( '"' === $type ) { self::quoted( $raw, $i, $length ); return; }
        while ( $i < $length && false === strpos( " \t\r\n,]}", $raw[$i] ) ) { ++$i; }
    }
    public static function decode( string $raw, int $max_bytes = 65536 ): array {
        if ( $max_bytes < 1 || $max_bytes > 4194304 || strlen( $raw ) > $max_bytes ) { throw new InvalidArgumentException( 'M2_INPUT_TOO_LARGE' ); }
        if ( substr( $raw, 0, 3 ) === "\xef\xbb\xbf" ) { $raw = substr( $raw, 3 ); }
        // Bound container allocation before json_decode: inline document strings do not
        // count as structural tokens. Prevent tiny-value arrays exhausting PHP memory.
        $length = strlen( $raw ); $tokens = 0;
        for ( $j = 0; $j < $length; ) {
            if ( '"' === $raw[$j] ) { self::quoted( $raw, $j, $length ); continue; }
            if ( false !== strpos( '{}[],:', $raw[$j] ) && ++$tokens > 50000 ) { throw new InvalidArgumentException( 'M2_JSON_TOKEN_LIMIT' ); }
            ++$j;
        }
        $data = json_decode( $raw, true, 16, JSON_THROW_ON_ERROR );
        if ( ! is_array( $data ) ) { throw new InvalidArgumentException( 'M2_OBJECT_REQUIRED' ); }
        $i = 0; $length = strlen( $raw ); self::scan( $raw, $i, $length, 0 ); self::whitespace( $raw, $i, $length );
        if ( $i !== $length ) { throw new InvalidArgumentException( 'M2_JSON_TOKENS_INVALID' ); }
        return $data;
    }
}
