<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Read-only AHDA core API contract. No calls to core writer methods or SQL. */
final class ADE_Dependencies {
    private const REQUIRED = array(
        'AHDA_Profile' => array( 'meta', 'verified_school', 'extracurriculars' ),
        'AHDA_Public'  => array( 'verified_socials' ),
    );

    public static function report(): array {
        $checks = array();
        foreach ( self::REQUIRED as $class => $methods ) {
            $exists = class_exists( $class, false );
            $checks[] = array( 'name' => $class . ' tersedia', 'passed' => $exists );
            foreach ( $methods as $method ) {
                $passed = false;
                if ( $exists && method_exists( $class, $method ) ) {
                    try {
                        $reflect = new ReflectionMethod( $class, $method );
                        $passed = $reflect->isPublic() && $reflect->isStatic();
                    } catch ( ReflectionException $e ) {
                        $passed = false;
                    }
                }
                $checks[] = array( 'name' => $class . '::' . $method . '()', 'passed' => $passed );
            }
        }
        return $checks;
    }

    public static function ready(): bool {
        foreach ( self::report() as $check ) {
            if ( ! $check['passed'] ) { return false; }
        }
        return true;
    }
}
