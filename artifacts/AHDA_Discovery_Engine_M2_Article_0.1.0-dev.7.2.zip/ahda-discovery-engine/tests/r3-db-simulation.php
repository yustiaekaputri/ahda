<?php
/** Simulation only: php tests/r3-db-simulation.php. Not real LocalWP MySQL. */
if ( PHP_SAPI !== 'cli' ) { exit( 2 ); }
define( 'ABSPATH', __DIR__ . '/' );
define( 'WP_CLI', true );
define( 'ARRAY_A', 'ARRAY_A' );
final class WP_CLI {}
final class ADE_Schema {
    public static function table_name( string $s ): string { return 'wp_ahda_discovery_' . $s; }
}
final class ADE_Jobs {
    public static function preflight(): array {
        return array( 'ready' => true, 'local' => true, 'schema' => array( 'state' => 'INSTALLED', 'existing_discovery' => array_fill( 0, 7, 't' ), 'issues' => array(), 'legacy_hash' => 'simulated' ), 'unsafe_flags' => array(), 'worker_lock' => null );
    }
}
function sanitize_text_field( $v ) { return strip_tags( $v ); }
function current_time( $kind, $utc ) { return '2026-11-09 00:00:00'; }
final class FakeDB {
    public $prefix = 'wp_';
    public $last_error = '';
    public $insert_id = 0;
    public $fail_link_insert = false;
    public $transaction_started = false;
    public $tables = array( 'sources' => array(), 'school_sources' => array() );
    private $snapshot;
    private $next = array( 'sources' => 1, 'school_sources' => 1 );
    private $schools = array(
        '12345678' => array( 'id' => 100, 'npsn' => '12345678', 'name' => 'SMA Negeri Contoh', 'school_form' => 'SMA', 'education_level' => 'SMA', 'regency_raw' => 'Bandung', 'district_raw' => 'Coblong', 'village_raw' => 'Dago', 'visibility' => 'published' ),
        '23456789' => array( 'id' => 200, 'npsn' => '23456789', 'name' => 'SMK Negeri Contoh', 'school_form' => 'SMK', 'education_level' => 'SMK', 'regency_raw' => 'Bandung', 'district_raw' => 'Coblong', 'village_raw' => 'Dago', 'visibility' => 'published' ),
    );
    public function prepare( $sql, ...$args ) {
        if ( count( $args ) === 1 && is_array( $args[0] ) ) { $args = $args[0]; }
        $i=0;
        return preg_replace_callback( '/%[ds]/', static function($m) use (&$i,$args) {
            $arg=$args[$i++]; return $m[0] === '%d' ? (string) (int) $arg : "'" . str_replace( "'", "''", (string) $arg ) . "'";
        }, $sql );
    }
    public function get_results( $sql, $type = null ) {
        if ( strpos( $sql, 'FROM wp_ahda_schools' ) !== false ) {
            preg_match( "/npsn='([0-9]+)'/", $sql, $m );
            return isset( $this->schools[ $m[1] ?? '' ] ) ? array( $this->schools[$m[1]] ) : array();
        }
        if ( strpos( $sql, 'FROM wp_ahda_discovery_school_sources l INNER JOIN' ) !== false ) {
            preg_match( '/WHERE l.school_id=(\d+)/', $sql, $m );
            $school=(int)($m[1] ?? 0);
            $out=array();
            foreach( array_reverse($this->tables['school_sources']) as $link ) {
                if ( $link['school_id'] !== $school ) { continue; }
                $source=$this->tables['sources'][$link['source_id']];
                $out[] = array( 'relation_id' => $link['id'], 'identity_status' => $link['identity_status'], 'relationship_type' => $link['relationship_type'], 'confidence_score' => $link['confidence_score'], 'source_id' => $source['id'], 'source_type' => $source['source_type'], 'platform' => $source['platform'], 'canonical_url' => $source['canonical_url'], 'access_state' => $source['access_state'] );
            }
            return $out;
        }
        throw new RuntimeException( 'Unexpected SELECT: ' . $sql );
    }
    public function get_var( $sql ) {
        if ( strpos( $sql, 'wp_ahda_discovery_sources' ) !== false ) {
            preg_match( "/canonical_key='([a-f0-9]{64})'/", $sql, $m );
            foreach( $this->tables['sources'] as $s ) { if( $s['canonical_key'] === ($m[1] ?? null) ) { return $s['id']; } }
            return null;
        }
        if ( strpos( $sql, 'wp_ahda_discovery_school_sources' ) !== false ) {
            preg_match( '/school_id=(\d+) AND source_id=(\d+)/', $sql, $m );
            foreach( $this->tables['school_sources'] as $s ) { if( $s['school_id'] === (int)($m[1]??0) && $s['source_id'] === (int)($m[2]??0) ) { return $s['id']; } }
            return null;
        }
        throw new RuntimeException( 'Unexpected get_var ' . $sql );
    }
    public function insert( $table, $fields ) {
        $suffix=substr( $table, strlen( 'wp_ahda_discovery_' ) );
        if ( ! in_array( $suffix, array( 'sources', 'school_sources' ), true ) ) { throw new RuntimeException( 'Unexpected write to non-R3 Discovery table: ' . $table ); }
        if ( 'school_sources' === $suffix && $this->fail_link_insert ) { $this->last_error='simulation failed insert'; return false; }
        foreach ( $this->tables[$suffix] as $row ) {
            $duplicate = 'sources' === $suffix ? $row['canonical_key'] === $fields['canonical_key'] : $row['school_id'] === $fields['school_id'] && $row['source_id'] === $fields['source_id'];
            if ( $duplicate ) { $this->last_error = 'duplicate'; return false; }
        }
        $id=$this->next[$suffix]++;
        $this->tables[$suffix][$id]=array_merge( array( 'id' => $id ), $fields );
        $this->insert_id=$id;
        $this->last_error='';
        return 1;
    }
    public function query( $sql ) {
        if ( $sql === 'START TRANSACTION' ) {
            if ( $this->transaction_started ) { throw new RuntimeException( 'Nested transaction.' ); }
            $this->snapshot = array( $this->tables, $this->next );
            $this->transaction_started = true; return 0;
        }
        if ( $sql === 'COMMIT' ) { $this->transaction_started=false; $this->snapshot=null; return 0; }
        if ( $sql === 'ROLLBACK' ) { if ( $this->transaction_started ) { list($this->tables,$this->next)=$this->snapshot; } $this->transaction_started=false; return 0; }
        throw new RuntimeException( 'Unexpected SQL write: ' . $sql );
    }
}
$wpdb = new FakeDB();
require_once dirname(__DIR__) . '/includes/class-ade-source-urls.php';
require_once dirname(__DIR__) . '/includes/class-ade-identity.php';
require_once dirname(__DIR__) . '/includes/class-ade-sources.php';
$n=0;
$ok=static function( $condition, $label ) use ( &$n ) { ++$n; if ( !$condition ) { fwrite(STDERR, 'FAIL: ' . $label . "\n" ); exit(1); } };
$p=ADE_Sources::preview( '12345678', 'https://www.instagram.com/osis_contoh?utm_source=abc', 'SMA NEGERI CONTOH' );
$ok( $p['identity_status'] === 'pending' && $p['claimed_name_comparison'] === 'exact_normalized', 'preview pending' );
$ok( count($wpdb->tables['sources']) === 0, 'preview no writes' );
$a=ADE_Sources::observe( '12345678', 'https://www.instagram.com/osis_contoh?utm_source=abc', 'OSIS', 'SMA NEGERI CONTOH' );
$ok( $a['source_created'] && $a['relation_created'], 'new source+link' );
$ok( $wpdb->tables['sources'][$a['source_id']]['access_state'] === 'manual_only', 'manual_only access' );
$ok( $wpdb->tables['school_sources'][$a['school_source_id']]['identity_status'] === 'pending', 'pending identity' );
$ok( $wpdb->tables['school_sources'][$a['school_source_id']]['relationship_type'] === 'pending', 'pending relationship' );
$ok( $wpdb->tables['school_sources'][$a['school_source_id']]['confidence_score'] === 0, 'no invented confidence' );
$b=ADE_Sources::observe( '12345678', 'https://www.instagram.com/osis_contoh', 'OSIS', 'SMA NEGERI CONTOH' );
$ok( !$b['source_created'] && !$b['relation_created'], 'idempotent duplicate source+link' );
$ok( $a['source_id'] === $b['source_id'] && $a['school_source_id'] === $b['school_source_id'], 'same IDs after repeat' );
$c=ADE_Sources::observe( '23456789', 'https://www.instagram.com/osis_contoh' );
$ok( !$c['source_created'] && $c['relation_created'], 'source one, school association many' );
$ok( count($wpdb->tables['sources']) === 1 && count($wpdb->tables['school_sources']) === 2, 'one canonical source, two pending links' );
$rows=ADE_Sources::list_for_school( '12345678' );
$ok( count($rows['rows']) === 1 && $rows['rows'][0]['identity_status'] === 'pending', 'read-only listing' );
$rejected=false;
try { ADE_Sources::observe( '12345678', 'http://127.0.0.1/private' ); } catch( InvalidArgumentException $e ) { $rejected=true; }
$ok( $rejected, 'IP denied before write' );
$rejected=false;
try { ADE_Sources::observe( '12345678', 'https://school.sch.id/', '', 'Sekolah Salah' ); } catch( RuntimeException $e ) { $rejected=true; }
$ok( $rejected, 'mismatched claim denied' );
$rejected=false;
try { ADE_Sources::observe( '87654321', 'https://school.sch.id/' ); } catch( RuntimeException $e ) { $rejected=true; }
$ok( $rejected, 'unknown NPSN denied' );
$ok( count($wpdb->tables['sources']) === 1 && count($wpdb->tables['school_sources']) === 2, 'rejected observations did not write' );
$wpdb->fail_link_insert=true;
$rejected=false;
try { ADE_Sources::observe( '12345678', 'https://new.school.sch.id/' ); } catch( RuntimeException $e ) { $rejected=true; }
$ok( $rejected, 'forced insert failure detected' );
$ok( !$wpdb->transaction_started && count($wpdb->tables['sources']) === 1 && count($wpdb->tables['school_sources']) === 2, 'rollback removes partial source insert' );
echo 'PASS: ' . $n . " R3 database simulations (fake DB; NO LocalWP/MySQL writes).\n";
