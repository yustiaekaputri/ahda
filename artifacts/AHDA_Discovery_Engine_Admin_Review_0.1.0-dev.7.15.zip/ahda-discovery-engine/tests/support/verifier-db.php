<?php
if(PHP_SAPI!=='cli'){exit(2);}
final class VerifyDB {
 public $prefix='custom_',$last_error='',$insert_id=0,$backend,$pair_reads=0,$race=false,$fail=false;
 public function __construct(){$this->backend=new ArchiveDB;}
 public function prepare($sql,...$args){return $this->backend->prepare($sql,...$args);}
 public function get_results($key,$kind){[$sql,$args]=$this->backend->db->inner->prepared[$key]??[$key,[]];if($this->fail){$this->last_error='Synthetic DB read failure';return null;}
  if(strpos($sql,'FROM custom_ahda_discovery_candidates c INNER JOIN')!==false){$this->pair_reads++;[$cid,$school,$eid,$es]=$args;$c=$this->backend->db->tables['candidates'][$cid]??null;$e=$this->backend->db->tables['evidence'][$eid]??null;if(!$c||!$e||$c['school_id']!==$school||$e['school_id']!==$es){return [];}$link=null;foreach($this->backend->db->tables['candidate_evidence'] as $l){if($l['candidate_id']===$cid&&$l['evidence_id']===$eid){$link=$l;break;}}if(!$link){return [];}
   $r=$c;$r['candidate_id']=$cid;$r['evidence_id']=$eid;$r['link_id']=$link['id'];$r['relation_type']=$link['relation_type'];$r['proposed_bytes']=strlen($c['proposed_value']);foreach(['source_id','evidence_type','attribute_hint','evidence_url','evidence_key','content_fingerprint','snippet_text','observed_value','parse_status','checked_at'] as $k){$r[$k]=$e[$k];}$r['snippet_bytes']=strlen($e['snippet_text']);$r['observed_bytes']=is_string($e['observed_value'])?strlen($e['observed_value']):null;if($this->race&&$this->pair_reads===2){$r['row_version']++;}return [$r];}
  if(strpos($sql,'s.canonical_url,s.normalized_host')!==false){foreach(['https://example.org/','https://example.net/'] as $url){$k=ADE_Source_URLs::canonicalize($url)['canonical_key'];$row=$this->backend->relations[$k]??null;if($row&&$row['source_id']===$args[0]){return [array_merge($row,['canonical_url'=>$url,'normalized_host'=>parse_url($url,PHP_URL_HOST)])];}}return [];}
  $r=$this->backend->get_results($key,$kind);$this->last_error=$this->backend->last_error;return $r;
 }
 public function insert($t,$v){$r=$this->backend->insert($t,$v);$this->last_error=$this->backend->last_error;$this->insert_id=$this->backend->insert_id;return $r;}
 public function query($sql){$r=$this->backend->query($sql);$this->last_error=$this->backend->last_error;return $r;}
}
