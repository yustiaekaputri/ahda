<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Evidence-linked editorial draft. No model, fetch, DB mutation or frontend hook. */
final class ADE_Article_Preview {
    private const TOPICS = array(
        'programs' => array( 'Program pendidikan', 'profile_programs', 'Dokumen program atau pilihan pembelajaran sekolah.' ),
        'curriculum' => array( 'Kurikulum', 'profile_curriculum', 'Kurikulum yang berlaku beserta periode berlakunya.' ),
        'hours' => array( 'Jam layanan', 'profile_hours', 'Hari dan jam layanan serta pengecualian bila tersedia.' ),
        'admissions' => array( 'Penerimaan siswa', null, 'Kanal resmi, tahun ajaran, jadwal, syarat dan prosedur pendaftaran.' ),
        'fees' => array( 'Biaya dan bantuan pendidikan', null, 'Rincian biaya, periode berlaku dan bantuan dari sumber resmi; jangan menganggap sekolah negeri selalu gratis.' ),
        'facilities' => array( 'Fasilitas', null, 'Fasilitas yang benar-benar tersedia dan tanggal pemeriksaannya.' ),
        'extracurriculars' => array( 'Ekstrakurikuler', null, 'Kegiatan yang masih aktif; bedakan dari program akademik.' ),
        'accreditation' => array( 'Akreditasi', null, 'Lembaga pemberi, hasil, tahun dan masa berlaku dari sumber otoritatif.' ),
        'history' => array( 'Sejarah sekolah', null, 'Tahun berdiri dan riwayat yang didukung dokumen.' ),
        'contact' => array( 'Alamat dan kontak resmi', null, 'Alamat lengkap, petunjuk akses, website serta kontak institusi; hindari nomor pribadi.' ),
        'accessibility' => array( 'Aksesibilitas', null, 'Layanan dan akses fisik yang sudah dikonfirmasi, bukan diasumsikan.' ),
        'achievements' => array( 'Prestasi', null, 'Nama kegiatan, hasil, tingkat dan tanggal; hindari data pribadi siswa.' ),
    );

    private static function text( $value, int $max ): string {
        if ( ! is_string( $value ) || strlen( $value ) > $max || ! preg_match( '//u', $value ) ||
            preg_match( '/[<>\x00-\x08\x0b\x0c\x0e-\x1f\x7f\x{200B}-\x{200F}\x{202A}-\x{202E}\x{2060}-\x{206F}\x{FEFF}]/u', $value ) ) {
            throw new InvalidArgumentException( 'M2_ARTICLE_PLAIN_TEXT_REQUIRED' );
        }
        $value = trim( $value );
        if ( '' === $value ) { throw new InvalidArgumentException( 'M2_ARTICLE_PLAIN_TEXT_REQUIRED' ); }
        return $value;
    }

    private static function short( string $value, int $max ): string {
        preg_match_all( '/./us', $value, $chars );
        if ( count( $chars[0] ) <= $max ) { return $value; }
        return rtrim( implode( '', array_slice( $chars[0], 0, $max - 1 ) ) ) . '…';
    }

    private static function escape( string $text ): string {
        return htmlspecialchars( $text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' );
    }

    /** Raw documents are always validated here; never accept caller-certified facts. */
    public static function build( string $raw, array $school, int $now ): array {
        $preview = ADE_Enrichment_Preview::normalize( $raw, $now );
        ADE_Pilot_Scope::assert_school( $school );
        if ( (string) ( $school['npsn'] ?? '' ) !== $preview['npsn'] ||
            ! is_int( $school['id'] ?? null ) || $school['id'] < 1 ) { throw new RuntimeException( 'M2_ARTICLE_IDENTITY_CONFLICT' ); }
        $name = self::text( $school['name'] ?? null, 400 );
        $region = self::text( $school['regency_raw'], 100 );
        $label = $preview['fixture_only'] ? 'CONTOH SINTETIS — BUKAN FAKTA SEKOLAH' : 'DRAF BELUM DIVERIFIKASI — PERLU REVIEW ADMIN';
        $intro = sprintf( '%s tercatat pada indeks AHDA dengan NPSN %s di %s.', $name, $preview['npsn'], $region );
        $sections = array(); $gaps = array(); $sources = array(); $evidence = array();
        foreach ( $preview['evidence'] as $entry ) { $evidence[$entry['preview_key']] = $entry; }
        $candidates = array();
        foreach ( $preview['candidates'] as $candidate ) { $candidates[$candidate['target_key']] = $candidate; }
        foreach ( self::TOPICS as $topic => $spec ) {
            list( $heading, $target, $requirement ) = $spec;
            if ( null === $target || ! isset( $candidates[$target] ) ) {
                $gaps[] = array( 'topic' => $topic, 'heading' => $heading,
                    'status' => null === $target ? 'not_assessed_by_this_adapter' : 'no_claim_in_document',
                    'source_needed' => $requirement );
                continue;
            }
            $candidate = $candidates[$target];
            $value = self::text( $candidate['proposed_value'], 500 );
            $citations = array();
            foreach ( $candidate['evidence_preview_keys'] as $key ) {
                $entry = $evidence[$key];
                $quote = self::text( $entry['supporting_quote'], 2000 );
                if ( ! isset( $sources[$key] ) ) {
                    $sources[$key] = array( 'id' => 'ade-source-' . substr( $key, 0, 16 ), 'evidence_preview_key' => $key,
                        'url' => $entry['source_url'], 'checked_at' => $entry['checked_at'],
                        'supporting_quote' => $quote, 'content_fingerprint' => $entry['content_fingerprint'],
                        'identity_status' => 'pending', 'permission_state' => 'NOT_INDEPENDENTLY_VERIFIED' );
                }
                $citations[] = $sources[$key]['id'];
            }
            $sections[] = array( 'topic' => $topic, 'heading' => $heading, 'target_key' => $target,
                'text' => 'Menurut dokumen sumber, ' . strtolower( $heading ) . ' yang dicantumkan: ' . $value,
                'candidate_preview_key' => $candidate['preview_key'], 'source_ids' => $citations,
                'status' => 'unverified_document_claim', 'approved' => false );
        }
        $title = 'Profil ' . self::short( $name, 110 ) . ' | NPSN ' . $preview['npsn'];
        $description = self::short( 'Profil ' . $name . ' di ' . $region . '. NPSN ' . $preview['npsn'] . '. Informasi sekolah beserta sumber dan status pemeriksaannya.', 160 );
        $html = '<article lang="id"><p><strong>' . self::escape( $label ) . '</strong></p><h1>' . self::escape( 'Profil ' . $name ) . '</h1><p>' . self::escape( $intro ) . '</p>';
        $html .= '<p>Identitas berasal dari indeks AHDA. Klaim berikut berasal dari dokumen operator dan belum diverifikasi atau disetujui. Waktu pemeriksaan dokumen bukan tanggal pembaruan profil.</p>';
        foreach ( $sections as $section ) {
            $html .= '<section><h2>' . self::escape( $section['heading'] ) . '</h2><p>' . self::escape( $section['text'] ) . '</p><p>Sumber: ';
            foreach ( $section['source_ids'] as $id ) { $html .= '<a href="#' . self::escape( $id ) . '">lihat kutipan</a> '; }
            $html .= '</p></section>';
        }
        $html .= '<section><h2>Dokumen sumber untuk review</h2><ol>';
        foreach ( $sources as $entry ) {
            $html .= '<li id="' . self::escape( $entry['id'] ) . '"><a rel="nofollow noopener noreferrer" href="' . self::escape( $entry['url'] ) . '">' . self::escape( $entry['url'] ) . '</a>';
            $html .= '<p>Waktu pemeriksaan dokumen: ' . self::escape( $entry['checked_at'] ) . ' (belum diverifikasi)</p><blockquote>' . self::escape( $entry['supporting_quote'] ) . '</blockquote></li>';
        }
        $html .= '</ol></section></article>';
        return array( 'mode' => 'EDITORIAL_DRAFT_READ_ONLY', 'fixture_only' => $preview['fixture_only'], 'label' => $label,
            'scope' => $preview['scope'], 'npsn' => $preview['npsn'], 'school_id' => $school['id'],
            'input_sha256' => $preview['input_sha256'], 'identity_provenance' => 'existing_ahda_index_not_independent_verification',
            'draft_title' => $title, 'draft_introduction' => $intro, 'sections' => $sections, 'sources' => array_values( $sources ),
            'article_html' => $html, 'information_gaps' => $gaps,
            'coverage' => array( 'topics_in_editorial_checklist' => count( self::TOPICS ), 'topics_with_document_claims' => count( $sections ),
                'topics_approved' => 0, 'meaning' => 'Document coverage only; not completeness of legacy profile, factual verification, SEO score or ranking.' ),
            'search_metadata_draft' => array( 'title' => $title, 'description' => $description, 'apply_enabled' => false,
                'structured_data_emitted' => false, 'canonical_emitted' => false ),
            'quality_status' => 'not_ready_for_publication',
            'blocking_reasons' => array_values( array_unique( array_merge( $preview['blocking_reasons'], array( 'EDITORIAL_REVIEW_REQUIRED', 'FULL_PROFILE_NOT_ASSESSED' ) ) ) ),
            'persisted' => false, 'network_requests' => 0, 'database_writes' => 0, 'publication_enabled' => false );
    }

    /** One indexed identity SELECT. Existing profile content is neither read nor replaced. */
    public static function preview( string $raw ): array {
        ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
        $normalized = ADE_Enrichment_Preview::normalize( $raw, time() );
        $school = ADE_Identity::lookup_pilot( $normalized['npsn'] );
        $school['id'] = (int) $school['id'];
        return self::build( $raw, $school, time() );
    }
}
