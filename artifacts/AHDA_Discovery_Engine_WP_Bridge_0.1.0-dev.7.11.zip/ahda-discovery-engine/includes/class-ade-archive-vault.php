<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Explicit local raw-pending archive only; no evidence/candidate/profile writer. */
final class ADE_Archive_Vault {
    public const TYPE = 'm2_raw_archive_pending';
    public const MAX_BYTES = 1048576;
    public static function enabled(): bool { return defined( 'ADE_LOCAL_ARCHIVE_STORAGE_ENABLED' ) && ADE_LOCAL_ARCHIVE_STORAGE_ENABLED === true; }
    private static function guard(): int {
        ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
        if ( ! current_user_can( 'ade_review_candidates' ) || (int) get_current_user_id() < 1 ) { throw new RuntimeException( 'VAULT_OPERATOR_REQUIRED' ); }
        return (int) get_current_user_id();
    }
    private static function rows( string $sql, array $args ): array {
        global $wpdb; $wpdb->last_error = '';
        $rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
        if ( ! is_array( $rows ) || $wpdb->last_error ) { throw new RuntimeException( 'VAULT_READ_FAILED' ); }
        return $rows;
    }
    private static function query( string $sql ): void {
        global $wpdb; $wpdb->last_error = '';
        if ( ! in_array( $sql, array( 'START TRANSACTION', 'COMMIT', 'ROLLBACK' ), true ) || false === $wpdb->query( $sql ) || $wpdb->last_error ) { throw new RuntimeException( 'VAULT_TRANSACTION_FAILED' ); }
    }
    private static function one( string $sql, array $args ): ?array {
        $rows = self::rows( $sql, $args ); if ( count( $rows ) > 1 ) { throw new RuntimeException( 'VAULT_ROW_NOT_UNIQUE' ); } return $rows[0] ?? null;
    }
    private static function summary( array $payload, string $raw ): array {
        $documents = array();
        foreach ( $payload['selected_bundle']['documents'] as $key => $doc ) { $documents[] = array( 'document_key' => $key, 'raw_sha256' => $doc['raw_sha256'], 'format' => $doc['format'], 'bytes' => strlen( $doc['content'] ) ); }
        return array( 'schema_version' => 1, 'operation_key' => $payload['operation_key'], 'school_id' => $payload['school_id'], 'npsn' => $payload['npsn'],
            'actor_user_id' => $payload['actor_user_id'], 'captured_at' => $payload['captured_at'], 'source_manifest_sha256' => $payload['source_manifest_sha256'],
            'source_input_sha256' => $payload['source_input_sha256'], 'raw_payload_sha256' => hash( 'sha256', $raw ), 'payload_bytes' => strlen( $raw ),
            'documents' => $documents, 'status' => 'raw_pending_unverified', 'evidence_rows_created' => 0, 'candidate_rows_created' => 0,
            'permission_attested' => false, 'identity_attested' => false, 'approval_enabled' => false, 'publication_enabled' => false );
    }
    /** Check stored bytes without HTML rendering or current-time factual certification. */
    private static function decode( array $row ): array {
        if ( ( $row['status'] ?? null ) !== 'completed' || (int) ( $row['scope_bytes'] ?? PHP_INT_MAX ) > self::MAX_BYTES || (int) ( $row['stats_bytes'] ?? PHP_INT_MAX ) > 16384 || ! is_string( $row['scope_filter'] ?? null ) || ! is_string( $row['stats_payload'] ?? null ) ) { throw new RuntimeException( 'VAULT_RECEIPT_INVALID' ); }
        $p = ADE_Strict_JSON::decode( $row['scope_filter'], self::MAX_BYTES ); $stats = ADE_Strict_JSON::decode( $row['stats_payload'], 16384 );
        ADE_Local_Archive::keys( $p, array( 'schema_version', 'operation_key', 'scope_hash', 'source_manifest_sha256', 'source_input_sha256', 'school_id', 'npsn', 'actor_user_id', 'selected_bundle', 'bindings', 'extraction', 'review_plan_sha256', 'privacy_reviewed', 'permission_attested', 'identity_attested', 'approval_enabled', 'publication_enabled', 'captured_at', 'preview_token' ) );
        if ( $p['schema_version'] !== 1 || $p['scope_hash'] !== ADE_Pilot_Scope::SHA256 || ! is_int( $p['school_id'] ) || $p['school_id'] < 1 || ! is_int( $p['actor_user_id'] ) || $p['actor_user_id'] < 1 || ! is_string( $p['npsn'] ) || ! ADE_Pilot_Scope::contains( $p['npsn'] ) || $p['privacy_reviewed'] !== true || $p['permission_attested'] !== false || $p['identity_attested'] !== false || $p['approval_enabled'] !== false || $p['publication_enabled'] !== false || ! is_array( $p['selected_bundle'] ) || ! is_array( $p['bindings'] ) || ! is_array( $p['extraction'] ) || ! is_string( $p['captured_at'] ) ) { throw new RuntimeException( 'VAULT_RECEIPT_INVALID' ); }
        foreach ( array( 'operation_key', 'source_manifest_sha256', 'source_input_sha256', 'review_plan_sha256', 'preview_token' ) as $key ) { if ( ! is_string( $p[$key] ) || ! preg_match( '/^[a-f0-9]{64}$/D', $p[$key] ) ) { throw new RuntimeException( 'VAULT_RECEIPT_INVALID' ); } }
        $bundle = ADE_Local_Archive::freeze( json_encode( $p['selected_bundle'], JSON_THROW_ON_ERROR ) )['bundle'];
        if ( $bundle['fixture_only'] !== false || count( $bundle['documents'] ) < 1 || count( $bundle['documents'] ) > 3 || $p['selected_bundle'] !== $bundle ) { throw new RuntimeException( 'VAULT_RECEIPT_INVALID' ); }
        foreach ( $bundle['schools'] as $school ) { if ( $school['npsn'] !== $p['npsn'] && $school['document_keys'] ) { throw new RuntimeException( 'VAULT_RECEIPT_INVALID' ); } }
        $operation = ADE_Local_Archive::digest( array( 'ade-raw-vault-v1', ADE_Pilot_Scope::SHA256, $p['source_manifest_sha256'], $p['school_id'], $p['npsn'], ADE_Local_Archive::digest( $bundle ) ) );
        if ( ! hash_equals( $operation, $p['operation_key'] ) || ( $row['job_key'] ?? null ) !== $operation || $stats !== self::summary( $p, $row['scope_filter'] ) ) { throw new RuntimeException( 'VAULT_RECEIPT_INVALID' ); }
        return array( 'payload' => $p, 'summary' => $stats );
    }
    private static function select_row( string $where, array $args, bool $lock = false ): ?array {
        $table = ADE_Schema::table_name( 'jobs' ); $limit = self::MAX_BYTES + 1; $suffix = $lock ? ' FOR UPDATE NOWAIT' : '';
        if ( ! in_array( $where, array( 'job_key=%s', 'id=%d' ), true ) ) { throw new RuntimeException( 'VAULT_QUERY_INVALID' ); }
        $args[] = self::TYPE;
        return self::one( "SELECT id,job_key,status,LEFT(scope_filter,{$limit}) AS scope_filter,OCTET_LENGTH(scope_filter) AS scope_bytes,LEFT(stats_payload,16385) AS stats_payload,OCTET_LENGTH(stats_payload) AS stats_bytes FROM {$table} WHERE {$where} AND job_type=%s LIMIT 1{$suffix}", $args );
    }
    private static function lock_sources( array $plan ): void {
            $sources = ADE_Schema::table_name( 'sources' ); $relations = ADE_Schema::table_name( 'school_sources' );
            foreach ( $plan['documents'] as $doc ) {
                $locked = self::one( "SELECT s.id AS source_id,l.id AS relation_id,s.source_type,s.access_state,s.source_status,l.identity_status,l.relationship_type FROM {$sources} s INNER JOIN {$relations} l ON l.source_id=s.id WHERE l.school_id=%d AND s.id=%d AND l.id=%d AND s.canonical_key=%s AND s.canonical_url=%s AND s.normalized_host=%s LIMIT 2 FOR UPDATE NOWAIT", array( $plan['school_id'], $doc['source_id'], $doc['relation_id'], ADE_Source_URLs::canonicalize( $doc['registered_url'] )['canonical_key'], $doc['registered_url'], parse_url( $doc['registered_url'], PHP_URL_HOST ) ) );
                if ( ! $locked ) { throw new RuntimeException( 'VAULT_SOURCE_CHANGED' ); }
                foreach ( array( 'source_type', 'access_state', 'source_status', 'identity_status', 'relationship_type' ) as $field ) { if ( ! is_string( $locked[$field] ?? null ) || strtolower( trim( $locked[$field] ) ) !== $doc[$field] ) { throw new RuntimeException( 'VAULT_SOURCE_CHANGED' ); } }
            }
    }
    /** Internal guarded service API; never echoes raw bodies or exposes a web endpoint. */
    public static function for_candidates( int $id, string $npsn, bool $lock = false ): array {
        self::guard(); if ( $id < 1 ) { throw new InvalidArgumentException( 'VAULT_RECEIPT_ID_INVALID' ); }
        $row = self::select_row( 'id=%d', array( $id ), $lock ); if ( ! $row ) { throw new RuntimeException( 'VAULT_RECEIPT_NOT_FOUND' ); }
        $decoded = self::decode( $row ); $payload = $decoded['payload'];
        if ( $payload['npsn'] !== $npsn ) { throw new RuntimeException( 'VAULT_SCHOOL_BINDING_CONFLICT' ); }
        $raw = json_encode( $payload['selected_bundle'], JSON_THROW_ON_ERROR );
        $plan = ADE_Archive_Review::plan( $raw, $npsn, $payload['bindings'] );
        if ( $plan['school_id'] !== $payload['school_id'] || $plan['fixture_only'] || $plan['outcome'] !== 'preview_needs_review' || in_array( 'STALE_EVIDENCE', $plan['blocking_reasons'], true ) ) { throw new RuntimeException( 'VAULT_DOCUMENTS_NOT_READY' ); }
        foreach ( $plan['documents'] as $doc ) { if ( ! $doc['pending_source_policy_passed'] ) { throw new RuntimeException( 'VAULT_BOUND_SOURCES_REQUIRED' ); } }
        if ( $lock ) { self::lock_sources( $plan ); }
        // Captured extraction is historical only: callers receive a fresh raw parse.
        return array( 'preview' => $plan, 'raw_receipt_id' => $id, 'raw_payload_sha256' => $decoded['summary']['raw_payload_sha256'], 'vault_operation_key' => $decoded['summary']['operation_key'] );
    }
    private static function context( string $raw, string $npsn, array $bindings, int $actor, bool $lock ): array {
        $plan = ADE_Archive_Review::plan( $raw, $npsn, $bindings );
        if ( $plan['fixture_only'] ) { throw new RuntimeException( 'VAULT_FIXTURE_BLOCKED' ); }
        if ( $plan['outcome'] !== 'preview_needs_review' || in_array( 'STALE_EVIDENCE', $plan['blocking_reasons'], true ) || ! $plan['documents'] ) { throw new RuntimeException( 'VAULT_DOCUMENTS_NOT_READY' ); }
        foreach ( $plan['documents'] as $doc ) { if ( ! $doc['pending_source_policy_passed'] ) { throw new RuntimeException( 'VAULT_BOUND_SOURCES_REQUIRED' ); } }
        if ( $lock ) { self::lock_sources( $plan ); }
        $bundle = ADE_Local_Archive::freeze( $raw )['bundle']; $keys = array_column( $plan['documents'], 'document_key' );
        $bundle['documents'] = array_intersect_key( $bundle['documents'], array_fill_keys( $keys, true ) );
        foreach ( $bundle['schools'] as &$school ) { if ( $school['npsn'] !== $npsn ) { $school['document_keys'] = array(); } } unset( $school );
        $bundle = ADE_Local_Archive::freeze( json_encode( $bundle, JSON_THROW_ON_ERROR ) )['bundle'];
        $operation = ADE_Local_Archive::digest( array( 'ade-raw-vault-v1', ADE_Pilot_Scope::SHA256, $plan['manifest_sha256'], $plan['school_id'], $npsn, ADE_Local_Archive::digest( $bundle ) ) );
        ksort( $bindings, SORT_STRING );
        $base = array( 'schema_version' => 1, 'operation_key' => $operation, 'scope_hash' => ADE_Pilot_Scope::SHA256, 'source_manifest_sha256' => $plan['manifest_sha256'], 'source_input_sha256' => $plan['archive_input_sha256'],
            'school_id' => $plan['school_id'], 'npsn' => $npsn, 'actor_user_id' => $actor, 'selected_bundle' => $bundle, 'bindings' => $bindings,
            'extraction' => array( 'pipeline' => ADE_Local_Worker::PIPELINE, 'candidates' => $plan['candidates'], 'evidence' => $plan['evidence'] ), 'review_plan_sha256' => $plan['plan_sha256'],
            'privacy_reviewed' => true, 'permission_attested' => false, 'identity_attested' => false, 'approval_enabled' => false, 'publication_enabled' => false );
        $dummy = array_merge( $base, array( 'captured_at' => gmdate( 'Y-m-d\TH:i:s\Z' ), 'preview_token' => str_repeat( '0', 64 ) ) );
        $bytes = strlen( json_encode( $dummy, JSON_THROW_ON_ERROR ) ); if ( $bytes > self::MAX_BYTES ) { throw new RuntimeException( 'VAULT_PAYLOAD_TOO_LARGE' ); }
        $receipt = self::select_row( 'job_key=%s', array( $operation ), $lock ); $decoded = $receipt ? self::decode( $receipt ) : null;
        if ( $decoded && $decoded['payload']['actor_user_id'] !== $actor ) { throw new RuntimeException( 'VAULT_RECEIPT_OTHER_ACTOR' ); }
        $token = $decoded ? $decoded['payload']['preview_token'] : ADE_Local_Archive::digest( array( 'ade-vault-plan-v1', $actor, $operation, ADE_Local_Archive::digest( $base ) ) );
        return array( 'plan' => $plan, 'base' => $base, 'bytes' => $bytes, 'operation' => $operation, 'token' => $token, 'receipt' => $receipt, 'decoded' => $decoded );
    }
    public static function stage( string $raw, string $npsn, array $bindings ): array {
        $actor = self::guard(); $c = self::context( $raw, $npsn, $bindings, $actor, false );
        return array( 'mode' => 'READ_ONLY_RAW_ARCHIVE_STAGE', 'npsn' => $npsn, 'school_id' => $c['plan']['school_id'], 'operation_key' => $c['operation'], 'preview_token' => $c['token'],
            'storage_module_enabled' => self::enabled(), 'already_recorded' => null !== $c['receipt'], 'receipt_id' => $c['receipt']['id'] ?? null,
            'estimated_jobs_rows_created' => $c['receipt'] ? 0 : 1, 'estimated_payload_bytes' => $c['bytes'], 'document_count' => count( $c['plan']['documents'] ),
            'write_scope' => array( 'Discovery jobs: one raw_pending_unverified archive row' ), 'evidence_rows_created' => 0, 'candidate_rows_created' => 0,
            'database_writes' => 0, 'network_requests' => 0, 'publication_enabled' => false );
    }
    public static function receipt( int $id ): array {
        self::guard(); if ( $id < 1 ) { throw new InvalidArgumentException( 'VAULT_RECEIPT_ID_INVALID' ); }
        $row = self::select_row( 'id=%d', array( $id ) ); if ( ! $row ) { throw new RuntimeException( 'VAULT_RECEIPT_NOT_FOUND' ); }
        $decoded = self::decode( $row );
        return array( 'receipt_id' => (int) $row['id'], 'historical' => true, 'summary' => $decoded['summary'], 'raw_content_returned' => false, 'database_writes' => 0, 'network_requests' => 0, 'publication_enabled' => false );
    }
    public static function record( string $raw, string $npsn, array $bindings, string $token, string $confirm, string $backup, string $privacy ): array {
        if ( ! self::enabled() ) { throw new RuntimeException( 'VAULT_STORAGE_DISABLED' ); }
        if ( $confirm !== 'STORE_RAW_PENDING' || $backup !== 'YES' || $privacy !== 'YES' || ! preg_match( '/^[a-f0-9]{64}$/D', $token ) ) { throw new RuntimeException( 'VAULT_EXPLICIT_APPROVAL_REQUIRED' ); }
        $actor = self::guard(); $c = self::context( $raw, $npsn, $bindings, $actor, false );
        $name = 'ade_m2_' . substr( ADE_Local_Archive::digest( array( ADE_Schema::table_name( 'candidates' ), $c['plan']['school_id'] ) ), 0, 48 );
        $lock = self::one( 'SELECT GET_LOCK(%s,0) AS acquired', array( $name ) ); if ( (int) ( $lock['acquired'] ?? 0 ) !== 1 ) { throw new RuntimeException( 'VAULT_WRITER_BUSY' ); }
        $transaction = false;
        try {
            self::query( 'START TRANSACTION' ); $transaction = true;
            $c = self::context( $raw, $npsn, $bindings, $actor, true );
            if ( ! hash_equals( $c['token'], $token ) ) { throw new RuntimeException( 'VAULT_PREVIEW_STALE' ); }
            if ( $c['receipt'] ) { self::query( 'COMMIT' ); $transaction = false; return array( 'receipt_id' => (int) $c['receipt']['id'], 'replayed' => true, 'rows_created' => 0, 'summary' => $c['decoded']['summary'], 'publication_enabled' => false ); }
            $payload = array_merge( $c['base'], array( 'captured_at' => gmdate( 'Y-m-d\TH:i:s\Z' ), 'preview_token' => $token ) );
            $payload_raw = json_encode( $payload, JSON_THROW_ON_ERROR ); if ( strlen( $payload_raw ) > self::MAX_BYTES ) { throw new RuntimeException( 'VAULT_PAYLOAD_TOO_LARGE' ); }
            $summary = self::summary( $payload, $payload_raw ); $now = current_time( 'mysql', true );
            global $wpdb; $wpdb->last_error = '';
            $ok = $wpdb->insert( ADE_Schema::table_name( 'jobs' ), array( 'job_key' => $c['operation'], 'job_type' => self::TYPE, 'scope_level' => 'TASIK_NEGERI_200', 'scope_filter' => $payload_raw,
                'status' => 'completed', 'attempt_count' => 1, 'max_attempts' => 1, 'cursor_school_id' => $c['plan']['school_id'], 'batch_size' => 1, 'stats_payload' => json_encode( $summary, JSON_THROW_ON_ERROR ),
                'created_at' => $now, 'updated_at' => $now, 'started_at' => $now, 'finished_at' => $now ) );
            if ( false === $ok || $wpdb->last_error || (int) $wpdb->insert_id < 1 ) { throw new RuntimeException( 'VAULT_INSERT_FAILED' ); }
            $id = (int) $wpdb->insert_id; self::query( 'COMMIT' ); $transaction = false;
            return array( 'receipt_id' => $id, 'replayed' => false, 'rows_created' => 1, 'summary' => $summary, 'publication_enabled' => false );
        } catch ( Throwable $e ) { if ( $transaction ) { self::query( 'ROLLBACK' ); } throw $e; }
        finally { self::one( 'SELECT RELEASE_LOCK(%s) AS released', array( $name ) ); }
    }
}
