<?php
/** CLI handlers under stubs; no WordPress/MySQL/network. */
require_once __DIR__.'/support/m1-fake-db.php';
foreach(['identity','source-urls','sources','pilot-scope','pilot','pilot-jobs','pilot-cli'] as $name){require_once dirname(__DIR__).'/includes/class-ade-'.$name.'.php';}
$wpdb=new FakeDB;$n=0;
function ck($ok,$label){global $n;++$n;if(!$ok){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$label){$caught=false;try{$fn();}catch(RuntimeException|InvalidArgumentException $e){$caught=true;}ck($caught,$label);}
$id=0;foreach(ADE_Pilot_Scope::reference() as $code=>$row){$wpdb->schools[(string)$code]=array_merge($row,['id'=>++$id,'name'=>'Fixture','visibility'=>'publish','education_level'=>'fixture','district_raw'=>'fixture','village_raw'=>'fixture']);}
$cli=new ADE_Pilot_CLI;
$cli->preflight([],[]);$report=json_decode(end(WP_CLI::$messages),true);
ck($report['all_valid'] && $report['checked']===200,'default bundled pilot preflight');ck($wpdb->jobs===[],'preflight zero jobs');
$cli->preview([],['dry-run'=>true,'batch-size'=>'10']);$preview=json_decode(end(WP_CLI::$messages),true);
ck($preview['selection_count']===200 && count($preview['batch']['results'])===10,'default frozen preview ten rows');ck($wpdb->jobs===[],'preview zero writes');
foreach(['enqueue'=>'ENQUEUE_M1_PLAN','run_one_batch'=>'RUN_M1_PLAN','recover'=>'RECOVER_M1_PLAN','retry_failed'=>'RETRY_M1_PLAN','cancel'=>'CANCEL_M1_PLAN'] as $method=>$confirmation){
    $before=count($wpdb->sql);
    blocked(fn()=>$cli->$method([],['confirm'=>$confirmation,'dry-run'=>true,'job-id'=>'1']),'dry-run write denied '.$method);
    ck(count($wpdb->sql)===$before && $wpdb->jobs===[],'no query before rejected dry-run '.$method);
    blocked(fn()=>$cli->$method([],['job-id'=>'1']),'missing confirmation '.$method);
}
blocked(fn()=>$cli->preview([],['batch-size'=>'10;DROP TABLE x']),'numeric CLI injection');
blocked(fn()=>$cli->preflight([],['npsn-file'=>['invalid']]),'malformed path argument');
$first=(string)array_key_first($wpdb->schools);$saved=$wpdb->schools[$first]['regency_raw'];$wpdb->schools[$first]['regency_raw']='KAB. CILACAP';
blocked(fn()=>$cli->preflight([],[]),'nonzero preflight on province conflict');$report=json_decode(end(WP_CLI::$messages),true);
ck(!$report['all_valid'] && $report['failed']===1 && $report['issues'][0]['code']==='PILOT_CLASSIFICATION_CONFLICT_REGENCY_RAW','structured preflight issue');$wpdb->schools[$first]['regency_raw']=$saved;
$cap=false;blocked(fn()=>$cli->preflight([],[]),'unauthorized read denied');blocked(fn()=>$cli->enqueue([],['confirm'=>'ENQUEUE_M1_PLAN']),'unauthorized write denied');$cap=true;
ADE_Schema::$local=false;blocked(fn()=>$cli->enqueue([],['confirm'=>'ENQUEUE_M1_PLAN']),'production site denied');ADE_Schema::$local=true;
$cli->enqueue([],['confirm'=>'ENQUEUE_M1_PLAN']);ck(count($wpdb->jobs)===1,'confirmed scoped enqueue');
$cli->status([],['job-id'=>'1']);$status=json_decode(end(WP_CLI::$messages),true);ck($status['selection_scope']===ADE_Pilot_Scope::NAME && !isset($status['lease_token'],$status['scope_filter']),'status scope visible/token and manifest hidden');
$wpdb->insert('custom_ahda_discovery_jobs',['job_key'=>str_repeat('b',64),'job_type'=>ADE_Pilot_Jobs::TYPE,'scope_filter'=>json_encode(['version'=>1]),'status'=>'queued']);
blocked(fn()=>$cli->run_one_batch([],['job-id'=>'2','confirm'=>'RUN_M1_PLAN']),'legacy unscoped job cannot run through current pilot CLI');
ck($wpdb->jobs[2]['status']==='queued' && $wpdb->jobs[2]['attempt_count']===0,'rejected legacy job remains untouched');
echo "PASS: $n M1 CLI scope/permission/dry-run checks (fake DB).\n";
