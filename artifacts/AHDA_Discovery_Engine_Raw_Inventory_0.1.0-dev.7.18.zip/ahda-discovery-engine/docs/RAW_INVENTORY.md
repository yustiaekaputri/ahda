# Raw archive inventory — dev7.18

Explicit CLI, LocalWP-only, authenticated ade_manage_jobs + ade_review_candidates.
Uses existing guard/preflight; works while writers OFF. No admin/frontend/cron hook.

Safe read-only example after installing companion on ahda.local:

```
wp --user="admin" ade pilot raw_inventory --limit=25 --after=0 --dry-run
```

For the next page use the returned cursor as --after. Stop when has_more=false.
Limits1–100, default25; after>=0. Missing/false --dry-run is rejected. No backup or
mutation consent is needed for this SELECT-only command. No URLs are requested.

Query projects id,status,created_at and OCTET_LENGTH of payload/summary, restricted
to m2_raw_archive_pending, id>cursor, ordered id, LIMIT page+1. It does not retrieve
raw JSON, summary JSON, school identities, quotes, bindings or actor details.
Preflight still reads schema metadata. No COUNT/OFFSET/table-lock/transaction.
Bounded result size is not a hard bound on database engine rows examined or IO;
existing type_scope/primary indexes apply, no schema/index added. VPS load untested.

page_bytes is payload+summary byte size for RETURNED rows only. Lookahead excluded.
Not MySQL table/index/backup size, not a global total or quota. Pagination does not
hold a consistent snapshot; concurrent changes can affect pages. Do not sum pages
and claim a certified global capacity estimate while writers are running.

created_at_utc/age_days describe capture receipt creation, not school/source update,
source permission lifetime or deletion eligibility. Future timestamps flagged with
age_days=null; oversized stored metadata flagged without parsing content. Invalid
IDs/order/size/date/status metadata fails closed; no raw fallback. No contents or
integrity validation implied by presence in this listing.

No retention deletion, encryption-at-rest, enforced total quota or automated expiry
is implemented. These remain gates before bulk real raw captures. No automatic
cleanup: raw may be required for evidence, review, publisher/undo and audit; a proper
retention policy needs dependency/rights rules and an operator-approved preview.

Tests:28 offline suites1680 checks PHP8.2/8.4DOM;1612 noDOM (HTML not run),97PHP lint.
FakeDB inventory34checks +officialWPCLI parser/dispatcher coverage. Native synthetic
WordPress/MySQL projection/bytes/cursor/hash checks documented in current QA. No
real user DB or production tested. Rollback companion to backed-up7.17; no data or
schema migration needed. Existing publisher undo still available in7.17.
