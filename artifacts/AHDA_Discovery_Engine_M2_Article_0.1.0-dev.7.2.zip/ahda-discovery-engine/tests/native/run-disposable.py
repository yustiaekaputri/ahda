#!/usr/bin/env python3
from pathlib import Path
import subprocess,os,secrets,time,json,argparse
parser=argparse.ArgumentParser(description="Opt-in disposable MySQL test; never connects to existing WordPress DB")
parser.add_argument("--approved-disposable-mysql",action="store_true",required=True)
parser.add_argument("--php-bin",required=True)
parser.add_argument("--extension-dir",required=True)
parser.add_argument("--output-dir",required=True)
args=parser.parse_args()
r=Path(__file__).resolve().parents[2];q=Path(args.output_dir).resolve();q.mkdir(parents=True,exist_ok=True)
image='mysql@sha256:a81d043930e51745522bd5c430961cf8286f0a23f0a9a2a6e0108f7ea71b0902'
env=dict(os.environ)
for k in ['DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH']:env.pop(k,None)
cmd=['docker','--host=unix:///var/run/docker.sock']
def docker(args,check=True):return subprocess.run(cmd+args,env=env,text=True,capture_output=True,check=check)
name='ahda-m2-test-'+secrets.token_hex(5);password=secrets.token_hex(32);owned_id=None
(q/'native-mysql-result.json').write_text(json.dumps({'status':'NOT_COMPLETED','container_removed':False},indent=2))
env['MYSQL_ROOT_PASSWORD']=password
def run():
 global owned_id
 c=docker(['run','-d','--name',name,'--label','ahda.disposable-test=true','--cpus=1','--memory=1g','--memory-swap=1g','--tmpfs','/var/lib/mysql:rw,size=512m','-p','127.0.0.1::3306','-e','MYSQL_ROOT_PASSWORD','-e','MYSQL_ROOT_HOST=%','-e','MYSQL_DATABASE=ahda_m2_disposable',image,'--innodb-buffer-pool-size=67108864','--performance-schema=OFF','--mysqlx=OFF','--max-connections=12','--innodb-redo-log-capacity=16777216'])
 ident=c.stdout.strip();assert len(ident)==64 and all(c in '0123456789abcdef' for c in ident);owned_id=ident;print('Created disposable container '+name,flush=True)
 binding=docker(['port',ident,'3306/tcp']).stdout.strip();assert binding.startswith('127.0.0.1:');port=int(binding.split(':')[-1]);assert port>=20000
 for i in range(90):
  ping=docker(['exec',ident,'mysqladmin','ping','-h127.0.0.1','--silent'],False)
  if ping.returncode==0:break
  time.sleep(1)
 else:raise RuntimeError('MySQL did not become ready within90s')
 print('MySQL ready on isolated loopback port; running native SQL tests.',flush=True)
 phpenv=dict(os.environ,AHDA_NATIVE_TEST_APPROVED='DISPOSABLE_SYNTHETIC_ONLY',AHDA_NATIVE_TEST_PORT=str(port),AHDA_NATIVE_TEST_PASSWORD=password)
 php=[args.php_bin,'-n','-d','extension='+str(Path(args.extension_dir)/'mysqlnd.so'),'-d','extension='+str(Path(args.extension_dir)/'mysqli.so'),str(r/'tests/native/m2-mysql.php')]
 start=time.monotonic();x=subprocess.run(php,env=phpenv,text=True,capture_output=True,timeout=120)
 log=(x.stdout+x.stderr).replace(password,'[REDACTED]');(q/'native-mysql-tests.txt').write_text(log);print(log,flush=True)
 record={'status':'PASS' if x.returncode==0 else 'FAIL','exit_code':x.returncode,'duration_seconds':round(time.monotonic()-start,3),'image_digest':docker(['image','inspect',image,'--format','{{index .RepoDigests 0}}']).stdout.strip(),'scope':'actual MySQL8.4; WordPress/wpdb adapter stubs; synthetic data only','limits':'1CPU/1GiB;512MiB tmpfs data; loopback-only ephemeral port','operator_approval':'explicit --approved-disposable-mysql; cloud operator affirmative2026-11-10 recorded in PROGRESS.md','container_removed':False}
 (q/'native-mysql-result.json').write_text(json.dumps(record,indent=2));return x.returncode
try:code=run()
finally:
 result=docker(['rm','-f','-v',owned_id],False) if owned_id else None
 removed=result is not None and result.returncode==0
 print('Disposable test container removed: '+str(removed),flush=True)
 path=q/'native-mysql-result.json'
 if path.exists():
  d=json.loads(path.read_text());d['container_removed']=removed;path.write_text(json.dumps(d,indent=2))
raise SystemExit(code)
