<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Explicit one-evidence read-only raw comparison. Never grants approval/permission. */
final class ADE_Archive_Verifier {
    private static function rows( string $sql, array $args ): array {
        global $wpdb; $wpdb->last_error = '';
        $rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
        if ( ! is_array( $rows ) || $wpdb->last_error ) { throw new RuntimeException( 'RAW_VERIFY_READ_FAILED' ); }
        return $rows;
    }
    private static function pair( int $candidate, int $evidence, int $school, bool $lock = false ): array {
        $ct = ADE_Schema::table_name( 'candidates' ); $et = ADE_Schema::table_name( 'evidence' ); $lt = ADE_Schema::table_name( 'candidate_evidence' );
        $end = $lock ? ' FOR UPDATE NOWAIT' : '';
        $rows = self::rows( "SELECT c.id AS candidate_id,c.school_id,c.candidate_type,c.target_type,c.target_key,LEFT(c.proposed_value,501) AS proposed_value,OCTET_LENGTH(c.proposed_value) AS proposed_bytes,c.base_target_hash,c.row_version,c.review_status,c.publish_status,ce.id AS link_id,ce.relation_type,e.id AS evidence_id,e.source_id,e.evidence_type,e.attribute_hint,e.evidence_url,e.evidence_key,e.content_fingerprint,LEFT(e.snippet_text,2001) AS snippet_text,OCTET_LENGTH(e.snippet_text) AS snippet_bytes,LEFT(e.observed_value,4097) AS observed_value,OCTET_LENGTH(e.observed_value) AS observed_bytes,e.parse_status,e.checked_at FROM {$ct} c INNER JOIN {$lt} ce ON ce.candidate_id=c.id INNER JOIN {$et} e ON e.id=ce.evidence_id WHERE c.id=%d AND c.school_id=%d AND e.id=%d AND e.school_id=%d LIMIT 2{$end}", array( $candidate, $school, $evidence, $school ) );
        if ( count( $rows ) !== 1 ) { throw new RuntimeException( 'RAW_VERIFY_LINK_NOT_FOUND' ); }
        $r = $rows[0];
        foreach ( array( 'proposed_value', 'snippet_text', 'observed_value', 'evidence_url', 'evidence_key', 'content_fingerprint', 'checked_at' ) as $field ) { if ( ! is_string( $r[$field] ?? null ) ) { throw new RuntimeException( 'RAW_VERIFY_ROW_INVALID' ); } }
        if ( $r['candidate_type'] !== 'm2_meta_text_v1' || $r['target_type'] !== 'school_meta' || ! in_array( $r['target_key'], array( 'profile_programs', 'profile_curriculum', 'profile_hours' ), true ) || $r['relation_type'] !== 'supports' || $r['evidence_type'] !== 'document' || $r['attribute_hint'] !== $r['target_key'] || $r['parse_status'] !== 'm2_archive_unverified' || (int) $r['row_version'] < 1 || (int) $r['proposed_bytes'] > 500 || (int) $r['snippet_bytes'] > 2000 || (int) $r['observed_bytes'] > 4096 ) { throw new RuntimeException( 'RAW_VERIFY_ROW_INVALID' ); }
        return $r;
    }
    public static function verify( string $npsn, int $candidate_id, int $evidence_id, bool $lock = false ): array {
        if ( ! ADE_Schema::is_allowed_local() || ! current_user_can( 'ade_review_candidates' ) || (int) get_current_user_id() < 1 || ! ADE_Jobs::preflight()['ready'] ) { throw new RuntimeException( 'RAW_VERIFY_REVIEW_GATE_BLOCKED' ); }
        if ( $candidate_id < 1 || $evidence_id < 1 ) { throw new InvalidArgumentException( 'RAW_VERIFY_IDS_REQUIRED' ); }
        $school = ADE_Identity::lookup_pilot( $npsn ); ADE_Pilot_Scope::assert_school( $school ); $school_id = (int) $school['id'];
        $r = self::pair( $candidate_id, $evidence_id, $school_id, $lock );
        $o = ADE_Strict_JSON::decode( $r['observed_value'], 4096 );
        if ( ( $o['schema_version'] ?? null ) !== 1 || ( $o['provenance'] ?? null ) !== 'stored_raw_archive' || ! is_int( $o['raw_receipt_id'] ?? null ) || $o['raw_receipt_id'] < 1 || ( $o['scope_hash'] ?? null ) !== ADE_Pilot_Scope::SHA256 || ( $o['identity_status'] ?? null ) !== 'pending' || ( $o['permission_state'] ?? null ) !== 'NOT_INDEPENDENTLY_VERIFIED' || ( $o['value'] ?? null ) !== $r['proposed_value'] ) { throw new RuntimeException( 'RAW_VERIFY_PROOF_INVALID' ); }
        foreach ( array( 'raw_payload_sha256', 'input_sha256', 'document_key', 'raw_document_sha256', 'archive_evidence_key' ) as $key ) { if ( ! is_string( $o[$key] ?? null ) || ! preg_match( '/^[a-f0-9]{64}$/D', $o[$key] ) ) { throw new RuntimeException( 'RAW_VERIFY_PROOF_INVALID' ); } }
        $archive = ADE_Archive_Vault::verification_archive( $o['raw_receipt_id'], $npsn, $lock );
        if ( $archive['school_id'] !== $school_id || ! hash_equals( $archive['raw_payload_sha256'], $o['raw_payload_sha256'] ) || $o['input_sha256'] !== $archive['raw_payload_sha256'] ) { throw new RuntimeException( 'RAW_VERIFY_RECEIPT_HASH_CONFLICT' ); }
        $doc = $archive['bundle']['documents'][$o['document_key']] ?? null;
        if ( ! is_array( $doc ) || ( $o['format'] ?? null ) !== $doc['format'] || $o['raw_document_sha256'] !== $doc['raw_sha256'] ) { throw new RuntimeException( 'RAW_VERIFY_DOCUMENT_CONFLICT' ); }
        $raw = json_encode( $archive['bundle'], JSON_THROW_ON_ERROR );
        $parsed = ADE_Local_Worker::inspect( $raw, $npsn, time(), static function( string $code ) use ( $school ): array { return $school; } )['result'];
        if ( $parsed['outcome'] !== 'preview_needs_review' ) { throw new RuntimeException( 'RAW_VERIFY_DOCUMENTS_BLOCKED' ); }
        $entry = array_column( $parsed['evidence'], null, 'archive_evidence_key' )[$o['archive_evidence_key']] ?? null;
        if ( ! is_array( $entry ) || $entry['document_key'] !== $o['document_key'] || $entry['target_key'] !== $r['target_key'] || $entry['observed_value'] !== $r['proposed_value'] || $entry['supporting_quote'] !== $r['snippet_text'] || $entry['source_url'] !== $r['evidence_url'] || $entry['content_fingerprint'] !== $r['content_fingerprint'] || ( new DateTimeImmutable( $entry['checked_at'] ) )->format( 'Y-m-d H:i:s' ) !== $r['checked_at'] ) { throw new RuntimeException( 'RAW_VERIFY_CLAIM_CONFLICT' ); }
        $registered_url = $archive['bindings'][$o['document_key']] ?? null;
        if ( ! is_string( $registered_url ) ) { throw new RuntimeException( 'RAW_VERIFY_SOURCE_BINDING_REQUIRED' ); }
        ADE_Local_Archive::document( 'binding', 'csv', $registered_url, $doc['checked_at'], $doc['permission_reference'] );
        $registered = ADE_Source_URLs::canonicalize( $registered_url );
        if ( $registered['source_type'] !== 'website' || $registered['normalized_host'] !== parse_url( $doc['source_url'], PHP_URL_HOST ) ) { throw new RuntimeException( 'RAW_VERIFY_SOURCE_BINDING_CONFLICT' ); }
        $st = ADE_Schema::table_name( 'sources' ); $rt = ADE_Schema::table_name( 'school_sources' );
        $end = $lock ? ' FOR UPDATE NOWAIT' : '';
        $sources = self::rows( "SELECT s.id AS source_id,l.id AS relation_id,s.source_type,s.access_state,s.source_status,l.identity_status,l.relationship_type FROM {$st} s INNER JOIN {$rt} l ON l.source_id=s.id WHERE l.school_id=%d AND s.canonical_key=%s AND s.id=%d LIMIT 2{$end}", array( $school_id, $registered['canonical_key'], (int) $r['source_id'] ) );
        if ( count( $sources ) !== 1 || (int) ( $sources[0]['relation_id'] ?? 0 ) < 1 || (int) $sources[0]['source_id'] !== (int) $r['source_id'] ) { throw new RuntimeException( 'RAW_VERIFY_SOURCE_BINDING_CONFLICT' ); }
        $source = $sources[0];
        foreach ( array( 'source_type', 'access_state', 'source_status', 'identity_status', 'relationship_type' ) as $field ) { if ( ! is_string( $source[$field] ?? null ) ) { throw new RuntimeException( 'RAW_VERIFY_SOURCE_STATE_BLOCKED' ); } $source[$field] = strtolower( trim( $source[$field] ) ); }
        if ( $source['source_type'] !== 'website' || $source['access_state'] !== 'manual_only' || ! in_array( $source['source_status'], array( 'discovered', 'verified', 'active' ), true ) || ! in_array( $source['identity_status'], array( 'pending', 'verified' ), true ) || ! in_array( $source['relationship_type'], array( 'pending', 'official' ), true ) ) { throw new RuntimeException( 'RAW_VERIFY_SOURCE_STATE_BLOCKED' ); }
        $expected_key = ADE_Local_Archive::digest( array( 'm2-stored-archive-evidence-v1', $school_id, (int) $r['source_id'], $o['raw_receipt_id'], $archive['raw_payload_sha256'], $o['archive_evidence_key'] ) );
        if ( ! hash_equals( $expected_key, (string) $r['evidence_key'] ) ) { throw new RuntimeException( 'RAW_VERIFY_EVIDENCE_KEY_CONFLICT' ); }
        global $wpdb; $meta = $wpdb->prefix . 'ahda_school_meta'; if ( strlen( $meta ) > 64 ) { throw new RuntimeException( 'RAW_VERIFY_META_INVALID' ); }
        $current = self::rows( "SELECT LEFT(meta_value,16385) AS meta_value,OCTET_LENGTH(meta_value) AS value_bytes FROM {$meta} WHERE school_id=%d AND verification_status=%s AND meta_key=%s LIMIT 2", array( $school_id, 'verified', $r['target_key'] ) );
        if ( count( $current ) > 1 || ( $current && ( ! is_string( $current[0]['meta_value'] ) || (int) $current[0]['value_bytes'] > 16384 ) ) ) { throw new RuntimeException( 'RAW_VERIFY_META_INVALID' ); }
        $current_hash = ADE_Local_Archive::digest( array( 'm2-meta-snapshot-v1', $school_id, $r['target_key'], $current ? $current[0]['meta_value'] : null ) );
        if ( self::pair( $candidate_id, $evidence_id, $school_id, $lock ) !== $r ) { throw new RuntimeException( 'RAW_VERIFY_CHANGED_DURING_CHECK' ); }
        $blockers = array( 'SOURCE_IDENTITY_ATTESTATION_REQUIRED', 'SOURCE_PERMISSION_ATTESTATION_REQUIRED', 'POSITIVE_REVIEW_NOT_IMPLEMENTED', 'PUBLISHER_DISABLED' );
        $conflict = ! is_string( $r['base_target_hash'] ) || ! hash_equals( $current_hash, $r['base_target_hash'] ); if ( $conflict ) { $blockers[] = 'CURRENT_VALUE_CHANGED'; }
        if ( in_array( 'STALE_EVIDENCE', $parsed['blocking_reasons'], true ) ) { $blockers[] = 'STALE_EVIDENCE'; }
        return array( 'mode' => 'READ_ONLY_ARCHIVE_BINDING_CHECK', 'npsn' => $npsn, 'school_id' => $school_id, 'candidate_id' => $candidate_id, 'candidate_version' => (int) $r['row_version'], 'evidence_id' => $evidence_id,
            'raw_receipt_id' => $o['raw_receipt_id'], 'raw_payload_sha256' => $o['raw_payload_sha256'], 'document_key' => $o['document_key'], 'raw_document_sha256' => $o['raw_document_sha256'], 'source_id' => (int) $r['source_id'], 'target_key' => $r['target_key'],
            'binding_matches' => true, 'current_value_conflict' => $conflict, 'checked_at' => gmdate( 'Y-m-d\TH:i:s\Z' ), 'snapshot_only' => true, 'must_revalidate_for_approval' => true,
            'identity_attested' => false, 'permission_attested' => false, 'ready_for_approval' => false, 'blocking_reasons' => $blockers,
            'raw_content_returned' => false, 'filesystem_writes' => 0, 'database_writes' => 0, 'network_requests' => 0, 'publication_enabled' => false );
    }
}
