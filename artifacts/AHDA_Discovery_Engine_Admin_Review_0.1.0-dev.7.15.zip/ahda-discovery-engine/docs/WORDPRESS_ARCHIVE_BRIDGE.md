# Integrasi arsip–kandidat pada WordPress nyata — dev.7.11

Tahap ini memperluas pembuktian dev7.10. Runtime plugin sama, selain nomor versi.
Write tetap default OFF; tidak ada perubahan konfigurasi atau database pengguna.
Pengujian dilakukan di salinan situs sementara dengan data sekolah sintetis.

## Yang benar-benar digunakan

- WordPress7.1.4 resmi, pinned SHA db96f5eaa77a8d3e8eec8923a518fa2326f0d46a.
- Directory0.8.9 dan companion7.11 aktual, activation/install/schema/preflight nyata.
- MySQL8.4.13 InnoDB pada container sendiri1CPU/1GiB,512MiBtmpfs, portloopback sementara.
- PHP8.2.32, **wpdb asli** dari wp-includes/class-wpdb.php.
- Capability WordPress asli dari wp-includes/capabilities.php, administrator/editor asli.
- Browser Chromium login/cookies/session/nonces/admin-post dan halaman wp-admin asli.

83pemeriksaan layanan menggunakan API plugin langsung setelah bootstrap WordPress.
Satu kelas marker WP_CLI tanpa metode hanya memenuhi pengecekan keberadaan kelas
pada guard CLI. Ini **bukan official WP-CLI runner end-to-end**. Parser/dispatcher
WP-CLI2.12 diuji terpisah secara offline pada suite yang sudah ada. Tidak ada stub
untuk wpdb, SQL, role, capability, nonce, user atau API service yang diuji di situs ini.

Bootstrap uji khusus mengganti wp-load hanya pada salinan Core; tidak membaca,
membuat atau mengubah wp-config. WP_HOME alias ahda.local dipakai untuk guard
lokal, admin/REST diarahkan ke127.0.0.1 milik tes. Tidak menghubungi ahda.local
pengguna. WP_MAIL/HTTP/cron/update diblokir/dinonaktifkan di harness. Perilaku update
situs pengguna tidak diubah. Core cache resmi dan source baseline tetap utuh.

## Hasil final

**83 service checks PASS +47 browser/admin checks PASS** (dua kelompok terpisah).
Bukti docs/qa/dev7.11/wordpress. Seluruh25tabel legacy sintetis dari schema aktual
Directory sama hash-nya sebelum/sesudah bridge. Ini bukan salinan555.460profil
pengguna, bukan uji beban VPS atau acceptance konten sumber nyata.

Layanan mencakup rawstage read-only, raw/candidate opt-in OFF, raw insert/replay,
capability editor, IDOR NPSN, token/backup/konfirmasi,3kandidat/6evidence/6link/
1receipt, rawreceipt immutable, dua host/sourceID berbeda, snapshot inspector,
replay tanpa perubahan, receipt historis, revision append/version, reviewed row
serta link frozen, dan original candidate/evidence/link/source/relation/audit utuh.

Seluruh16posisi insert digagalkan lewat filter **query WordPress asli**, terbatas
pada operasi layanan dan tabel Discovery sintetis. Filter mengganti tepat satu
INSERT dengan SQL invalid; actualwpdb/MySQL menolaknya. Snapshot semua7tabel
Discovery tetap sama setelah rollback. Tidak mengganti adapter SQL/transaction.
Prior-review state pada fixture revision dibuat melalui update sintetis terkontrol;
authenticated negative-review POST diuji sendiri dalam browser suite yang sama.

Browser mempertahankan39checks lama dan menambah8checks integrasi: daftar/detail
raw dari hasil layanan, provenance/revalidation notice, no mutation forms setelah
opt-in proses uji berakhir, mobile wrapping, seluruh25legacy hashes dan semua
approved/publication fields tetap NULL/not_ready. Dua source URL hanya metadata,
tidak diminta oleh crawler/browser. Blocked browser target list kosong.

Opt-in raw/candidate hanya konstanta pada satu proses CLI uji, tidak ditulis ke
bootstrap atau situs pengguna; request HTTP berikutnya kembali OFF. Runtime negatif
juga diuji OFF/ON testfixture/OFF seperti suite sebelumnya. Screenshot wp-admin
mobile terbaru diperiksa manual, label sintetis terlihat jelas.

## Catatan percobaan dan cleanup

Percobaan awal lulus83+47functional checks tetapi log berisi3peringatan Core saat
update-check mencoba memakai HTTP yang diblokir harness. Hanya lingkungan uji.
Bukti awal dipertahankan di wordpress-attempt-1. Harness lalu melepas callback
updatecheck Core pada plugins_loaded (khusus salinan tes) dan menambahkan gate
no PHP warning/notice/deprecation/fatal. Hasil final harus bersih, bukan menyembunyikan
peringatan plugin. Tidak menonaktifkan verifikasi TLS atau membuka network.

Dua container/salinan situs/server sendiri (awal dan final, tidak bersamaan)
dibersihkan via finally. Random password/salt/cookie/nonce body tidak disimpan dalam
laporan. Tidak ada source privat, production, user wp-config atau database nyata.

## Reproduksi dan batas

Lihat tests/wordpress/README.md dan run-isolated.py. Harus izin MySQL sintetis dan
Core/cache/module PHP lokal yang tepat; runner tidak menerima credential/database
pengguna dan tidak boleh diarahkan ke ahda.local/ahda.sch.id. bridge-pipeline.php
hanya dipanggil control CLI setelah marker lingkungan tersendiri.

Belum diuji: official WP-CLI command runner penuh, situs LocalWP pengguna dengan
theme/plugin pihak ketiga, stress/concurrency/load1GB, genuine TCP commit-ack loss
(native suite sebelumnya memakai simulasi setelah actualCOMMIT), privacy/retention,
source authenticity, positif approval dan publisher. Di sisi UI, binding raw masih
pointer yang belum diperiksa ulang penuh pada halaman; gate tersebut tetap jelas.
MVP_ACCEPTANCE.md mencatat estimasi fondasi55% dan pengayaan fakta nyata0/200.
Tambahan bukti tes tidak otomatis berarti persentase konten naik.
