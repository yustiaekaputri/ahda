# Negative review security review

Default OFF technical switch, no option/role/config writes; write endpoint
unregistered and no POST forms when absent. Additional opt-in never replaces
capability/local actor/preflight, scoped WP nonce, explicit backup/confirmation,
strict types/schema/scope/action/plan. Approval/publish/reopen rejected unconditionally.
Controller POST only, WP unslash once, server-side constraints, fixed safe redirect,
no raw errors or fake GET success. Internal unknown-result message preserves
operator awareness that failed response may still follow committed transaction.

SQL identifiers fixed through schema allowlist and validated legacy prefix.
Values prepared or wpdb insert arrays. Shared M2 app lock, short transaction,
FOR UPDATE NOWAIT and candidate CAS, status-only mutation with no approved or
published fields. Review INSERT only, receipt INSERT only; no audit UPDATE/DELETE.
Exact replay integrity checks receipt and referenced audit; operation binds actor,
scope, expected version, plan, decision, reason and note. Nonce not persisted.
No uncontrolled HTML/unserialize/eval/HTTP. Notes bounded/UTF8/plain and escaped in
history; raw operator notes don't go to public profiles or external services.

Native MySQL proves transaction/locks/rollback/unknown outcome under WP stubs.
Controller child tests prove mapping/nonces/status/redirect under fakes, not Core
WordPress. Actual WP nonce/session/cookie/capability/preflight and routing remains
unverified; release must stay OFF for real data. Receipt hashes detect corruption,
not cryptographic authorization against a DB administrator changing all records.
No source authority/permission approval exists yet, no publisher, no post-commit
undo. Deferred/rejected candidates frozen against M2 hidden evidence mutation.
