# Durable local archive batch — dev.7.16

Local CLI only, default OFF. Consumes explicitly selected already-stored raw
receipts. Never downloads, discovers new schools, approves, publishes, or writes
legacy profile tables. Existing frozen200 Tasikmalaya/JawaBarat selection unchanged.

## Frozen input and consent

Strict JSON <=32KiB with exactly schema_version1, scope_hash (frozen pilot hash),
and entries list1..200 of {npsn:string8,raw_receipt_id:positiveinteger}. No duplicate
NPSN/rawreceipt, no other provinces/schools. Stage checks actual existing school
identity/classification, freezes IDs, sorts by schoolID and binds preview to actor.
It DOES NOT read raw payloads, validate rights or promise candidate extraction.

```
wp --user="admin" ade pilot batch_stage --request-file=PATH --dry-run
```

Input sample SHAPE ONLY (replace with legitimate records; do not store demo):

```json
{"schema_version":1,"scope_hash":"be4c291f4013bd14143f305fb107183a7a8c067985fbd90019f65753343803b1","entries":[{"npsn":"20268071","raw_receipt_id":123}]}
```

`batch_enqueue --request-file=PATH --preview-token=TOKEN --backup-confirmed=YES
--confirm=ENQUEUE_ARCHIVE_BATCH` stores one immutable-scope job, idempotent on actor
+manifest. Gate ADE_LOCAL_ARCHIVE_BATCH_ENABLED === true, undefined/OFF. Run also
requires existing ADE_LOCAL_ARCHIVE_CANDIDATES_ENABLED === true. Neither flag is
changed by this delivery; no new option/schema/table/role. No web/cron/autostart.
Actual user data/configuration operations need scoped approval and backup first.

Each command additionally enforces local CLI/manage-jobs/reviewer/positive actor
and existing preflight. Batch owner must execute/control it; no silent reassignment.
CLI is not a web CSRF surface, so no browser nonce endpoint is introduced.

## Processing and budgets

`batch_run --job-id=ID --backup-confirmed=YES --confirm=RUN_ARCHIVE_BATCH`
processes at most3 entries. It checks elapsed20s and96MiB PHP allocated memory
BETWEEN entries; a single bounded parser call may exceed these soft thresholds.
Raw receipt capped1MiB, individual document parser caps unchanged. One job mutex,
one school mutex, no concurrent crawler/browser process. No setting of user PHP
memory/time or MySQL server limits. Repeated metadata preflight remains a known
cost; no cross-request authorization cache. VPS load not measured.

For each entry:

1. Short transaction acquires 90s random lease + attempt under job row lock.
   Job mutex also prevents another cooperating run/control while active.
2. Existing explicit archive candidate stage reparses source/raw locally.
3. A narrow `record_for_batch` path enters the SAME existing writer transaction,
   locks/fences batch job by type/token/attempt/index/expiry/owner/manifest, then
   performs fresh source/raw/candidate/evidence locks and existing pending writes.
4. Candidate/evidence/link/receipt and cursor/stats checkpoint commit together.
   Final CAS repeats token/attempt/expiry, so lease expiring after inserts rolls
   back those rows too. No outer transaction wraps a writer START TRANSACTION.
5. Reviewed candidates remain immutable, exactly as in manual writer. Replayed
   existing candidate receipt can checkpoint with zero new candidate records.
6. On success release lease, reset per-entry attempts, advance durable prefix.
   Repeated completed run/enqueue does not replay extraction or reset cursor.

Unexpected storage/parse/corruption failures stop at current index with retry_wait,
max3 attempts then failed. Earlier committed entries remain. Fixed known semantic
codes VAULT_SCHOOL_BINDING_CONFLICT, VAULT_DOCUMENTS_NOT_READY and
VAULT_BOUND_SOURCES_REQUIRED instead append outcome=blocked, candidate_receipt_id
NULL and explicit code in a jobs-only fenced transaction, then continue remaining
entries. They never fabricate candidate facts or claim that blocked school was
successfully enriched. Unknown failures are not silently skipped.

`processed_this_run` counts completed outcomes including blocked. Read individual
results/outcome; completed job means all entries assessed, NOT all profiles enriched.
Status exposes no raw content, quotes, notes, full manifest or lease token. Results
are bounded128KiB, digest-checked ordered prefix with matching scope/receipt refs.
Digests detect corruption, not a privileged database administrator rewriting hashes.

## Resume, recovery, cancellation and audit

- `batch_status --job-id=ID`: read-only status/next_index/results/last error.
- `batch_control --job-id=ID --operation=recover --backup-confirmed=YES
  --confirm=RECOVER_ARCHIVE_BATCH`: expired lease only; live lease refused.
- `--operation=retry --confirm=RETRY_ARCHIVE_BATCH`: failed OR cancelled job;
  preserves committed prefix, resets attempts for remaining entries.
- `--operation=cancel --confirm=CANCEL_ARCHIVE_BATCH`: queued/retry/failed/expired
  lease only, leaves all previously committed rows and receipts unchanged.

Controls acquire same job mutex and transactional row lock. One append-only
m2_batch_control jobs audit records actor/action/before-after state/index/backup/
time atomically with state update. Audit insertion failure rolls back control.
Audit events are not queue work. Repeated control after uncertain COMMIT requires
reading current status; control commands are not claimed idempotent receipts.

Completed manifest is immutable, including blocked outcomes. To reassess blocked
school, obtain a fresh validated raw receipt (or an explicitly different remaining
subset) and stage a new manifest; exact completed manifest returns historical job.
Do not reset stats, delete records, rewrite approvals or edit raw receipts in place.

If COMMIT succeeds but acknowledgment is lost, candidate receipt and checkpoint
already agree. Failure marker is fenced and cannot overwrite an advanced cursor;
read/retry sees committed prefix and does not duplicate rows. Tests simulate actual
COMMIT followed by injected response error, not genuine dropped TCP transport.
Process crash before commit causes DB rollback; leased job can recover after expiry.
Actual OS kill/restart and network disconnect tests not performed.

## Regression and evidence

Final qa/dev7.16 includes actual WordPress7.1.4/Directory0.8.9/wpdb/MySQL8.4 synthetic
205service+89browser checks. Four synthetic schools demonstrate3+1 continuation;
partial checkpoint failure rolls back candidate rows, token/attempt/expiry fencing,
final-CAS expiry rollback, expired recovery/live denial,3 bounded retries, cancel/
retry, immutable controls audit and fault rollback, owner enforcement, corrupted
checkpoint rejection, blocked-source/raw mismatch continuation and unknown-COMMIT
receipt recovery. All25 legacy synthetic table hashes unchanged. No factual schools.

27 offline suites1634checks each PHP8.2/8.4 DOM,1566withoutDOM (HTML NOT RUN),94lint,
84baselinehashes/6originaltests intact. New26 input tests validate frozen200 SHAPE
with fakeIDs, not an actual200-school native batch. Official CLI parser/dispatcher
checks separate; full CLI runner/userLocalWP/VPSload not E2E-tested. Owned SQL/site/
server resources removed; no wp-config, production or external-source operation.

Manual writer body preserved mechanically, with nullable internal fence hooks only;
no arbitrary callback or generic SQL hook. Original API signatures/output retained.
Rollback plugin files7.15 from local backup, retain jobs/receipts/data/audits. Older
worker cannot process new type; reinstall7.16 to resume. No schema downgrade/delete.
Still missing publisher/undo, raw retention/encryption/totalquota, broader fields and
real licensed sources. Real profile enrichment0/200; no production-ready/SEO claim.
