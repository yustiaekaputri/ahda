> dev.7.2 update: evidence-linked editorial article preview now exists; see
> M2_ARTICLE.md and CONTENT_QUALITY.md. It is still unverified/read-only and has
> no publication target. Native pending writer validation is described separately
> in NATIVE_MYSQL.md. The remainder documents the original dev7.0 preview.

# M2 awal — evidence terstruktur dan kandidat pratinjau

Build `0.1.0-dev.7.0`. Fondasi M2, bukan MVP lengkap. Source discovery/crawl
masih terkunci; akses katalog cloud belum diizinkan oleh kebijakan egress meski
operator sudah menyetujui riset. Sisa anggaran riset18/20, tidak digunakan ulang.
Tidak ada database, profil, evidence atau candidate yang ditulis oleh modul ini.

## Yang dapat diuji sekarang

- Dokumen JSON terstruktur lokal, maksimum64KiB, bukan HTML/CSV mentah.
- Validasi schema/version/type/keys, termasuk menolak duplicate JSON keys.
- NPSN dokumen dan observed_npsn harus sama, anggota200 pilihan Tasikmalaya.
- Source content wajib menyebut NPSN yang dipilih; NPSN eksplisit lain diblokir.
- Proposed value wajib literal di supporting_quote; quote wajib literal di content.
- Whitelist tiga meta field yang memang didukung Directory: profile_programs,
  profile_curriculum dan profile_hours. Field lain/protected tidak diterima.
- URL HTTPS format publik tanpa kredensial/token-query; tidak ada DNS/HTTP.
- UTF8 plain text, tanpa markup/control,500 byte nilai,2000 byte quote,
  16384 byte content, maksimum20 klaim. Tidak ada pemanggilan LLM/eval/unserialize.
- Evidence fingerprints/candidate keys deterministik; dedupe menjaga provenance.
  Dua nilai berbeda untuk target sama ditolak, tidak memakai last-write-wins.
- Timestamp UTC valid; timestamp masa depan ditolak, bukti lebih1tahun diberi
  alasan STALE_EVIDENCE. Operator reference bukan bukti izin yang terverifikasi.
- Scope/ownership/jenjang/wilayah dibaca ulang dari LocalWP pada preview native.
- Snapshot nilai lama hanya SELECT verified pada tiga field; query bounded,
  nilai terlalu besar/error tidak disamarkan sebagai kosong. Hash snapshot
  diberi namespace untuk pekerjaan conflict check berikutnya, bukan token publish.

Semua evidence/candidate merupakan preview in-memory: persisted=false,
review_status=new, readiness=needs_evidence, publish_status=not_ready,
approved_value=null. Pencantuman NPSN/kutipan tidak membuktikan keaslian situs.
Identity dan permission selalu belum diverifikasi. Input tidak bisa menyetel
approval, status publikasi atau mengganti nilai lama.

## Uji demo lokal — data sintetis, bukan fakta sekolah

Pemasangan build baru hanya setelah backup dan persetujuan lokal, seperti panduan
M1. Ganti Discovery saja; jangan ganti Directory/schema/reimport. Pengguna yang
hanya melanjutkan riset sumber tidak perlu menginstal build ini sekarang.

Setelah pemasangan lokal yang disetujui, jalankan dari Site Shell AHDA:

```sh
wp --user="admin" ade pilot extract --demo --dry-run
```

Nama command satu kata `extract`, tidak memakai tanda hubung atau underscore.
Demo memakai NPSN20268071 hanya untuk memeriksa binding ke sekolah pilot yang
sudah ada. Isi program/kurikulum/jam dan URL example.org SEPENUHNYA SINTETIS.
Tanggal demo sengaja lama. Hasil harus berlabel FIXTURE_ONLY_READ_ONLY, tiga
preview evidence/kandidat, blocker FIXTURE_NOT_SCHOOL_FACTS dan STALE_EVIDENCE,
network_requests0, database_writes0, publication_enabled=false.
Jangan menyalin nilai demo ke profil atau memperlakukannya sebagai fakta.

Tidak ada approve/record/publish untuk modul M2 ini. Perintah R4a manual evidence
lama tetap memiliki kontraknya sendiri; jangan gunakan record R4a untuk mengimpor
JSON M2 atau melewati pending identity. R4a identity hints tidak diubah.

## Dokumen nyata ketika sumber berizin tersedia

Gunakan schema pada data/examples/m2-structured-fixture.json sebagai referensi
format, bukan sebagai sumber fakta. Semua key wajib dan key tambahan ditolak.
Dokumen nyata mengisi fixture_only=false, npsn/observed_npsn sesuai sekolah,
source_url/checked_at/permission_reference dengan data pengamatan aktual, serta
source_content plain text dan kutipan/nilai yang benar-benar ada. Jangan masukkan
data pribadi murid, credential, HTML, atau instruksi sebagai perintah.

```sh
wp --user="admin" ade pilot extract --evidence-file="C:/path/evidence.json" --dry-run
```

--demo dan --evidence-file tidak boleh dipakai bersamaan. Tidak ada file yang
secara otomatis diunduh, dipindai atau dieksekusi. JSON dan konten sumber adalah
data tidak tepercaya; tidak dipakai untuk memberi instruksi pada model/worker.
Perubahan wording bebas/generator artikel dan penilaian confidence belum dibuat.

## Batas dan langkah berikutnya

Parser HTML/CSV, persistence M2 dalam transaksi, worker extraction, admin review,
local publication/rollback, native MySQL race tests, dan izin/transport crawler
belum selesai. Tidak ada klaim bahwa200 profil sudah diperkaya, atau build siap
produksi. Dibutuhkan sumber nyata berizin dan hasil integrasi LocalWP untuk
melanjutkan validasi. Semua gate produksi tetap berlaku.

Rollback build: kembalikan ZIP Discovery dev.6.2.1 setelah backup/approval lokal.
Tidak ada migrasi tabel atau baris baru dari preview untuk dibatalkan. Semua job
scoped v2, baseline7 tabel dan data lama dipertahankan.


## dev.7.1 update

Preview remains strictly nonpersistent. A separate manual pending-store backend
now exists: see M2_STORE.md for stage, explicit write gates, transaction/receipt
and all limitations. Fake DB tests pass; native MySQL/LocalWP writes have not
been executed. Do not pass demo data to store. Extraction worker, HTML/CSV parser,
admin decisions and publisher/rollback remain unfinished.
