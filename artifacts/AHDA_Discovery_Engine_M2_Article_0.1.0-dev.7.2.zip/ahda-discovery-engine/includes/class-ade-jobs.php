<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * R2: manual-only synthetic queue exercise. No hooks, cron, network, or school writes.
 * Real discovery job execution is intentionally not implemented in this release.
 */
final class ADE_Jobs {
    public const TEST_TYPE = 'r2_smoke_test';
    private const LOCK_OPTION = 'ade_r2_worker_lock';
    private const LEASE_SECONDS = 120;

    /** Distinguish read-only diagnosis from strict write guard. */
    public static function preflight(): array {
        $report = ADE_Schema::report();
        $flags = ADE_Config::flags();
        $bad_flags = array();
        foreach ( $flags as $name => $state ) {
            if ( ! $state['valid'] ) { $bad_flags[] = $name; }
        }
        $allowed = ADE_Schema::is_allowed_local();
        $ok = $allowed && ADE_Dependencies::ready() && $report['state'] === 'INSTALLED'
            && empty( $report['issues'] ) && empty( $bad_flags );
        return array(
            'ready' => $ok,
            'schema' => $report,
            'unsafe_flags' => $bad_flags,
            'local' => $allowed,
            'worker_lock' => get_option( self::LOCK_OPTION, null ),
        );
    }

    private static function assert_manual_write(): void {
        if ( ! defined( 'WP_CLI' ) || ! WP_CLI || ! class_exists( 'WP_CLI' ) ) {
            throw new RuntimeException( 'R2 hanya menerima perubahan melalui WP-CLI eksplisit.' );
        }
        if ( ! self::preflight()['ready'] ) {
            throw new RuntimeException( 'Preflight R2 BLOCKED. Jalankan wp ade jobs preflight untuk diagnosis.' );
        }
    }

    public static function validate_test_key( string $value ): string {
        if ( ! preg_match( '/^[a-z0-9][a-z0-9_-]{2,39}$/D', $value ) ) {
            throw new InvalidArgumentException( 'test-key harus 3–40 karakter: a-z, 0-9, underscore, minus; diawali huruf/angka.' );
        }
        return $value;
    }

    public static function job_key( string $test_key ): string {
        return hash( 'sha256', 'ade:r2:smoke:v1:' . self::validate_test_key( $test_key ) );
    }

    public static function retry_delay_seconds( int $attempt ): int {
        return min( 300, 15 * ( 2 ** max( 0, min( 5, $attempt - 1 ) ) ) );
    }

    private static function table(): string { return ADE_Schema::table_name( 'jobs' ); }

    private static function require_query( string $sql, array $params = array() ): int {
        global $wpdb;
        $wpdb->last_error = '';
        $prepared = $params ? $wpdb->prepare( $sql, $params ) : $sql;
        $result = $wpdb->query( $prepared );
        if ( false === $result || $wpdb->last_error ) {
            throw new RuntimeException( 'R2 SQL gagal: ' . (string) $wpdb->last_error );
        }
        return (int) $result;
    }

    private static function fetch( string $sql, array $params = array() ) {
        global $wpdb;
        $wpdb->last_error = '';
        $prepared = $params ? $wpdb->prepare( $sql, $params ) : $sql;
        $value = $wpdb->get_row( $prepared, ARRAY_A );
        if ( $wpdb->last_error ) { throw new RuntimeException( 'R2 query gagal: ' . $wpdb->last_error ); }
        return $value ?: null;
    }

    /** Insert only a synthetic job; never enqueue real crawlers in R2. */
    public static function seed( string $test_key ): array {
        self::assert_manual_write();
        global $wpdb;
        $key = self::job_key( $test_key );
        $table = self::table();
        $exists = self::fetch( "SELECT id,status FROM {$table} WHERE job_key=%s LIMIT 1", array( $key ) );
        if ( $exists ) { return array( 'id' => (int) $exists['id'], 'created' => false, 'status' => $exists['status'] ); }
        $now = current_time( 'mysql', true );
        $wpdb->last_error = '';
        $result = $wpdb->insert( $table, array(
            'job_key' => $key,
            'job_type' => self::TEST_TYPE,
            'priority' => 0,
            'scope_level' => 'TEST',
            'scope_filter' => wp_json_encode( array( 'test_key' => $test_key, 'synthetic' => true ) ),
            'status' => 'queued',
            'attempt_count' => 0,
            'max_attempts' => 3,
            'batch_size' => 1,
            'created_at' => $now,
            'updated_at' => $now,
        ) );
        if ( false === $result ) {
            // Concurrent duplicate insert is safe: unique job_key returns one existing row.
            $existing = self::fetch( "SELECT id,status FROM {$table} WHERE job_key=%s LIMIT 1", array( $key ) );
            if ( $existing ) { return array( 'id' => (int) $existing['id'], 'created' => false, 'status' => $existing['status'] ); }
            throw new RuntimeException( 'R2 seed gagal: ' . (string) $wpdb->last_error );
        }
        return array( 'id' => (int) $wpdb->insert_id, 'created' => true, 'status' => 'queued' );
    }

    /** Read-only view; only R2 synthetic jobs, bounded results. */
    public static function list_jobs( int $limit = 15 ): array {
        $limit = max( 1, min( 50, $limit ) );
        $report = self::preflight();
        if ( ! $report['ready'] ) { throw new RuntimeException( 'Preflight R2 BLOCKED.' ); }
        global $wpdb;
        $table = self::table();
        $wpdb->last_error = '';
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id,job_type,status,attempt_count,max_attempts,cursor_school_id,leased_until,next_run_at,last_error_code,created_at,updated_at FROM {$table} WHERE job_type=%s ORDER BY id DESC LIMIT %d",
            self::TEST_TYPE, $limit
        ), ARRAY_A );
        if ( null === $rows || $wpdb->last_error ) { throw new RuntimeException( 'R2 list gagal: ' . (string) $wpdb->last_error ); }
        return $rows;
    }

    public static function inspect( int $id ): ?array {
        $report = self::preflight();
        if ( ! $report['ready'] ) { throw new RuntimeException( 'Preflight R2 BLOCKED.' ); }
        if ( $id < 1 ) { throw new InvalidArgumentException( 'ID job tidak valid.' ); }
        return self::fetch(
            'SELECT id,job_type,status,attempt_count,max_attempts,cursor_school_id,leased_until,next_run_at,stats_payload,last_error_code,created_at,started_at,finished_at,updated_at FROM ' . self::table() . ' WHERE id=%d AND job_type=%s LIMIT 1',
            array( $id, self::TEST_TYPE )
        );
    }

    /** Atomic mutex: at most one manual R2 worker process at a time. */
    private static function lock(): string {
        $token = bin2hex( random_bytes( 32 ) );
        $value = array( 'token' => $token, 'started' => time() );
        if ( ! add_option( self::LOCK_OPTION, $value, '', false ) ) {
            throw new RuntimeException( 'Worker mutex R2 aktif. Jangan memulai worker paralel; gunakan status untuk diagnosis.' );
        }
        return $token;
    }

    private static function unlock_own( string $token ): void {
        $stored = get_option( self::LOCK_OPTION, null );
        if ( is_array( $stored ) && isset( $stored['token'] ) && hash_equals( $token, (string) $stored['token'] ) ) {
            delete_option( self::LOCK_OPTION );
        }
    }

    /**
     * Execute exactly one synthetic job. No external request or content discovery.
     * Lease token fences checkpoint, failure and completion updates.
     */
    public static function step( bool $simulate_failure = false ): array {
        self::assert_manual_write();
        $lock_token = self::lock();
        try {
            $table = self::table();
            $job = self::fetch(
                "SELECT id,attempt_count,max_attempts FROM {$table} WHERE job_type=%s AND status IN ('queued','retry_wait') AND (next_run_at IS NULL OR next_run_at <= UTC_TIMESTAMP()) AND attempt_count < max_attempts ORDER BY priority DESC,id ASC LIMIT 1",
                array( self::TEST_TYPE )
            );
            if ( ! $job ) { return array( 'processed' => false, 'message' => 'Tidak ada job smoke yang siap. Cek retry_wait atau antrean kosong.' ); }
            $id = (int) $job['id'];
            $attempt = (int) $job['attempt_count'] + 1;
            $lease_token = bin2hex( random_bytes( 32 ) );
            $claimed = self::require_query(
                "UPDATE {$table} SET status='leased',lease_token=%s,leased_until=DATE_ADD(UTC_TIMESTAMP(),INTERVAL %d SECOND),attempt_count=attempt_count+1,started_at=COALESCE(started_at,UTC_TIMESTAMP()),updated_at=UTC_TIMESTAMP() WHERE id=%d AND job_type=%s AND status IN ('queued','retry_wait') AND (next_run_at IS NULL OR next_run_at<=UTC_TIMESTAMP()) AND attempt_count<max_attempts",
                array( $lease_token, self::LEASE_SECONDS, $id, self::TEST_TYPE )
            );
            if ( $claimed !== 1 ) { return array( 'processed' => false, 'message' => 'Job berubah secara bersamaan; silakan periksa status.' ); }
            // Heartbeat proves token-based fencing, without unbounded processing.
            $heartbeat = self::require_query(
                "UPDATE {$table} SET leased_until=DATE_ADD(leased_until,INTERVAL %d SECOND),updated_at=UTC_TIMESTAMP() WHERE id=%d AND job_type=%s AND status='leased' AND lease_token=%s AND leased_until>UTC_TIMESTAMP()",
                array( self::LEASE_SECONDS, $id, self::TEST_TYPE, $lease_token )
            );
            if ( $heartbeat !== 1 ) { throw new RuntimeException( 'Heartbeat R2 gagal; jangan melanjutkan job.' ); }
            if ( $simulate_failure ) {
                $final = $attempt >= (int) $job['max_attempts'];
                $delay = self::retry_delay_seconds( $attempt );
                $failed = self::require_query(
                    "UPDATE {$table} SET status=%s,lease_token=NULL,leased_until=NULL,next_run_at=IF(%d=1,NULL,DATE_ADD(UTC_TIMESTAMP(),INTERVAL %d SECOND)),last_error_code='R2_SIMULATED_FAILURE',finished_at=IF(%d=1,UTC_TIMESTAMP(),finished_at),updated_at=UTC_TIMESTAMP() WHERE id=%d AND job_type=%s AND status='leased' AND lease_token=%s AND leased_until>UTC_TIMESTAMP()",
                    array( $final ? 'failed' : 'retry_wait', $final ? 1 : 0, $delay, $final ? 1 : 0, $id, self::TEST_TYPE, $lease_token )
                );
                if ( $failed !== 1 ) { throw new RuntimeException( 'Transition gagal; lease tidak valid.' ); }
                return array( 'processed' => true, 'id' => $id, 'attempt' => $attempt, 'status' => $final ? 'failed' : 'retry_wait', 'next_delay_seconds' => $final ? null : $delay );
            }
            $payload = wp_json_encode( array( 'synthetic' => true, 'steps_completed' => 1, 'result' => 'R2_TEST_ONLY' ) );
            $checkpoint = self::require_query(
                "UPDATE {$table} SET cursor_school_id=1,stats_payload=%s,updated_at=UTC_TIMESTAMP() WHERE id=%d AND job_type=%s AND status='leased' AND lease_token=%s AND leased_until>UTC_TIMESTAMP()",
                array( $payload, $id, self::TEST_TYPE, $lease_token )
            );
            if ( $checkpoint !== 1 ) { throw new RuntimeException( 'Checkpoint R2 gagal; lease tidak valid.' ); }
            $done = self::require_query(
                "UPDATE {$table} SET status='completed',lease_token=NULL,leased_until=NULL,next_run_at=NULL,last_error_code=NULL,finished_at=UTC_TIMESTAMP(),updated_at=UTC_TIMESTAMP() WHERE id=%d AND job_type=%s AND status='leased' AND lease_token=%s AND leased_until>UTC_TIMESTAMP()",
                array( $id, self::TEST_TYPE, $lease_token )
            );
            if ( $done !== 1 ) { throw new RuntimeException( 'Completion R2 gagal; lease tidak valid.' ); }
            return array( 'processed' => true, 'id' => $id, 'attempt' => $attempt, 'status' => 'completed', 'checkpoint' => 1 );
        } finally {
            self::unlock_own( $lock_token );
        }
    }

    /** Explicitly recover expired R2 leases only; no other job types touched. */
    public static function recover_expired(): array {
        self::assert_manual_write();
        $lock_token = self::lock();
        try {
            $table = self::table();
            $failed = self::require_query(
                "UPDATE {$table} SET status='failed',lease_token=NULL,leased_until=NULL,next_run_at=NULL,finished_at=UTC_TIMESTAMP(),last_error_code='R2_LEASE_EXPIRED',updated_at=UTC_TIMESTAMP() WHERE job_type=%s AND status='leased' AND leased_until<UTC_TIMESTAMP() AND attempt_count>=max_attempts",
                array( self::TEST_TYPE )
            );
            $retried = self::require_query(
                "UPDATE {$table} SET status='retry_wait',lease_token=NULL,leased_until=NULL,next_run_at=UTC_TIMESTAMP(),last_error_code='R2_LEASE_EXPIRED',updated_at=UTC_TIMESTAMP() WHERE job_type=%s AND status='leased' AND leased_until<UTC_TIMESTAMP() AND attempt_count<max_attempts",
                array( self::TEST_TYPE )
            );
            return array( 'failed' => $failed, 'retried' => $retried );
        } finally {
            self::unlock_own( $lock_token );
        }
    }

    /** Manual cancellation only for queued/retry_wait R2 smoke rows; never delete. */
    public static function cancel( int $id ): bool {
        self::assert_manual_write();
        if ( $id < 1 ) { throw new InvalidArgumentException( 'ID job harus positif.' ); }
        return self::require_query(
            "UPDATE " . self::table() . " SET status='cancelled',next_run_at=NULL,finished_at=UTC_TIMESTAMP(),updated_at=UTC_TIMESTAMP() WHERE id=%d AND job_type=%s AND status IN ('queued','retry_wait')",
            array( $id, self::TEST_TYPE )
        ) === 1;
    }

    /** Human-operated recovery after confirming no other WP-CLI step is running. */
    public static function unlock_stale(): bool {
        self::assert_manual_write();
        $stored = get_option( self::LOCK_OPTION, null );
        if ( ! is_array( $stored ) || ! isset( $stored['started'], $stored['token'] ) ) { return false; }
        if ( time() - (int) $stored['started'] < 600 ) {
            throw new RuntimeException( 'Mutex belum berumur 10 menit. Pastikan proses worker telah berhenti.' );
        }
        // Guard against a concurrently replaced token; no active process may run here.
        $current = get_option( self::LOCK_OPTION, null );
        if ( ! is_array( $current ) || ! hash_equals( (string) $stored['token'], (string) ( $current['token'] ?? '' ) ) ) {
            throw new RuntimeException( 'Mutex berubah; jangan menghapus token milik proses baru.' );
        }
        return delete_option( self::LOCK_OPTION );
    }
}
