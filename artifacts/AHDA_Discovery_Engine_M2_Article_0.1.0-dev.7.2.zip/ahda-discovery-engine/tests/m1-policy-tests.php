<?php
if ( PHP_SAPI !== 'cli' ) { exit(2); }
define('ABSPATH', __DIR__ . '/');
require_once dirname(__DIR__) . '/includes/class-ade-evidence-urls.php';
require_once dirname(__DIR__) . '/includes/class-ade-crawl-policy.php';
require_once dirname(__DIR__) . '/includes/class-ade-crawler.php';
$count=0;
function check($ok,$message) { global $count; ++$count; if(!$ok) { throw new RuntimeException('FAIL: '.$message); } }
function rejects(callable $f,$label) { $caught=false; try {$f();} catch(InvalidArgumentException|RuntimeException $e) {$caught=true;} check($caught,$label); }
$hosts=['school.sch.id'];
check(ADE_Crawl_Policy::url('https://school.sch.id/a?utm_source=demo',$hosts)==='https://school.sch.id/a','canonical URL');
foreach(['http://school.sch.id/','https://evil.sch.id/','https://school.sch.id.evil.com/','https://school.sch.id:8443/','https://user:pass@school.sch.id/','https://127.0.0.1/','https://[::1]/','file:///etc/passwd','https://school.sch.id/%0d%0aX','https://school.sch.id/a/../admin','https://school.sch.id/\\evil','https://school.local/'] as $url) {
 rejects(fn()=>ADE_Crawl_Policy::url($url,$hosts),'URL blocked '.$url);
}
foreach(['instagram.com','www.instagram.com','facebook.com','youtube.com','tiktok.com'] as $h) { rejects(fn()=>ADE_Crawl_Policy::url('https://'.$h.'/school',[$h]),'manual platform'); }
foreach(['0.0.0.0','10.1.1.1','100.64.1.1','127.0.0.1','169.254.169.254','172.16.1.1','192.0.0.9','192.0.2.1','192.168.1.1','198.18.0.1','198.51.100.1','203.0.113.1','224.0.0.1','255.255.255.255','::','::1','::ffff:8.8.8.8','64:ff9b::808:808','fc00::1','fe80::1','2001:db8::1','2001::1','2002:0808:0808::1','3fff::1','ff02::1','127.1','2130706433','not-an-ip'] as $ip) {
 check(!ADE_Crawl_Policy::public_ip($ip),'private/reserved IP blocked '.$ip);
}
foreach(['8.8.8.8','1.1.1.1','2606:4700:4700::1111'] as $ip) {check(ADE_Crawl_Policy::public_ip($ip),'global address accepted');}
foreach([[],['8.8.8.8','127.0.0.1'],['8.8.8.8','::1'],['8.8.8.8',null],array_fill(0,33,'8.8.8.8')] as $ips) {rejects(fn()=>ADE_Crawl_Policy::addresses($ips),'DNS empty/mixed/oversized blocked');}
check(ADE_Crawl_Policy::addresses(['8.8.8.8','8.8.8.8'])===['8.8.8.8'],'DNS dedupe');
foreach([301,302,303,307,308,401,403,404,429,500] as $code) {rejects(fn()=>ADE_Crawl_Policy::response($code,'text/html','x'),'non200 or redirect blocked');}
foreach(['application/octet-stream','image/svg+xml','application/pdf',''] as $type) {rejects(fn()=>ADE_Crawl_Policy::response(200,$type,'x'),'unsupported type');}
foreach(['text/html; charset=utf-8','application/json','text/csv'] as $type) {check(ADE_Crawl_Policy::response(200,$type,'abc')['sha256']===hash('sha256','abc'),'response hash');}
check(strlen(ADE_Crawl_Policy::response(200,'text/html',str_repeat('x',ADE_Crawl_Policy::MAX_BYTES))['body'])===ADE_Crawl_Policy::MAX_BYTES,'exact size limit');
rejects(fn()=>ADE_Crawl_Policy::response(200,'text/html',str_repeat('x',ADE_Crawl_Policy::MAX_BYTES+1)),'byte cap');
$permit=['url'=>'https://school.sch.id/a','hosts'=>$hosts,'robots_allowed'=>true,'terms_allowed'=>true,'expires_at'=>1100,'review_reference'=>'manual-review-1'];
check(ADE_Crawler::permission($permit['url'],$permit,1000)===$permit['url'],'specific reviewed URL');
foreach(['robots_allowed'=>false,'terms_allowed'=>false,'expires_at'=>999,'review_reference'=>'<script>','hosts'=>[],'url'=>'https://school.sch.id/b'] as $key=>$value) {$bad=$permit;$bad[$key]=$value;rejects(fn()=>ADE_Crawler::permission($permit['url'],$bad,1000),'permission blocked '.$key);}
$bad=$permit;$bad['expires_at']=1000000;rejects(fn()=>ADE_Crawler::permission($permit['url'],$bad,1000),'permission too long');
// No WP_CLI defined: approval guard must fail before any resolver or transport.
$called=false;$crawler=new ADE_Crawler(function()use(&$called){$called=true;return ['8.8.8.8'];});
rejects(fn()=>$crawler->fetch($permit['url'],$permit,'FETCH_M1_LOCAL'),'no CLI gate');
check(!$called,'guard before DNS');
echo "PASS: $count M1 policy checks (offline, no network).\n";
