<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** R0 administration page is strictly read-only. */
final class ADE_Admin_Status {
    public static function register(): void {
        add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
        add_action( 'admin_notices', array( __CLASS__, 'dependency_notice' ) );
    }

    public static function menu(): void {
        add_menu_page(
            'AHDA Discovery Engine — Status R4a',
            'AHDA Discovery',
            'manage_options',
            'ahda-discovery-status',
            array( __CLASS__, 'render' ),
            'dashicons-shield-alt',
            58
        );
        ADE_Admin_Review::menu();
    }

    public static function dependency_notice(): void {
        if ( ! current_user_can( 'manage_options' ) || ADE_Dependencies::ready() ) { return; }
        $url = admin_url( 'admin.php?page=ahda-discovery-status' );
        echo '<div class="notice notice-warning"><p>';
        echo esc_html( 'AHDA Discovery Engine R4a: API plugin AHDA induk belum lengkap atau belum terdeteksi. Tidak ada operasi discovery yang dijalankan. ' );
        echo '<a href="' . esc_url( $url ) . '">Lihat pemeriksaan R3</a>';
        echo '</p></div>';
    }

    public static function render(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Tidak diizinkan.', '', array( 'response' => 403 ) );
        }
        global $wpdb;
        $checks = ADE_Dependencies::report();
        $flags = ADE_Config::flags();
        $ready = ADE_Dependencies::ready();
        $env = function_exists( 'wp_get_environment_type' ) ? wp_get_environment_type() : 'tidak diketahui';
        $db_version = method_exists( $wpdb, 'db_version' ) ? $wpdb->db_version() : 'tidak diketahui';
        ?>
        <div class="wrap">
            <h1>AHDA Discovery Engine — Evidence Foundation R4a</h1>
            <p><strong>Versi:</strong> <?php echo esc_html( ADE_R0_VERSION ); ?> | <strong>Mode:</strong> status admin baca-saja; instalasi schema hanya WP-CLI eksplisit</p>
            <div class="notice notice-info inline"><p>
                R3 mempertahankan R1 Schema Installer dan R2 Job Engine. Pengamatan sumber dilakukan manual melalui WP-CLI, disimpan berstatus pending. Aktivasi dan halaman ini tidak mengakses jaringan, memulai worker, atau menerbitkan profil.
            </p></div>
            <h2>Kompatibilitas runtime</h2>
            <table class="widefat striped" style="max-width:850px"><tbody>
                <tr><th scope="row">WordPress</th><td><?php echo esc_html( get_bloginfo( 'version' ) ); ?></td></tr>
                <tr><th scope="row">PHP</th><td><?php echo esc_html( PHP_VERSION ); ?></td></tr>
                <tr><th scope="row">Database server</th><td><?php echo esc_html( (string) $db_version ); ?></td></tr>
                <tr><th scope="row">Lingkungan menurut WordPress</th><td><?php echo esc_html( $env ); ?></td></tr>
                <tr><th scope="row">Alamat situs</th><td><?php echo esc_html( home_url( '/' ) ); ?></td></tr>
                <tr><th scope="row">API AHDA induk</th><td><strong><?php echo esc_html( $ready ? 'Terpenuhi (method-level)' : 'Belum terpenuhi' ); ?></strong></td></tr>
            </tbody></table>
            <p><em>Versi plugin AHDA induk tidak disimpulkan dari nama folder. Kecocokan fungsi diperiksa langsung; untuk rilis berikutnya diperlukan verifikasi versi dan schema yang lebih lengkap.</em></p>
            <h2>Pemeriksaan metode induk</h2>
            <table class="widefat striped" style="max-width:850px"><thead><tr><th>API</th><th>Hasil</th></tr></thead><tbody>
            <?php foreach ( $checks as $check ) : ?>
                <tr><td><code><?php echo esc_html( $check['name'] ); ?></code></td><td><?php echo esc_html( $check['passed'] ? 'OK' : 'TIDAK TERSEDIA' ); ?></td></tr>
            <?php endforeach; ?>
            </tbody></table>
            <h2>Feature flags (baca-saja)</h2>
            <table class="widefat striped" style="max-width:850px"><thead><tr><th>Opsi</th><th>Nilai tersimpan</th><th>Default aman</th></tr></thead><tbody>
            <?php foreach ( $flags as $key => $state ) : ?>
                <tr><td><code><?php echo esc_html( $key ); ?></code></td>
                    <td><?php echo esc_html( $state['stored'] === null ? '(belum ada)' : $state['stored'] ); ?></td>
                    <td><?php echo esc_html( $state['expected'] ); ?><?php echo $state['valid'] ? ' — OK' : ' — PERIKSA'; ?></td></tr>
            <?php endforeach; ?>
            </tbody></table>
            <p><strong>Fail-closed:</strong> meskipun sebuah opsi diubah dari luar, R3 tidak menjalankan HTTP otomatis, crawler, review, maupun publikasi.</p>
            <h2>Schema R1 (informasi saja)</h2>
            <?php
            $schema_report = ADE_Schema::report();
            ?>
            <p><strong>Status:</strong> <?php echo esc_html( $schema_report['state'] ); ?> | <strong>Schema version:</strong> <?php echo esc_html( (string) ( get_option( 'ade_schema_version', '(belum dipasang)' ) ) ); ?></p>
            <p><?php echo esc_html( implode( '; ', $schema_report['issues'] ) ); ?></p>
            <p><strong>Tabel Discovery yang ditemukan:</strong> <?php echo esc_html( (string) count( $schema_report['existing_discovery'] ) ); ?> dari 7 tabel yang direncanakan.</p>
            <p>Untuk pemeriksaan dan pemasangan, buka LocalWP Site Shell lalu jalankan <code>wp ade schema preflight</code>, kemudian ikuti panduan R1. Halaman admin ini tidak memiliki tombol pemasangan.</p>
            <h2>Job Engine R2 — hanya uji manual</h2>
            <p>Tidak ada penjadwalan otomatis, crawler, atau operasi HTTP. Perintah baca-saja: <code>wp ade jobs preflight</code> dan <code>wp ade jobs status</code>. Pekerjaan uji sintetis hanya boleh dibuat atau dijalankan dengan konfirmasi WP-CLI eksplisit di ahda.local.</p>
            <h2>Source &amp; Identity Foundation R3 — manual only</h2>
            <p><strong>Tidak ada HTTP otomatis, DNS lookup, crawler, atau perubahan profil.</strong> R3 mengenali URL dan NPSN melalui perintah WP-CLI eksplisit. Sumber dan hubungan sekolah selalu berstatus <code>pending</code>, <code>manual_only</code>, dan tidak dianggap resmi.</p>
            <p>Perintah baca-saja: <code>wp ade sources preflight</code>, <code>wp ade sources selftest</code>, <code>wp ade sources check --source-url=https://sekolah.sch.id/</code>, <code>wp ade sources school --npsn=12345678</code>, dan <code>wp ade sources preview ...</code>.</p>
            <p>Penulisan satu observasi manual hanya melalui <code>wp ade sources observe ... --confirm=STORE_R3_PENDING</code> dan hanya menyentuh tabel sumber Discovery dan relasinya, tidak menyentuh tabel sekolah lama. Ikuti panduan R3.</p>
            <h2>Evidence Foundation R4a — manual only</h2>
            <p>R4a mencatat klaim faktual manual melalui <code>wp ade evidence preview</code>, <code>wp ade evidence record</code> (konfirmasi eksplisit), dan <code>wp ade evidence list</code>. Tidak melakukan HTTP, tidak mengklaim bukti cukup untuk ownership, dan tidak mengubah status relasi maupun profil sekolah.</p>
            <h2>Batasan dan langkah selanjutnya</h2>
            <p>Installer schema R1 tersedia hanya melalui WP-CLI dengan konfirmasi backup dan operasi. Semua operasi instalasi dibatasi pada tujuh tabel Discovery yang baru. Tidak ada sinkronisasi ke VPS produksi.</p>
        </div>
        <?php
    }
}
