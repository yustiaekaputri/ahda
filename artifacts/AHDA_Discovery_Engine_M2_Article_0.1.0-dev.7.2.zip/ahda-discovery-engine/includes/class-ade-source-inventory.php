<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Read existing verified URL fields only. Never certifies, stores or fetches. */
final class ADE_Source_Inventory {
    private static function read( string $suffix, string $columns, string $where, array $args ): array {
        global $wpdb;
        // Call sites are fixed internal definitions, not external table/SQL inputs.
        if ( ! in_array( $suffix, array( 'school_meta', 'school_details', 'school_socials' ), true ) ||
            ! preg_match( '/^[a-zA-Z0-9_]+$/D', (string) $wpdb->prefix ) || strlen( $wpdb->prefix . 'ahda_' . $suffix ) > 64 ) {
            throw new RuntimeException( 'INVENTORY_IDENTIFIER_BLOCKED' );
        }
        $table = $wpdb->prefix . 'ahda_' . $suffix;
        $wpdb->last_error = '';
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT {$columns} FROM {$table} WHERE {$where}", $args ), ARRAY_A );
        if ( ! is_array( $rows ) || $wpdb->last_error ) { throw new RuntimeException( 'INVENTORY_READ_FAILED' ); }
        return $rows;
    }

    private static function hints( int $school_id ): array {
        $meta = self::read( 'school_meta', 'meta_key,meta_value,verification_status',
            'school_id=%d AND verification_status=%s AND meta_key IN (%s,%s) ORDER BY meta_key LIMIT 3',
            array( $school_id, 'verified', 'profile_website', 'profile_source_url' ) );
        $details = self::read( 'school_details', 'official_website,verification_status',
            'school_id=%d AND verification_status=%s LIMIT 2', array( $school_id, 'verified' ) );
        $socials = self::read( 'school_socials', 'platform,profile_url,verification_status',
            'school_id=%d AND verification_status=%s AND platform IN (%s,%s,%s,%s) ORDER BY platform LIMIT 5',
            array( $school_id, 'verified', 'instagram', 'facebook', 'youtube', 'tiktok' ) );
        if ( count( $meta ) > 2 || count( $details ) > 1 || count( $socials ) > 4 ) { throw new RuntimeException( 'INVENTORY_INTEGRITY_ERROR' ); }
        $raw = array();
        foreach ( $meta as $row ) {
            if ( ! in_array( $row['meta_key'] ?? null, array( 'profile_website', 'profile_source_url' ), true ) ) { throw new RuntimeException( 'INVENTORY_ROW_INVALID' ); }
            $raw[] = array( 'value' => $row['meta_value'] ?? null, 'origin' => 'school_meta.' . $row['meta_key'], 'platform' => null, 'status' => $row['verification_status'] ?? null );
        }
        foreach ( $details as $row ) { $raw[] = array( 'value' => $row['official_website'] ?? null, 'origin' => 'school_details.official_website', 'platform' => null, 'status' => $row['verification_status'] ?? null ); }
        foreach ( $socials as $row ) {
            if ( ! in_array( $row['platform'] ?? null, array( 'instagram', 'facebook', 'youtube', 'tiktok' ), true ) ) { throw new RuntimeException( 'INVENTORY_ROW_INVALID' ); }
            $raw[] = array( 'value' => $row['profile_url'] ?? null, 'origin' => 'school_socials.' . $row['platform'], 'platform' => $row['platform'], 'status' => $row['verification_status'] ?? null );
        }
        $hints = array(); $rejected = array();
        foreach ( $raw as $row ) {
            if ( $row['status'] !== 'verified' ) { throw new RuntimeException( 'INVENTORY_UNVERIFIED_ROW' ); }
            if ( null === $row['value'] || '' === $row['value'] ) { continue; }
            if ( ! is_string( $row['value'] ) ) { throw new RuntimeException( 'INVENTORY_ROW_INVALID' ); }
            try {
                $source = ADE_Source_URLs::canonicalize( $row['value'] );
                $sensitive = false;
                foreach ( explode( '&', (string) parse_url( $source['canonical_url'], PHP_URL_QUERY ) ) as $pair ) {
                    $key = strtolower( rawurldecode( explode( '=', $pair, 2 )[0] ) );
                    if ( $key === 'key' || preg_match( '/token|secret|password|authorization|credential|signature|nonce|api[_-]?key/i', $key ) ) { $sensitive = true; }
                }
                if ( $sensitive ) { $rejected[] = array( 'origin' => $row['origin'], 'code' => 'SENSITIVE_QUERY_BLOCKED' ); continue; }
                if ( null !== $row['platform'] && $source['platform'] !== $row['platform'] ) {
                    $rejected[] = array( 'origin' => $row['origin'], 'code' => 'PLATFORM_MISMATCH' ); continue;
                }
            } catch ( InvalidArgumentException $e ) {
                // No raw unsafe URL or DB error is echoed into reports.
                $rejected[] = array( 'origin' => $row['origin'], 'code' => 'URL_FORMAT_REJECTED' ); continue;
            }
            $key = $source['canonical_key'];
            if ( ! isset( $hints[$key] ) ) {
                $hints[$key] = array( 'canonical_url' => $source['canonical_url'], 'canonical_key' => $key,
                    'source_type' => $source['source_type'], 'platform' => $source['platform'],
                    'origins' => array(), 'legacy_storage_verification' => 'verified',
                    'identity_status' => 'pending', 'access_state' => 'manual_only', 'fetch_permission' => 'NOT_GRANTED' );
            }
            if ( ! in_array( $row['origin'], $hints[$key]['origins'], true ) ) { $hints[$key]['origins'][] = $row['origin']; }
        }
        return array( 'hints' => array_values( $hints ), 'rejected' => $rejected );
    }

    /** Operator-triggered bounded preview on the current immutable pilot only. */
    public static function preview( array $manifest, int $after = 0, int $size = 10 ): array {
        ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
        if ( ( $manifest['version'] ?? null ) !== 2 ) { throw new RuntimeException( 'INVENTORY_REQUIRES_FROZEN_SCOPE' ); }
        $batch = ADE_Pilot::batch( $manifest, $after, $size );
        $results = array();
        foreach ( $batch['results'] as $school ) {
            $inventory = self::hints( $school['school_id'] );
            $results[] = array( 'school_id' => $school['school_id'], 'npsn' => $school['npsn'],
                'discovery_link_count_capped_at_5' => $school['source_count_capped_at_5'],
                'hint_count' => count( $inventory['hints'] ), 'url_hints' => $inventory['hints'],
                'rejected' => $inventory['rejected'],
                'outcome' => $inventory['hints'] ? 'review_existing_url_hints' : $school['outcome'] );
        }
        return array( 'mode' => 'READ_ONLY_NO_FETCH', 'scope' => $manifest['scope'], 'manifest_hash' => $manifest['hash'],
            'after' => $after, 'cursor' => $batch['cursor'], 'complete' => $batch['complete'], 'results' => $results,
            'network_requests' => 0, 'database_writes' => 0 );
    }
}
