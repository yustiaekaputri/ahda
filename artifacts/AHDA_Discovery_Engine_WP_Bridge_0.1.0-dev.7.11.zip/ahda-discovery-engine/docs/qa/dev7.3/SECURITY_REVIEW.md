# dev.7.3 security review

Runtime diff: new document adapter, CLI parse and version/class load. Existing
writer/schema/Directory/crawler/flags and review/publish hooks unchanged. No new
admin forms/mutations or CSRF/nonce surface. Native CLI scope/current-meta SELECT
uses established prepared SQL/prefix checks; per-command local/capability gate and
explicit true dry-run. No fetch/DNS/model/export/persistence in parser.

CSV: deterministic strict grammar, exact header/columns, byte/row/value budgets,
quote recovery forbidden, formula-leading cells blocked, same NPSN every row,
fixed targets, duplicate dedupe/conflicting claims block. HTML: actual DOM,
NONET, no NOENT/DTDLOAD, external/ENTITY/processing declarations rejected, inert
HTML5 doctype only, explicit hidden/non-content nodes ignored, no asset loading
or script evaluation, same-table identity and ambiguity/block/resource limits.
No inferencing from arbitrary prose. Source URL/query/plain-text/quote/NPSN checks
inherited from M2. Test external-resource resolver sentinel observes zero loads.

DOM normalized text is not original byte slices or factual certification. Raw
SHA-256 stays in preview only; raw archive persistence requires future contract.
CSS/layout/JS not computed; sophisticated hidden styles and repaired malformed
HTML require human check. Literal containment not source authority or truth.
All data unverified and pending; current writer still rejects fixture/stale input
and requires separate approval/token/backup. No frontend SEO or new target fields.

Native actual MySQL tests validate parser-to-pending persistence/replay under
WP/wpdb/preflight stubs with explicit disposable consent; never real LocalWP data.
Full WP/nonce/review/publisher/transport/queue concurrency remain incomplete or
unverified. No guarantee of production security, completeness, SEO rankings or
AI recommendations. No real school documents or secrets fetched/printed.
