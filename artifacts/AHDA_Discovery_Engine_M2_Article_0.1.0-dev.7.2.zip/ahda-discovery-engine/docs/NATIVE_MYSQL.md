# Native disposable MySQL test — 2026-11-10

Operator explicitly approved temporary cloud MySQL8.4 synthetic tests only.
Actual engine8.4.13:70checks PASS. Seven tables created from unmodified actual
ADE_Schema::create_sql()/definitions(), InnoDB/utf8mb4, two synthetic legacy tables
and one synthetic source relation. No user/LocalWP/production records or secrets.
No external source request. Fixture flag false is used exclusively inside this
isolated test to exercise writer; test data remains synthetic and is discarded.

Covered: stage without writes, exact pending inserts, native dedupe/replay,
receipt read, review/approval defaults, actual transaction rollback at all10
insert positions, actual COMMIT plus simulated lost acknowledgment and recovery,
appending evidence/version increments, two-session GET_LOCK contention and
FOR UPDATE NOWAIT row lock, changed-review stale token, reviewed candidate/link
immutability, changed-current-meta snapshot, quoted SQL literal roundtrip,
legacy/source/review row hashes preserved. Native article identity SELECT tested.

WordPress functions, capabilities, local-site context and ADE_Jobs::preflight are
stubs. wpdb-compatible adapter uses mysqli/escaping; not WordPress wpdb itself.
Missing: real WordPress bootstrap/preflight/capability integration, full native
queue/concurrency load, native external version-race injection, genuine network
commit-ack interruption, deadlock recovery and frontend/publisher integration.
Therefore this is native MySQL integration under WP stubs, NOT LocalWP end-to-end
PASS or production readiness. Fake DB tests still cover additional failure paths.

Official image pinned:
mysql@sha256:a81d043930e51745522bd5c430961cf8286f0a23f0a9a2a6e0108f7ea71b0902
Temporary container:1CPU/1GiB,512MiB tmpfs database, ephemeral loopback-only port,
no existing volumes, random password only in process/container environment.
Test container/storage removed in finally; approved image cache retained for
reproducibility. No Docker daemon restart or other container manipulation.

Opt-in harness: tests/native/run-disposable.py. Does not run in bin/test-offline.sh.
Requires operator approval, healthy local managed Docker, approved official image
already pulled, PHP8.2 mysqli/mysqlnd modules. Never point at an existing DB.
Example for an independently approved disposable environment:

```
python3 tests/native/run-disposable.py --approved-disposable-mysql \
  --php-bin=/path/to/php8.2 --extension-dir=/path/to/php/modules \
  --output-dir=/path/to/test-logs
```

The runner creates its own fixed-name database on a new uniquely named local
container and accepts no arbitrary database/host/credential input. Test name,
password and port generated per run. Do not execute native PHP test manually
against ahda.local. Logs contain safe result/digest/exit/cleanup metadata only.
Cloud disposable approval does not authorize LocalWP real data writes.
