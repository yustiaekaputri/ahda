<?php
if(PHP_SAPI!=='cli'||getenv('AHDA_UI_FIXTURE_ONLY')!=='SYNTHETIC_NO_WORDPRESS'){exit(2);}
$path=getenv('AHDA_UI_FIXTURE_DATA_FILE');if(!is_string($path)||$path===''){exit(2);}
require dirname(__DIR__).'/m3-inspector-tests.php';
$db=fresh();$db->inner->schools['20268071']['name']='SMP CONTOH UJI (DATA SINTETIS)';
$list=ADE_Candidate_Inspector::listing('20268071');$detail=ADE_Candidate_Inspector::detail('20268071',42);
$db->meta=[['meta_value'=>'Nilai terverifikasi yang diubah editor lain','value_bytes'=>44]];$conflict=ADE_Candidate_Inspector::detail('20268071',42);
$empty=$list;$empty['candidates']=[];
$xss=$detail;$payload='<img src=x onerror="window.__AHDA_XSS=1"><script>window.__AHDA_XSS=1</script>';
$xss['school']['name']=$payload;$xss['candidate']['proposed_value']=$payload;$xss['candidate']['current_value_snapshot']=$payload;$xss['current_verified_value']=$payload;$xss['candidate']['approved_value']=$payload;$xss['evidence'][0]['snippet_text']=$payload;
$db=fresh();$o=['value'=>'Program uji','scope_hash'=>ADE_Pilot_Scope::SHA256,'provenance'=>'stored_raw_archive','raw_receipt_id'=>123,'raw_payload_sha256'=>str_repeat('a',64),'document_key'=>str_repeat('b',64),'raw_document_sha256'=>str_repeat('c',64),'archive_evidence_key'=>str_repeat('d',64),'format'=>'csv'];
$db->evidence[0]['parse_status']='m2_archive_unverified';$db->evidence[0]['observed_value']=json_encode($o);$db->evidence[0]['observed_bytes']=strlen($db->evidence[0]['observed_value']);$archive=ADE_Candidate_Inspector::detail('20268071',42);
file_put_contents($path,json_encode(['listing'=>$list,'detail'=>$detail,'conflict'=>$conflict,'empty'=>$empty,'xss'=>$xss,'archive'=>$archive],JSON_THROW_ON_ERROR));
