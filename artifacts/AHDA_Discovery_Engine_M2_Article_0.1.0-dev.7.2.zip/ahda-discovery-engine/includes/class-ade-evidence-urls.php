<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** R4a: offline-only, public-domain URL validation for evidence documents/posts. */
final class ADE_Evidence_URLs {
    private const BLOCKED_TLDS = array( 'local', 'localhost', 'internal', 'test', 'example', 'invalid', 'lan', 'home', 'onion', 'arpa' );
    private const TRACKING = array( 'fbclid', 'gclid', 'igshid', 'mc_cid', 'mc_eid' );

    public static function canonicalize( string $raw ): string {
        $raw = trim( $raw );
        if ( '' === $raw || strlen( $raw ) > 1000 || preg_match( '/[\x00-\x20\x7f\\\\]/', $raw ) || preg_match( '/%(?:0[0-9a-f]|1[0-9a-f]|7f|5c|2f)/i', $raw ) ) {
            throw new InvalidArgumentException( 'Evidence URL kosong/terlalu panjang atau mengandung karakter tidak aman.' );
        }
        $p = parse_url( $raw );
        if ( ! is_array( $p ) || ! isset( $p['scheme'], $p['host'] ) || isset( $p['user'] ) || isset( $p['pass'] ) ) {
            throw new InvalidArgumentException( 'Evidence URL wajib http(s) dengan host domain publik, tanpa kredensial.' );
        }
        $scheme = strtolower( (string) $p['scheme'] );
        if ( ! in_array( $scheme, array( 'https', 'http' ), true ) ) {
            throw new InvalidArgumentException( 'Evidence URL hanya http/https.' );
        }
        $host = strtolower( rtrim( (string) $p['host'], '.' ) );
        if ( strlen( $host ) > 190 || ! preg_match( '/^[a-z0-9.-]+$/D', $host ) || filter_var( $host, FILTER_VALIDATE_IP ) ) {
            throw new InvalidArgumentException( 'Evidence host tidak valid atau berupa IP.' );
        }
        $labels = explode( '.', $host );
        if ( count( $labels ) < 2 ) { throw new InvalidArgumentException( 'Evidence host bukan domain publik.' ); }
        foreach ( $labels as $label ) {
            if ( strlen( $label ) < 1 || strlen( $label ) > 63 || ! preg_match( '/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/D', $label ) ) {
                throw new InvalidArgumentException( 'Evidence host memiliki label domain yang tidak valid.' );
            }
        }
        $tld = end( $labels );
        if ( in_array( $tld, self::BLOCKED_TLDS, true ) || ! preg_match( '/^(?:[a-z]{2,63}|xn--[a-z0-9-]{2,59})$/D', $tld ) ) {
            throw new InvalidArgumentException( 'Evidence host tidak didukung / domain privat.' );
        }
        if ( isset( $p['port'] ) && (int) $p['port'] !== ( 'https' === $scheme ? 443 : 80 ) ) {
            throw new InvalidArgumentException( 'Evidence URL dengan port khusus ditolak.' );
        }
        if ( in_array( $host, array( 'www.instagram.com', 'm.instagram.com', 'www.facebook.com', 'm.facebook.com', 'www.youtube.com', 'm.youtube.com', 'www.tiktok.com', 'm.tiktok.com' ), true ) ) {
            $host = preg_replace( '/^(?:www|m)\./', '', $host );
        }
        $path = isset( $p['path'] ) && '' !== $p['path'] ? (string) $p['path'] : '/';
        if ( substr( $path, 0, 1 ) !== '/' || preg_match( '~(?:^|/)(?:\.{1,2}|%2e(?:%2e)?)(?:/|$)~i', $path ) ) {
            throw new InvalidArgumentException( 'Evidence path tidak aman.' );
        }
        if ( '/' !== $path ) { $path = rtrim( $path, '/' ); }
        $query_parts = array();
        foreach ( explode( '&', (string) ( $p['query'] ?? '' ) ) as $kv ) {
            if ( '' === $kv ) { continue; }
            $key = strtolower( rawurldecode( explode( '=', $kv, 2 )[0] ) );
            if ( strpos( $key, 'utm_' ) === 0 || in_array( $key, self::TRACKING, true ) ) { continue; }
            $query_parts[] = $kv;
        }
        $query = implode( '&', $query_parts );
        $url = $scheme . '://' . $host . $path . ( '' !== $query ? '?' . $query : '' );
        if ( strlen( $url ) > 1000 ) { throw new InvalidArgumentException( 'Evidence canonical URL terlalu panjang.' ); }
        return $url;
    }
}
