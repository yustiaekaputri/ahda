<?php
if(PHP_SAPI!=='cli'||getenv('AHDA_UI_FIXTURE_ONLY')!=='SYNTHETIC_NO_WORDPRESS'){exit(2);}
$path=getenv('AHDA_UI_FIXTURE_DATA_FILE');if(!is_string($path)||$path===''){exit(2);}
require dirname(__DIR__).'/m3-inspector-tests.php';
$db=fresh();$db->inner->schools['20268071']['name']='SMP CONTOH UJI (DATA SINTETIS)';
$list=ADE_Candidate_Inspector::listing('20268071');$detail=ADE_Candidate_Inspector::detail('20268071',42);
$db->meta=[['meta_value'=>'Nilai terverifikasi yang diubah editor lain','value_bytes'=>44]];$conflict=ADE_Candidate_Inspector::detail('20268071',42);
$empty=$list;$empty['candidates']=[];
$xss=$detail;$payload='<img src=x onerror="window.__AHDA_XSS=1"><script>window.__AHDA_XSS=1</script>';
$xss['school']['name']=$payload;$xss['candidate']['proposed_value']=$payload;$xss['candidate']['current_value_snapshot']=$payload;$xss['current_verified_value']=$payload;$xss['candidate']['approved_value']=$payload;$xss['evidence'][0]['snippet_text']=$payload;
file_put_contents($path,json_encode(['listing'=>$list,'detail'=>$detail,'conflict'=>$conflict,'empty'=>$empty,'xss'=>$xss],JSON_THROW_ON_ERROR));
