<?php
/** R4a offline fake DB simulation. NOT a WordPress/MySQL integration test. */
if ( PHP_SAPI !== 'cli' ) { exit(2); }
define( 'ABSPATH', __DIR__ . '/' );
define( 'WP_CLI', true );
define( 'ARRAY_A', 'ARRAY_A' );
final class WP_CLI {}
final class ADE_Schema { public static function table_name( string $s ): string { return 'wp_ahda_discovery_' . $s; } }
final class ADE_Sources { public static function preflight(): array { return array( 'ready' => true ); } }
function sanitize_textarea_field( $s ) { return trim( strip_tags( (string) $s ) ); }
function sanitize_text_field( $s ) { return trim( strip_tags( (string) $s ) ); }
function current_time( $t, $utc ) { return '2026-11-09 00:00:00'; }
final class FakeDB {
    public $prefix = 'wp_';
    public $last_error = '';
    public $insert_id = 0;
    public $fail_evidence_insert = false;
    public $transaction = false;
    public $rows = array();
    public $write_targets = array();
    private $snapshot;
    private $next = 1;
    public function prepare( $sql, ...$args ) {
        if ( count($args)===1 && is_array($args[0]) ) { $args=$args[0]; }
        $i=0;
        return preg_replace_callback('/%[ds]/', static function ($m) use ($args,&$i) {
            $arg=$args[$i++]; return $m[0]==='%d' ? (string)(int)$arg : "'" . str_replace("'", "''", (string)$arg) . "'";
        }, $sql);
    }
    public function get_results( $sql, $kind = null ) {
        if ( strpos($sql,'FROM wp_ahda_schools')!==false ) {
            preg_match("/npsn='([0-9]+)'/",$sql,$m);
            if(($m[1]??'')!=='20515441') { return array(); }
            return array(array('id'=>196744,'npsn'=>'20515441','name'=>'SMKN 1 BANDUNG','school_form'=>'SMK','education_level'=>'PENDIDIKAN MENENGAH','regency_raw'=>'KAB. TULUNGAGUNG','district_raw'=>'KEC. BANDUNG','village_raw'=>'BANTENGAN','visibility'=>'publish'));
        }
        if ( strpos($sql,'FROM wp_ahda_discovery_sources s INNER JOIN wp_ahda_discovery_school_sources l')!==false ) {
            preg_match('/l.school_id=(\d+) AND s.canonical_key=\'([a-f0-9]{64})\'/',$sql,$m);
            $expected=ADE_Source_URLs::canonicalize('https://instagram.com/smknbandung');
            if((int)($m[1]??0)!==196744 || ($m[2]??'')!==$expected['canonical_key']) { return array(); }
            return array(array('source_id'=>1,'relation_id'=>1,'identity_status'=>'pending','relationship_type'=>'pending','access_state'=>'manual_only'));
        }
        if ( strpos($sql,'FROM wp_ahda_discovery_evidence')!==false && strpos($sql,'ORDER BY id DESC')!==false ) {
            preg_match('/school_id=(\d+)/',$sql,$m);
            return array_values(array_reverse(array_filter($this->rows,static function($r)use($m){return $r['school_id']===(int)($m[1]??0);}))) ;
        }
        throw new RuntimeException('Unexpected SELECT: '.$sql);
    }
    public function get_var( $sql ) {
        if ( strpos($sql,'SELECT id FROM wp_ahda_discovery_evidence WHERE evidence_key=')!==false ) {
            preg_match("/evidence_key='([a-f0-9]{64})'/",$sql,$m);
            foreach($this->rows as $r) { if($r['evidence_key']===($m[1]??'')) { return $r['id']; } }
            return null;
        }
        throw new RuntimeException('Unexpected scalar read: '.$sql);
    }
    public function query( $sql ) {
        if ($sql==='START TRANSACTION') { if($this->transaction){throw new RuntimeException('Nested transaction');} $this->transaction=true;$this->snapshot=array($this->rows,$this->next);return 0; }
        if ($sql==='COMMIT') {$this->transaction=false;return 0;}
        if ($sql==='ROLLBACK') {if($this->transaction){list($this->rows,$this->next)=$this->snapshot;}$this->transaction=false;return 0;}
        throw new RuntimeException('Unexpected DB transaction command');
    }
    public function insert( $table, $fields ) {
        $this->write_targets[]=$table;
        if ($table!=='wp_ahda_discovery_evidence') { throw new RuntimeException('Unexpected write target: '.$table); }
        if ($this->fail_evidence_insert) { $this->last_error='insert failure'; return false; }
        foreach($this->rows as $r){if($r['evidence_key']===$fields['evidence_key']){$this->last_error='duplicate';return false;}}
        $fields['id']=$this->next++;
        $this->insert_id=$fields['id'];
        $this->rows[$this->insert_id]=$fields;
        $this->last_error='';return 1;
    }
}
$wpdb = new FakeDB();
require_once dirname(__DIR__).'/includes/class-ade-source-urls.php';
require_once dirname(__DIR__).'/includes/class-ade-evidence-urls.php';
require_once dirname(__DIR__).'/includes/class-ade-identity.php';
require_once dirname(__DIR__).'/includes/class-ade-evidence.php';
$n=0;
$ok=static function($val,$label)use(&$n){$n++;if(!$val){fwrite(STDERR,"FAIL #{$n}: {$label}\n");exit(1);}};
$src='https://www.instagram.com/smknbandung/';
$ev='https://www.smknbandung.sch.id/berita/akun-instagram?utm_source=demo';
$normalize=ADE_Evidence_URLs::canonicalize($ev);
$ok($normalize==='https://www.smknbandung.sch.id/berita/akun-instagram','offline evidence URL normalization');
$ok(ADE_Evidence_URLs::canonicalize('https://www.instagram.com/p/EXAMPLE123/?utm_source=demo')==='https://instagram.com/p/EXAMPLE123','Instagram post evidence allowed');
foreach(array('http://127.0.0.1/','http://localhost/x','http://192.168.1.1/','https://foo.local/x','file:///etc/passwd','https://user:pw@school.sch.id/','https://school.sch.id:8080/','https://school.sch.id/%2e%2e/secret','https://a.sch.id/%0aevil','https://foo.example/x') as $bad){
    $threw=false;try{ADE_Evidence_URLs::canonicalize($bad);}catch(InvalidArgumentException $e){$threw=true;}
    $ok($threw,'reject unsafe URL '.$bad);
}
$p=ADE_Evidence::preview('20515441',$src,$ev,'document','school_relationship','Website sekolah mencantumkan akun Instagram.','Tautan resmi');
$ok($p['source_id']===1 && $p['relation_id']===1 && $p['identity_status']==='pending','matched pending relation');
$ok(count($wpdb->rows)===0,'preview no writes');
$a=ADE_Evidence::record('20515441',$src,$ev,'document','school_relationship','Website sekolah mencantumkan akun Instagram.','Tautan resmi');
$ok($a['created'] && $a['id']===1,'new evidence');
$ok($wpdb->rows[1]['parse_status']==='manual' && $wpdb->rows[1]['content_fingerprint']===null,'manual provenance, no invented fetch');
$ok($wpdb->rows[1]['observed_value']==='Website sekolah mencantumkan akun Instagram.','claim stored');
$b=ADE_Evidence::record('20515441',$src,$ev,'document','school_relationship','Website sekolah mencantumkan akun Instagram.','Tautan resmi');
$ok(!$b['created'] && $b['id']===$a['id'] && count($wpdb->rows)===1,'idempotency');
$c=ADE_Evidence::record('20515441',$src,$ev,'document','school_relationship','Keterangan baru, harus membuat versi bukti baru.');
$ok($c['created'] && count($wpdb->rows)===2,'material claim change is a distinct evidence');
$ok(count(ADE_Evidence::list_for_school('20515441')['rows'])===2,'read-only list');
$threw=false;try{ADE_Evidence::record('12345678',$src,$ev,'document','school_relationship','claim');}catch(RuntimeException $e){$threw=true;}
$ok($threw,'nonexistent NPSN fails');
$threw=false;try{ADE_Evidence::record('20515441','https://instagram.com/notlinked',$ev,'document','school_relationship','claim');}catch(RuntimeException $e){$threw=true;}
$ok($threw,'unlinked source fails');
$threw=false;try{ADE_Evidence::record('20515441',$src,$ev,'document','school_relationship','');}catch(InvalidArgumentException $e){$threw=true;}
$ok($threw,'empty claim fails');
$threw=false;try{ADE_Evidence::record('20515441',$src,$ev,'document','school_relationship','x',str_repeat('A',256));}catch(InvalidArgumentException $e){$threw=true;}
$ok($threw,'overlong title fails');
$threw=false;try{ADE_Evidence::record('20515441',$src,$ev,'document','wrong-attribute','claim');}catch(InvalidArgumentException $e){$threw=true;}
$ok($threw,'unknown attribute fails');
$wpdb->fail_evidence_insert=true;
$threw=false;try{ADE_Evidence::record('20515441',$src,'https://smknbandung.sch.id/unique-page','document','school_relationship','new');}catch(RuntimeException $e){$threw=true;}
$ok($threw && !$wpdb->transaction && count($wpdb->rows)===2,'rollback on failed insert');
$ok(count(array_unique($wpdb->write_targets))===1 && $wpdb->write_targets[0]==='wp_ahda_discovery_evidence','write isolation evidence only');
echo 'PASS: '.$n." R4a manual evidence simulations (fake DB; no LocalWP/MySQL writes).\n";
