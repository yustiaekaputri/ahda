Pre-final-review run PASS149 service +47 browser checks. Retained historical scope; final run adds revocation phantom test, request normalization and UI wording.
