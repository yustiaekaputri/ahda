<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Explicit local raw-receipt batch; candidate + checkpoint commit together. */
final class ADE_Archive_Batch {
    public const TYPE = 'm2_archive_batch';
    private const BLOCKED_CODES = array( 'VAULT_SCHOOL_BINDING_CONFLICT', 'VAULT_DOCUMENTS_NOT_READY', 'VAULT_BOUND_SOURCES_REQUIRED' );
    private const SCOPE_CAP = 32768;
    private const STATS_CAP = 131072;
    public static function enabled(): bool { return defined( 'ADE_LOCAL_ARCHIVE_BATCH_ENABLED' ) && ADE_LOCAL_ARCHIVE_BATCH_ENABLED === true; }
    private static function guard( bool $write = false ): int {
        if ( $write && ! self::enabled() ) { throw new RuntimeException( 'AB_WRITES_DISABLED' ); }
        ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
        if ( ! current_user_can( 'ade_review_candidates' ) || (int) get_current_user_id() < 1 ) { throw new RuntimeException( 'AB_REVIEW_OPERATOR_REQUIRED' ); } return (int) get_current_user_id();
    }
    private static function rows( string $sql, array $args = array() ): array {
        global $wpdb; $wpdb->last_error = ''; $out = $wpdb->get_results( $args ? $wpdb->prepare( $sql, $args ) : $sql, ARRAY_A );
        if ( ! is_array( $out ) || $wpdb->last_error ) { throw new RuntimeException( 'AB_READ_FAILED' ); } return $out;
    }
    private static function one( string $sql, array $args ): ?array { $r = self::rows( $sql, $args ); if ( count( $r ) > 1 ) { throw new RuntimeException( 'AB_ROW_NOT_UNIQUE' ); } return $r[0] ?? null; }
    private static function query( string $sql, array $args = array() ): int {
        global $wpdb; $wpdb->last_error = ''; $out = $wpdb->query( $args ? $wpdb->prepare( $sql, $args ) : $sql );
        if ( false === $out || $wpdb->last_error ) { throw new RuntimeException( 'AB_WRITE_FAILED' ); } return (int) $out;
    }
    private static function consent( string $actual, string $expected, string $backup ): void {
        if ( $actual !== $expected || $backup !== 'YES' ) { throw new RuntimeException( 'AB_EXPLICIT_CONFIRMATION_REQUIRED' ); }
    }
    private static function manifest_valid( array $m ): void {
        ADE_Local_Archive::keys( $m, array( 'schema_version', 'scope_hash', 'actor_user_id', 'entries' ) );
        if ( $m['schema_version'] !== 1 || $m['scope_hash'] !== ADE_Pilot_Scope::SHA256 || ! is_int( $m['actor_user_id'] ) || $m['actor_user_id'] < 1 || ! is_array( $m['entries'] ) || count( $m['entries'] ) < 1 || count( $m['entries'] ) > 200 || ! array_is_list( $m['entries'] ) ) { throw new InvalidArgumentException( 'AB_MANIFEST_INVALID' ); }
        $previous = 0; $seen = array();
        foreach ( $m['entries'] as $e ) {
            if ( ! is_array( $e ) ) { throw new InvalidArgumentException( 'AB_MANIFEST_INVALID' ); } ADE_Local_Archive::keys( $e, array( 'npsn', 'school_id', 'raw_receipt_id' ) );
            if ( ! is_string( $e['npsn'] ) || ! ADE_Pilot_Scope::contains( $e['npsn'] ) || ! is_int( $e['school_id'] ) || $e['school_id'] <= $previous || ! is_int( $e['raw_receipt_id'] ) || $e['raw_receipt_id'] < 1 || isset( $seen['n'.$e['npsn']] ) || isset( $seen['r'.$e['raw_receipt_id']] ) ) { throw new InvalidArgumentException( 'AB_MANIFEST_INVALID' ); }
            $previous = $e['school_id']; $seen['n'.$e['npsn']] = true; $seen['r'.$e['raw_receipt_id']] = true;
        }
    }
    private static function freeze( string $raw, int $actor ): array {
        $input = ADE_Strict_JSON::decode( $raw, self::SCOPE_CAP ); ADE_Local_Archive::keys( $input, array( 'schema_version', 'scope_hash', 'entries' ) );
        if ( $input['schema_version'] !== 1 || $input['scope_hash'] !== ADE_Pilot_Scope::SHA256 || ! is_array( $input['entries'] ) || ! array_is_list( $input['entries'] ) || count( $input['entries'] ) < 1 || count( $input['entries'] ) > 200 ) { throw new InvalidArgumentException( 'AB_INPUT_INVALID' ); }
        $entries = array();
        foreach ( $input['entries'] as $e ) {
            if ( ! is_array( $e ) ) { throw new InvalidArgumentException( 'AB_INPUT_INVALID' ); } ADE_Local_Archive::keys( $e, array( 'npsn', 'raw_receipt_id' ) );
            if ( ! is_string( $e['npsn'] ) || ! ADE_Pilot_Scope::contains( $e['npsn'] ) || ! is_int( $e['raw_receipt_id'] ) || $e['raw_receipt_id'] < 1 ) { throw new InvalidArgumentException( 'AB_INPUT_INVALID' ); }
            $s = ADE_Identity::lookup_pilot( $e['npsn'] ); ADE_Pilot_Scope::assert_school( $s );
            $entries[] = array( 'npsn' => $e['npsn'], 'school_id' => (int) $s['id'], 'raw_receipt_id' => $e['raw_receipt_id'] );
        }
        usort( $entries, static function( array $a, array $b ): int { return $a['school_id'] <=> $b['school_id']; } );
        $m = array( 'schema_version' => 1, 'scope_hash' => ADE_Pilot_Scope::SHA256, 'actor_user_id' => $actor, 'entries' => $entries ); self::manifest_valid( $m ); return $m;
    }
    private static function op( array $m ): string { return ADE_Local_Archive::digest( array( self::TYPE, $m ) ); }
    private static function encode_stats( array $results ): string {
        $body = array( 'schema_version' => 1, 'next_index' => count( $results ), 'results' => $results ); $body['sha256'] = ADE_Local_Archive::digest( $body ); $raw = json_encode( $body, JSON_THROW_ON_ERROR ); if ( strlen( $raw ) > self::STATS_CAP ) { throw new RuntimeException( 'AB_STATS_TOO_LARGE' ); } return $raw;
    }
    private static function job( int $id, bool $lock = false ): array {
        if ( $id < 1 ) { throw new InvalidArgumentException( 'AB_ID_INVALID' ); } $table = ADE_Schema::table_name( 'jobs' ); $end = $lock ? ' FOR UPDATE NOWAIT' : '';
        $r = self::one( "SELECT id,job_key,status,attempt_count,max_attempts,cursor_school_id,lease_token,leased_until,(leased_until>UTC_TIMESTAMP()) AS lease_live,last_error_code,LEFT(scope_filter,32769) AS scope_filter,OCTET_LENGTH(scope_filter) AS scope_bytes,LEFT(stats_payload,131073) AS stats_payload,OCTET_LENGTH(stats_payload) AS stats_bytes FROM {$table} WHERE id=%d AND job_type=%s LIMIT 1{$end}", array( $id, self::TYPE ) );
        if ( ! $r ) { throw new RuntimeException( 'AB_JOB_NOT_FOUND' ); }
        if ( (int) $r['scope_bytes'] > self::SCOPE_CAP || (int) $r['stats_bytes'] > self::STATS_CAP || ! in_array( $r['status'], array( 'queued', 'leased', 'retry_wait', 'failed', 'completed', 'cancelled' ), true ) || (int) $r['max_attempts'] !== 3 || (int) $r['attempt_count'] < 0 || (int) $r['attempt_count'] > 3 ) { throw new RuntimeException( 'AB_JOB_INVALID' ); }
        $m = ADE_Strict_JSON::decode( $r['scope_filter'], self::SCOPE_CAP ); self::manifest_valid( $m ); if ( ! hash_equals( self::op( $m ), $r['job_key'] ) ) { throw new RuntimeException( 'AB_JOB_INVALID' ); }
        $s = ADE_Strict_JSON::decode( $r['stats_payload'], self::STATS_CAP ); ADE_Local_Archive::keys( $s, array( 'schema_version', 'next_index', 'results', 'sha256' ) ); $h = $s['sha256']; unset( $s['sha256'] );
        if ( $s['schema_version'] !== 1 || ! is_int( $s['next_index'] ) || ! is_array( $s['results'] ) || ! array_is_list( $s['results'] ) || $s['next_index'] !== count( $s['results'] ) || $s['next_index'] > count( $m['entries'] ) || ! is_string( $h ) || ! hash_equals( ADE_Local_Archive::digest( $s ), $h ) ) { throw new RuntimeException( 'AB_CHECKPOINT_INVALID' ); }
        foreach ( $s['results'] as $i => $result ) {
            $e = $m['entries'][$i];
            if ( ! is_array( $result ) || ( $result['npsn'] ?? null ) !== $e['npsn'] || ( $result['school_id'] ?? null ) !== $e['school_id'] || ( $result['raw_receipt_id'] ?? null ) !== $e['raw_receipt_id'] || ( ( $result['outcome'] ?? null ) === 'blocked' ? ( ( ! array_key_exists( 'candidate_receipt_id', $result ) || $result['candidate_receipt_id'] !== null ) || ! in_array( $result['error_code'] ?? null, self::BLOCKED_CODES, true ) ) : ( ( $result['outcome'] ?? null ) !== 'processed_review_required' || ! is_int( $result['candidate_receipt_id'] ?? null ) || $result['candidate_receipt_id'] < 1 ) ) || ( $result['publication_enabled'] ?? null ) !== false ) { throw new RuntimeException( 'AB_CHECKPOINT_INVALID' ); }
        }
        $cursor = $s['next_index'] ? $m['entries'][$s['next_index']-1]['school_id'] : null;
        if ( ( null === $cursor ? null !== $r['cursor_school_id'] : (int) $r['cursor_school_id'] !== $cursor ) || ( $r['status'] === 'completed' && $s['next_index'] !== count( $m['entries'] ) ) || ( $r['status'] !== 'completed' && $r['status'] !== 'cancelled' && $s['next_index'] === count( $m['entries'] ) ) ) { throw new RuntimeException( 'AB_CHECKPOINT_INVALID' ); }
        $r['manifest'] = $m; $r['stats'] = $s; return $r;
    }
    private static function own( array $r ): void { if ( $r['manifest']['actor_user_id'] !== (int) get_current_user_id() ) { throw new RuntimeException( 'AB_JOB_OTHER_ACTOR' ); } }
    private static function mutex( int $id ): string {
        $name = 'ade_ab_' . substr( ADE_Local_Archive::digest( array( ADE_Schema::table_name( 'jobs' ), $id ) ), 0, 48 ); $r = self::one( 'SELECT GET_LOCK(%s,0) AS acquired', array( $name ) ); if ( (int) ( $r['acquired'] ?? 0 ) !== 1 ) { throw new RuntimeException( 'AB_WORKER_BUSY' ); } return $name;
    }
    public static function stage( string $raw ): array {
        $actor = self::guard(); $m = self::freeze( $raw, $actor ); return array( 'mode' => 'READ_ONLY_ARCHIVE_BATCH_PLAN', 'entries' => $m['entries'], 'count' => count( $m['entries'] ), 'manifest_sha256' => self::op( $m ), 'preview_token' => ADE_Local_Archive::digest( array( 'archive-batch-plan-v1', $m ) ), 'write_enabled' => self::enabled(), 'raw_contents_checked' => false, 'maximum_schools_per_run' => 3, 'write_scope' => 'Pending Discovery records and batch jobs/checkpoint only', 'database_writes' => 0, 'network_requests' => 0, 'publication_enabled' => false );
    }
    public static function enqueue( string $raw, string $token, string $confirm, string $backup ): array {
        $actor = self::guard( true ); self::consent( $confirm, 'ENQUEUE_ARCHIVE_BATCH', $backup ); $m = self::freeze( $raw, $actor );
        if ( ! hash_equals( ADE_Local_Archive::digest( array( 'archive-batch-plan-v1', $m ) ), $token ) ) { throw new RuntimeException( 'AB_PLAN_STALE' ); }
        $op = self::op( $m ); $table = ADE_Schema::table_name( 'jobs' ); $find = static function() use ( $table, $op ): ?array { return self::one( "SELECT id FROM {$table} WHERE job_key=%s AND job_type=%s LIMIT 1", array( $op, self::TYPE ) ); };
        $existing = $find(); if ( $existing ) { self::own( self::job( (int) $existing['id'] ) ); return array( 'job_id' => (int) $existing['id'], 'replayed' => true, 'database_writes' => 0 ); }
        $scope = json_encode( $m, JSON_THROW_ON_ERROR ); if ( strlen( $scope ) > self::SCOPE_CAP ) { throw new RuntimeException( 'AB_MANIFEST_TOO_LARGE' ); }
        global $wpdb; $now = current_time( 'mysql', true ); $wpdb->last_error = '';
        $ok = $wpdb->insert( $table, array( 'job_key' => $op, 'job_type' => self::TYPE, 'scope_level' => 'TASIK_NEGERI_200', 'scope_filter' => $scope, 'stats_payload' => self::encode_stats( array() ), 'status' => 'queued', 'batch_size' => 3, 'max_attempts' => 3, 'attempt_count' => 0, 'created_at' => $now, 'updated_at' => $now ) );
        if ( false === $ok || $wpdb->last_error || (int) $wpdb->insert_id < 1 ) { $existing = $find(); if ( $existing ) { self::own( self::job( (int) $existing['id'] ) ); return array( 'job_id' => (int) $existing['id'], 'replayed' => true, 'database_writes' => 0 ); } throw new RuntimeException( 'AB_ENQUEUE_FAILED' ); }
        return array( 'job_id' => (int) $wpdb->insert_id, 'replayed' => false, 'database_writes' => 1, 'network_requests' => 0, 'publication_enabled' => false );
    }
    public static function status( int $id ): array {
        self::guard(); $r = self::job( $id ); return array( 'mode' => 'READ_ONLY_ARCHIVE_BATCH_STATUS', 'job_id' => $id, 'status' => $r['status'], 'total' => count( $r['manifest']['entries'] ), 'next_index' => $r['stats']['next_index'], 'attempt_count' => (int) $r['attempt_count'], 'last_error_code' => $r['last_error_code'], 'results' => $r['stats']['results'], 'database_writes' => 0, 'network_requests' => 0, 'publication_enabled' => false );
    }
    /** Internal fence. Caller MUST already own candidate transaction; never START here. */
    public static function assert_fence( array $f, string $npsn, int $raw ): array {
        self::guard( true ); ADE_Local_Archive::keys( $f, array( 'job_id', 'lease_token', 'attempt', 'index' ) );
        if ( ! is_int( $f['job_id'] ) || $f['job_id'] < 1 || ! is_int( $f['attempt'] ) || $f['attempt'] < 1 || ! is_int( $f['index'] ) || $f['index'] < 0 || ! is_string( $f['lease_token'] ) || ! preg_match( '/^[a-f0-9]{64}$/D', $f['lease_token'] ) ) { throw new RuntimeException( 'AB_FENCE_INVALID' ); }
        $r = self::job( $f['job_id'], true ); self::own( $r ); $e = $r['manifest']['entries'][$f['index']] ?? null;
        if ( $r['status'] !== 'leased' || (int) $r['lease_live'] !== 1 || ! is_string( $r['lease_token'] ) || ! hash_equals( $r['lease_token'], $f['lease_token'] ) || (int) $r['attempt_count'] !== $f['attempt'] || $r['stats']['next_index'] !== $f['index'] || ! $e || $e['npsn'] !== $npsn || $e['raw_receipt_id'] !== $raw ) { throw new RuntimeException( 'AB_LEASE_LOST' ); }
        $s = ADE_Identity::lookup_pilot( $npsn ); ADE_Pilot_Scope::assert_school( $s ); if ( (int) $s['id'] !== $e['school_id'] ) { throw new RuntimeException( 'AB_SCHOOL_ID_CHANGED' ); } return $r;
    }
    /** Atomically advances checkpoint INSIDE the pending-candidate transaction. */
    public static function finish_fence( array $f, string $npsn, int $raw, int $receipt ): void {
        if ( $receipt < 1 ) { throw new RuntimeException( 'AB_RECEIPT_REQUIRED' ); }
        self::checkpoint( $f, $npsn, $raw, array( 'candidate_receipt_id' => $receipt, 'outcome' => 'processed_review_required', 'publication_enabled' => false ) );
    }
    private static function checkpoint( array $f, string $npsn, int $raw, array $outcome ): void {
        $r = self::assert_fence( $f, $npsn, $raw ); $e = $r['manifest']['entries'][$f['index']]; $results = $r['stats']['results'];
        $results[] = $e + $outcome; $done = count( $results ) === count( $r['manifest']['entries'] ); $table = ADE_Schema::table_name( 'jobs' );
        $changed = self::query( "UPDATE {$table} SET stats_payload=%s,cursor_school_id=%d,status=%s,lease_token=NULL,leased_until=NULL,attempt_count=0,last_error_code=NULL,updated_at=UTC_TIMESTAMP(),finished_at=IF(%d=1,UTC_TIMESTAMP(),NULL) WHERE id=%d AND job_type=%s AND status='leased' AND lease_token=%s AND attempt_count=%d AND leased_until>UTC_TIMESTAMP()", array( self::encode_stats( $results ), $e['school_id'], $done ? 'completed' : 'queued', $done ? 1 : 0, $f['job_id'], self::TYPE, $f['lease_token'], $f['attempt'] ) );
        if ( $changed !== 1 ) { throw new RuntimeException( 'AB_CHECKPOINT_CONFLICT' ); }
    }
    private static function lease( int $id ): ?array {
        self::query( 'START TRANSACTION' ); $tx = true;
        try {
            $r = self::job( $id, true ); self::own( $r ); if ( in_array( $r['status'], array( 'completed', 'cancelled' ), true ) ) { self::query( 'COMMIT' ); $tx = false; return null; }
            if ( ! in_array( $r['status'], array( 'queued', 'retry_wait' ), true ) || (int) $r['attempt_count'] >= 3 ) { throw new RuntimeException( 'AB_JOB_NOT_RUNNABLE' ); }
            $token = bin2hex( random_bytes( 32 ) ); $table = ADE_Schema::table_name( 'jobs' );
            if ( self::query( "UPDATE {$table} SET status='leased',lease_token=%s,leased_until=DATE_ADD(UTC_TIMESTAMP(),INTERVAL 90 SECOND),attempt_count=attempt_count+1,started_at=COALESCE(started_at,UTC_TIMESTAMP()),updated_at=UTC_TIMESTAMP() WHERE id=%d AND job_type=%s AND status=%s AND attempt_count=%d", array( $token, $id, self::TYPE, $r['status'], (int) $r['attempt_count'] ) ) !== 1 ) { throw new RuntimeException( 'AB_LEASE_CONFLICT' ); }
            self::query( 'COMMIT' ); $tx = false; return array( 'job_id' => $id, 'lease_token' => $token, 'attempt' => (int) $r['attempt_count'] + 1, 'index' => $r['stats']['next_index'] );
        } finally { if ( $tx ) { self::query( 'ROLLBACK' ); } }
    }
    private static function blocked( array $f, array $entry, string $code ): void {
        if ( ! in_array( $code, self::BLOCKED_CODES, true ) ) { throw new RuntimeException( 'AB_BLOCK_CODE_INVALID' ); }
        self::query( 'START TRANSACTION' ); $tx = true;
        try {
            self::checkpoint( $f, $entry['npsn'], $entry['raw_receipt_id'], array( 'candidate_receipt_id' => null, 'outcome' => 'blocked', 'error_code' => $code, 'publication_enabled' => false ) );
            self::query( 'COMMIT' ); $tx = false;
        } finally { if ( $tx ) { self::query( 'ROLLBACK' ); } }
    }
    private static function failure( array $f, Throwable $error ): void {
        $code = preg_match( '/^[A-Z0-9_]{1,64}$/D', $error->getMessage() ) ? $error->getMessage() : 'AB_ITEM_FAILED'; $table = ADE_Schema::table_name( 'jobs' );
        // Token/attempt fencing: never overwrite another worker or a committed checkpoint.
        self::query( "UPDATE {$table} SET status=IF(attempt_count>=max_attempts,'failed','retry_wait'),lease_token=NULL,leased_until=NULL,last_error_code=%s,updated_at=UTC_TIMESTAMP() WHERE id=%d AND job_type=%s AND status='leased' AND lease_token=%s AND attempt_count=%d", array( $code, $f['job_id'], self::TYPE, $f['lease_token'], $f['attempt'] ) );
    }
    public static function run( int $id, string $confirm, string $backup ): array {
        self::guard( true ); self::consent( $confirm, 'RUN_ARCHIVE_BATCH', $backup ); if ( ! ADE_Archive_Candidates::enabled() ) { throw new RuntimeException( 'AC_STORAGE_DISABLED' ); } $lock = self::mutex( $id ); $start = microtime( true ); $processed = 0;
        try {
            for ( $i = 0; $i < 3 && microtime( true ) - $start < 20 && memory_get_usage( true ) < 100663296; ++$i ) {
                $e = null; $f = self::lease( $id ); if ( null === $f ) { break; }
                try {
                    $r = self::job( $id ); $e = $r['manifest']['entries'][$f['index']]; $p = ADE_Archive_Candidates::stage( $e['raw_receipt_id'], $e['npsn'] );
                    ADE_Archive_Candidates::record_for_batch( $e['raw_receipt_id'], $e['npsn'], $p['preview_token'], $f ); ++$processed;
                } catch ( Throwable $error ) {
                    if ( isset( $e ) && in_array( $error->getMessage(), self::BLOCKED_CODES, true ) ) {
                        try { self::blocked( $f, $e, $error->getMessage() ); ++$processed; continue; } catch ( Throwable $blocked_error ) { $error = $blocked_error; }
                    }
                    self::failure( $f, $error ); break;
                }
            }
            return array( 'processed_this_run' => $processed, 'status' => self::status( $id ), 'network_requests' => 0, 'publication_enabled' => false );
        } finally { self::rows( 'SELECT RELEASE_LOCK(%s) AS released', array( $lock ) ); }
    }
    public static function control( int $id, string $action, string $confirm, string $backup ): array {
        self::guard( true ); if ( ! in_array( $action, array( 'recover', 'retry', 'cancel' ), true ) ) { throw new InvalidArgumentException( 'AB_CONTROL_INVALID' ); } self::consent( $confirm, strtoupper( $action ) . '_ARCHIVE_BATCH', $backup ); $lock = self::mutex( $id ); $tx = false;
        try {
            self::query( 'START TRANSACTION' ); $tx = true; $r = self::job( $id, true ); self::own( $r );
            if ( $action === 'recover' && ( $r['status'] !== 'leased' || (int) $r['lease_live'] === 1 ) ) { throw new RuntimeException( 'AB_RECOVERY_NOT_ALLOWED' ); }
            if ( $action === 'retry' && ! in_array( $r['status'], array( 'failed', 'cancelled' ), true ) ) { throw new RuntimeException( 'AB_RETRY_NOT_ALLOWED' ); }
            if ( $action === 'cancel' && ( in_array( $r['status'], array( 'completed', 'cancelled' ), true ) || ( $r['status'] === 'leased' && (int) $r['lease_live'] === 1 ) ) ) { throw new RuntimeException( 'AB_CANCEL_NOT_ALLOWED' ); }
            $status = $action === 'cancel' ? 'cancelled' : ( $action === 'recover' && (int) $r['attempt_count'] >= 3 ? 'failed' : 'retry_wait' ); $table = ADE_Schema::table_name( 'jobs' );
            if ( self::query( "UPDATE {$table} SET status=%s,lease_token=NULL,leased_until=NULL,attempt_count=%d,last_error_code=%s,updated_at=UTC_TIMESTAMP() WHERE id=%d AND job_type=%s", array( $status, $action === 'retry' ? 0 : (int) $r['attempt_count'], 'AB_' . strtoupper( $action ), $id, self::TYPE ) ) !== 1 ) { throw new RuntimeException( 'AB_CONTROL_CONFLICT' ); }
            $event = array( 'schema_version' => 1, 'job_id' => $id, 'action' => $action, 'actor_user_id' => (int) get_current_user_id(), 'before_status' => $r['status'], 'after_status' => $status, 'next_index' => $r['stats']['next_index'], 'attempt_before' => (int) $r['attempt_count'], 'backup_confirmed' => true, 'publication_enabled' => false );
            $event_raw = json_encode( $event, JSON_THROW_ON_ERROR ); global $wpdb; $wpdb->last_error = ''; $now = current_time( 'mysql', true );
            $ok = $wpdb->insert( $table, array( 'job_key' => ADE_Local_Archive::digest( array( 'archive-batch-control-v1', $event, bin2hex( random_bytes( 16 ) ) ) ), 'job_type' => 'm2_batch_control', 'scope_level' => 'AB_' . $id, 'scope_filter' => json_encode( array( 'event_sha256' => ADE_Local_Archive::digest( $event ) ), JSON_THROW_ON_ERROR ), 'stats_payload' => $event_raw, 'status' => 'completed', 'attempt_count' => 1, 'max_attempts' => 1, 'batch_size' => 1, 'created_at' => $now, 'updated_at' => $now, 'finished_at' => $now ) );
            if ( false === $ok || $wpdb->last_error || (int) $wpdb->insert_id < 1 ) { throw new RuntimeException( 'AB_CONTROL_AUDIT_FAILED' ); }
            self::query( 'COMMIT' ); $tx = false; return self::status( $id );
        } finally { if ( $tx ) { self::query( 'ROLLBACK' ); } self::rows( 'SELECT RELEASE_LOCK(%s) AS released', array( $lock ) ); }
    }
}
