<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Negative review only. Explicit opt-in, nonce, CAS, append-only audit and receipt. */
final class ADE_Review_Decisions {
    public const TYPE = 'm3_negative_review';
    public static function enabled(): bool {
        return defined( 'ADE_LOCAL_NEGATIVE_REVIEW_ENABLED' ) && ADE_LOCAL_NEGATIVE_REVIEW_ENABLED === true;
    }
    public static function reasons( string $decision ): array {
        if ( $decision === 'reject' ) { return array( 'WRONG_INFORMATION', 'INSUFFICIENT_EVIDENCE', 'DUPLICATE' ); }
        if ( $decision === 'defer' ) { return array( 'WAITING_SOURCE', 'NEEDS_CLARIFICATION', 'INSUFFICIENT_EVIDENCE' ); }
        throw new InvalidArgumentException( 'M3_APPROVAL_NOT_AVAILABLE' );
    }
    public static function nonce_action( int $id, int $version, string $decision ): string {
        self::reasons( $decision );
        return 'ade_negative_review_' . $id . '_' . $version . '_' . $decision;
    }
    private static function guard(): int {
        if ( ! current_user_can( 'ade_review_candidates' ) || ! ADE_Schema::is_allowed_local() || get_current_user_id() < 1 ) { throw new RuntimeException( 'M3_REVIEW_LOCAL_CAP_REQUIRED' ); }
        if ( ! ADE_Jobs::preflight()['ready'] ) { throw new RuntimeException( 'M3_REVIEW_PREFLIGHT_BLOCKED' ); }
        return (int) get_current_user_id();
    }
    private static function hash( array $data ): string { return hash( 'sha256', json_encode( $data, JSON_THROW_ON_ERROR ) ); }
    private static function rows( string $sql, array $args = array() ): array {
        global $wpdb; $wpdb->last_error = '';
        $rows = $wpdb->get_results( $args ? $wpdb->prepare( $sql, $args ) : $sql, ARRAY_A );
        if ( ! is_array( $rows ) || $wpdb->last_error ) { throw new RuntimeException( 'M3_REVIEW_READ_FAILED' ); }
        return $rows;
    }
    private static function transaction( string $sql ): void {
        global $wpdb; $wpdb->last_error = '';
        if ( ! in_array( $sql, array( 'START TRANSACTION', 'COMMIT', 'ROLLBACK' ), true ) || false === $wpdb->query( $sql ) || $wpdb->last_error ) { throw new RuntimeException( 'M3_REVIEW_TRANSACTION_FAILED' ); }
    }
    private static function insert( string $suffix, array $values ): int {
        global $wpdb; $wpdb->last_error = '';
        if ( ! in_array( $suffix, array( 'reviews', 'jobs' ), true ) || false === $wpdb->insert( ADE_Schema::table_name( $suffix ), $values ) || $wpdb->last_error || (int) $wpdb->insert_id < 1 ) { throw new RuntimeException( 'M3_REVIEW_INSERT_FAILED' ); }
        return (int) $wpdb->insert_id;
    }
    private static function context( string $npsn, int $id, string $decision, bool $lock ): array {
        self::reasons( $decision );
        if ( $id < 1 || ! ADE_Pilot_Scope::contains( $npsn ) ) { throw new InvalidArgumentException( 'M3_REVIEW_SCOPE_INVALID' ); }
        $school = ADE_Identity::lookup_pilot( $npsn ); ADE_Pilot_Scope::assert_school( $school );
        $table = ADE_Schema::table_name( 'candidates' ); $end = $lock ? ' FOR UPDATE NOWAIT' : '';
        $rows = self::rows( "SELECT id,school_id,target_key,LEFT(proposed_value,501) AS proposed_value,OCTET_LENGTH(proposed_value) AS proposed_bytes,current_value_snapshot IS NULL AS snapshot_null,SHA2(COALESCE(current_value_snapshot,''),256) AS snapshot_digest,base_target_hash,review_status,publish_status,row_version,approved_value IS NULL AS approval_null,approved_by_user_id,approved_at,published_local_at FROM {$table} WHERE id=%d AND school_id=%d AND candidate_type=%s AND target_type=%s LIMIT 2{$end}", array( $id, (int) $school['id'], 'm2_meta_text_v1', 'school_meta' ) );
        if ( count( $rows ) !== 1 ) { throw new RuntimeException( 'M3_REVIEW_CANDIDATE_NOT_FOUND' ); }
        $row = $rows[0];
        if ( ! in_array( $row['target_key'], array( 'profile_programs', 'profile_curriculum', 'profile_hours' ), true ) || (int) $row['proposed_bytes'] > 500 || (int) $row['row_version'] < 1 ) { throw new RuntimeException( 'M3_REVIEW_CANDIDATE_INVALID' ); }
        return array( 'school_id' => (int) $school['id'], 'npsn' => $npsn, 'candidate' => $row );
    }
    private static function mutable( array $row ): void {
        if ( ! in_array( $row['review_status'], array( 'new', 'deferred' ), true ) || $row['publish_status'] !== 'not_ready' || (int) $row['approval_null'] !== 1 ||
            null !== $row['approved_by_user_id'] || null !== $row['approved_at'] || null !== $row['published_local_at'] ) { throw new RuntimeException( 'M3_REVIEW_STATE_LOCKED' ); }
    }
    private static function token( array $context, int $actor, string $decision ): string {
        return self::hash( array( 'm3-negative-plan-v1', ADE_Pilot_Scope::SHA256, $actor, $decision, $context ) );
    }
    public static function plan( string $npsn, int $id, string $decision ): array {
        $actor = self::guard(); $context = self::context( $npsn, $id, $decision, false ); self::mutable( $context['candidate'] );
        return array( 'mode' => 'READ_ONLY_NEGATIVE_REVIEW_PLAN', 'npsn' => $npsn, 'school_id' => $context['school_id'], 'candidate_id' => $id,
            'row_version' => (int) $context['candidate']['row_version'], 'decision' => $decision, 'before_status' => $context['candidate']['review_status'],
            'after_status' => $decision === 'reject' ? 'rejected' : 'deferred', 'preview_token' => self::token( $context, $actor, $decision ),
            'writes_if_explicitly_enabled_and_confirmed' => array( 'candidate_status_updates' => 1, 'audit_inserts' => 1, 'receipt_inserts' => 1 ),
            'write_enabled' => self::enabled(), 'database_writes' => 0, 'network_requests' => 0, 'publication_enabled' => false );
    }
    public static function history( string $npsn, int $id, int $after = 0 ): array {
        self::guard(); self::context( $npsn, $id, 'defer', false );
        if ( $after < 0 ) { throw new InvalidArgumentException( 'M3_REVIEW_REQUEST_INVALID' ); }
        $table = ADE_Schema::table_name( 'reviews' );
        $rows = self::rows( "SELECT id,review_action,before_status,after_status,candidate_version,reason_code,user_id,created_at,LEFT(review_notes,2049) AS review_notes,OCTET_LENGTH(review_notes) AS notes_bytes FROM {$table} WHERE candidate_id=%d AND id>%d AND review_action IN ('reject','defer') ORDER BY id ASC LIMIT 21", array( $id, $after ) );
        if ( count( $rows ) > 21 ) { throw new RuntimeException( 'M3_REVIEW_AUDIT_INVALID' ); }
        foreach ( $rows as &$row ) {
            if ( (int) $row['notes_bytes'] > 2048 ) { throw new RuntimeException( 'M3_REVIEW_AUDIT_INVALID' ); }
            $notes = json_decode( $row['review_notes'], true, 8, JSON_THROW_ON_ERROR );
            if ( ! is_array( $notes ) || ( $notes['schema_version'] ?? null ) !== 1 || ! is_string( $notes['note'] ?? null ) || strlen( $notes['note'] ) > 500 || ! is_int( $notes['after_version'] ?? null ) || $notes['after_version'] !== (int) $row['candidate_version'] + 1 ||
                ! in_array( $row['before_status'], array( 'new', 'deferred' ), true ) || $row['after_status'] !== ( $row['review_action'] === 'reject' ? 'rejected' : 'deferred' ) ||
                ! in_array( $row['reason_code'], self::reasons( $row['review_action'] ), true ) || (int) $row['id'] <= $after ||
                ! is_string( $notes['operation_key'] ?? null ) || ! preg_match( '/^[a-f0-9]{64}$/D', $notes['operation_key'] ) ) { throw new RuntimeException( 'M3_REVIEW_AUDIT_INVALID' ); }
            $row['note'] = $notes['note']; $row['after_version'] = $notes['after_version']; $row['id'] = (int) $row['id']; unset( $row['review_notes'] );
        } unset( $row );
        $more = count( $rows ) > 20; if ( $more ) { array_pop( $rows ); }
        return array( 'mode' => 'READ_ONLY_NEGATIVE_REVIEW_HISTORY', 'rows' => $rows, 'next_after' => $more ? end( $rows )['id'] : null, 'database_writes' => 0, 'network_requests' => 0 );
    }
    public static function record( array $r ): array {
        if ( ! self::enabled() ) { throw new RuntimeException( 'M3_REVIEW_WRITES_DISABLED' ); }
        $actor = self::guard();
        $keys = array( 'npsn', 'candidate_id', 'row_version', 'decision', 'reason', 'note', 'preview_token', 'nonce', 'confirm', 'backup_confirmed' );
        if ( array_diff( array_keys( $r ), $keys ) || array_diff( $keys, array_keys( $r ) ) ) { throw new InvalidArgumentException( 'M3_REVIEW_REQUEST_INVALID' ); }
        foreach ( array_diff( $keys, array( 'candidate_id', 'row_version' ) ) as $key ) { if ( ! is_string( $r[$key] ) ) { throw new InvalidArgumentException( 'M3_REVIEW_REQUEST_INVALID' ); } }
        if ( ! preg_match( '/^[0-9]{8}$/D', $r['npsn'] ) || strlen( $r['nonce'] ) > 128 ) { throw new InvalidArgumentException( 'M3_REVIEW_REQUEST_INVALID' ); }
        if ( ! is_int( $r['candidate_id'] ) || $r['candidate_id'] < 1 || ! is_int( $r['row_version'] ) || $r['row_version'] < 1 || ! preg_match( '/^[a-f0-9]{64}$/D', $r['preview_token'] ) ) { throw new InvalidArgumentException( 'M3_REVIEW_REQUEST_INVALID' ); }
        if ( ! in_array( $r['reason'], self::reasons( $r['decision'] ), true ) ) { throw new InvalidArgumentException( 'M3_REVIEW_REASON_INVALID' ); }
        if ( strlen( $r['note'] ) > 500 || ! preg_match( '//u', $r['note'] ) || preg_match( '/[<>\x00-\x08\x0b\x0c\x0e-\x1f\x7f\x{200B}-\x{200F}\x{202A}-\x{202E}\x{2060}-\x{206F}\x{FEFF}]/u', $r['note'] ) ) { throw new InvalidArgumentException( 'M3_REVIEW_NOTE_INVALID' ); }
        if ( $r['confirm'] !== 'SAVE_NEGATIVE_REVIEW' || $r['backup_confirmed'] !== 'YES' ) { throw new RuntimeException( 'M3_REVIEW_EXPLICIT_CONFIRMATION_REQUIRED' ); }
        if ( ! wp_verify_nonce( $r['nonce'], self::nonce_action( $r['candidate_id'], $r['row_version'], $r['decision'] ) ) ) { throw new RuntimeException( 'M3_REVIEW_NONCE_INVALID' ); }
        if ( ! ADE_Pilot_Scope::contains( $r['npsn'] ) ) { throw new RuntimeException( 'M3_REVIEW_SCOPE_INVALID' ); }
        $school = ADE_Identity::lookup_pilot( $r['npsn'] ); ADE_Pilot_Scope::assert_school( $school ); $school_id = (int) $school['id'];
        $request_hash = self::hash( array( $actor, ADE_Pilot_Scope::SHA256, $school_id, $r['npsn'], $r['candidate_id'], $r['row_version'], $r['decision'], $r['reason'], $r['note'], $r['preview_token'] ) );
        $operation = self::hash( array( 'm3-negative-operation-v1', $request_hash ) );
        // Same application lock as M2 pending writer; review and evidence updates serialize.
        $lock = 'ade_m2_' . substr( self::hash( array( ADE_Schema::table_name( 'candidates' ), $school_id ) ), 0, 48 );
        $acquired = self::rows( 'SELECT GET_LOCK(%s,0) AS acquired', array( $lock ) );
        if ( count( $acquired ) !== 1 || (int) $acquired[0]['acquired'] !== 1 ) { throw new RuntimeException( 'M3_REVIEW_WRITER_BUSY' ); }
        $transaction = false;
        try {
            self::transaction( 'START TRANSACTION' ); $transaction = true;
            $jobs = ADE_Schema::table_name( 'jobs' );
            $receipts = self::rows( "SELECT id,status,LEFT(scope_filter,4097) AS scope_filter,OCTET_LENGTH(scope_filter) AS scope_bytes,LEFT(stats_payload,4097) AS stats_payload,OCTET_LENGTH(stats_payload) AS stats_bytes FROM {$jobs} WHERE job_key=%s AND job_type=%s LIMIT 2 FOR UPDATE NOWAIT", array( $operation, self::TYPE ) );
            if ( count( $receipts ) > 1 ) { throw new RuntimeException( 'M3_REVIEW_RECEIPT_INVALID' ); }
            if ( $receipts ) {
                $receipt = $receipts[0];
                if ( (int) $receipt['scope_bytes'] > 4096 || (int) $receipt['stats_bytes'] > 4096 || $receipt['status'] !== 'completed' ) { throw new RuntimeException( 'M3_REVIEW_RECEIPT_INVALID' ); }
                $meta = json_decode( $receipt['scope_filter'], true, 8, JSON_THROW_ON_ERROR ); $result = json_decode( $receipt['stats_payload'], true, 8, JSON_THROW_ON_ERROR );
                if ( ! is_array( $meta ) || ! is_array( $result ) || ( $meta['request_hash'] ?? null ) !== $request_hash || ( $meta['result_hash'] ?? null ) !== self::hash( $result ) ||
                    ( $result['operation_key'] ?? null ) !== $operation || ( $result['publication_enabled'] ?? null ) !== false || ( $result['actor_user_id'] ?? null ) !== $actor ||
                    ( $result['candidate_id'] ?? null ) !== $r['candidate_id'] || ( $result['school_id'] ?? null ) !== $school_id ||
                    ( $result['decision'] ?? null ) !== $r['decision'] || ( $result['before_version'] ?? null ) !== $r['row_version'] || ( $result['after_version'] ?? null ) !== $r['row_version'] + 1 ||
                    ( $result['after_status'] ?? null ) !== ( $r['decision'] === 'reject' ? 'rejected' : 'deferred' ) || ! is_int( $result['audit_id'] ?? null ) || $result['audit_id'] < 1 ) { throw new RuntimeException( 'M3_REVIEW_RECEIPT_INVALID' ); }
                $reviews = ADE_Schema::table_name( 'reviews' );
                $audits = self::rows( "SELECT candidate_id,school_id,review_action,before_status,after_status,candidate_version,reason_code,user_id,LEFT(review_notes,2049) AS review_notes,OCTET_LENGTH(review_notes) AS notes_bytes FROM {$reviews} WHERE id=%d LIMIT 2", array( $result['audit_id'] ) );
                if ( count( $audits ) !== 1 || (int) $audits[0]['notes_bytes'] > 2048 ) { throw new RuntimeException( 'M3_REVIEW_RECEIPT_INVALID' ); }
                $audit = $audits[0]; $notes = json_decode( $audit['review_notes'], true, 8, JSON_THROW_ON_ERROR );
                if ( (int) $audit['candidate_id'] !== $r['candidate_id'] || (int) $audit['school_id'] !== $school_id || $audit['review_action'] !== $r['decision'] ||
                    $audit['reason_code'] !== $r['reason'] || (int) $audit['user_id'] !== $actor || (int) $audit['candidate_version'] !== $r['row_version'] ||
                    $audit['before_status'] !== $result['before_status'] || $audit['after_status'] !== $result['after_status'] ||
                    ( $notes['operation_key'] ?? null ) !== $operation || ( $notes['note'] ?? null ) !== $r['note'] || ( $notes['after_version'] ?? null ) !== $result['after_version'] ) { throw new RuntimeException( 'M3_REVIEW_RECEIPT_INVALID' ); }
                self::transaction( 'COMMIT' ); $transaction = false;
                return array( 'replayed' => true, 'receipt_id' => (int) $receipt['id'], 'result_is_historical' => true, 'result' => $result, 'database_writes' => 0, 'publication_enabled' => false );
            }
            $context = self::context( $r['npsn'], $r['candidate_id'], $r['decision'], true ); $row = $context['candidate'];
            self::mutable( $row );
            if ( (int) $row['row_version'] !== $r['row_version'] || ! hash_equals( self::token( $context, $actor, $r['decision'] ), $r['preview_token'] ) ) { throw new RuntimeException( 'M3_REVIEW_STALE' ); }
            $now = current_time( 'mysql', true ); $status = $r['decision'] === 'reject' ? 'rejected' : 'deferred'; $table = ADE_Schema::table_name( 'candidates' );
            global $wpdb; $wpdb->last_error = '';
            $changed = $wpdb->query( $wpdb->prepare( "UPDATE {$table} SET review_status=%s,row_version=row_version+1,updated_at=%s WHERE id=%d AND school_id=%d AND row_version=%d AND review_status=%s AND publish_status='not_ready' AND approved_value IS NULL AND approved_by_user_id IS NULL AND approved_at IS NULL AND published_local_at IS NULL", $status, $now, $r['candidate_id'], $school_id, $r['row_version'], $row['review_status'] ) );
            if ( $changed !== 1 || $wpdb->last_error ) { throw new RuntimeException( 'M3_REVIEW_VERSION_CONFLICT' ); }
            $audit = self::insert( 'reviews', array( 'candidate_id' => $r['candidate_id'], 'school_id' => $school_id, 'review_action' => $r['decision'], 'before_status' => $row['review_status'], 'after_status' => $status,
                'candidate_version' => $r['row_version'], 'reviewed_value' => null, 'reason_code' => $r['reason'], 'review_notes' => json_encode( array( 'schema_version' => 1, 'operation_key' => $operation, 'note' => $r['note'], 'after_version' => $r['row_version'] + 1 ), JSON_THROW_ON_ERROR ), 'user_id' => $actor, 'created_at' => $now ) );
            $result = array( 'operation_key' => $operation, 'school_id' => $school_id, 'candidate_id' => $r['candidate_id'], 'actor_user_id' => $actor, 'decision' => $r['decision'],
                'before_status' => $row['review_status'], 'after_status' => $status, 'before_version' => $r['row_version'], 'after_version' => $r['row_version'] + 1, 'audit_id' => $audit, 'publication_enabled' => false );
            $receipt_id = self::insert( 'jobs', array( 'job_key' => $operation, 'job_type' => self::TYPE, 'scope_level' => 'TASIK_NEGERI_200', 'scope_filter' => json_encode( array( 'request_hash' => $request_hash, 'result_hash' => self::hash( $result ) ), JSON_THROW_ON_ERROR ),
                'status' => 'completed', 'attempt_count' => 1, 'max_attempts' => 1, 'batch_size' => 1, 'cursor_school_id' => $school_id, 'stats_payload' => json_encode( $result, JSON_THROW_ON_ERROR ),
                'created_at' => $now, 'updated_at' => $now, 'started_at' => $now, 'finished_at' => $now ) );
            self::transaction( 'COMMIT' ); $transaction = false;
            return array( 'replayed' => false, 'receipt_id' => $receipt_id, 'result' => $result, 'database_writes' => 3, 'network_requests' => 0, 'publication_enabled' => false );
        } catch ( Throwable $e ) { if ( $transaction ) { self::transaction( 'ROLLBACK' ); } throw $e; }
        finally { self::rows( 'SELECT RELEASE_LOCK(%s) AS released', array( $lock ) ); }
    }
}
