<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** R3: single-source operator-led observations; no HTTP, no auto verification. */
final class ADE_Sources {
    public static function preflight(): array {
        $base = ADE_Jobs::preflight();
        // No new schema, options, or activation hooks at R3.
        return array(
            'ready' => $base['ready'],
            'local' => $base['local'],
            'schema' => $base['schema'],
            'unsafe_flags' => $base['unsafe_flags'],
            'r2_worker_lock' => $base['worker_lock'],
            'network_requests' => false,
            'profile_publication' => false,
        );
    }

    private static function assert_local_cli(): void {
        if ( ! defined( 'WP_CLI' ) || ! WP_CLI || ! class_exists( 'WP_CLI' ) ) {
            throw new RuntimeException( 'R3 hanya diperbolehkan melalui Site Shell WP-CLI.' );
        }
        $p = self::preflight();
        if ( ! $p['ready'] ) { throw new RuntimeException( 'R3 BLOCKED; jalankan wp ade sources preflight.' ); }
    }

    public static function preview( string $npsn, string $url, string $claimed_name = '' ): array {
        self::assert_local_cli();
        $school = ADE_Identity::lookup( $npsn );
        $canonical = ADE_Source_URLs::canonicalize( $url );
        $comparison = ADE_Identity::compare_name( (string) $school['name'], $claimed_name );
        return array(
            'school' => $school,
            'source' => $canonical,
            'claimed_name_comparison' => $comparison,
            'identity_status' => 'pending',
            'relationship_type' => 'pending',
            'verification' => 'NOT_PERFORMED',
        );
    }

    private static function lookup_id( string $table, string $column, $value ): int {
        global $wpdb;
        $wpdb->last_error = '';
        $id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE {$column}=%s LIMIT 1", (string) $value ) );
        if ( '' !== $wpdb->last_error ) { throw new RuntimeException( 'Gagal membaca ID Discovery: ' . (string) $wpdb->last_error ); }
        return null === $id ? 0 : (int) $id;
    }

    /**
     * Write ONLY to two R1 discovery tables. No flags are enabled.
     * Both inserts run in one InnoDB transaction, for duplicate-safe recovery.
     */
    public static function observe( string $npsn, string $url, string $label = '', string $claimed_name = '' ): array {
        self::assert_local_cli();
        $data = self::preview( $npsn, $url, $claimed_name );
        if ( $data['claimed_name_comparison'] === 'mismatch_manual_review' ) {
            throw new RuntimeException( 'Nama yang diklaim tidak cocok dengan sekolah terpilih. Tidak ada data ditulis.' );
        }
        $label = trim( $label );
        if ( strlen( $label ) > 255 ) { throw new InvalidArgumentException( 'Label sumber maksimal 255 byte.' ); }
        $label = sanitize_text_field( $label );
        $school_id = (int) $data['school']['id'];
        $src = $data['source'];
        $sources = ADE_Schema::table_name( 'sources' );
        $links = ADE_Schema::table_name( 'school_sources' );
        global $wpdb;
        if ( false === $wpdb->query( 'START TRANSACTION' ) ) {
            throw new RuntimeException( 'Tidak dapat memulai transaksi R3.' );
        }
        try {
            $source_id = self::lookup_id( $sources, 'canonical_key', $src['canonical_key'] );
            $source_created = false;
            if ( 0 === $source_id ) {
                $inserted = $wpdb->insert( $sources, array(
                    'source_type' => $src['source_type'],
                    'platform' => $src['platform'],
                    'canonical_url' => $src['canonical_url'],
                    'canonical_key' => $src['canonical_key'],
                    'normalized_host' => $src['normalized_host'],
                    'handle_or_slug' => $src['handle_or_slug'],
                    'display_name' => '' !== $label ? $label : null,
                    'access_state' => 'manual_only',
                    'source_status' => 'discovered',
                    'created_at' => current_time( 'mysql', true ),
                    'updated_at' => current_time( 'mysql', true ),
                ) );
                if ( false === $inserted ) {
                    $source_id = self::lookup_id( $sources, 'canonical_key', $src['canonical_key'] );
                    if ( 0 === $source_id ) { throw new RuntimeException( 'Gagal menyimpan sumber Discovery: ' . (string) $wpdb->last_error ); }
                } else {
                    $source_id = (int) $wpdb->insert_id;
                    $source_created = true;
                }
            }
            // No overwriting a previous verified/rejected relation on repeat.
            $wpdb->last_error = '';
            $link_id = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$links} WHERE school_id=%d AND source_id=%d LIMIT 1",
                $school_id, $source_id
            ) );
            if ( '' !== $wpdb->last_error ) { throw new RuntimeException( 'Gagal membaca hubungan sekolah–sumber.' ); }
            $relation_created = false;
            if ( ! $link_id ) {
                $inserted = $wpdb->insert( $links, array(
                    'school_id' => $school_id,
                    'source_id' => $source_id,
                    'relationship_type' => 'pending',
                    'identity_status' => 'pending',
                    'confidence_score' => 0,
                    'is_primary' => 0,
                    'verification_notes' => 'R3 manual observation only; no HTTP or independent identity verification.',
                    'created_at' => current_time( 'mysql', true ),
                    'updated_at' => current_time( 'mysql', true ),
                ) );
                if ( false === $inserted ) {
                    $wpdb->last_error = '';
                    $link_id = $wpdb->get_var( $wpdb->prepare(
                        "SELECT id FROM {$links} WHERE school_id=%d AND source_id=%d LIMIT 1",
                        $school_id, $source_id
                    ) );
                    if ( ! $link_id || '' !== $wpdb->last_error ) { throw new RuntimeException( 'Gagal menyimpan hubungan sekolah–sumber.' ); }
                } else {
                    $link_id = (int) $wpdb->insert_id;
                    $relation_created = true;
                }
            }
            if ( false === $wpdb->query( 'COMMIT' ) ) { throw new RuntimeException( 'Gagal COMMIT transaksi R3.' ); }
            return array(
                'source_id' => $source_id,
                'school_source_id' => (int) $link_id,
                'source_created' => $source_created,
                'relation_created' => $relation_created,
                'school_id' => $school_id,
                'canonical_url' => $src['canonical_url'],
                'identity_status' => 'pending',
            );
        } catch ( Throwable $e ) {
            $wpdb->query( 'ROLLBACK' );
            throw $e;
        }
    }

    public static function list_for_school( string $npsn, int $limit = 15 ): array {
        self::assert_local_cli();
        $school = ADE_Identity::lookup( $npsn );
        $limit = max( 1, min( 50, $limit ) );
        $links = ADE_Schema::table_name( 'school_sources' );
        $sources = ADE_Schema::table_name( 'sources' );
        global $wpdb;
        $wpdb->last_error = '';
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT l.id AS relation_id,l.identity_status,l.relationship_type,l.confidence_score,s.id AS source_id,s.source_type,s.platform,s.canonical_url,s.access_state FROM {$links} l INNER JOIN {$sources} s ON s.id=l.source_id WHERE l.school_id=%d ORDER BY l.id DESC LIMIT %d",
            (int) $school['id'], $limit
        ), ARRAY_A );
        if ( ! is_array( $rows ) || '' !== $wpdb->last_error ) { throw new RuntimeException( 'Gagal membaca daftar sumber sekolah.' ); }
        return array( 'school' => $school, 'rows' => $rows );
    }
}
