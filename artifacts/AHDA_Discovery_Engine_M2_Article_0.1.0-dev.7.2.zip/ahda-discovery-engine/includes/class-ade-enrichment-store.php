<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Manual-only M2 pending records. Writes pending Discovery data only, never profiles. */
final class ADE_Enrichment_Store {
    public const TYPE = 'm2_document_record';

    private static function guard(): int {
        if ( ! current_user_can( 'ade_review_candidates' ) ) { throw new RuntimeException( 'M2_REVIEW_CAPABILITY_REQUIRED' ); }
        ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
        $actor = (int) get_current_user_id();
        if ( $actor < 1 ) { throw new RuntimeException( 'M2_OPERATOR_REQUIRED' ); }
        return $actor;
    }

    private static function hash( array $data ): string {
        return hash( 'sha256', json_encode( $data, JSON_THROW_ON_ERROR ) );
    }

    private static function rows( string $sql, array $args = array() ): array {
        global $wpdb;
        $wpdb->last_error = '';
        $rows = $wpdb->get_results( $args ? $wpdb->prepare( $sql, $args ) : $sql, ARRAY_A );
        if ( ! is_array( $rows ) || $wpdb->last_error ) { throw new RuntimeException( 'M2_READ_FAILED' ); }
        return $rows;
    }

    private static function one( string $sql, array $args ): ?array {
        $rows = self::rows( $sql, $args );
        if ( count( $rows ) > 1 ) { throw new RuntimeException( 'M2_ROW_NOT_UNIQUE' ); }
        return $rows[0] ?? null;
    }

    private static function transaction( string $sql ): void {
        global $wpdb;
        if ( ! in_array( $sql, array( 'START TRANSACTION', 'COMMIT', 'ROLLBACK' ), true ) ) { throw new RuntimeException( 'M2_TRANSACTION_INVALID' ); }
        $wpdb->last_error = '';
        if ( false === $wpdb->query( $sql ) || $wpdb->last_error ) { throw new RuntimeException( 'M2_TRANSACTION_FAILED' ); }
    }

    private static function insert( string $suffix, array $values ): int {
        global $wpdb;
        if ( ! in_array( $suffix, array( 'evidence', 'candidates', 'candidate_evidence', 'jobs' ), true ) ) { throw new RuntimeException( 'M2_WRITE_TABLE_BLOCKED' ); }
        $wpdb->last_error = '';
        if ( false === $wpdb->insert( ADE_Schema::table_name( $suffix ), $values ) || $wpdb->last_error || (int) $wpdb->insert_id < 1 ) {
            throw new RuntimeException( 'M2_INSERT_FAILED' );
        }
        return (int) $wpdb->insert_id;
    }

    private static function context( string $raw, string $registered_url ): array {
        $preview = ADE_Enrichment_Preview::preview( $raw );
        if ( $preview['fixture_only'] ) { throw new RuntimeException( 'M2_FIXTURE_RECORD_BLOCKED' ); }
        if ( in_array( 'STALE_EVIDENCE', $preview['blocking_reasons'], true ) ) { throw new RuntimeException( 'M2_STALE_RECORD_BLOCKED' ); }
        $source = ADE_Source_URLs::canonicalize( $registered_url );
        if ( $source['source_type'] !== 'website' || parse_url( $source['canonical_url'], PHP_URL_SCHEME ) !== 'https' ) { throw new RuntimeException( 'M2_REGISTERED_WEBSITE_REQUIRED' ); }
        foreach ( explode( '&', (string) parse_url( $source['canonical_url'], PHP_URL_QUERY ) ) as $pair ) {
            $key = rawurldecode( explode( '=', $pair, 2 )[0] );
            if ( strtolower( $key ) === 'key' || preg_match( '/token|secret|password|authorization|credential|signature|nonce|api[_-]?key/i', $key ) ) { throw new RuntimeException( 'M2_SENSITIVE_SOURCE_URL' ); }
        }
        if ( parse_url( $preview['evidence'][0]['source_url'], PHP_URL_HOST ) !== $source['normalized_host'] ) { throw new RuntimeException( 'M2_SOURCE_HOST_MISMATCH' ); }
        return array( 'preview' => $preview, 'source' => $source );
    }

    private static function build( array $context, int $actor, bool $lock ): array {
        $p = $context['preview']; $s = $context['source']; $for_update = $lock ? ' FOR UPDATE NOWAIT' : '';
        $sources = ADE_Schema::table_name( 'sources' ); $relations = ADE_Schema::table_name( 'school_sources' );
        $link = self::one( "SELECT s.id AS source_id,l.id AS relation_id,s.source_type,s.access_state,s.source_status,l.identity_status,l.relationship_type FROM {$sources} s INNER JOIN {$relations} l ON l.source_id=s.id WHERE l.school_id=%d AND s.canonical_key=%s LIMIT 2{$for_update}", array( $p['school_id'], $s['canonical_key'] ) );
        if ( $link ) {
            foreach ( array( 'source_type', 'access_state', 'source_status', 'identity_status', 'relationship_type' ) as $field ) {
                if ( ! is_string( $link[$field] ?? null ) ) { throw new RuntimeException( 'M2_SOURCE_RELATION_REQUIRED_OR_BLOCKED' ); }
                $link[$field] = strtolower( trim( $link[$field] ) );
            }
        }
        if ( ! $link || (int) $link['source_id'] < 1 || (int) $link['relation_id'] < 1 || $link['source_type'] !== 'website' || $link['access_state'] !== 'manual_only' ||
            ! in_array( $link['source_status'], array('discovered','verified','active'), true ) ||
            ! in_array( $link['identity_status'], array('pending','verified'), true ) || ! in_array( $link['relationship_type'], array('pending','official'), true ) ) {
            throw new RuntimeException( 'M2_SOURCE_RELATION_REQUIRED_OR_BLOCKED' );
        }
        $link['source_id'] = (int) $link['source_id']; $link['relation_id'] = (int) $link['relation_id'];
        $operation = self::hash( array( 'm2-document-operation-v1', ADE_Pilot_Scope::SHA256, $p['school_id'], $p['input_sha256'], $s['canonical_key'] ) );
        $jobs = ADE_Schema::table_name( 'jobs' );
        $receipt = self::one( "SELECT id,status,LEFT(scope_filter,16385) AS scope_filter,OCTET_LENGTH(scope_filter) AS scope_bytes,LEFT(stats_payload,16385) AS stats_payload,OCTET_LENGTH(stats_payload) AS stats_bytes FROM {$jobs} WHERE job_key=%s AND job_type=%s LIMIT 1{$for_update}", array( $operation, self::TYPE ) );
        if ( $receipt ) {
            if ( (int) ( $receipt['scope_bytes'] ?? 999999 ) > 16384 || (int) ( $receipt['stats_bytes'] ?? 999999 ) > 16384 ) { throw new RuntimeException( 'M2_RECEIPT_INVALID' ); }
            $meta = json_decode( $receipt['scope_filter'], true, 16, JSON_THROW_ON_ERROR );
            $result = json_decode( $receipt['stats_payload'], true, 16, JSON_THROW_ON_ERROR );
            if ( $receipt['status'] !== 'completed' || ! is_array( $meta ) || ! is_array( $result ) ||
                ( $result['publication_enabled'] ?? null ) !== false || ( $result['operation_key'] ?? null ) !== $operation ||
                ( $result['school_id'] ?? null ) !== $p['school_id'] || ( $result['npsn'] ?? null ) !== $p['npsn'] ||
                ( $meta['result_sha256'] ?? null ) !== self::hash( $result ) || ( $meta['input_sha256'] ?? null ) !== $p['input_sha256'] ||
                ( $meta['scope_hash'] ?? null ) !== ADE_Pilot_Scope::SHA256 || ! is_string( $meta['preview_token'] ?? null ) ) { throw new RuntimeException( 'M2_RECEIPT_INVALID' ); }
            return array( 'context' => $context, 'source_link' => $link, 'operation_key' => $operation, 'preview_token' => $meta['preview_token'], 'replay' => $result, 'receipt_id' => (int) $receipt['id'] );
        }
        $candidates = ADE_Schema::table_name( 'candidates' ); $evidence = ADE_Schema::table_name( 'evidence' );
        $links = ADE_Schema::table_name( 'candidate_evidence' ); $plans = array(); $state = array();
        $evidence_map = array_column( $p['evidence'], null, 'preview_key' );
        foreach ( $p['candidates'] as $candidate ) {
            $key = self::hash( array( 'm2-stored-candidate-v1', $p['school_id'], $candidate['preview_key'] ) );
            $existing = self::one( "SELECT id,school_id,candidate_type,target_type,target_key,LEFT(proposed_value,501) AS proposed_value,OCTET_LENGTH(proposed_value) AS proposed_bytes,base_target_hash,review_status,publish_status,row_version,(approved_value IS NOT NULL) AS has_approved,approved_by_user_id,approved_at,published_local_at FROM {$candidates} WHERE dedupe_key=%s LIMIT 1{$for_update}", array( $key ) );
            if ( $existing && ( (int) $existing['school_id'] !== $p['school_id'] || $existing['candidate_type'] !== 'm2_meta_text_v1' ||
                $existing['target_type'] !== 'school_meta' || $existing['target_key'] !== $candidate['target_key'] ||
                (int) $existing['proposed_bytes'] > 500 || $existing['proposed_value'] !== $candidate['proposed_value'] ) ) { throw new RuntimeException( 'M2_EXISTING_CANDIDATE_CONFLICT' ); }
            $locked = $existing && ( $existing['review_status'] !== 'new' || $existing['publish_status'] !== 'not_ready' ||
                (int) $existing['row_version'] < 1 || (int) $existing['has_approved'] !== 0 || null !== $existing['approved_by_user_id'] ||
                null !== $existing['approved_at'] || null !== $existing['published_local_at'] );
            if ( $existing && ! $locked && $existing['base_target_hash'] !== $candidate['base_target_hash'] ) { throw new RuntimeException( 'M2_EXISTING_SNAPSHOT_CONFLICT' ); }
            $entries = array();
            if ( ! $locked ) {
                foreach ( $candidate['evidence_preview_keys'] as $preview_key ) {
                    $entry = $evidence_map[$preview_key];
                    $stored_key = self::hash( array( 'm2-stored-evidence-v1', $p['school_id'], $link['source_id'], $preview_key ) );
                    $row = self::one( "SELECT id,school_id,source_id,evidence_type,attribute_hint,evidence_url,content_fingerprint,LEFT(snippet_text,2001) AS snippet_text,LEFT(observed_value,4097) AS observed_value,parse_status FROM {$evidence} WHERE evidence_key=%s LIMIT 1{$for_update}", array( $stored_key ) );
                    if ( $row ) {
                        $observed = json_decode( $row['observed_value'], true, 8, JSON_THROW_ON_ERROR );
                        if ( (int) $row['school_id'] !== $p['school_id'] || (int) $row['source_id'] !== $link['source_id'] ||
                            $row['evidence_type'] !== 'document' || $row['attribute_hint'] !== $entry['target_key'] ||
                            $row['evidence_url'] !== $entry['source_url'] || $row['content_fingerprint'] !== $entry['content_fingerprint'] ||
                            $row['snippet_text'] !== $entry['supporting_quote'] || $row['parse_status'] !== 'm2_manual_unverified' ||
                            ( $observed['value'] ?? null ) !== $entry['observed_value'] || ( $observed['scope_hash'] ?? null ) !== ADE_Pilot_Scope::SHA256 ) { throw new RuntimeException( 'M2_EXISTING_EVIDENCE_CONFLICT' ); }
                    }
                    $join = $existing && $row ? self::one( "SELECT id FROM {$links} WHERE candidate_id=%d AND evidence_id=%d LIMIT 1{$for_update}", array( (int) $existing['id'], (int) $row['id'] ) ) : null;
                    $entries[] = array( 'entry' => $entry, 'evidence_key' => $stored_key, 'existing_id' => $row ? (int) $row['id'] : null, 'existing_link_id' => $join ? (int) $join['id'] : null );
                }
            }
            $plans[] = array( 'candidate' => $candidate, 'dedupe_key' => $key, 'existing_id' => $existing ? (int) $existing['id'] : null, 'existing_version' => $existing ? (int) $existing['row_version'] : null, 'locked' => (bool) $locked, 'evidence' => $entries );
            $state[] = array( 'candidate' => $existing, 'evidence' => $entries );
        }
        $token = self::hash( array( 'm2-record-plan-v1', $operation, $actor, $link, $p['candidates'], $state ) );
        return array( 'context' => $context, 'source_link' => $link, 'operation_key' => $operation, 'preview_token' => $token, 'plans' => $plans, 'replay' => null );
    }

    public static function stage( string $raw, string $registered_url ): array {
        $actor = self::guard(); $built = self::build( self::context( $raw, $registered_url ), $actor, false );
        $rows = array(); $estimated_rows = null === $built['replay'] ? 1 : 0; $estimated_versions = 0;
        foreach ( $built['plans'] ?? array() as $plan ) {
            $new_evidence = 0; $new_links = 0;
            foreach ( $plan['evidence'] as $entry ) {
                if ( null === $entry['existing_id'] ) { ++$new_evidence; }
                if ( null === $entry['existing_link_id'] ) { ++$new_links; }
            }
            $advance = ! $plan['locked'] && null !== $plan['existing_id'] && $new_links > 0;
            $estimated_rows += ( ! $plan['locked'] && null === $plan['existing_id'] ? 1 : 0 ) + $new_evidence + $new_links;
            if ( $advance ) { ++$estimated_versions; }
            $rows[] = array( 'target_key' => $plan['candidate']['target_key'], 'proposed_value' => $plan['candidate']['proposed_value'],
                'current_value_snapshot' => $plan['candidate']['current_value_snapshot'], 'existing_candidate_id' => $plan['existing_id'],
                'action' => $plan['locked'] ? 'skip_reviewed_no_mutation' : ( $plan['existing_id'] ? 'reuse_pending' : 'insert_pending' ),
                'evidence_count' => count( $plan['evidence'] ), 'new_evidence_rows' => $new_evidence, 'new_links' => $new_links,
                'candidate_version_will_advance' => $advance );
        }
        return array( 'mode' => 'READ_ONLY_M2_STAGE', 'school_id' => $built['context']['preview']['school_id'], 'npsn' => $built['context']['preview']['npsn'],
            'operation_key' => $built['operation_key'], 'preview_token' => $built['preview_token'], 'already_recorded' => null !== $built['replay'],
            'existing_receipt_id' => $built['receipt_id'] ?? null, 'estimated_rows_created_including_receipt' => $estimated_rows,
            'estimated_pending_versions_advanced' => $estimated_versions, 'source_id' => $built['source_link']['source_id'], 'candidates' => $rows,
            'blocking_reasons' => $built['context']['preview']['blocking_reasons'], 'write_scope' => array('Discovery evidence','Discovery candidates','Discovery candidate_evidence','Discovery jobs receipt'),
            'database_writes' => 0, 'network_requests' => 0, 'publication_enabled' => false );
    }

    public static function receipt( int $id ): array {
        self::guard();
        if ( $id < 1 ) { throw new InvalidArgumentException( 'M2_RECEIPT_ID_INVALID' ); }
        $table = ADE_Schema::table_name( 'jobs' );
        $row = self::one( "SELECT id,status,LEFT(scope_filter,16385) AS scope_filter,OCTET_LENGTH(scope_filter) AS scope_bytes,LEFT(stats_payload,16385) AS stats_payload,OCTET_LENGTH(stats_payload) AS stats_bytes FROM {$table} WHERE id=%d AND job_type=%s LIMIT 1", array( $id, self::TYPE ) );
        if ( ! $row || $row['status'] !== 'completed' ) { throw new RuntimeException( 'M2_RECEIPT_NOT_FOUND' ); }
        if ( (int) ( $row['scope_bytes'] ?? 999999 ) > 16384 || (int) ( $row['stats_bytes'] ?? 999999 ) > 16384 ) { throw new RuntimeException( 'M2_RECEIPT_INVALID' ); }
        $meta = json_decode( $row['scope_filter'], true, 16, JSON_THROW_ON_ERROR );
        $result = json_decode( $row['stats_payload'], true, 16, JSON_THROW_ON_ERROR );
        if ( ! is_array( $meta ) || ! is_array( $result ) || ( $result['publication_enabled'] ?? null ) !== false ||
            ( $meta['result_sha256'] ?? null ) !== self::hash( $result ) || ( $meta['scope_hash'] ?? null ) !== ADE_Pilot_Scope::SHA256 ) { throw new RuntimeException( 'M2_RECEIPT_INVALID' ); }
        return array( 'receipt_id' => (int) $row['id'], 'historical' => true, 'metadata' => $meta,
            'result' => $result, 'database_writes' => 0, 'network_requests' => 0, 'publication_enabled' => false );
    }

    public static function record( string $raw, string $registered_url, string $token, string $confirmation, string $backup ): array {
        if ( $confirmation !== 'STORE_M2_PENDING' || $backup !== 'YES' || ! preg_match( '/^[a-f0-9]{64}$/D', $token ) ) { throw new RuntimeException( 'M2_EXPLICIT_WRITE_APPROVAL_REQUIRED' ); }
        $actor = self::guard(); $context = self::context( $raw, $registered_url );
        $lock_name = 'ade_m2_' . substr( self::hash( array( ADE_Schema::table_name('candidates'), $context['preview']['school_id'] ) ), 0, 48 );
        $acquired = self::one( 'SELECT GET_LOCK(%s,0) AS acquired', array( $lock_name ) );
        if ( (int) ( $acquired['acquired'] ?? 0 ) !== 1 ) { throw new RuntimeException( 'M2_WRITER_BUSY' ); }
        $transaction = false;
        try {
            self::transaction( 'START TRANSACTION' ); $transaction = true;
            // Fresh snapshot/scope, locked Discovery rows; external review cannot slip in.
            $built = self::build( self::context( $raw, $registered_url ), $actor, true );
            if ( ! hash_equals( $built['preview_token'], $token ) ) { throw new RuntimeException( 'M2_PREVIEW_STALE' ); }
            if ( null !== $built['replay'] ) {
                self::transaction( 'COMMIT' ); $transaction = false;
                return array( 'receipt_id' => $built['receipt_id'], 'replayed' => true, 'rows_created' => 0, 'candidate_versions_advanced' => 0, 'original_result_is_historical' => true, 'original_result' => $built['replay'], 'publication_enabled' => false );
            }
            $p = $built['context']['preview']; $source_id = $built['source_link']['source_id']; $now = current_time( 'mysql', true );
            $result = array( 'operation_key' => $built['operation_key'], 'school_id' => $p['school_id'], 'npsn' => $p['npsn'], 'candidates' => array(), 'rows_created' => 0, 'candidate_versions_advanced' => 0, 'publication_enabled' => false );
            foreach ( $built['plans'] as $plan ) {
                if ( $plan['locked'] ) { $result['candidates'][] = array( 'id' => $plan['existing_id'], 'action' => 'skipped_reviewed', 'target_key' => $plan['candidate']['target_key'] ); continue; }
                $candidate = $plan['candidate']; $candidate_id = $plan['existing_id'];
                if ( null === $candidate_id ) {
                    $candidate_id = self::insert( 'candidates', array( 'school_id' => $p['school_id'], 'candidate_type' => 'm2_meta_text_v1', 'target_type' => 'school_meta', 'target_key' => $candidate['target_key'],
                        'dedupe_key' => $plan['dedupe_key'], 'proposed_value' => $candidate['proposed_value'], 'current_value_snapshot' => $candidate['current_value_snapshot'], 'base_target_hash' => $candidate['base_target_hash'],
                        'identity_score' => 0, 'evidence_score' => 0, 'overall_score' => 0, 'review_status' => 'new', 'publish_status' => 'not_ready', 'row_version' => 1,
                        'approved_value' => null, 'approved_by_user_id' => null, 'approved_at' => null, 'published_local_at' => null, 'last_error_code' => 'M2_MANUAL_REVIEW_REQUIRED', 'created_at' => $now, 'updated_at' => $now ) );
                    ++$result['rows_created'];
                }
                $ids = array(); $new_links = 0;
                foreach ( $plan['evidence'] as $planned ) {
                    $entry = $planned['entry']; $evidence_id = $planned['existing_id'];
                    if ( null === $evidence_id ) {
                        $observed = array( 'schema_version' => 1, 'provenance' => 'operator_supplied_document', 'value' => $entry['observed_value'], 'input_sha256' => $p['input_sha256'], 'scope_hash' => ADE_Pilot_Scope::SHA256,
                            'operator_reference' => $entry['operator_reference'], 'identity_status' => 'pending', 'permission_state' => 'NOT_INDEPENDENTLY_VERIFIED' );
                        $checked = new DateTimeImmutable( $entry['checked_at'] );
                        $evidence_id = self::insert( 'evidence', array( 'school_id' => $p['school_id'], 'source_id' => $source_id, 'evidence_type' => 'document', 'attribute_hint' => $entry['target_key'], 'evidence_url' => $entry['source_url'],
                            'evidence_key' => $planned['evidence_key'], 'content_fingerprint' => $entry['content_fingerprint'], 'title' => 'M2 unverified operator document', 'snippet_text' => $entry['supporting_quote'],
                            'observed_value' => json_encode( $observed, JSON_THROW_ON_ERROR ), 'parse_status' => 'm2_manual_unverified', 'http_code' => null, 'checked_at' => $checked->format('Y-m-d H:i:s'), 'created_at' => $now ) );
                        ++$result['rows_created'];
                    }
                    if ( null === $planned['existing_link_id'] ) { self::insert( 'candidate_evidence', array( 'candidate_id' => $candidate_id, 'evidence_id' => $evidence_id, 'relation_type' => 'supports', 'weight_score' => 0, 'created_at' => $now ) ); ++$result['rows_created']; ++$new_links; }
                    $ids[] = $evidence_id;
                }
                if ( null !== $plan['existing_id'] && $new_links > 0 ) {
                    global $wpdb;
                    $table = ADE_Schema::table_name( 'candidates' );
                    $wpdb->last_error = '';
                    $changed = $wpdb->query( $wpdb->prepare(
                        "UPDATE {$table} SET row_version=row_version+1,updated_at=%s WHERE id=%d AND school_id=%d AND row_version=%d AND review_status='new' AND publish_status='not_ready' AND approved_value IS NULL AND approved_by_user_id IS NULL AND approved_at IS NULL AND published_local_at IS NULL",
                        $now, $candidate_id, $p['school_id'], $plan['existing_version']
                    ) );
                    if ( $changed !== 1 || $wpdb->last_error ) { throw new RuntimeException( 'M2_CANDIDATE_VERSION_CONFLICT' ); }
                    ++$result['candidate_versions_advanced'];
                }
                $result['candidates'][] = array( 'id' => $candidate_id, 'target_key' => $candidate['target_key'], 'action' => $plan['existing_id'] ? 'reused_pending' : 'created_pending', 'evidence_ids' => $ids );
            }
            ++$result['rows_created']; // Receipt itself is committed atomically with all rows.
            $meta = array( 'schema_version' => 1, 'result_sha256' => self::hash( $result ), 'scope_hash' => ADE_Pilot_Scope::SHA256, 'input_sha256' => $p['input_sha256'], 'preview_token' => $token, 'actor_user_id' => $actor, 'source_id' => $source_id,
                'relation_id' => $built['source_link']['relation_id'], 'registered_source_url' => $built['context']['source']['canonical_url'], 'blocking_reasons' => $p['blocking_reasons'], 'operator_reference' => $p['evidence'][0]['operator_reference'] );
            $receipt_id = self::insert( 'jobs', array( 'job_key' => $built['operation_key'], 'job_type' => self::TYPE, 'scope_level' => 'TASIK_NEGERI_200', 'scope_filter' => json_encode( $meta, JSON_THROW_ON_ERROR ),
                'status' => 'completed', 'attempt_count' => 1, 'max_attempts' => 1, 'cursor_school_id' => $p['school_id'], 'batch_size' => 1, 'stats_payload' => json_encode( $result, JSON_THROW_ON_ERROR ),
                'created_at' => $now, 'updated_at' => $now, 'started_at' => $now, 'finished_at' => $now ) );
            self::transaction( 'COMMIT' ); $transaction = false;
            return array( 'receipt_id' => $receipt_id, 'replayed' => false, 'result' => $result, 'publication_enabled' => false );
        } catch ( Throwable $e ) {
            if ( $transaction ) { self::transaction( 'ROLLBACK' ); }
            throw $e;
        } finally { self::one( 'SELECT RELEASE_LOCK(%s) AS released', array( $lock_name ) ); }
    }
}
