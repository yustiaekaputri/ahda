<?php
/** R3 hotfix tests. Pure CLI argument simulation; NO real WP-CLI, database, or network. */
if ( PHP_SAPI !== 'cli' ) { exit( 2 ); }
define( 'ABSPATH', __DIR__ . '/' );
final class WP_CLI {
    public static $messages = array();
    public static function error( $message ): void { throw new RuntimeException( $message ); }
    public static function log( $message ): void { self::$messages[] = $message; }
    public static function success( $message ): void { self::$messages[] = $message; }
}
final class ADE_Sources {
    public static $calls = array();
    public static function preflight(): array { return array( 'ready' => true ); }
    public static function preview( string $npsn, string $url, string $claimed_name = '' ): array {
        self::$calls[] = array('action' => 'preview', 'npsn' => $npsn, 'url' => $url);
        return array(
            'school' => array('id' => 100, 'npsn' => $npsn, 'name' => 'Sekolah Uji', 'regency_raw' => 'KAB. UJI', 'district_raw' => 'KEC. UJI'),
            'source' => array('canonical_url' => $url, 'source_type' => 'website', 'platform' => ''),
            'claimed_name_comparison' => 'not_supplied'
        );
    }
    public static function observe( string $npsn, string $url, string $label = '', string $claimed_name = '' ): array {
        self::$calls[] = array('action' => 'observe', 'npsn' => $npsn, 'url' => $url);
        return array('source_id' => 1, 'source_created' => true, 'school_source_id' => 1, 'relation_created' => true, 'school_id' => 100);
    }
}
require_once dirname(__DIR__) . '/includes/class-ade-source-urls.php';
require_once dirname(__DIR__) . '/includes/class-ade-sources-cli.php';
$cli = new ADE_Sources_CLI();
$count = 0;
$test = static function ( bool $condition, string $name ) use ( &$count ): void {
    $count++;
    if ( ! $condition ) { fwrite(STDERR, 'FAIL: ' . $name . "\n"); exit(1); }
};
$source_url = 'https://www.instagram.com/osis_contoh/?utm_source=demo';
$cli->check(array(), array('source-url' => $source_url));
$test( count(WP_CLI::$messages) > 2, 'check accepts source-url' );
$test( in_array('canonical_url: https://instagram.com/osis_contoh', WP_CLI::$messages, true), 'check canonicalizes social URL' );
WP_CLI::$messages = array();
$cli->preview(array(), array('npsn' => '20515441', 'source-url' => 'https://sekolah.sch.id/'));
$test( ADE_Sources::$calls[0]['url'] === 'https://sekolah.sch.id/', 'preview receives source-url' );
$test( in_array('identity_status: pending; relationship_type: pending; HTTP: NOT_PERFORMED', WP_CLI::$messages, true), 'preview remains pending' );
$cli->observe(array(), array('npsn' => '20515441', 'source-url' => 'https://sekolah.sch.id/', 'confirm' => 'STORE_R3_PENDING'));
$test( ADE_Sources::$calls[1]['action'] === 'observe', 'observe receives source-url' );
$test( ADE_Sources::$calls[1]['url'] === 'https://sekolah.sch.id/', 'observe URL correctly routed' );
foreach ( array('check', 'preview') as $method ) {
    $failed = false;
    try { $cli->$method(array(), array('npsn' => '20515441', 'url' => 'https://sekolah.sch.id/')); }
    catch ( RuntimeException $e ) { $failed = strpos($e->getMessage(), '--source-url') !== false; }
    $test( $failed, "$method refuses old global --url" );
}
$failed = false;
try { $cli->observe(array(), array('npsn' => '20515441', 'url' => 'https://sekolah.sch.id/', 'confirm' => 'STORE_R3_PENDING')); }
catch ( RuntimeException $e ) { $failed = strpos($e->getMessage(), '--source-url') !== false; }
$test( $failed, 'observe refuses old global --url' );
$failed = false;
try { $cli->observe(array(), array('npsn' => '20515441', 'source-url' => 'https://sekolah.sch.id/')); }
catch ( RuntimeException $e ) { $failed = strpos($e->getMessage(), '--confirm=STORE_R3_PENDING') !== false; }
$test( $failed, 'observe requires explicit confirmation' );
echo 'PASS: ' . $count . " R3 CLI argument hotfix checks (no WP, DB, HTTP).\n";
