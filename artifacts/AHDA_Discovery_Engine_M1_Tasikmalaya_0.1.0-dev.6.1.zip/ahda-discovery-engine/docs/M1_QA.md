# M1 QA dev.6.1 — scope Tasikmalaya

## Perubahan

- Membundel daftar operator 200 sekolah dan JSON klasifikasi dengan checksum.
- lookup_pilot SELECT ownership_status tanpa mengubah kontrak lookup R3.
- Validator identifier prefix ditambahkan pada lookup identitas.
- Manifest scoped v2 mengikat daftar NPSN, ID LocalWP dan checksum rujukan.
- CLI default memakai daftar beku; job baru tidak boleh unscoped.
- Preflight read-only seluruh 200, structured issues, failed/unrun terpisah.
- Scope diperiksa ulang setiap batch: negeri, region, jenjang dan NPSN/ID.
- Dry-run ditolak pada semua mutasi CLI, bukan hanya enqueue/run-one-batch.
- Legacy manifest v1 tetap dibaca untuk job lama; tidak ada DDL/schema change.

## Tes dan bukti

Jalankan `sh bin/test-offline.sh` dengan PHP CLI 8.2. `PHP_BIN=/path/php8.2`
dapat dipakai bila perlu. Runner memakai `-n`; setiap suite berjalan terpisah.
Fake cURL suite menolak native extension agar tidak membuka socket sungguhan.
Regresi enam suite R2/R3/R4a tetap dipertahankan. Tambahan scope/CLI memakai
NPSN dan klasifikasi yang dipilih, tetapi school_id SINTETIS dan database palsu.
Kelulusan fixture bukan bukti bahwa NPSN tersebut sudah cocok ke LocalWP aktual.

Bukti run, exit status, jumlah pemeriksaan dan lint tersimpan dalam
`docs/qa` paket dan `docs/qa/dev6.1` repositori. Perubahan kode hanya pada
salinan development, bukan baseline atau plugin Directory. PHP 8.2.32 / 8.4.24
CLI tersedia dari paket Debian bertanda tangan; bukan PHP LocalWP 8.2.29 pengguna.

Cakupan: original regressions, scope checksum, 200 identifiers, reclassification,
state/private, regency/province mismatch, changed ID, form mismatch, SQL prefix/
NPSN injection, permission/confirmation/local gate, dry-run zero-query rejection,
reference membership, complete 200-row audit, batch resume, conflict checkpoint,
dedupe, stale lease, commit rollback, retry/cancel, bootstrap no side effects.

## NOT TESTED / outstanding

- WordPress/LocalWP/MySQL 8.4 real integration, writes or schema postflight.
- Native HTTP/cURL, robots/terms policy, OS DNS bound and durable host throttle.
- Full parent plugin security review; some original manual CLI methods still
  lack explicit capability checks. New pilot entrypoints have capability gates.
- Real VPS resource usage, search-engine indexing and AI recommendations.
- Extraction/candidate generation, admin review and publication adapters.

No real network crawl, DB write, installation, activation, production or publish
was executed. All operational flags remain off; global dry-run stays on.
Read M1_LOCALWP.md before any operator-approved LocalWP operations.
