# Pemeriksaan eksplisit bukti terhadap raw — dev.7.12

`ADE_Archive_Verifier` membaca ulang **satu evidence yang terkait satu kandidat**.
Tujuannya memastikan nilai/kutipan/hash benar-benar berasal dari rawreceipt lokal.
Tidak memberikan persetujuan, bukti otoritas sumber, izin konten, atau publikasi.
Tidak ada source fetch maupun penulisan database/file oleh layanan ini.

## Cara memakai bila sudah ada record sah

Di SiteShell lokal, gunakan ID aktual dari inspector/candidate store:

```bat
wp --user="admin" ade pilot archive_verify --npsn=NPSN_PILIHAN --candidate-id=ID_KANDIDAT --evidence-id=ID_EVIDENCE --dry-run
```

Ganti placeholder dengan nilai aktual; jangan salin literal. Tidak ada opsi demo,
file, atau checkpoint yang dapat mengesahkan fakta. Saat ini demo Anda tidak
tersimpan, sehingga tidak perlu mengulang tes atau membuat record hanya untuk
mencoba command. Jangan mengaktifkan raw/candidate write atau mengubah fixture_only.
Nama command menggunakan underscore dan --dry-run wajib boolean true.

Command CLI memerlukan guard lokal/managejobs, capability review dan actor aktif.
API layanan internal memerlukan reviewcap/local/preflight; guard ini dapat dipakai
workflow review berikutnya tanpa markerCLI. Tidak ada endpoint web baru, form,
cron atau pemeriksaan berat otomatis pada page load. Raw1MiB maksimum, <=3dokumen
satu sekolah, SELECT dengan batas ukuran dan LIMIT2. UI tetap ringan dan tetap
jujur menyatakan bahwa raw belum diperiksa ulang **pada halaman** tersebut.

## Yang dibandingkan

1. Candidate/evidence/link harus ada, berelasi supports dan milik sekolah sama,
   tipe m2_meta_text_v1/school_meta dan salah satu3target M2; target terlindungi
   tidak diperbolehkan. Status evidence harus m2_archive_unverified.
2. Metadata observed JSON ketat/duplicatekeys ditolak, provenance/schema/scope,
   rawreceiptID dan SHA64, format dan value harus sesuai. Label identity/permission
   pada bukti tetap pending/NOT_INDEPENDENTLY_VERIFIED.
3. Rawreceipt diseleksi berdasarkan ID/type, ukuran/hash/kontrak diperiksa ulang,
   sekolah cocok dengan lookup legacy dan pilihan pilot. Raw body diambil oleh
   service internal berizin, tidak dikembalikan dalam hasil command.
4. Seluruh dokumen sekolah dalam rawreceipt di-parse ulang; captured extraction
   saat capture tetap tidak dianggap fakta. Error/konflik/identitas tidak cocok
   menghalangi pemeriksaan.
5. Kutipan, nilai, target, documentkey/rawSHA, format, sourceURL, normalized content
   fingerprint, waktu cek dan archive_evidence_key harus cocok persis dengan
   hasil parse. Stored evidence_key dihitung ulang menggunakan school/source/
   rawreceipt/payloadSHA/previewkey yang sama dengan writer.
6. Registered source binding/host cocok, sourceID dan relasi sekolah masih ada dan
   state lolos kebijakan pending. Source blocked/unknown/relationship lain ditolak.
   Label official/verified di DB tidak berubah menjadi attestation independen.
7. Current verified meta dibaca dan base hash dibandingkan. Bila berubah, raw
   masih dapat cocok tetapi current_value_conflict=true dan blocker ditambahkan.
   Pair candidate/evidence/link dibaca ulang di akhir; drift versi/data terdeteksi.

Kesalahan menghasilkan kode penahanan, tanpa menyalin raw atau query SQL/private
note ke output. Field NULL/oversized, mismatch, inaccessible DB, IDOR dan invalidID
fail closed. Evidence manual lama tidak dipaksa seolah punya rawreceipt baru.

## Arti hasil

`binding_matches:true` = konsistensi bukti terhadap arsip lokal pada pembacaan ini.
Hasil tetap identity_attested=false, permission_attested=false,
ready_for_approval=false, publication_enabled=false. Stale evidence dan konflik
nilai saat ini menjadi blocker. Tidak memperbarui verified badge, review_status,
row_version atau last_checked/profile date. Report tidak menyertakan nilai usulan,
kutipan/rawbody atau token otorisasi; hanya pointer/hash dan status.

`snapshot_only:true`, `must_revalidate_for_approval:true`: bukan transaction lock,
signature atau jaminan tidak ada perubahan sesudah pembacaan. Dua pembacaan pair
mendeteksi drift yang terlihat, bukan serialisasi editor DB lain/ABA/DBadmin.
Source/raw/current meta dapat berubah sesudah check. Workflow approve/publish masa
depan harus memeriksa ulang di dalam protokol transaksinya, beserta source
attestation/permission dan persetujuan admin. Jangan menerima report JSON sebagai
pengganti pemeriksaan tersebut. Checksum tidak melindungi DBadmin yang mengubah
raw+hash+metadata sekaligus. Source authenticity dan hak konten tetap belum terbukti.

## Bukti tes

- 25suite/1545checks masing-masing PHP8.2.32/8.4.24 dengan DOM;1477tanpaDOM (HTML NOT RUN pada konfigurasi itu).
- 85filePHP lint,84hash baseline dan6file tes asli utuh. Suite baru38checks fakeDB: quote/raw/value/fingerprint/time/source/proof tamper, duplicatekeys, IDOR/capability/local, candidate drift, current conflict, rejected state tetap, labelDB tidak memberi attestation; no mutation.
- 96service checks realWordPress7.1.4/Directory0.8.9/wpdb/MySQL8.4.13, ditambah47browser/admin checks. Enam bukti dua host dicek dari raw nyata di DB sintetis; quote/SHA/source-block dan actor/IDOR negative cases serta restore hash7Discovery diuji.25legacy synthetic tables utuh.
- OfficialWPCLI2.12 parser/dispatcher103checksDOM/101tanpaDOM; command/dry-run diuji. Harness actualWordPress memakai directservice API dan markerCLI untuk modul write sebelumnya; officialrunner penuh belum diuji.

Bukti final docs/qa/dev7.12/wordpress dan offline logs. Attempt1 FAIL login timeout
30s sebelum bridge; root cause tidak terbukti karena harness awal belum menyimpan
loginerror/server log. Diagnostik aman ditambahkan; attempts2dan3 pada situs baru
keduanya PASS96+47, PHPlog bersih. Tidak menaikkan timeout atau menyembunyikan FAIL.
Keterbatasan reproduksi login pertama tetap dicatat. Semua3DB/site/server milik
sesi dibersihkan, tidak ada wp-config pengguna/produksi/source network.

Rollback kode ke7.11 tanpa migrasi/penghapusan data. Verifier tidak membuat record
sehingga tidak ada data undo. Runtime writer/review/publisher lama tidak diubah,
semuanya tetap defaultOFF. Data nyata pengguna belum diproses; pengayaan0/200.
Berikutnya source/identity/permission attestations dan approval positif yang
memverifikasi raw secara segar, kemudian durableworker/publisher lokal/rollback.
