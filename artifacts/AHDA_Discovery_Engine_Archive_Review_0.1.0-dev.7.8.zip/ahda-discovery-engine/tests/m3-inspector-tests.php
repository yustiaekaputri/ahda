<?php
require_once __DIR__.'/support/m1-fake-db.php';
foreach(['identity','evidence-urls','pilot-scope','candidate-inspector','review-decisions'] as $name){require_once dirname(__DIR__).'/includes/class-ade-'.$name.'.php';}
require_once dirname(__DIR__).'/admin/class-ade-admin-review.php';
function wp_unslash($value){return stripslashes($value);}
function esc_html($value){return htmlspecialchars((string)$value,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
function esc_attr($value){return esc_html($value);}
function esc_url($value){return esc_attr($value);}
function admin_url($path){return 'http://ahda.local/wp-admin/'.$path;}
function add_query_arg($args,$url){return $url.'?'.http_build_query($args,'','&',PHP_QUERY_RFC3986);}
function wp_die($message,...$args){throw new RuntimeException('WP_DIE_403');}
function add_submenu_page(...$args){global $menu;$menu=$args;}
final class InspectDB {
 public $prefix='custom_',$last_error='',$inner,$candidate,$evidence=[],$list=[],$meta=[],$queries=[],$fail=false;
 public function __construct(){
  $this->inner=new FakeDB;$ref=ADE_Pilot_Scope::reference()['20268071'];$this->inner->schools['20268071']=array_merge($ref,['id'=>913,'name'=>'Synthetic inspector school','visibility'=>'publish']);
  $hash=hash('sha256',json_encode(['m2-meta-snapshot-v1',913,'profile_programs',null],JSON_THROW_ON_ERROR));
  $this->candidate=['id'=>'42','school_id'=>'913','target_key'=>'profile_programs','proposed_value'=>'Program uji','proposed_bytes'=>11,'current_value_snapshot'=>null,'snapshot_bytes'=>null,'base_target_hash'=>$hash,'approved_value'=>null,'approved_bytes'=>null,'review_status'=>'new','publish_status'=>'not_ready','row_version'=>'1','updated_at'=>'2026-11-10 00:00:00'];
  $this->evidence=[['link_id'=>'5','id'=>'7','school_id'=>'913','source_id'=>'7','attribute_hint'=>'profile_programs','evidence_type'=>'document','evidence_url'=>'https://example.org/profile','snippet_text'=>'Program: Program uji','snippet_bytes'=>20,'observed_value'=>json_encode(['value'=>'Program uji','scope_hash'=>ADE_Pilot_Scope::SHA256]),'observed_bytes'=>160,'parse_status'=>'m2_manual_unverified','checked_at'=>gmdate('Y-m-d H:i:s',time()-60),'access_state'=>'manual_only','source_status'=>'discovered','identity_status'=>'pending','relationship_type'=>'pending']];
  $this->list=[['id'=>'42','target_key'=>'profile_programs','proposed_excerpt'=>'Program uji','review_status'=>'new','publish_status'=>'not_ready','row_version'=>'1','updated_at'=>'2026-11-10 00:00:00']];
 }
 public function prepare($sql,...$args){return $this->inner->prepare($sql,...$args);}
 public function get_results($key,$kind){[$sql,$args]=$this->inner->prepared[$key];$this->queries[]=[$sql,$args];if($this->fail){$this->last_error='SQL hidden-private-detail';return null;}
  if(strpos($sql,'FROM custom_ahda_schools ')!==false){return $this->inner->get_results($key,$kind);}
  if(strpos($sql,'FROM custom_ahda_discovery_candidates ')!==false){if(strpos($sql,'WHERE id=%d')!==false){return $args[0]===42&&$args[1]===913?[$this->candidate]:[];}return $this->list;}
  if(strpos($sql,'FROM custom_ahda_school_meta ')!==false){if($args!==[913,'profile_programs','verified']){throw new RuntimeException('Unsafe current lookup');}return $this->meta;}
  if(strpos($sql,'FROM custom_ahda_discovery_candidate_evidence ')!==false){return $this->evidence;}
  if(strpos($sql,'FROM custom_ahda_discovery_reviews ')!==false){return [];}
  throw new RuntimeException('Unexpected inspector query');
 }
 public function query(...$args){throw new RuntimeException('Forbidden inspector write');}
 public function insert(...$args){throw new RuntimeException('Forbidden inspector write');}
}
$n=0;function ck($v,$label){global $n;++$n;if(!$v){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$label,$expected=null){$e=null;try{$fn();}catch(Throwable $x){$e=$x->getMessage();}ck($e!==null,$label);if($expected!==null){ck($e===$expected,'reason '.$label);}}
function fresh(){global $wpdb;$wpdb=new InspectDB;return $wpdb;}
function render($get){$_GET=$get;ob_start();try{ADE_Admin_Review::render();return ob_get_contents();}finally{ob_end_clean();}}
$db=fresh();$r=ADE_Candidate_Inspector::listing('20268071');ck(count($r['candidates'])===1&&$r['next_after']===null,'bounded list');
ck(!$r['review_actions_enabled']&&$r['database_writes']===0&&$r['network_requests']===0&&!$r['publication_enabled'],'read-only flags');
$r=ADE_Candidate_Inspector::detail('20268071',42);ck(!$r['current_value_conflict']&&$r['current_verified_value']===null,'current/base hash match');
ck(count($r['evidence'])===1&&$r['evidence'][0]['url']==='https://example.org/profile','same-school evidence');
ck(!isset($r['evidence'][0]['observed_value'])&&!isset($r['evidence'][0]['evidence_url']),'raw JSON and raw URL not exposed');
ck(in_array('SOURCE_IDENTITY_NOT_VERIFIED',$r['readiness_reasons'],true)&&in_array('SOURCE_PERMISSION_NOT_INDEPENDENTLY_VERIFIED',$r['readiness_reasons'],true),'pending state transparent');
$db->meta=[['meta_value'=>'Changed current','value_bytes'=>15]];$r=ADE_Candidate_Inspector::detail('20268071',42);ck($r['current_value_conflict'],'current hash conflict');
$db->meta=[['meta_value'=>'x','value_bytes'=>999999]];blocked(fn()=>ADE_Candidate_Inspector::detail('20268071',42),'oversized current','M3_CURRENT_VALUE_INVALID');
$db->meta=[['meta_value'=>'x','value_bytes'=>1],['meta_value'=>'y','value_bytes'=>1]];blocked(fn()=>ADE_Candidate_Inspector::detail('20268071',42),'duplicate current','M3_CURRENT_VALUE_INVALID');$db->meta=[];
blocked(fn()=>ADE_Candidate_Inspector::detail('20268071',43),'candidate IDOR','M3_CANDIDATE_NOT_FOUND');
blocked(fn()=>ADE_Candidate_Inspector::listing('12345678'),'outside scope','M3_OUTSIDE_PILOT');
blocked(fn()=>ADE_Candidate_Inspector::listing('20268071',"new' OR 1=1"),'SQL injection status','M3_FILTER_INVALID');
blocked(fn()=>ADE_Candidate_Inspector::listing('20268071','all',-1),'negative cursor','M3_FILTER_INVALID');
blocked(fn()=>ADE_Candidate_Inspector::detail('20268071',0),'zero ID','M3_ID_INVALID');
$db->candidate['proposed_bytes']=501;blocked(fn()=>ADE_Candidate_Inspector::detail('20268071',42),'oversized candidate','M3_CANDIDATE_INVALID');$db->candidate['proposed_bytes']=11;
$db->candidate['target_key']='profile_school_verified';blocked(fn()=>ADE_Candidate_Inspector::detail('20268071',42),'protected target','M3_CANDIDATE_INVALID');$db->candidate['target_key']='profile_programs';
$entry=$db->evidence[0];foreach(['school_id'=>999,'attribute_hint'=>'profile_hours','evidence_type'=>'other','observed_bytes'=>99999] as $field=>$value){$db->evidence[0]=$entry;$db->evidence[0][$field]=$value;blocked(fn()=>ADE_Candidate_Inspector::detail('20268071',42),'cross-link/corrupt evidence '.$field,'M3_EVIDENCE_CONFLICT');}$db->evidence[0]=$entry;
$db->evidence[0]['observed_value']=json_encode(['value'=>'Other','scope_hash'=>ADE_Pilot_Scope::SHA256]);blocked(fn()=>ADE_Candidate_Inspector::detail('20268071',42),'evidence value mismatch','M3_EVIDENCE_CONFLICT');$db->evidence[0]=$entry;
foreach(['javascript:alert(1)','https://127.0.0.1/','https://example.org/?access_token=HIDDEN_SECRET','https://user:HIDDEN_SECRET@example.org/'] as $url){$db->evidence[0]['evidence_url']=$url;$r=ADE_Candidate_Inspector::detail('20268071',42);ck($r['evidence'][0]['url']===null&&strpos(json_encode($r),'HIDDEN_SECRET')===false,'unsafe/sensitive URL not exposed');}$db->evidence[0]=$entry;
$db->evidence[0]['checked_at']='2020-01-01 00:00:00';ck(in_array('STALE_EVIDENCE',ADE_Candidate_Inspector::detail('20268071',42)['readiness_reasons'],true),'stale observation');$db->evidence[0]['checked_at']='2099-01-01 00:00:00';ck(in_array('EVIDENCE_TIMESTAMP_INVALID',ADE_Candidate_Inspector::detail('20268071',42)['readiness_reasons'],true),'future observation');
$db=fresh();$base=$db->list[0];$db->list=[];for($i=1;$i<=21;++$i){$v=$base;$v['id']=(string)$i;$db->list[]=$v;}$r=ADE_Candidate_Inspector::listing('20268071');ck(count($r['candidates'])===20&&$r['next_after']===20,'candidate keyset20+1');
$db=fresh();$base=$db->evidence[0];$db->evidence=[];for($i=1;$i<=21;++$i){$v=$base;$v['link_id']=(string)$i;$v['id']=(string)$i;$db->evidence[]=$v;}$r=ADE_Candidate_Inspector::detail('20268071',42);ck(count($r['evidence'])===20&&$r['next_evidence_after']===20&&$r['readiness_is_page_scoped'],'evidence keyset20+1');
$db=fresh();$db->evidence=[];ck(in_array('EVIDENCE_MISSING',ADE_Candidate_Inspector::detail('20268071',42)['readiness_reasons'],true),'missing evidence');
$cap=false;blocked(fn()=>ADE_Candidate_Inspector::listing('20268071'),'read capability','M3_LOCAL_REVIEW_CAP_REQUIRED');blocked(fn()=>render([]),'render unauthorized','WP_DIE_403');$cap=true;
ADE_Schema::$local=false;blocked(fn()=>ADE_Candidate_Inspector::detail('20268071',42),'production blocked','M3_LOCAL_REVIEW_CAP_REQUIRED');ADE_Schema::$local=true;
ADE_Jobs::$ready=false;blocked(fn()=>ADE_Candidate_Inspector::listing('20268071'),'preflight blocked','M3_PREFLIGHT_BLOCKED');ADE_Jobs::$ready=true;
$db=fresh();$before=count($db->queries);$h=render([]);ck(strpos($h,'Pilih sekolah')!==false&&count($db->queries)===$before,'empty page no candidate/schema reads');
$db->list=[];$h=render(['npsn'=>'20268071']);ck(strpos($h,'Belum ada kandidat tersimpan')!==false&&strpos($h,'Jangan menyimpan demo')!==false,'honest empty state');
$db=fresh();$payload='</td><img src=x onerror=alert(1)><script>bad</script>';$db->inner->schools['20268071']['name']=$payload;$db->list[0]['proposed_excerpt']=$payload;$h=render(['npsn'=>'20268071']);ck(strpos($h,'<img')===false&&strpos($h,'<script>')===false&&strpos($h,'&lt;img')!==false,'list/name XSS escaped');
$db->candidate['current_value_snapshot']=$payload;$db->candidate['proposed_value']=$payload;$db->evidence[0]['observed_value']=json_encode(['value'=>$payload,'scope_hash'=>ADE_Pilot_Scope::SHA256]);$db->evidence[0]['snippet_text']=$payload;$h=render(['npsn'=>'20268071','candidate'=>'42']);ck(strpos($h,'<img')===false&&strpos($h,'<script>')===false&&strpos($h,'&lt;script&gt;')!==false,'detail snapshot/value/quote XSS escaped');
ck(strpos($h,'method="post"')===false&&strpos($h,'type="submit"')!==false&&strpos($h,'Penerbitan profil belum diaktifkan')!==false,'GET only and clear disabled publication');
$h=render(['npsn'=>['x']]);ck(strpos($h,'M3_FILTER_INVALID')!==false,'array GET rejected');$h=render(['candidate'=>'1 OR 1=1']);ck(strpos($h,'M3_ID_INVALID')!==false,'unsafe ID rejected');
$db=fresh();$db->fail=true;$h=render(['npsn'=>'20268071']);ck(strpos($h,'hidden-private-detail')===false&&strpos($h,'M3_INSPECTOR_UNAVAILABLE')!==false,'raw SQL errors not leaked');
ADE_Admin_Review::menu();ck($menu[0]==='ahda-discovery-status'&&$menu[2]==='Kandidat (baca-saja)'&&$menu[3]==='ade_review_candidates','correct submenu and capability');
$db=fresh();ADE_Candidate_Inspector::detail('20268071',42);foreach($db->queries as [$sql,$args]){ck(strpos($sql,'SELECT ')===0&&strpos($sql,'LIMIT ')!==false,'only bounded SELECT');}
echo "PASS: $n M3 read-only inspector/security/UI checks (WP/fake DB stubs; no mutation).\n";
