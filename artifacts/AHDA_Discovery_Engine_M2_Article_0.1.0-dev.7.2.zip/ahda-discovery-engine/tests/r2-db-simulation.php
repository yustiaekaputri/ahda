<?php
/**
 * Queue state machine simulation without MySQL / WordPress. Not an integration test.
 * Run: php tests/r2-db-simulation.php
 */
if ( PHP_SAPI !== 'cli' ) { exit( 2 ); }
define( 'ABSPATH', __DIR__ . '/' );
define( 'WP_CLI', true );
define( 'ARRAY_A', 'ARRAY_A' );
final class WP_CLI {}
final class ADE_Schema {
    public static function report(): array { return array( 'state' => 'INSTALLED', 'issues' => array() ); }
    public static function is_allowed_local(): bool { return true; }
    public static function table_name( string $s ): string { return 'wp_ahda_discovery_' . $s; }
}
final class ADE_Config {
    public static function flags(): array { return array( 'ade_enable_jobs' => array( 'valid' => true ) ); }
}
final class ADE_Dependencies { public static function ready(): bool { return true; } }
$options = array();
function get_option( $key, $default = null ) { global $options; return array_key_exists( $key, $options ) ? $options[$key] : $default; }
function add_option( $key, $value, $deprecated = '', $autoload = false ) { global $options; if ( array_key_exists( $key, $options ) ) { return false; } $options[$key] = $value; return true; }
function delete_option( $key ) { global $options; if ( ! array_key_exists( $key, $options ) ) { return false; } unset( $options[$key] ); return true; }
function current_time( $type, $gmt = false ) { return gmdate( 'Y-m-d H:i:s' ); }
function wp_json_encode( $value ) { return json_encode( $value ); }
final class FakeDB {
    public $last_error = '';
    public $insert_id = 0;
    private $rows = array();
    private $next_id = 1;
    public function prepare( $template, ...$args ) {
        if ( count( $args ) === 1 && is_array( $args[0] ) ) { $args = $args[0]; }
        $i = 0;
        return preg_replace_callback( '/%[ds]/', function( $m ) use ( &$i, $args ) {
            $a = $args[$i++];
            return $m[0] === '%d' ? (string) intval($a) : "'" . str_replace("'", "''", (string) $a ) . "'";
        }, $template );
    }
    private function job( string $sql ) {
        if ( preg_match( '/job_key=\'([^\']+)\'/i', $sql, $m ) ) {
            foreach ( $this->rows as $r ) { if ( $r['job_key'] === $m[1] ) { return $r; } }
            return null;
        }
        if ( preg_match( '/WHERE id=(\d+)/i', $sql, $m ) ) { return $this->rows[(int)$m[1]] ?? null; }
        foreach ( $this->rows as $r ) {
            if ( $r['job_type'] === ADE_Jobs::TEST_TYPE && in_array( $r['status'], array( 'queued', 'retry_wait' ), true ) && $r['attempt_count'] < $r['max_attempts'] && ( ! $r['next_run_at'] || $r['next_run_at'] <= time() ) ) { return $r; }
        }
        return null;
    }
    public function get_row( $sql, $type = null ) { return $this->job( $sql ); }
    public function advance_retry( int $id ): void { $this->rows[$id]['next_run_at'] = time() - 1; }
    public function get_results( $sql, $type = null ) {
        if ( strpos( $sql, 'wp_ahda_discovery_jobs' ) !== false ) { return array_values( $this->rows ); }
        throw new RuntimeException( 'Unexpected mock SELECT: ' . $sql );
    }
    public function insert( $table, $fields ) {
        if ( $table !== 'wp_ahda_discovery_jobs' || $fields['job_type'] !== ADE_Jobs::TEST_TYPE ) { throw new RuntimeException( 'Unexpected insert into ' . $table ); }
        foreach ( $this->rows as $r ) { if ( $r['job_key'] === $fields['job_key'] ) { $this->last_error = 'duplicate'; return false; } }
        $id = $this->next_id++;
        $this->rows[$id] = array_merge( array( 'id' => $id, 'lease_token' => null, 'leased_until' => null, 'next_run_at' => null, 'cursor_school_id' => null, 'last_error_code' => null, 'stats_payload' => null, 'started_at' => null, 'finished_at' => null ), $fields );
        $this->insert_id = $id;
        return 1;
    }
    public function query( $sql ) {
        if ( strpos( $sql, 'UPDATE wp_ahda_discovery_jobs SET ' ) !== 0 ) { throw new RuntimeException( 'Unexpected SQL ' . $sql ); }
        if ( preg_match( '/WHERE id=(\d+)/', $sql, $m ) ) { $id = (int) $m[1]; }
        elseif ( preg_match( '/WHERE job_type=/', $sql ) ) { return 0; }
        else { throw new RuntimeException( 'UPDATE without expected WHERE' ); }
        $r =& $this->rows[$id];
        if ( ! $r || $r['job_type'] !== ADE_Jobs::TEST_TYPE ) { return 0; }
        if ( preg_match( "/AND status='leased' AND lease_token='([a-f0-9]+)'/", $sql, $t ) ) {
            if ( $r['status'] !== 'leased' || $r['lease_token'] !== $t[1] ) { return 0; }
        }
        if ( strpos( $sql, "SET status='leased'" ) !== false ) {
            if ( ! in_array( $r['status'], array( 'queued','retry_wait' ), true ) || $r['attempt_count'] >= $r['max_attempts'] ) { return 0; }
            preg_match( "/lease_token='([a-f0-9]+)'/", $sql, $token );
            $r['lease_token'] = $token[1];
            $r['status'] = 'leased';
            $r['leased_until'] = time() + 120;
            $r['attempt_count']++;
            return 1;
        }
        if ( strpos( $sql, 'SET leased_until=DATE_ADD(leased_until,' ) !== false ) { $r['leased_until'] += 120; return 1; }
        if ( strpos( $sql, 'SET cursor_school_id=1' ) !== false ) {
            $r['cursor_school_id'] = 1;
            $r['stats_payload'] = '{"synthetic":true}';
            return 1;
        }
        if ( strpos( $sql, "SET status='completed'" ) !== false ) { $r['status'] = 'completed'; $r['lease_token'] = null; $r['last_error_code'] = null; return 1; }
        if ( strpos( $sql, 'SET status=\'retry_wait\'' ) !== false ) { $r['status'] = 'retry_wait'; $r['lease_token'] = null; $r['next_run_at'] = time() + 15; return 1; }
        if ( strpos( $sql, "SET status='cancelled'" ) !== false ) { if ( ! in_array($r['status'], array('queued','retry_wait'),true) ) { return 0; } $r['status'] = 'cancelled'; return 1; }
        throw new RuntimeException( 'Unsupported simulated SQL ' . $sql );
    }
}
$wpdb = new FakeDB();
require_once dirname( __DIR__ ) . '/includes/class-ade-jobs.php';
$checks = 0;
$check = function( $ok, $name ) use ( &$checks ) {
    ++$checks;
    if ( ! $ok ) { fwrite(STDERR, "FAIL $name\n"); exit(1); }
};
$a = ADE_Jobs::seed( 'smoke-a' );
$check( $a['created'] && $a['status'] === 'queued', 'seed new' );
$b = ADE_Jobs::seed( 'smoke-a' );
$check( ! $b['created'] && $a['id'] === $b['id'], 'idempotent seed' );
$check( count( ADE_Jobs::list_jobs() ) === 1, 'list one' );
$result = ADE_Jobs::step();
$check( $result['processed'] && $result['status'] === 'completed', 'claim heartbeat checkpoint complete' );
$check( ADE_Jobs::inspect( $a['id'] )['cursor_school_id'] == 1, 'checkpoint' );
$check( ADE_Jobs::inspect( $a['id'] )['status'] === 'completed', 'persist complete' );
$check( ! ADE_Jobs::step()['processed'], 'no reprocessing completed' );
$check( get_option('ade_r2_worker_lock') === null, 'mutex cleaned up' );
$c = ADE_Jobs::seed( 'smoke-b' );
$check( ADE_Jobs::cancel( $c['id'] ), 'cancel queued' );
$check( ADE_Jobs::inspect( $c['id'] )['status'] === 'cancelled', 'persist cancelled' );
$check( ! ADE_Jobs::cancel( $a['id'] ), 'cannot cancel completed' );
$d = ADE_Jobs::seed( 'retry-test' );
$r = ADE_Jobs::step( true );
$check( $r['processed'] && $r['id'] === $d['id'] && $r['status'] === 'retry_wait', 'simulated failure to retry_wait' );
$check( ! ADE_Jobs::step()['processed'], 'not ready before retry_at' );
$wpdb->advance_retry( $d['id'] );
$r2 = ADE_Jobs::step();
$check( $r2['status'] === 'completed' && $r2['attempt'] === 2, 'retry to completed' );
$check( ADE_Jobs::inspect( $d['id'] )['status'] === 'completed', 'retry persisted' );
echo "PASS: $checks simulated queue checks (fake DB; no real MySQL).\n";
