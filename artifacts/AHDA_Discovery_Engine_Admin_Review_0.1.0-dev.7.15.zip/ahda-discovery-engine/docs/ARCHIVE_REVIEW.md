> dev7.10: receipt-to-pending-evidence/candidate module exists, default OFF.
> No real-data write approved/enabled; see ARCHIVE_CANDIDATES.md.
> Statements below retain their original version scope.

> dev7.9: raw-only archive vault now available but default OFF. This command
> remains read-only; raw-receipt to evidence/candidate storage is not implemented.
> See RAW_ARCHIVE_VAULT.md. Historical statements below retain their version scope.

# Review arsip dan draf multisumber — dev.7.8

Implementasi baca-saja untuk satu sekolah: baca ulang arsip raw, ekstrak bukti,
periksa relasi sumber yang telah terdaftar, bandingkan nilai profil saat ini,
dan buat draf artikel dengan kutipan setiap dokumen. Tidak membuat source baru,
tidak menyimpan evidence/candidate, tidak menyetujui atau menerbitkan konten.

## Coba di LocalWP (opsional)

Di Local > ahda > Open Site Shell setelah memperbarui companion7.8:

```bat
wp --user="admin" ade pilot inspect --demo --npsn=20210711 --dry-run
```

NPSN tersebut anggota pilihan200 dan dipakai sebagai sekolah pertama dalam
**demo sintetis**, bukan klaim fakta tentang sekolah itu. Semua fakta contoh
harus tetap berlabel sintetis. Dengan DOM tersedia dan identitas masih cocok,
contoh menghasilkan3kandidat,6bukti dari2dokumen yang sejalan,3bagian draf,
9topik belum dinilai. Tanpa DOM, contoh HTML ditahan dan artikel null; tidak
mengklaim ekstraksi HTML berhasil. Program yang berbeda pada sekolah demo kedua
menghasilkan konflik dan tidak menghasilkan artikel. Dokumen salahNPSN pada
sekolah ketiga juga tidak menghasilkan artikel. Sekolah tanpa dokumen needs_source.

Output JSON dapat panjang; periksa mode `READ_ONLY_ARCHIVE_REVIEW_PLAN`,
`database_writes:0`, `network_requests:0`, `storage_enabled:false`,
`approval_enabled:false`, `publication_enabled:false`. Tidak perlu mengulangi
seluruh demo/batch lama. Perintah ini bukan pengayaan artikel yang sudah tayang.

## Nilai profil dan relasi sumber

Identitas diambil dari indeks AHDA melalui lookup prepared yang sudah ada.
Klasifikasi/pilihan pilot/ownership/visibility diperiksa ulang. Hanya tiga target
lama: profile_programs, profile_curriculum, profile_hours. Snapshot membaca nilai
**verified** saat ini dari tabel meta lama dengan LIMIT4 dan cap16KiB/nilai;
baris duplikat, target lain, nilai terlalu besar dan error DB ditolak. Null berarti
nilai verified tidak ditemukan, bukan bukti bahwa seluruh profil tidak punya
informasi. Per kandidat ada current_value_snapshot, proposed_value,
change_required, base_target_hash. Nilai lama tidak ditimpa.

Tanpa bindings, setiap dokumen ditandai missing_operator_binding. Tidak menebak
bahwa host/domain sama berarti sumber resmi. Untuk arsip operator yang sah:

```bat
wp --user="admin" ade pilot inspect --archive-file="C:\Users\user\Documents\AHDA-preview\arsip.json" --bindings-file="C:\Users\user\Documents\AHDA-preview\bindings.json" --npsn=NPSN_PILIHAN --dry-run
```

Ganti path dan NPSN dengan nilai aktual; jangan memakai placeholder secara literal.
Arsip tetap kontrak docs/LOCAL_ARCHIVE_WORKER.md, tepat200pilihan, <=4MiB.
Bindings opsional JSON object <=16KiB, maksimal3entry:

```json
{"KUNCI_DOKUMEN_64_HEX_DARI_ARSIP":"https://website-yang-sudah-terdaftar/"}
```

Ini contoh bentuk, bukan file siap dijalankan. Kunci harus milik sekolah yang
sedang diperiksa. URL harus HTTPS kanonik tanpa token/credential, website, host
sama dengan dokumen. Query JOIN dibatasi ke school_id dan canonical_key, LIMIT2;
relasi tidak ditemukan/ambigu/blocked tidak dilewati. Tidak ada source auto-create.
Status manual_only + source dikenal + identity pending/verified + relationship
pending/official hanya berarti cocok untuk **kebijakan kandidat pending lama**.
Bahkan bila label DB verified/official, fitur ini tidak melakukan pembuktian baru;
identity_attested dan permission_attested tetap false. Blocker review/izin tetap.

## Draf artikel dan kualitas

Artikel menggabungkan klaim yang sejalan dan mempertahankan6kutipan pada contoh
2dokumen/3klaim, dengan document_key, raw_document_sha256, format, URL dan waktu
cek. Kutipan CSV/HTML berasal dari teks yang dinormalisasi, bukan offset byte raw.
Nama/judul/klaim/URL di-escape pada HTML. Tidak mengeksekusi script/aset sumber.
Metadata title/description hanya usulan, tidak diterapkan ke frontend/canonical/
structured data. Tidak menambah badge verified atau skor confidence buatan.

Bagian tanpa bukti tidak diisi otomatis. Sembilan topik lain masih
not_assessed_by_this_adapter dalam information_gaps; ini bukan kesimpulan bahwa
profil lama/sekolah tidak memiliki informasi tersebut. Kelengkapan seluruh profil,
SEO/peringkat Google dan rekomendasiAI belum terbukti. Draf belum layak terbit.
Bangunan artikel lama dari structured JSON tetap didukung; hasil fixture pada
jam beku dibandingkan byte-for-byte dengan7.7 dan identik.

## Integritas dan batas otoritas

Perintah ini selalu membaca arsip asli dan mem-parse ulang. Report/checkpoint
worker bukan input yang mengesahkan fakta. Tidak ada parameter checkpoint di
inspect. Perubahan raw/manifest/metadata/snapshot/actor/source mengubah checksum
rencana yang relevan. plan_sha256 adalah checksum operator-controlled, **bukan
signature, token persetujuan, atau token untuk store**. `pilot store` lama tetap
manual-only dengan kontrak structured evidence tersendiri; jangan mengirim output
inspect/work ke sana. Tidak ada command store-archive baru atau write opt-in.

Raw dokumen tidak disalin lagi ke output inspect; metadata/hash dan kutipan tetap
ada. Simpan arsip/laporan di luar webroot, jangan unggah data privat ke GitHub.
Fitur belum membuat arsip immutable tepercaya atau ikatan raw-evidence persisten.
Source relation dan snapshot bisa berubah setelah pembacaan (tanpa lock, karena
read-only); writer masa depan wajib validasi ulang dalam transaksi/lease/fencing.
Draf dirakit dari arsip raw secara independen; penanda identitas pada pure article
builder bukan bukti verifikasi sumber. Pekerjaan per sekolah dibatasi3dokumen;
arsip divalidasi ulang untuk tiap lapis, belum dioptimalkan sebagai scheduler.

## Pengujian dan rollback

22suite offline1371checks per PHP8.2.32/8.4.24 dengan DOM;1304tanpaDOM (HTML
NOT RUN).76filePHP lint.84hash baseline dan6file tes asli tetap utuh.131checks
review baru dengan fakeDB; officialWPCLI dispatcher86checks dengan DOM termasuk
file/bindings, tanpa parameter synopsis bermasalah.

164checks native MySQL8.4.13 memakai schema7tabel asli, adapter wpdb/WordPress
**stub** dan data sintetis sementara:18checks tambahan untuk jembatan arsip,
JOIN, snapshot,6kutipan, sumber blocked, tepat4SELECT pada jalur2bindings, dan
hash9tabel uji sebelum/sesudah. Ini bukan25tabel pengguna, bukan fullWordPress
atau LocalWP end-to-end. Sisa146checks mencakup writer lama, transaksi, rollback,
dedupe/retry/locks/review. Dua container milik sesi7.8 dibersihkan setelah dua run;
run final ada docs/qa/dev7.8/native-final. Tidak menyentuh database asli Anda.

WordPress39checks dev7.6 tetap bukti versi sebelumnya; inspect7.8 belum diuji
pada WordPress nyata/LocalWP pengguna. Tidak ada fetch sumber, perubahan profil,
role, schema, wp-config atau operasi produksi. Rollback ganti foldercompanion7.7,
tanpa migrasi/delete/import; simpan arsip/report operator. Bukti log/diff di QA.

Berikutnya: storage raw-pending dengan binding/retensi yang dapat diaudit,
transaction+receipt+lease/fencing dan recheck snapshot; persetujuan sumber/identitas
serta approval positif terpisah; publisher lokal berizin terakhir. Akses katalog
resmi masih dibatasi kebijakan cloud dan belum diulang; sisa izin riset18/20
request hanya untuk10sekolah awal. Tidak menjanjikan200profil faktual lengkap.
