> dev.7.6 adds real WordPress7.1.4 synthetic admin integration evidence for
> nonce/session/capability/wpdb/routing. See WORDPRESS_INTEGRATION.md. Earlier
> NOT TESTED statements below refer to prior versions; actual user LocalWP,
> third-party/theme/production operations still NOT TESTED. Writes remain OFF.

> dev.7.5 adds read-only negative-decision history and a separately guarded
> reject/defer foundation, OFF by default. No handler/forms active in standard
> package. See M3_NEGATIVE_REVIEW.md; original7.4 scope below is historical.

# M3 candidate inspector — dev.7.4 (read-only foundation)

WP Admin > AHDA Discovery > Kandidat (baca-saja).

Requires logged-in ade_review_candidates capability, ahda.local and successful
existing schema/dependency/safe-flags preflight. No CLI context required. Menu
registration/file load performs no queries/fetch; selecting a school reads only.
All operational flags stay OFF; don't enable ade_enable_review_ui to use this
read-only diagnostic. No capability writes, migrations or new options on load.

Choose one frozen pilot NPSN and optional stored review status. Only M2 text
candidates in the current three target fields are displayed, not unrelated R2/
R3/R4a data.20candidates/page, keyset cursor, no full directory scan/COUNT/OFFSET.
Unique-index school lookup checks current classification/visibility against pilot.
Invalid scope/identity/status/cursor/schema state blocks with a safe message.

Detail binds candidateID AND schoolID AND M2type; cross-school IDOR rejected.
Comparison: current VERIFIED meta value, original candidate snapshot, proposal,
and stored approved value. Hash matches same m2-meta-snapshot-v1 namespace as
writer; changed current value/base hash triggers warning, never overwrite.
A label 'approved' is stored state, not publication or independent certification.

Quotes/URL/time/source relationship shown with20evidence links/page. Evidence
must match same school, target, document type, M2parse status, value and frozen
scope hash; corrupt cross-links block, not leak another school's evidence. Raw
observed JSON/operator notes not emitted. HTTPS URLs canonical-validated and
credential/private-IP/token-query links hidden entirely; no DNS or HTTP request.
Source hyperlinks open only if operator explicitly clicks, with noreferrer/noopener.
Missing/unverified/blocked/stale source conditions explained. Permissions remain
not independently verified. Reasons apply only to loaded capped evidence page,
not a certificate of full readiness. Read-only multi-query view is not an atomic
snapshot; future decision handler must recheck row_version/base/evidence in a
transaction. No decisions are accepted from this view.

Text/name/value/quote/status attributes and links escaped with WordPress escaping
functions. GET filters only; no POST/action/AJAX/REST/write endpoint or nonce for
mutations (there are no mutations). Server capability/site checks on BOTH service
and controller, not just menu visibility. SQL values prepared, identifiers from
fixed validated prefix/schema allowlists. Bounded LEFT plus OCTET_LENGTH, duplicate/
oversized current snapshots rejected. SQL/raw exception details not reflected.

## Empty state is expected now

CLI extract/article/parse demo previews have persisted=false. Therefore selecting
a school will normally show no saved candidates. Do NOT store synthetic examples
just to populate the dashboard. No real school documents have been acquired or
profiles enriched. Previous native source/schema/parser reports remain evidence
for those specific commands only; not this admin page's LocalWP compatibility.

## Incomplete M3 scope

No approve/edit+approve/reject/defer, audit append, identity/permission decision,
bulk actions or publisher. No full confidence scoring or complete article review.
Candidate listing is M2only, no school-name search or separate level filter yet;
NPSN dropdown includes school form and Tasikmalaya regency. Future actions require
explicit local write enable/backup/operator approval, capability+nonce, optimistic
concurrency, source/period validation and append-only audit. Source permission
proof/archive contract still unresolved; no approval based on literal quote alone.
M4 publisher remains separate/OFF, no legacy writes allowed here.

## Testing / rollback

Offline fake WP/DB tests cover caps/local/preflight, scope/IDOR, current conflicts,
pagination, corrupt evidence, URL redaction and stored/reflected XSS escaping.
Native MySQL inspector queries/preservation tested under WP/wpdb stubs; not full
WordPress. Actual PHP view rendered in Chromium desktop/mobile under synthetic
WP/controller/data stubs with minimal CSS. Screenshots don't show real LocalWP,
theme/WordPress CSS or real candidates. See tests/browser/README.md and qa/dev7.4.
Native user LocalWP inspector page test pending. No public/frontend changes or
SEO hook/canonical/schema modifications. Rollback plugin files to7.3, no migration;
preserve every table/row. Do not deploy to ahda.sch.id.
