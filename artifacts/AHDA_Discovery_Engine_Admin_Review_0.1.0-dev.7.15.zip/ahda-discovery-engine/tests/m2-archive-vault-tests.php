<?php
require_once __DIR__.'/support/m1-fake-db.php';
foreach(['identity','source-urls','evidence-urls','pilot-scope','pilot','pilot-jobs','enrichment-preview','document-parser','local-archive','local-worker','article-preview','archive-review','archive-vault'] as $name){require_once dirname(__DIR__).'/includes/class-ade-'.$name.'.php';}
final class VaultDB {
 public $prefix='custom_',$last_error='',$insert_id=0,$inner,$meta=[],$jobs=[],$snapshot=null,$held=false,$fail_insert=false,$commit_fail=false,$ack_lost=false,$source_changed=false,$writes=0,$next=1;
 public $source=['source_id'=>7,'relation_id'=>8,'source_type'=>'website','access_state'=>'manual_only','source_status'=>'discovered','identity_status'=>'pending','relationship_type'=>'pending'];
 public function __construct(){$this->inner=new FakeDB;$this->inner->schools['20268071']=array_merge(ADE_Pilot_Scope::reference()['20268071'],['id'=>913,'name'=>'Synthetic vault test','visibility'=>'publish']);}
 public function prepare($sql,...$args){return $this->inner->prepare($sql,...$args);}
 public function get_results($key,$kind){[$sql,$args]=$this->inner->prepared[$key];
  if(strpos($sql,'GET_LOCK')!==false){if($this->held){return [['acquired'=>0]];}$this->held=true;return [['acquired'=>1]];}
  if(strpos($sql,'RELEASE_LOCK')!==false){$this->held=false;return [['released'=>1]];}
  if(strpos($sql,'FROM custom_ahda_schools ')!==false){return $this->inner->get_results($key,$kind);}
  if(strpos($sql,'FROM custom_ahda_school_meta ')!==false){return $this->meta;}
  if(strpos($sql,'FROM custom_ahda_discovery_sources ')!==false){$row=$this->source;if($this->source_changed&&strpos($sql,'FOR UPDATE')!==false){$row['access_state']='blocked';}return $row?[$row]:[];}
  if(strpos($sql,'FROM custom_ahda_discovery_jobs ')!==false){foreach($this->jobs as $row){if($row['job_type']===$args[1]&&(strpos($sql,'WHERE id=%d')!==false?$row['id']===$args[0]:$row['job_key']===$args[0])){$row['scope_bytes']=strlen($row['scope_filter']);$row['stats_bytes']=strlen($row['stats_payload']);return [$row];}}return [];}
  throw new RuntimeException('Unexpected read');
 }
 public function query($sql){if($sql==='START TRANSACTION'){$this->snapshot=[$this->jobs,$this->next];return 0;}if($sql==='ROLLBACK'){if($this->snapshot!==null){[$this->jobs,$this->next]=$this->snapshot;}$this->snapshot=null;return 0;}if($sql==='COMMIT'){if($this->ack_lost){$this->snapshot=null;$this->last_error='Ack lost';return false;}if($this->commit_fail){$this->last_error='Commit failed';return false;}$this->snapshot=null;return 0;}throw new RuntimeException('Mutation not allowed');}
 public function insert($table,$values){if($table!=='custom_ahda_discovery_jobs'||$values['job_type']!==ADE_Archive_Vault::TYPE){throw new RuntimeException('Non-vault write');}++$this->writes;if($this->fail_insert){$this->last_error='Insert failed';return false;}foreach($this->jobs as $old){if($old['job_key']===$values['job_key']){$this->last_error='Duplicate';return false;}}$id=$this->next++;$this->jobs[$id]=array_merge($values,['id'=>$id]);$this->insert_id=$id;return 1;}
}
$n=0;function ck($ok,$label){global $n;++$n;if(!$ok){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$label,$expected=null){try{$fn();}catch(Throwable $e){ck($expected===null||$e->getMessage()===$expected,$label.' actual='.$e->getMessage());return;}ck(false,$label.' accepted');}
function raw_archive($fixture=false,$date=null){$a=ADE_Local_Archive::freeze(ADE_Local_Archive::demo())['bundle'];$a['fixture_only']=$fixture;$a['documents']=[];foreach($a['schools'] as &$school){$school['document_keys']=[];}unset($school);$csv=file_get_contents(dirname(__DIR__).'/data/examples/m2-profile-fixture.csv');$d=ADE_Local_Archive::document($csv,'csv','https://example.org/synthetic-vault-test',$date??gmdate('Y-m-d\TH:i:s\Z',time()-60),'synthetic-test-only');$a['documents'][$d['key']]=$d['entry'];foreach($a['schools'] as &$school){if($school['npsn']==='20268071'){$school['document_keys']=[$d['key']];}}unset($school);return json_encode($a,JSON_THROW_ON_ERROR);}
function bindings($raw){$a=ADE_Local_Archive::freeze($raw);return array_fill_keys(array_keys($a['bundle']['documents']),'https://example.org/');}
function stage($raw){return ADE_Archive_Vault::stage($raw,'20268071',bindings($raw));}
function store($raw,$token){return ADE_Archive_Vault::record($raw,'20268071',bindings($raw),$token,'STORE_RAW_PENDING','YES','YES');}
$wpdb=new VaultDB;$raw=raw_archive();$old=hash('sha256',serialize($wpdb->inner->schools));
ck(!ADE_Archive_Vault::enabled(),'default storage disabled');blocked(fn()=>store($raw,str_repeat('0',64)),'write blocked by default','VAULT_STORAGE_DISABLED');
$p=stage($raw);ck($p['estimated_jobs_rows_created']===1&&$p['document_count']===1&&$p['database_writes']===0&&$wpdb->writes===0,'concrete one-row read-only stage');
blocked(fn()=>stage(raw_archive(true)),'fixture rejected','VAULT_FIXTURE_BLOCKED');blocked(fn()=>stage(raw_archive(false,'2020-01-01T00:00:00Z')),'stale rejected','VAULT_DOCUMENTS_NOT_READY');
blocked(fn()=>ADE_Archive_Vault::stage($raw,'20268071',[]),'bindings required','VAULT_BOUND_SOURCES_REQUIRED');
define('ADE_LOCAL_ARCHIVE_STORAGE_ENABLED',true);
foreach([['BAD','YES','YES'],['STORE_RAW_PENDING','NO','YES'],['STORE_RAW_PENDING','YES','NO']] as $args){blocked(fn()=>ADE_Archive_Vault::record($raw,'20268071',bindings($raw),$p['preview_token'],...$args),'explicit guards','VAULT_EXPLICIT_APPROVAL_REQUIRED');}
$done=store($raw,$p['preview_token']);ck($done['rows_created']===1&&!$done['replayed']&&count($wpdb->jobs)===1,'one immutable raw receipt');ck(!$wpdb->held,'lock released');
$r=ADE_Archive_Vault::receipt($done['receipt_id']);ck(!$r['raw_content_returned']&&$r['historical']&&!isset($r['summary']['content'])&&$r['summary']['status']==='raw_pending_unverified','receipt metadata only');
ck($r['summary']['evidence_rows_created']===0&&$r['summary']['candidate_rows_created']===0&&!$r['summary']['permission_attested']&&!$r['summary']['identity_attested']&&!$r['summary']['publication_enabled'],'raw archive not evidence or authority');
$payload=json_decode($wpdb->jobs[$done['receipt_id']]['scope_filter'],true);$selected=ADE_Local_Archive::freeze(json_encode($payload['selected_bundle'],JSON_THROW_ON_ERROR))['bundle'];
ck(count($selected['documents'])===1&&$selected['fixture_only']===false&&count($payload['extraction']['evidence'])===3,'raw plus extraction trace captured');
ck(count(array_filter($selected['schools'],static function($s){return $s['npsn']!=='20268071'&&$s['document_keys']!==[];}))===0,'no raw from other199schools');
$again=store($raw,$p['preview_token']);ck($again['replayed']&&$again['rows_created']===0&&count($wpdb->jobs)===1,'exact retry idempotent');
ck(stage($raw)['already_recorded']&&stage($raw)['estimated_jobs_rows_created']===0,'stage identifies historical receipt');
$id=$done['receipt_id'];$saved=$wpdb->jobs[$id];$wpdb->jobs[$id]['scope_filter']=str_replace('PROGRAM CONTOH UJI','PROGRAM CHANGED',$saved['scope_filter']);blocked(fn()=>ADE_Archive_Vault::receipt($id),'raw corruption detected');$wpdb->jobs[$id]=$saved;
$stats=json_decode($saved['stats_payload'],true);$stats['publication_enabled']=true;$wpdb->jobs[$id]['stats_payload']=json_encode($stats);blocked(fn()=>ADE_Archive_Vault::receipt($id),'status tamper','VAULT_RECEIPT_INVALID');$wpdb->jobs[$id]=$saved;
$test_actor=2;blocked(fn()=>store($raw,$p['preview_token']),'other actor replay blocked','VAULT_RECEIPT_OTHER_ACTOR');$test_actor=1;
$wpdb=new VaultDB;$p=stage($raw);$wpdb->meta=[['meta_key'=>'profile_hours','meta_value'=>'Changed','value_bytes'=>7]];blocked(fn()=>store($raw,$p['preview_token']),'snapshot changed','VAULT_PREVIEW_STALE');ck(!$wpdb->jobs&&!$wpdb->held,'stale no write and unlock');
$wpdb=new VaultDB;$p=stage($raw);$wpdb->source_changed=true;blocked(fn()=>store($raw,$p['preview_token']),'locking source state recheck','VAULT_SOURCE_CHANGED');ck(!$wpdb->jobs&&!$wpdb->held,'source race no write');
$wpdb=new VaultDB;$p=stage($raw);$wpdb->held=true;blocked(fn()=>store($raw,$p['preview_token']),'shared M2 lock busy','VAULT_WRITER_BUSY');ck(!$wpdb->jobs,'contention no write');
foreach(['fail_insert','commit_fail'] as $fault){$wpdb=new VaultDB;$p=stage($raw);$wpdb->$fault=true;blocked(fn()=>store($raw,$p['preview_token']),$fault);ck(!$wpdb->jobs&&!$wpdb->held,'atomic rollback '.$fault);}
$wpdb=new VaultDB;$p=stage($raw);$wpdb->ack_lost=true;blocked(fn()=>store($raw,$p['preview_token']),'commit ack loss','VAULT_TRANSACTION_FAILED');ck(count($wpdb->jobs)===1&&!$wpdb->held,'unknown native outcome retained');$wpdb->ack_lost=false;ck(store($raw,$p['preview_token'])['replayed']&&count($wpdb->jobs)===1,'receipt recovers unknown outcome');
$denied_caps=['ade_review_candidates'];blocked(fn()=>stage($raw),'review capability','VAULT_OPERATOR_REQUIRED');$denied_caps=[];ADE_Schema::$local=false;blocked(fn()=>stage($raw),'local gate','LOCAL_OPERATOR_GATE_BLOCKED');ADE_Schema::$local=true;
ck(hash('sha256',serialize($wpdb->inner->schools))===$old,'legacy school bytes unchanged');
if(class_exists('DOMDocument')){
 $a=ADE_Local_Archive::freeze($raw)['bundle'];$a['documents']=[];foreach($a['schools'] as &$school){$school['document_keys']=[];}unset($school);
 $html=file_get_contents(dirname(__DIR__).'/data/examples/m2-profile-fixture.html').'<!--'.str_repeat('\\',200000).'-->';
 for($i=0;$i<3;$i++){$d=ADE_Local_Archive::document($html,'html','https://example.org/big-'.$i,gmdate('Y-m-d\TH:i:s\Z',time()-60),'synthetic-test-only');$a['documents'][$d['key']]=$d['entry'];foreach($a['schools'] as &$school){if($school['npsn']==='20268071'){$school['document_keys'][]=$d['key'];}}unset($school);}
 blocked(fn()=>stage(json_encode($a,JSON_THROW_ON_ERROR)),'encoded payload cap','VAULT_PAYLOAD_TOO_LARGE');
}
echo "PASS: $n raw archive vault/consent/idempotence/rollback checks (fake DB; synthetic inputs, no actual writes/network).\n";
