# dev.7.2 security review

Runtime diff limited to version/class include, shared bounded local JSON loader,
and new read-only article command/class. No changed schema/writer/crawler/legacy
or admin mutation hooks. No new SQL interpolation; indexed identity lookup uses
existing prepared-query path and validated prefix. Local/capability/dry-run guard
required on command. Input schema/identity/target/quote limits inherited from M2.
HTML text and attributes escaped, no raw Markdown/HTML inclusion. URL canonical
validation inherited, no fetch/DNS/redirect surface. Hidden bidi/control and
oversized/invalid identity names blocked. Sources/observations never promoted to
verified/approved/published. Metadata unapplied; no canonical/schema duplication.

Native testing runs only by explicit opt-in, fixed synthetic DB on own new
container. No arbitrary DB/host option. Random credentials memory only. Cleanup
uses only successful-create containerID, not a preexisting name. Actual schema,
InnoDB atomic rollback, unique dedupe, receipt replay, NOWAIT and two-session locks
verified under WP stubs. PHP/Python default invocations refuse before DB/Docker.
Runtime does not include test vendor/native files. No private/student data fetched.

Limits: literal quote containment is not factual verification/source authority or
permission. Untrusted instructions may appear as escaped text for human review;
no model is invoked. Full WP/theme/admin nonce/authorization integration, source
policy/DNS/throttle, native queue, external real races/load, real network commit
failure and publisher/rollback are not established by these tests. No guarantees
of complete security, production readiness, rankings or AI recommendations.
