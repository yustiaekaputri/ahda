<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * R1 create-only physical schema. No public/front-end/cron calls should invoke
 * create_missing(). Only the explicit WP-CLI installer is allowed to do so.
 *
 * SQL identifiers are never derived from external input; $wpdb->prefix is
 * validated and every table/column/index comes from fixed internal definitions.
 */
final class ADE_Schema {
    public const VERSION = 1;

    private const LEGACY_SUFFIXES = array(
        'bulk_events', 'bulk_jobs', 'data_sources', 'import_logs',
        'publication_events', 'publication_jobs', 'regions',
        'school_achievements', 'school_admissions', 'school_changes',
        'school_claims', 'school_contacts', 'school_details', 'school_events',
        'school_extracurriculars', 'school_facilities', 'school_fees',
        'school_jobs', 'school_media', 'school_meta', 'school_news',
        'school_search_terms', 'school_socials', 'school_stats', 'schools',
    );

    /** Fixed schema contract. MySQL 8.x / MariaDB-compatible declarations only. */
    public static function definitions(): array {
        return array(
            'sources' => array(
                'columns' => array(
                    'id' => 'bigint unsigned NOT NULL AUTO_INCREMENT',
                    'source_type' => 'varchar(32) NOT NULL',
                    'platform' => "varchar(32) NOT NULL DEFAULT ''",
                    'canonical_url' => 'varchar(1000) NOT NULL',
                    'canonical_key' => 'char(64) NOT NULL',
                    'normalized_host' => 'varchar(190) NOT NULL',
                    'handle_or_slug' => 'varchar(190) NULL',
                    'display_name' => 'varchar(255) NULL',
                    'catalog_source_id' => 'bigint unsigned NULL',
                    'access_state' => "varchar(24) NOT NULL DEFAULT 'manual_only'",
                    'source_status' => "varchar(24) NOT NULL DEFAULT 'discovered'",
                    'last_http_code' => 'smallint unsigned NULL',
                    'last_error_code' => 'varchar(64) NULL',
                    'last_checked_at' => 'datetime NULL',
                    'created_at' => 'datetime NOT NULL',
                    'updated_at' => 'datetime NOT NULL',
                ),
                'indexes' => array(
                    'PRIMARY' => array( true, array( 'id' ) ),
                    'canonical_key' => array( true, array( 'canonical_key' ) ),
                    'platform_handle' => array( false, array( 'platform', 'handle_or_slug' ) ),
                    'host_status' => array( false, array( 'normalized_host', 'source_status' ) ),
                ),
            ),
            'school_sources' => array(
                'columns' => array(
                    'id' => 'bigint unsigned NOT NULL AUTO_INCREMENT',
                    'school_id' => 'bigint unsigned NOT NULL',
                    'source_id' => 'bigint unsigned NOT NULL',
                    'relationship_type' => "varchar(24) NOT NULL DEFAULT 'pending'",
                    'identity_status' => "varchar(24) NOT NULL DEFAULT 'pending'",
                    'confidence_score' => 'tinyint unsigned NOT NULL DEFAULT 0',
                    'is_primary' => 'tinyint unsigned NOT NULL DEFAULT 0',
                    'verification_notes' => 'text NULL',
                    'verified_by_user_id' => 'bigint unsigned NULL',
                    'verified_at' => 'datetime NULL',
                    'last_checked_at' => 'datetime NULL',
                    'created_at' => 'datetime NOT NULL',
                    'updated_at' => 'datetime NOT NULL',
                ),
                'indexes' => array(
                    'PRIMARY' => array( true, array( 'id' ) ),
                    'school_source' => array( true, array( 'school_id', 'source_id' ) ),
                    'school_identity' => array( false, array( 'school_id', 'identity_status', 'relationship_type' ) ),
                    'source_identity' => array( false, array( 'source_id', 'identity_status' ) ),
                ),
            ),
            'evidence' => array(
                'columns' => array(
                    'id' => 'bigint unsigned NOT NULL AUTO_INCREMENT',
                    'school_id' => 'bigint unsigned NOT NULL',
                    'source_id' => 'bigint unsigned NOT NULL',
                    'evidence_type' => 'varchar(32) NOT NULL',
                    'attribute_hint' => 'varchar(64) NOT NULL',
                    'evidence_url' => 'varchar(1000) NOT NULL',
                    'evidence_key' => 'char(64) NOT NULL',
                    'content_fingerprint' => 'char(64) NULL',
                    'title' => 'varchar(255) NULL',
                    'snippet_text' => 'text NULL',
                    'observed_value' => 'text NULL',
                    'parse_status' => "varchar(24) NOT NULL DEFAULT 'new'",
                    'http_code' => 'smallint unsigned NULL',
                    'checked_at' => 'datetime NOT NULL',
                    'created_at' => 'datetime NOT NULL',
                ),
                'indexes' => array(
                    'PRIMARY' => array( true, array( 'id' ) ),
                    'evidence_key' => array( true, array( 'evidence_key' ) ),
                    'school_attribute' => array( false, array( 'school_id', 'attribute_hint' ) ),
                    'source_checked' => array( false, array( 'source_id', 'checked_at' ) ),
                ),
            ),
            'candidates' => array(
                'columns' => array(
                    'id' => 'bigint unsigned NOT NULL AUTO_INCREMENT',
                    'school_id' => 'bigint unsigned NOT NULL',
                    'candidate_type' => 'varchar(48) NOT NULL',
                    'target_type' => 'varchar(32) NOT NULL',
                    'target_key' => 'varchar(120) NOT NULL',
                    'dedupe_key' => 'char(64) NOT NULL',
                    'proposed_value' => 'longtext NOT NULL',
                    'current_value_snapshot' => 'longtext NULL',
                    'base_target_hash' => 'char(64) NULL',
                    'identity_score' => 'tinyint unsigned NOT NULL DEFAULT 0',
                    'evidence_score' => 'tinyint unsigned NOT NULL DEFAULT 0',
                    'overall_score' => 'tinyint unsigned NOT NULL DEFAULT 0',
                    'review_status' => "varchar(24) NOT NULL DEFAULT 'new'",
                    'publish_status' => "varchar(24) NOT NULL DEFAULT 'not_ready'",
                    'row_version' => 'bigint unsigned NOT NULL DEFAULT 1',
                    'approved_value' => 'longtext NULL',
                    'approved_by_user_id' => 'bigint unsigned NULL',
                    'approved_at' => 'datetime NULL',
                    'published_local_at' => 'datetime NULL',
                    'last_error_code' => 'varchar(64) NULL',
                    'created_at' => 'datetime NOT NULL',
                    'updated_at' => 'datetime NOT NULL',
                ),
                'indexes' => array(
                    'PRIMARY' => array( true, array( 'id' ) ),
                    'dedupe_key' => array( true, array( 'dedupe_key' ) ),
                    'school_review' => array( false, array( 'school_id', 'review_status', 'candidate_type' ) ),
                    'review_queue' => array( false, array( 'review_status', 'overall_score', 'id' ) ),
                    'publish_queue' => array( false, array( 'publish_status', 'approved_at', 'id' ) ),
                ),
            ),
            'candidate_evidence' => array(
                'columns' => array(
                    'id' => 'bigint unsigned NOT NULL AUTO_INCREMENT',
                    'candidate_id' => 'bigint unsigned NOT NULL',
                    'evidence_id' => 'bigint unsigned NOT NULL',
                    'relation_type' => "varchar(24) NOT NULL DEFAULT 'supports'",
                    'weight_score' => 'tinyint unsigned NOT NULL DEFAULT 50',
                    'created_at' => 'datetime NOT NULL',
                ),
                'indexes' => array(
                    'PRIMARY' => array( true, array( 'id' ) ),
                    'candidate_evidence' => array( true, array( 'candidate_id', 'evidence_id' ) ),
                    'evidence_relation' => array( false, array( 'evidence_id', 'relation_type' ) ),
                ),
            ),
            'reviews' => array(
                'columns' => array(
                    'id' => 'bigint unsigned NOT NULL AUTO_INCREMENT',
                    'candidate_id' => 'bigint unsigned NOT NULL',
                    'school_id' => 'bigint unsigned NOT NULL',
                    'review_action' => 'varchar(24) NOT NULL',
                    'before_status' => 'varchar(24) NOT NULL',
                    'after_status' => 'varchar(24) NOT NULL',
                    'candidate_version' => 'bigint unsigned NOT NULL',
                    'reviewed_value' => 'longtext NULL',
                    'reason_code' => 'varchar(64) NULL',
                    'review_notes' => 'text NULL',
                    'user_id' => 'bigint unsigned NOT NULL',
                    'created_at' => 'datetime NOT NULL',
                ),
                'indexes' => array(
                    'PRIMARY' => array( true, array( 'id' ) ),
                    'candidate_history' => array( false, array( 'candidate_id', 'created_at', 'id' ) ),
                    'school_history' => array( false, array( 'school_id', 'created_at', 'id' ) ),
                    'user_history' => array( false, array( 'user_id', 'created_at' ) ),
                ),
            ),
            'jobs' => array(
                'columns' => array(
                    'id' => 'bigint unsigned NOT NULL AUTO_INCREMENT',
                    'job_key' => 'char(64) NOT NULL',
                    'job_type' => 'varchar(32) NOT NULL',
                    'priority' => 'smallint unsigned NOT NULL DEFAULT 0',
                    'scope_level' => 'varchar(32) NOT NULL',
                    'scope_filter' => 'longtext NULL',
                    'status' => "varchar(24) NOT NULL DEFAULT 'queued'",
                    'lease_token' => 'char(64) NULL',
                    'leased_until' => 'datetime NULL',
                    'next_run_at' => 'datetime NULL',
                    'attempt_count' => 'smallint unsigned NOT NULL DEFAULT 0',
                    'max_attempts' => 'smallint unsigned NOT NULL DEFAULT 3',
                    'cursor_school_id' => 'bigint unsigned NULL',
                    'batch_size' => 'smallint unsigned NOT NULL DEFAULT 10',
                    'stats_payload' => 'longtext NULL',
                    'last_error_code' => 'varchar(64) NULL',
                    'started_at' => 'datetime NULL',
                    'finished_at' => 'datetime NULL',
                    'created_at' => 'datetime NOT NULL',
                    'updated_at' => 'datetime NOT NULL',
                ),
                'indexes' => array(
                    'PRIMARY' => array( true, array( 'id' ) ),
                    'job_key' => array( true, array( 'job_key' ) ),
                    'ready_queue' => array( false, array( 'status', 'next_run_at', 'priority', 'id' ) ),
                    'expired_lease' => array( false, array( 'status', 'leased_until' ) ),
                    'type_scope' => array( false, array( 'job_type', 'scope_level' ) ),
                ),
            ),
        );
    }

    public static function table_name( string $suffix ): string {
        global $wpdb;
        if ( ! preg_match( '/^[a-zA-Z0-9_]+$/D', (string) $wpdb->prefix ) ) {
            throw new RuntimeException( 'WordPress table prefix tidak aman untuk installer R1.' );
        }
        $definitions = self::definitions();
        if ( ! isset( $definitions[ $suffix ] ) ) {
            throw new InvalidArgumentException( 'Tabel Discovery tidak masuk allowlist.' );
        }
        $name = $wpdb->prefix . 'ahda_discovery_' . $suffix;
        if ( strlen( $name ) > 64 ) { throw new RuntimeException( 'Nama tabel melebihi batas MySQL.' ); }
        return $name;
    }

    /** Create DDL for one allowlisted, demonstrably absent table. */
    public static function create_sql( string $suffix ): string {
        global $wpdb;
        $definition = self::definitions()[ $suffix ];
        $pieces = array();
        foreach ( $definition['columns'] as $column => $declaration ) {
            $pieces[] = '  ' . $column . ' ' . $declaration;
        }
        foreach ( $definition['indexes'] as $index_name => $index ) {
            $column_list = implode( ',', $index[1] );
            if ( 'PRIMARY' === $index_name ) {
                $pieces[] = '  PRIMARY KEY  (' . $column_list . ')';
            } else {
                $pieces[] = '  ' . ( $index[0] ? 'UNIQUE ' : '' ) . 'KEY ' . $index_name . ' (' . $column_list . ')';
            }
        }
        $collation = trim( $wpdb->get_charset_collate() );
        if ( ! preg_match( '/\butf8mb4\b/i', $collation ) ) {
            throw new RuntimeException( 'R1 mengharuskan charset utf8mb4 pada database LocalWP.' );
        }
        return 'CREATE TABLE ' . self::table_name( $suffix ) . " (\n" . implode( ",\n", $pieces ) . "\n) ENGINE=InnoDB " . $collation;
    }

    /** Local site only. No environment-guessing on the VPS. */
    public static function is_allowed_local(): bool {
        $host = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
        return $host === 'ahda.local' && ! is_multisite();
    }

    /** Strictly read-only metadata query. */
    private static function query( string $sql, array $args = array() ): array {
        global $wpdb;
        $prepared = $args ? $wpdb->prepare( $sql, $args ) : $sql;
        $wpdb->last_error = '';
        $rows = $wpdb->get_results( $prepared, ARRAY_A );
        if ( null === $rows || '' !== $wpdb->last_error ) {
            throw new RuntimeException( 'Tidak dapat membaca metadata database: ' . (string) $wpdb->last_error );
        }
        return $rows;
    }

    /** Only metadata for tables starting with AHDA prefix, never row content. */
    private static function legacy_snapshot(): array {
        global $wpdb;
        $prefix = $wpdb->prefix . 'ahda_';
        $pattern = $wpdb->esc_like( $prefix ) . '%';
        $tables = self::query( 'SELECT TABLE_NAME,ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_TYPE=%s AND TABLE_NAME LIKE %s ORDER BY TABLE_NAME', array( 'BASE TABLE', $pattern ) );
        $found = array();
        $legacy_names = array();
        foreach ( $tables as $row ) {
            $name = $row['TABLE_NAME'];
            if ( strpos( $name, $wpdb->prefix . 'ahda_discovery_' ) === 0 ) { continue; }
            $found[] = $name;
            $legacy_names[ $name ] = strtoupper( (string) $row['ENGINE'] );
        }
        sort( $found, SORT_STRING );
        $expected = array();
        foreach ( self::LEGACY_SUFFIXES as $suffix ) { $expected[] = $wpdb->prefix . 'ahda_' . $suffix; }
        sort( $expected, SORT_STRING );
        $issues = array();
        if ( $found !== $expected ) {
            $issues[] = 'Inventaris tabel AHDA lama berbeda dari 25 tabel baseline; hentikan instalasi.';
        }
        foreach ( $legacy_names as $name => $engine ) {
            if ( 'INNODB' !== $engine ) { $issues[] = 'Engine tabel lama tidak InnoDB: ' . $name; }
        }
        if ( $found !== $expected ) {
            return array( 'issues' => $issues, 'hash' => null, 'names' => $found );
        }
        $cols = self::query( 'SELECT TABLE_NAME,COLUMN_NAME,COLUMN_TYPE,IS_NULLABLE,COLUMN_DEFAULT,EXTRA,ORDINAL_POSITION FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME LIKE %s ORDER BY TABLE_NAME,ORDINAL_POSITION', array( $pattern ) );
        $idx = self::query( 'SELECT TABLE_NAME,INDEX_NAME,NON_UNIQUE,SEQ_IN_INDEX,COLUMN_NAME,SUB_PART FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME LIKE %s ORDER BY TABLE_NAME,INDEX_NAME,SEQ_IN_INDEX', array( $pattern ) );
        $oldcols = array_values( array_filter( $cols, static function ( $item ) use ( $legacy_names ) { return isset( $legacy_names[ $item['TABLE_NAME'] ] ); } ) );
        $oldidx = array_values( array_filter( $idx, static function ( $item ) use ( $legacy_names ) { return isset( $legacy_names[ $item['TABLE_NAME'] ] ); } ) );
        $payload = array( 'names' => $legacy_names, 'columns' => $oldcols, 'indexes' => $oldidx );
        $json = wp_json_encode( $payload );
        if ( ! is_string( $json ) ) { throw new RuntimeException( 'Tidak bisa membuat fingerprint metadata lama.' ); }
        return array( 'issues' => $issues, 'hash' => hash( 'sha256', $json ), 'names' => $found );
    }

    private static function discovery_inventory(): array {
        global $wpdb;
        $pattern = $wpdb->esc_like( $wpdb->prefix . 'ahda_discovery_' ) . '%';
        return self::query( 'SELECT TABLE_NAME,ENGINE,TABLE_COLLATION FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME LIKE %s ORDER BY TABLE_NAME', array( $pattern ) );
    }

    /** Check exact columns and indexes; never repair or ALTER an existing table. */
    public static function verify_table( string $suffix ): array {
        $name = self::table_name( $suffix );
        $issues = array();
        $rows = self::query( 'SELECT ENGINE,TABLE_COLLATION FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=%s AND TABLE_TYPE=%s', array( $name, 'BASE TABLE' ) );
        if ( count( $rows ) !== 1 ) { return array( 'Tidak ada tabel yang sesuai: ' . $name ); }
        if ( strtoupper( (string) $rows[0]['ENGINE'] ) !== 'INNODB' ) { $issues[] = $name . ': engine bukan InnoDB'; }
        if ( strpos( strtolower( (string) $rows[0]['TABLE_COLLATION'] ), 'utf8mb4_' ) !== 0 ) { $issues[] = $name . ': charset bukan utf8mb4'; }
        $columns = self::query( 'SELECT COLUMN_NAME,DATA_TYPE,COLUMN_TYPE,CHARACTER_MAXIMUM_LENGTH,IS_NULLABLE,COLUMN_DEFAULT,EXTRA FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=%s ORDER BY ORDINAL_POSITION', array( $name ) );
        $actual = array();
        foreach ( $columns as $column ) { $actual[ $column['COLUMN_NAME'] ] = $column; }
        $def = self::definitions()[ $suffix ];
        if ( array_keys( $actual ) !== array_keys( $def['columns'] ) ) {
            $issues[] = $name . ': daftar/urutan kolom berbeda';
        }
        foreach ( $def['columns'] as $colname => $spec ) {
            if ( ! isset( $actual[ $colname ] ) ) { continue; }
            $col = $actual[ $colname ];
            if ( ! preg_match( '/^([a-z]+)(?:\((\d+)\))?/i', $spec, $m ) ) {
                throw new RuntimeException( 'Definisi kolom internal tidak valid.' );
            }
            $type = strtolower( $m[1] );
            if ( strtolower( (string) $col['DATA_TYPE'] ) !== $type ) { $issues[] = $name . '.' . $colname . ': tipe berbeda'; }
            if ( isset( $m[2] ) && (int) $col['CHARACTER_MAXIMUM_LENGTH'] !== (int) $m[2] ) {
                $issues[] = $name . '.' . $colname . ': panjang karakter berbeda';
            }
            $unsigned = (bool) preg_match( '/\bunsigned\b/i', $spec );
            if ( $unsigned !== (bool) preg_match( '/\bunsigned\b/i', (string) $col['COLUMN_TYPE'] ) ) {
                $issues[] = $name . '.' . $colname . ': signed/unsigned berbeda';
            }
            $nullable = (bool) preg_match( '/\bNULL\b/i', $spec ) && ! preg_match( '/\bNOT NULL\b/i', $spec );
            if ( $nullable !== ( 'YES' === $col['IS_NULLABLE'] ) ) { $issues[] = $name . '.' . $colname . ': nullability berbeda'; }
            $auto = (bool) preg_match( '/\bAUTO_INCREMENT\b/i', $spec );
            if ( $auto !== ( strpos( strtolower( (string) $col['EXTRA'] ), 'auto_increment' ) !== false ) ) {
                $issues[] = $name . '.' . $colname . ': auto_increment berbeda';
            }
            if ( preg_match( '/\bDEFAULT\s+(?:\'([^\']*)\'|([0-9]+))/', $spec, $d ) ) {
                $exp_default = isset( $d[1] ) && $d[1] !== '' ? $d[1] : ( isset( $d[2] ) ? $d[2] : '' );
                $got_default = $col['COLUMN_DEFAULT'];
                $got_default = is_string( $got_default ) ? trim( $got_default, "'" ) : $got_default;
                if ( (string) $got_default !== (string) $exp_default ) { $issues[] = $name . '.' . $colname . ': default berbeda'; }
            }
        }
        $indexes = self::query( 'SELECT INDEX_NAME,NON_UNIQUE,SEQ_IN_INDEX,COLUMN_NAME,SUB_PART FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=%s ORDER BY INDEX_NAME,SEQ_IN_INDEX', array( $name ) );
        $idx = array();
        foreach ( $indexes as $row ) {
            $key = $row['INDEX_NAME'];
            if ( ! isset( $idx[ $key ] ) ) { $idx[ $key ] = array( 'unique' => (int) $row['NON_UNIQUE'] === 0, 'columns' => array(), 'partial' => false ); }
            $idx[ $key ]['columns'][] = $row['COLUMN_NAME'];
            if ( null !== $row['SUB_PART'] ) { $idx[ $key ]['partial'] = true; }
        }
        $expected_index_names = array_keys( $def['indexes'] );
        $actual_index_names = array_keys( $idx );
        sort( $expected_index_names, SORT_STRING ); sort( $actual_index_names, SORT_STRING );
        if ( $expected_index_names !== $actual_index_names ) { $issues[] = $name . ': daftar index berbeda'; }
        foreach ( $def['indexes'] as $key => $expected ) {
            if ( ! isset( $idx[ $key ] ) ) { continue; }
            if ( $idx[ $key ]['unique'] !== $expected[0] || $idx[ $key ]['columns'] !== $expected[1] || $idx[ $key ]['partial'] ) {
                $issues[] = $name . ': index tidak sesuai: ' . $key;
            }
        }
        return $issues;
    }

    /**
     * Metadata-only report; intended for preflight, postflight, and admin page.
     * Returns status but never changes WordPress options or SQL schema.
     */
    public static function report(): array {
        $issues = array();
        $existing = array();
        $missing = array();
        $old_hash = null;
        try {
            $local = self::is_allowed_local();
            if ( ! $local ) { $issues[] = 'Installer R1 hanya diperbolehkan pada situs ahda.local non-multisite.'; }
            if ( ! ADE_Dependencies::ready() ) { $issues[] = 'API AHDA induk belum lengkap.'; }
            $flag_safe = true;
            foreach ( ADE_Config::flags() as $flag ) { if ( ! $flag['valid'] ) { $flag_safe = false; } }
            if ( ! $flag_safe ) { $issues[] = 'Feature flags tidak pada nilai aman.'; }
            global $wpdb;
            if ( ! preg_match( '/\butf8mb4\b/i', (string) $wpdb->get_charset_collate() ) ) {
                $issues[] = 'Charset WordPress tidak terkonfirmasi utf8mb4.';
            }
            $legacy = self::legacy_snapshot();
            $old_hash = $legacy['hash'];
            $issues = array_merge( $issues, $legacy['issues'] );
            $inv = self::discovery_inventory();
            $all_expected = array();
            foreach ( array_keys( self::definitions() ) as $suffix ) { $all_expected[] = self::table_name( $suffix ); }
            $actual_names = array();
            foreach ( $inv as $row ) {
                $actual_names[] = $row['TABLE_NAME'];
                if ( ! in_array( $row['TABLE_NAME'], $all_expected, true ) ) { $issues[] = 'Tabel Discovery asing ditemukan: ' . $row['TABLE_NAME']; }
            }
            foreach ( array_keys( self::definitions() ) as $suffix ) {
                $table = self::table_name( $suffix );
                if ( ! in_array( $table, $actual_names, true ) ) {
                    $missing[] = $table;
                } else {
                    $existing[] = $table;
                    $issues = array_merge( $issues, self::verify_table( $suffix ) );
                }
            }
            $schema_version = get_option( 'ade_schema_version', null );
            $state = get_option( 'ade_schema_install_state', null );
            if ( null !== $schema_version && (string) $schema_version !== (string) self::VERSION ) {
                $issues[] = 'Versi schema discovery tidak didukung: ' . (string) $schema_version;
            }
            if ( count( $missing ) === 0 && count( $issues ) === 0 ) {
                $result_state = (string) $schema_version === (string) self::VERSION && (string) $state === 'complete' ? 'INSTALLED' : 'NEEDS_FINALIZATION';
            } elseif ( count( $existing ) === 0 && count( $issues ) === 0 ) {
                $result_state = null === $schema_version ? 'READY' : 'INVALID';
            } elseif ( count( $issues ) === 0 && in_array( (string) $state, array( 'installing', 'partial' ), true ) ) {
                $result_state = 'RESUMABLE';
            } else {
                $result_state = 'BLOCKED';
            }
            if ( $result_state === 'INVALID' ) { $issues[] = 'Versi schema tercatat tetapi tabel belum ada.'; $result_state = 'BLOCKED'; }
            return array(
                'state' => $result_state,
                'issues' => $issues,
                'existing_discovery' => $existing,
                'missing_discovery' => $missing,
                'legacy_hash' => $old_hash,
                'install_state' => $state,
                'schema_version' => $schema_version,
                'local' => $local,
            );
        } catch ( Throwable $e ) {
            return array(
                'state' => 'BLOCKED',
                'issues' => array_merge( $issues, array( 'Gagal memeriksa schema: ' . $e->getMessage() ) ),
                'existing_discovery' => $existing,
                'missing_discovery' => $missing,
                'legacy_hash' => $old_hash,
                'install_state' => null,
                'schema_version' => get_option( 'ade_schema_version', null ),
                'local' => false,
            );
        }
    }

    /** Only called from explicit WP-CLI command after confirmed operator choices. */
    public static function install( bool $resume = false ): array {
        global $wpdb;
        if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) {
            throw new RuntimeException( 'Pemasangan schema hanya diperbolehkan dari WP-CLI.' );
        }
        $before = self::report();
        $acceptable = $resume ? array( 'READY', 'RESUMABLE', 'NEEDS_FINALIZATION', 'INSTALLED' ) : array( 'READY', 'INSTALLED' );
        if ( ! in_array( $before['state'], $acceptable, true ) || $before['issues'] ) {
            throw new RuntimeException( 'Preflight tidak lulus: ' . implode( '; ', $before['issues'] ) . ' (state=' . $before['state'] . ')' );
        }
        if ( $before['state'] === 'INSTALLED' ) { return array( 'created' => array(), 'already_installed' => true ); }
        $token = bin2hex( random_bytes( 16 ) );
        $lock = array( 'token' => $token, 'started' => time() );
        if ( ! add_option( 'ade_schema_install_lock', $lock, '', false ) ) {
            throw new RuntimeException( 'Ada schema install lock. Jalankan wp ade schema postflight untuk diagnosis.' );
        }
        $created = array();
        try {
            $fresh = self::report();
            if ( ! in_array( $fresh['state'], $acceptable, true ) || $fresh['issues'] ) {
                throw new RuntimeException( 'Preflight berubah setelah lock diperoleh.' );
            }
            // R1 is schema-only. Never adopt a partially installed table that
            // already contains rows; refuse, do not delete data.
            if ( $fresh['state'] !== 'INSTALLED' ) {
                foreach ( $fresh['existing_discovery'] as $table ) {
                    $one = self::query( 'SELECT 1 AS present FROM ' . $table . ' LIMIT 1' );
                    if ( $one ) { throw new RuntimeException( 'Tabel Discovery partial sudah berisi data; R1 menolak adopsi: ' . $table ); }
                }
            }
            update_option( 'ade_schema_install_state', 'installing', false );
            foreach ( array_keys( self::definitions() ) as $suffix ) {
                $table = self::table_name( $suffix );
                if ( in_array( $table, $fresh['existing_discovery'], true ) ) { continue; }
                $wpdb->last_error = '';
                $ok = $wpdb->query( self::create_sql( $suffix ) );
                if ( false === $ok || $wpdb->last_error ) {
                    throw new RuntimeException( 'CREATE TABLE gagal untuk ' . $table . ': ' . (string) $wpdb->last_error );
                }
                $created[] = $table;
                $table_issues = self::verify_table( $suffix );
                if ( $table_issues ) {
                    throw new RuntimeException( 'Verifikasi tabel baru gagal: ' . implode( '; ', $table_issues ) );
                }
            }
            $after = self::report();
            if ( $after['issues'] || count( $after['missing_discovery'] ) > 0 ) {
                throw new RuntimeException( 'Postflight R1 gagal: ' . implode( '; ', $after['issues'] ) );
            }
            if ( ! hash_equals( (string) $before['legacy_hash'], (string) $after['legacy_hash'] ) ) {
                throw new RuntimeException( 'Fingerprint metadata tabel lama berubah selama pemasangan.' );
            }
            update_option( 'ade_schema_version', (string) self::VERSION, false );
            update_option( 'ade_schema_install_state', 'complete', false );
            $verify = self::report();
            if ( $verify['state'] !== 'INSTALLED' || $verify['issues'] ) {
                throw new RuntimeException( 'Verifikasi akhir schema version gagal.' );
            }
            return array( 'created' => $created, 'already_installed' => false );
        } catch ( Throwable $e ) {
            update_option( 'ade_schema_install_state', 'partial', false );
            throw $e;
        } finally {
            $current = get_option( 'ade_schema_install_lock', null );
            if ( is_array( $current ) && isset( $current['token'] ) && hash_equals( $token, (string) $current['token'] ) ) {
                delete_option( 'ade_schema_install_lock' );
            }
        }
    }

    /** Manual stale-lock recovery; never removes table/data. */
    public static function release_stale_lock(): bool {
        if ( ! defined( 'WP_CLI' ) || ! WP_CLI || ! self::is_allowed_local() ) {
            throw new RuntimeException( 'Unlock R1 hanya dapat dilakukan melalui WP-CLI di ahda.local.' );
        }
        $lock = get_option( 'ade_schema_install_lock', null );
        if ( ! is_array( $lock ) || ! isset( $lock['started'] ) ) { return false; }
        if ( time() - (int) $lock['started'] < 1800 ) {
            throw new RuntimeException( 'Lock belum berumur 30 menit. Pastikan tidak ada installer yang masih berjalan.' );
        }
        return delete_option( 'ade_schema_install_lock' );
    }
}
