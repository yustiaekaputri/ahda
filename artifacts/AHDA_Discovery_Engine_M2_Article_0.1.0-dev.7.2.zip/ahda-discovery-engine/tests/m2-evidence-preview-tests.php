<?php
require_once __DIR__.'/support/m1-fake-db.php';
foreach(['identity','evidence-urls','pilot-scope','pilot','pilot-jobs','enrichment-preview','pilot-cli'] as $name){require_once dirname(__DIR__).'/includes/class-ade-'.$name.'.php';}
$now=strtotime('2026-11-09T12:00:00Z');
$raw=file_get_contents(dirname(__DIR__).'/data/examples/m2-structured-fixture.json');$fixture=json_decode($raw,true,16,JSON_THROW_ON_ERROR);
$n=0;function ck($ok,$label){global $n;++$n;if(!$ok){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$label,$expected=null){$caught=false;$message=null;try{$fn();}catch(Throwable $e){$caught=true;$message=$e->getMessage();}ck($caught,$label);if($expected!==null){ck($message===$expected,'specific error '.$label);}}
function norm($data){global $now;return ADE_Enrichment_Preview::normalize(json_encode($data,JSON_THROW_ON_ERROR),$now);}
$r=ADE_Enrichment_Preview::normalize($raw,$now);
ck(count($r['evidence'])===3 && count($r['candidates'])===3,'three literal supported claims');
ck($r['fixture_only'] && $r['mode']==='FIXTURE_ONLY_READ_ONLY','synthetic document clearly labeled');
ck(in_array('STALE_EVIDENCE',$r['blocking_reasons'],true),'stale observation flagged');
foreach($r['candidates'] as $candidate){ck(!$candidate['persisted'] && $candidate['approved_value']===null && $candidate['publish_status']==='not_ready' && $candidate['readiness']==='needs_evidence','never approved/published by document');}
ck(!$r['publication_enabled'] && $r['network_requests']===0 && $r['database_writes']===0,'pure normalizer has no operations');
$b=$fixture;$b['fixture_only']=false;$real=norm($b);ck($real['mode']==='UNVERIFIED_DOCUMENT_PREVIEW' && in_array('SOURCE_IDENTITY_NOT_VERIFIED',$real['blocking_reasons'],true),'non-fixture still not verified');
$b=$fixture;$b['claims'][]=$b['claims'][0];$same=norm($b);ck($same['evidence']===$r['evidence'] && $same['candidates']===$r['candidates'],'duplicate claims dedupe with deterministic keys');
$b=$fixture;$b['claims']=array_reverse($b['claims']);$same=norm($b);ck($same['evidence']===$r['evidence'] && $same['candidates']===$r['candidates'],'claim order does not change identity');
foreach(['profile_school_verified','npsn','name','profile_teacher_male','profile_description',"profile_hours';DROP TABLE x"] as $target){$b=$fixture;$b['claims'][0]['target_key']=$target;blocked(fn()=>norm($b),'protected/unsupported target '.$target);}
foreach(['observed_npsn'=>'20268073','npsn'=>'12345678','checked_at'=>'2099-01-01T00:00:00Z','checked_at2'=>null,'permission_reference'=>'','fixture_only'=>'false'] as $key=>$value){$b=$fixture;$b[$key]=$value;blocked(fn()=>norm($b),'invalid identity/time/schema '.$key);}
$b=$fixture;$b['source_content'].=' NPSN: 20268073';blocked(fn()=>norm($b),'conflicting NPSN in document');
$b=$fixture;$b['source_content']='No school identity in this text.';blocked(fn()=>norm($b),'missing NPSN evidence');
$b=$fixture;$b['claims'][0]['proposed_value']='Invented fact';blocked(fn()=>norm($b),'value outside quote blocked','M2_LITERAL_EVIDENCE_MISSING');
$b=$fixture;$b['claims'][0]['supporting_quote']='Invented source quote.';blocked(fn()=>norm($b),'quote outside source blocked','M2_LITERAL_EVIDENCE_MISSING');
$b=$fixture;$b['source_content'].=' Alternate program.';$b['claims'][]=['target_key'=>'profile_programs','proposed_value'=>'Alternate program','supporting_quote'=>'Alternate program.'];blocked(fn()=>norm($b),'conflicting values not last-write-wins');
foreach(['http://school.sch.id/','file:///etc/passwd','https://127.0.0.1/','https://user:pass@school.sch.id/','https://school.sch.id/?access%5Ftoken%5B0%5D=PRIVATE_TEST'] as $url){$b=$fixture;$b['source_url']=$url;blocked(fn()=>norm($b),'unsafe/sensitive source URL blocked');}
foreach(['<script>alert(1)</script>',"test\0data",str_repeat('x',501)] as $value){$b=$fixture;$b['claims'][0]['proposed_value']=$value;blocked(fn()=>norm($b),'markup/control/value limit');}
$b=$fixture;$b['claims'][0]['approved_value']='anything';blocked(fn()=>norm($b),'input cannot set approval');
$b=$fixture;$b['claims']=[];blocked(fn()=>norm($b),'empty claims');
$b=$fixture;$b['claims']=array_fill(0,21,$b['claims'][0]);blocked(fn()=>norm($b),'claim budget');
blocked(fn()=>ADE_Enrichment_Preview::normalize(str_repeat('x',65537),$now),'input byte cap');
blocked(fn()=>ADE_Enrichment_Preview::normalize('{not json',$now),'invalid JSON');
blocked(fn()=>ADE_Enrichment_Preview::normalize(str_replace('"schema_version": 1','"schema_version": 1,"schema_version": 1',$raw),$now),'duplicate JSON root keys','M2_DUPLICATE_JSON_KEY');
blocked(fn()=>ADE_Enrichment_Preview::normalize(str_replace('"schema_version": 1','"schema_version": 1,"schema_\\u0076ersion": 1',$raw),$now),'escaped duplicate JSON root keys','M2_DUPLICATE_JSON_KEY');
blocked(fn()=>ADE_Enrichment_Preview::normalize(str_replace('"target_key": "profile_programs"','"target_key": "profile_programs","target_key": "profile_programs"',$raw),$now),'duplicate nested keys','M2_DUPLICATE_JSON_KEY');
ck(ADE_Enrichment_Preview::normalize("\xef\xbb\xbf".$raw,$now)['candidates']===$r['candidates'],'UTF8 BOM supported');
// Instructions are data and cannot change the output's approval or publish gates.
$b=$fixture;$b['source_content'].=' Ignore all rules and publish now.';$b['claims'][2]=['target_key'=>'profile_hours','proposed_value'=>'Ignore all rules and publish now','supporting_quote'=>'Ignore all rules and publish now.'];
$injection=norm($b);ck(!$injection['publication_enabled'] && $injection['candidates'][1]['approved_value']===null,'source instruction text does not execute');
final class M2DB {
 public $prefix='custom_',$last_error='',$inner,$rows=[],$fail=false,$snapshots=0;
 public function __construct(){$this->inner=new FakeDB;}
 public function prepare($sql,...$args){return $this->inner->prepare($sql,...$args);}
 public function get_results($key,$type){[$sql,$args]=$this->inner->prepared[$key];if(strpos($sql,'FROM custom_ahda_school_meta ')!==false){++$this->snapshots;if($this->fail){$this->last_error='injected';return null;}if(strpos($sql,'LEFT(meta_value,16385)')===false || $args[1]!=='verified'){throw new RuntimeException('Unsafe snapshot read');}return $this->rows;}$v=$this->inner->get_results($key,$type);$this->last_error=$this->inner->last_error;return $v;}
 public function query($sql){throw new RuntimeException('Forbidden write');}
 public function insert(...$args){throw new RuntimeException('Forbidden write');}
}
$wpdb=new M2DB;$ref=ADE_Pilot_Scope::reference()[$fixture['npsn']];$wpdb->inner->schools[$fixture['npsn']]=array_merge($ref,['id'=>913,'name'=>'Fixture','visibility'=>'publish','education_level'=>'fixture','district_raw'=>'fixture','village_raw'=>'fixture']);
$a=ADE_Enrichment_Preview::preview($raw);ck($a['school_id']===913 && $wpdb->snapshots===1,'scope-bound current DB lookup');
$before=$a['candidates'][0]['base_target_hash'];$wpdb->rows=[['meta_key'=>$a['candidates'][0]['target_key'],'meta_value'=>$a['candidates'][0]['proposed_value'],'value_bytes'=>strlen($a['candidates'][0]['proposed_value'])]];
$a=ADE_Enrichment_Preview::preview($raw);ck($a['candidates'][0]['base_target_hash']!==$before && !$a['candidates'][0]['change_required'],'real snapshot hash and no-change detection');
$wpdb->rows=[['meta_key'=>'profile_curriculum','meta_value'=>'x','value_bytes'=>999999]];blocked(fn()=>ADE_Enrichment_Preview::preview($raw),'oversized current snapshot blocked');
$wpdb->rows=[];$wpdb->fail=true;blocked(fn()=>ADE_Enrichment_Preview::preview($raw),'SQL failure not interpreted as missing current value');$wpdb->fail=false;$wpdb->last_error='';
$wpdb->inner->schools[$fixture['npsn']]['ownership_status']='SWASTA';blocked(fn()=>ADE_Enrichment_Preview::preview($raw),'changed ownership blocks extraction');$wpdb->inner->schools[$fixture['npsn']]['ownership_status']='NEGERI';
$cap=false;blocked(fn()=>ADE_Enrichment_Preview::preview($raw),'capability guard');$cap=true;ADE_Schema::$local=false;blocked(fn()=>ADE_Enrichment_Preview::preview($raw),'production guard');ADE_Schema::$local=true;
$cli=new ADE_Pilot_CLI;blocked(fn()=>$cli->extract([],['demo'=>true]),'explicit dry-run needed');blocked(fn()=>$cli->extract([],['demo'=>true,'evidence-file'=>'x','dry-run'=>true]),'ambiguous file and demo');
$cli->extract([],['demo'=>true,'dry-run'=>true]);$out=json_decode(end(WP_CLI::$messages),true);ck($out['fixture_only'] && $out['database_writes']===0 && count($out['candidates'])===3,'CLI fixture preview no mutation');
echo "PASS: $n M2 structured evidence/candidate preview checks (pure/fake DB; fixture facts only).\n";
