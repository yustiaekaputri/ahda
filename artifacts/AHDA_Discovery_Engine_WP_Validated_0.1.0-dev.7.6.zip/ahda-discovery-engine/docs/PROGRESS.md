# AHDA development checkpoint

Date: 2026-11-09. Status: M1 PARTIAL — offline development increment complete;
real transport and LocalWP integration gates remain OPEN.

## Contracts and authorization

Read uploaded AHDA_AGENTS.md and AHDA_Codex_Master_Prompt_FastTrack.md in full;
copied them to repository root as AGENTS.md and master prompt. Continue actual
R4a, never rebuild the directory. User supplied both baseline ZIPs and approved
PHP tooling downloads. No live crawl, real DB write, production access, LocalWP
installation or publication has been executed. Production ahda.sch.id excluded.

## Source and changes

Original ZIPs preserved; extracted baseline under baseline/ with hashes in
qa/baseline-files.json. Directory unchanged. Development source is under
`development/ahda-discovery-engine`, version `0.1.0-dev.6.0`.

Added crawl policy, disabled pinned cURL adapter, frozen NPSN pilot validator,
read-only source-planning batches, separate m1_discovery_plan jobs with confirmed
local capability gate, leases/fencing, transaction checkpoint, resume, retry,
cancel, status and integrity-check. New ade pilot CLI registers only; no startup
network/cron/write. R2/R3/R4a code/schema remain unchanged except bootstrap/main
loads and version. New job type does not fetch, extract, verify or publish.

Changed/new file list and patch: docs/qa/development-diff.patch.
LocalWP guide and risks: development plugin docs/M1_LOCALWP.md and M1_QA.md.

## Tests

Logs: docs/qa/offline-tests.json and lint-php8.2.json / lint-php8.4.json.
PHP 8.2.32 and 8.4.24 run with -n. Six original Discovery suites pass (149 checks
per runtime), plus four new M1 suites; exact counts are in the logs. All ten
Directory standalone smoke suites pass under mocks. All PHP source files lint.
These are offline fixtures, not the user's schools, WordPress or MySQL proof.

## Known findings and unfinished work

- Actual Directory visibility is publish; some old fixtures use published.
- R1 legacy_hash is schema metadata only, not row data integrity.
- Old manual CLI lacks explicit capability checks in some paths; audit further.
- Native crawler remains hard-disabled and has no CLI fetch entrypoint.
  Need bounded DNS, durable per-host throttle across runs, real transport tests,
  and approved robots/terms/source policy before exposure. Generic proxy denied.
- Full manual parent-plugin security audit remains incomplete.
- Real LocalWP/MySQL integration: NOT TESTED. No real frozen pilot list supplied.
- M2 extraction/evidence/candidates, M3 admin review, M4 publication: NOT STARTED.
- Packaging is a development handoff only; production readiness NOT established.

## Next session

Do not repeat source inventory or passed offline suites unless code changes.
Read QA and handoff, review targeted diff and original hashes. Finish remaining
M1 transport/policy gates, extend CLI security review, and obtain the explicit
200-NPSN file. LocalWP is on user's machine, not cloud localhost. Before real DB,
network or install actions present exact impact and obtain scoped approval.
Never access wp-config.php/secrets, reimport, rebuild, or deploy production.
After an approved LocalWP planning test, record actual outputs and continue M2.
Rollback is restoring the original Discovery R4a ZIP on an approved backed-up
local installation; preserve M1 job rows and all legacy data, never drop tables.


## National NPSN input — follow-up 2026-11-09

User supplied nationwide text, not an explicitly frozen 200-school pilot.
Offline analysis/export DONE. 555,463 entries, 555,460 unique; duplicate codes
69931346, 70005045, 70005078 each occur twice. Unique partition: 530,732 eight-digit
numeric codes and 24,728 uppercase alphanumeric eight-character codes. Preserve
alphanumeric codes; existing numeric-only R3/M1 validation remains unchanged.
Matching counts alone do not establish matching database identities.

Outputs: data/npsn-national-2026-11-09/{master-unique.txt,
numeric8-pilot-compatible.txt,alphanumeric8-review.txt,report.json,README.md}.
New utility: tools/validate_npsn_master.py; tests/test_npsn_master.py.
Four Python unit tests PASS; national uniqueness/partition/hash checks PASS.
Evidence: docs/qa/npsn-master-tests.txt. No PHP plugin changes, so previous PHP
results stand without unrelated reruns. Existing development ZIP unchanged.
Original upload preserved; no network, real DB operations or pilot selection.
Next: explicit pilot selection and read-only matching against existing school
index (with school level and region); never treat numeric syntax as eligibility.
LocalWP database access is still unavailable in this cloud session.


## Regional pilot scope — follow-up 2026-11-09

User selected Jawa Barat and Jawa Tengah. Default documented allocation is 100
schools each, eligible forms SMA/SMK/MA/SMAK with visibility publish. Deterministic
ascending school_id within each province, intersecting the supplied national
master; never infer region from NPSN prefixes. No real schools selected yet.

Prepared data/pilot-jabar-jateng/scope.json, README.md and a read-only SQL export
template using the actual Directory schools schema and shipped regency map:
27 mapped Jabar regencies/cities (32), 35 Jateng (33). Query returns at most 1000
candidates per province, six school identity/classification columns only; actual
WP prefix must replace the placeholder. Query NOT EXECUTED; no DB connection.

Added tools/select_regional_pilot.py and tests/test_regional_pilot.py. Four unit
tests PASS: balanced stable selection, insufficient/master mismatch fails closed,
wrong region/level/visibility/formula/alpha rejection, duplicates and header checks.
QA log: docs/qa/regional-pilot-tests.txt. No PHP or ZIP changes.

Next external input: CSV from read-only LocalWP export containing school_id,
npsn,school_form,regency_raw,visibility,province_code. National NPSNs alone do not
contain these attributes. Do not invent or silently guess region/level. After
receipt run the selector, verify 100+100 and publish the frozen pilot file for
review; this does not authorize network/DB mutation/publication. Keep all existing
crawl and production gates. Rollback new tooling/docs/output only; no DB changes.


## Scope correction — latest user instruction 2026-11-09

SUPERSEDES the two-province 100+100 allocation and prior level restriction.
Select at most 200 STATE schools in JAWA BARAT ONLY. Prioritize SMP/MTs; only
if fewer than 200 exist, fill remaining slots with MA/SMA/SMK negeri in Jawa
Barat. Do not include Jateng, other provinces or private schools. Use explicit
ownership and province/regency evidence, never name/NPSN-prefix guesses. Stable
NPSN ordering per tier is a routine implementation default. If combined eligible
count is below 200, report shortage rather than relaxing constraints.

New uploaded ahda-nasional-2026.csv could NOT be transferred: download_file
returned "file exceeds the executor transfer limit of 32 MiB". Actual byte size,
CSV headers, contents and eligibility counts are UNKNOWN; no local CSV exists.
Tool discovery found no alternate upload/range-reading facility. No repeated
transfer attempts or invented results. Need ZIP <=32 MiB or smaller CSV parts
(with headers) / a Jabar-only export; keep original content and string NPSNs.

Saved current criteria in data/pilot-jabar-negeri/scope.json; prior regional scope
and README explicitly marked SUPERSEDED. No selection or output pilot yet.
No source/plugin/runtime/DB changes, network crawl or production action. No tests
run for this documentation-only scope correction. Existing M1 PHP eligibility
still excludes SMP/MTs: update + regression-test before feeding this new pilot to
M1. The old Python two-province selector must NOT be run for the new scope.


## Tasikmalaya workbook selection — 2026-11-09

Latest user supplied kab ko tasikmalaya.xlsx and instructed selection from it.
Input transferred successfully (464049 bytes), SHA-256:
fd02a73281cc85b9580b04a05c6e9f370421df8068cc3e615f4e1abfb81b4946.
One worksheet, 5763 data rows, 12 explicit classification columns. Only KAB.
TASIKMALAYA (4503) and KOTA TASIKMALAYA (1260); both map to Jabar code32.
Status explicitly NEGERI/SWASTA; no formulas or duplicate source NPSNs found.

235 eligible state candidates all match supplied national master: priority177
(SMP159/MTS18), fallback58 (MA10/SMA30/SMK18). Selected all priority177 plus
23 lowest-NPSN candidates from combined fallback: SMA21/SMK2, MA0. No quality
ranking implied. Final200: Kabupaten164, Kota36, all negeri, none outside Jabar.
Selection is now OFFLINE FROZEN; no random choice or live database validation.

Files: tools/select_tasikmalaya_pilot.py, tests/test_tasikmalaya_pilot.py;
outputs under data/pilot-jabar-negeri/tasikmalaya-200/ (TXT, CSV, JSON, XLSX,
report, README). scope.json updated. Six unit tests PASS plus actual source-row,
master membership, uniqueness, state/region/priority, hashes and generated XLSX
reopen/no-formula checks PASS. Log: docs/qa/tasikmalaya-selection-tests.txt.
Pilot TXT SHA-256: 42aaa7c51d5e0163c08146d1c46df70e260496639b9a3cc55e34f58781b1af20.

No PHP/ZIP changes or repeated unrelated PHP suites. No DB, network crawl,
publication or production operations. Important next work: M1 dev.6.0 currently
excludes SMP/MTS; update allowed forms under latest user scope, add regressions,
then validate frozen identities/ownership/region against read-only LocalWP data
before any approved write/run. Workbook validation is not proof of live DB or
independent official school verification. Rollback generated local files only;
original workbook and legacy records remain intact.


## Continued integration — dev.6.1 / 2026-11-09

User said "lanjutkan". Completed safe M1 integration for the selected 200:
- New pinned reference class and bundled 200-NPSN TXT/classification JSON.
- Scoped manifest JSON v2 binds NPSNs, current database IDs and reference SHA;
  database schema stays 1, no DDL and no parent/legacy record changes.
- Identity lookup_pilot adds ownership_status via SELECT; validates table prefix.
  Existing R3 lookup shape retained; original regressions unchanged.
- SMP/MTS support; scope requires frozen school form, NEGERI and exact Tasikmalaya
  regency. Checks at freeze and every batch, including resume after changes.
- Current CLI cannot enqueue unscoped jobs or run legacy unscoped jobs. Legacy
  reading/recovery/cancel and API compatibility remain; no data rewritten.
- CLI preflight defaults to bundled list, checks all200 with passed/failed/unrun
  and safe issue codes. Preview remains SELECT-only, defaults10, no fetch.
- All CLI mutations now reject --dry-run and require explicit matching confirm.

Canonical results in docs/qa/dev6.1: 12 suites on PHP8.2.32 and PHP8.4.24, 482
checks per runtime, all PASS; 39 development PHP files lint each PASS. Original
six R2/R3/R4a suite files byte-identical; all84 original baseline file hashes match.
New tests cover scope, reclassification/ownership/region, unknown/changed IDs,
SQL identifier/NPSN injection, preflight counts/errors, dry-run zero-query,
permissions, no legacy mixing, scoped enqueue/dedupe, failed scope checkpoint,
20 resumable fake batches and reference integrity. Actual NPSNs/classification
are fixture input only; database IDs and DB engine remain synthetic.
Independent temp-copy tamper test PASS; extracted ZIP offline runner PASS.

Artifact: artifacts/AHDA_Discovery_Engine_M1_Tasikmalaya_0.1.0-dev.6.1.zip.
Full changed-file list/diff/logs/checksums: docs/qa/dev6.1/. Previous dev.6.0 ZIP
preserved. New ZIP guides under plugin docs/M1_LOCALWP.md and M1_QA.md.
Frozen list unchanged, SHA 42aaa7c51d5e0163c08146d1c46df70e260496639b9a3cc55e34f58781b1af20.

Current-instance writes: code/local generated artifacts ONLY. No real DB,
network crawl, plugin installation/activation, production or publication.
Crawler remains hard-disabled; full DNS/transport/durable throttle gate OPEN.
LocalWP/MySQL8.4 integration NOT TESTED: user's ahda.local is not available in
this cloud executor. Full parent security audit and old manual CLI capability
hardening remain outstanding. M2 extraction/candidates, M3 review and M4 local
publisher still NOT IMPLEMENTED; do not call the MVP complete or production-ready.

Next action: user runs approved backed-up LocalWP installation and read-only
pilot preflight/preview according to handoff, then provides actual safe report.
Do not repeat passed offline audits without changes. Resolve classification or
identity mismatches without altering legacy data. Obtain scoped explicit approval
before any real job write, crawl or publish; no production scope. Continue M1
source permission/transport gates then M2 when prerequisites permit.
Rollback: restore original R4a ZIP locally after backup/approval; do not delete
M1 job rows or alter Directory. R4a ignores new job type. Dev.6.0 cannot process
new scoped v2 jobs; retain dev.6.1 for diagnosis rather than downgrading job data.


## GitHub artifact delivery — 2026-11-09

User explicitly approved uploading the prepared delivery branch and instructed
future package delivery via GitHub. Do not request the same upload authorization
again for routine future AHDA package delivery; preserve production/network/DB
approval gates. Avoid chat artifact links for this user.

Pushed ONLY ZIP + LocalWP delivery guide to GitHub yustiaekaputri/ahda,
branch delivery/tasikmalaya-dev6.1. Remote ref verified with git ls-remote:
62f2bd26cf42b2fd161b74bdfd7a31311f8868a3.
Files in uploaded commit:
- artifacts/AHDA_Discovery_Engine_M1_Tasikmalaya_0.1.0-dev.6.1.zip
- artifacts/LOCALWP-DELIVERY-dev6.1.md
ZIP SHA256 60a47eb5e6485b680ff152a04eb243a51bbcf7fe872e81098fe785d42d650f41.
No main-branch update/merge, production deployment or LocalWP operations.
The full workspace source/checkpoint remains local; this delivery commit contains
only the two listed files. The plugin source/tests/docs are included inside ZIP.


## LocalWP feedback + dev.6.2 source inventory — 2026-11-09

USER-REPORTED actual LocalWP output received, stored in
`docs/qa/localwp-dev6.1-user-report.json` (not cloud-executed).
- dev.6.1 schema postflight INSTALLED, complete,7 tables,0 missing, schema1.
- legacy METADATA SHA fbd684d9502cfe8cab5d91068f7c6829197837b3e2d29f67068f5c8076ada3b6.
- scope hash matches pinned reference; pilot200 checked/passed,0 failed/unrun.
- preview first10 successful, cursor27323, all10 Discovery links0/needs_source.
- DB-bound manifest hash c804d6044cbbf14f02178647a416c6f71118726517b3320b2dc96bcbe2d08dca.
This validates read-only scope/classification on user's installation, NOT actual
job writes, MySQL transactions, evidence record, native fetch, full200 sources or
absence of URLs from legacy metadata. Initial username placeholder failed;
operator then successfully used --user="admin". Use admin in future instructions.

Added dev.6.2 Source_Inventory and `wp ade pilot source-preview` command. SELECTs
only verified profile_website/profile_source_url metadata, official_website on
details, and four supported social platform URLs. Does not read contacts or pupil
data. Three bounded indexed reads per school, batch1–20; validates current frozen
scope via existing batch reader. Canonical dedupe retains origins; all new hints
remain pending/manual_only/fetch_permission NOT_GRANTED. Rejects unsafe formats,
platform mismatch, and sensitive query keys without echoing values. SQL/row
integrity errors fail closed rather than returning needs_source. No new writes.

13 suites PASS PHP8.2.32/8.4.24,512 checks per runtime;41 PHP files lint PASS.
New inventory suite30 checks, including CLI, dedupe, scope/permission, SQL failure,
query caps, sensitive tokens and cursor continuation. Full original regressions
and original84 baseline hashes unchanged. Logs/diff in docs/qa/dev6.2/.
One initial fixture error (invalid Facebook profile underscore) was corrected to
exercise valid-URL platform mismatch; final assertions unchanged/passing.

Packaged dev.6.2 for GitHub delivery per persistent user authorization; no main
merge, production, LocalWP install, real database write or live crawl by cloud.
Next external check: operator replaces ONLY Discovery on backed-up LocalWP, then
runs `wp --user="admin" ade pilot source-preview --batch-size=10 --dry-run` and
provides output. Avoid rerunning prior passed schema/pilot checks unnecessarily.
If hints exist, review source access/identity and obtain scoped approvals before
persistence or fetch. If no verified hints, source discovery still requires an
allowed source list/search adapter; do not enqueue empty planning work as a fix.
M2/extraction/candidates, M3/admin review and M4/publication remain unimplemented.
Crawl transport/DNS/durable-throttle gates remain open; no production readiness.
Rollback dev.6.2 to dev.6.1 after normal local backup/approval: no schema or data
migration, existing scoped v2 jobs remain compatible. Original R4a ZIP preserved.

GitHub dev.6.2 delivery completed and remote ref verified: delivery/tasikmalaya-dev6.2 at 271d7c06ec34ff6a21b6d0077c26ee6f02fb8cce. Prior ZIP and guide retained. No main merge/deployment.


## CLI naming defect + new LocalWP source evidence — 2026-11-09

User dev.6.2 reported source-preview NOT REGISTERED, suggestion source_preview.
Workaround immediately provided; user then successfully ran underscore spelling.
Root cause: WP-CLI does NOT convert reflected underscores into hyphens by default.
Prior stub/direct-method tests did not exercise native command-name resolution.
Corrected assumption; do not describe this as a data failure or failed install.

Actual USER-REPORTED source_preview output captured at
`docs/qa/localwp-dev6.2-user-report.json`: first10, cursor27323, scope/manifest hash
unchanged, links0, verified legacy URL hints0, rejected0, no requests or writes.
Do not extrapolate to all200 or infer schools have no websites. Further input
requires source acquisition, not creating empty planning jobs or repeated installs.

Hotfix dev.6.2.1 adds explicit WP_CLI registrations for four hyphen aliases while
retaining original underscore methods. Added8 bootstrap assertions; no SQL,
source reader, flags, schema or crawler changes. Existing6.2 works with underscore;
installing hotfix is optional for ongoing source discovery. Release to GitHub
under prior standing authorization after offline regression/package verification.

Prepared precise source-acquisition scope in docs/source-research-plan-first10.json:
10 existing first-batch schools, public education reference catalogs only,
20 HTTPS requests maximum,5s host interval,10s request timeout,256KiB cap,
one process, no automatic redirects, robots/terms respected, no social fetches,
DB writes, production or publication. Candidate hosts not yet independently
verified. Asked operator via async input for required network approval. Pending
approval is NOT authorization. No research network fetch has been made.


Operator approved catalog research via async reply "Izinkan pemeriksaan katalog
terbatas". Standing scope: first10 only, two named catalog hosts, total20 requests,
5s host interval,10s timeout,256KiB cap, no redirects/DB/production/social login.
Two robots requests attempted (one per host), both curl56 CONNECT tunnel403,
http000, zero body. This is cloud proxy failure before site response, not robots
or target content refusal. Current runtime observations enforced restricted
policy and neither catalog host allowed. No bypass/repeated attempts.
Budget used2,remaining18; successful catalog requests0; scope/ledger in
`docs/source-research-plan-first10.json` and `docs/research-first10/catalog-probes.json`.

Draft read tool failed INVALID_ARGUMENT (current draft could not be verified),
so unknown saved custom rules were not replaced. Runtime request_changes tool
unavailable. User needs to ADD referensi.data.kemendikdasmen.go.id and
referensi.data.kemdikbud.go.id to cloud environment network permissions. Do not
ask for the same research permission again. Retry only after policy change and
fresh enforced/current status, preserving remaining request budget and limits.

Unblocked hotfix:13 suites PASS on PHP8.2.32/8.4.24,520 checks each;41 PHP files
lint each. Bootstrap aliases explicitly tested, native LocalWP alias resolution
still NOT TESTED. SQL/parser/source reader unchanged; underscore source_preview
already works on user's LocalWP. Package dev.6.2.1 to GitHub per standing delivery
authorization; installation optional, no need repeat already-passed native tests.
No job/enrichment write, production action or successful catalog fetch occurred.

Hotfix dev.6.2.1 pushed to delivery/tasikmalaya-dev6.2.1, remote ref verified 57e95c674c750ab60dcdf9ee4d23fea6f0677c9b. Prior artifacts preserved. Research remains blocked by cloud allowlist; operator consent remains valid,18/20 requests left. No WordPress or production writes.


## Continued offline M2 foundation — dev.7.0 / 2026-11-09

User requested continue. Fresh runtime status: observations_current=true,
network policy enforced/restricted, neither approved catalog host allowed.
No repeated catalog requests (budget still2 used/18 remaining). Existing research
approval retained. Draft/runtime change tooling limitation unchanged; external
network settings block real source acquisition, not offline implementation.

Implemented ADE_Enrichment_Preview + `ade pilot extract`, structured JSON only:
- strict schema/types/byte/depth limits + duplicate/escaped-key rejection;
- immutable200-pilot scope, exact observed/source NPSN, explicit mismatch blocks;
- source content/quote/value literal containment; no fabricated fact generation;
- only profile_programs/profile_curriculum/profile_hours targets from actual
  Directory whitelist, protected keys/status injection blocked;
- plain UTF8/control/markup constraints, HTTPS URL/sensitive-key rejection,
  timestamp validation, stale evidence reason;
- deterministic evidence/candidate preview keys and dedupe; conflicting target
  values rejected; no facts/identity/permission certified by user document;
- current verified display snapshots from bounded prepared SELECT, school scope
  rechecked, snapshot hash and no-change marker; storage/publisher contract remains
  future work, this hash is NOT a publication authorization;
- previews always persisted=false, approved_value=null, not_ready/needs_evidence,
  no fetch/model/generation/write/publish. Demo fixture clearly synthetic and stale.

New files: includes/class-ade-enrichment-preview.php, data/examples/
m2-structured-fixture.json, tests/m2-evidence-preview-tests.php, docs/M2_PREVIEW.md.
Main/CLI/readme/QA updated, version0.1.0-dev.7.0. Existing R4a writers/identity-only
hint contracts unchanged. No browser endpoint/nonce-consuming mutation added.

14 suites PASS PHP8.2.32 and8.4.24,580 checks each;43 PHP files lint each. New M2
suite60 checks. All84 baseline files and6 original R2/R3/R4a tests unchanged.
Logs/diff/checksums in docs/qa/dev7.0/. LocalWP/MySQL M2 integration NOT TESTED;
real source permissions, HTML/CSV parsing, evidence/candidate persistence,
extraction worker, M3 review and M4 local publisher remain outstanding.

Deliver dev.7.0 ZIP + guide via GitHub standing authorization. New native smoke,
optional after normal backed-up/operator-approved LocalWP replacement:
`wp --user="admin" ade pilot extract --demo --dry-run`.
Expected FIXTURE_ONLY_READ_ONLY,3 in-memory candidates/evidence, false publication,
zero writes/requests, fixture/stale/identity/permission/review blockers. Synthetic
values must never be copied to actual profiles. Real data enrichment still0.
Do not require install just to fix cloud egress; dev6.2/6.2.1 source readers remain
usable. Keep known passed native scope/reader evidence without unrelated reruns.
Rollback to dev6.2.1 needs no migration/row removal; preserve all old data/jobs.
Next: resolve the two cloud catalog host permissions, use remaining18 budget and
operator-approved access only; then actual source evidence and native integration.

Dev.7.0 ZIP and guide pushed to delivery/m2-preview-dev7.0; remote ref verified b63c464fe047eeafd29dd6a988fd231744f117d0. Earlier artifacts preserved. Network source budget remains18; no catalog probes or real DB writes this continuation.


## Continued M2 pending persistence — dev.7.1 / 2026-11-09

User requested continue. Catalog policy freshly observed enforced/restricted,
no approved catalog hosts; no new probes.2 used/18 remaining still valid. Source
permission unchanged; no source/production network fetch or LocalWP writes.

Implemented ADE_Enrichment_Store with stage (read-only), store (explicit local
write gates, NOT EXECUTED on real DB), receipt (read-only historical diagnostics).
Guards: manage_jobs+review_candidates, operatorID, local WPCLI, schema preflight,
immutable200 scope, non-fixture and non-stale structured document, pre-existing
registered website/source-school relation, same host and known unblocked states.
No source auto-creation or source/identity promotion. Whitelist three meta targets
and literal evidence validation retained from7.0.

Store changes only Discovery candidates/evidence/candidate_evidence/jobs; no
legacy/profile/source/review writes. Source/current snapshots and expected row
states bind staging token. Stage exposes exact projected new rows/version bumps.
GET_LOCK0 per school; FOR UPDATE NOWAIT; atomic inserts + completed operation
receipt. Data errors roll back; repeat request reads receipt/no duplicates, even
simulated lost commit acknowledgment. Receipts bind result hash/provenance and
bounded payload sizes. No auto-approval/publish and all scores0. Existing reviewed
rows skipped unchanged, no evidence appended behind reviewer; pending additions
conditionally increment row_version. Source/snapshot/review/corruption races block.
Old evidence and proposals are never silently overwritten or deleted.

New files: includes/class-ade-enrichment-store.php, tests/m2-store-simulation.php,
docs/M2_STORE.md. Main/CLI/readme/docs and fake fixture helper updated. No schema
version or dependency/lockfile changes. Runtime remains dev, all automatic flagsOFF.

15 suites PASS PHP8.2.32/8.4.24,695 checks each;45 PHP files lint each. New store
suite115 fake checks, all10 insertion positions rollback, commit/ack loss,
idempotence, pending version race, changed review, approved-row immutability,
source/role/backup/confirmation, receipt/evidence corruption and CLI paths.
All84 baseline file hashes and6 original R2/R3/R4a tests unchanged. Canonical logs,
diff/checksums at docs/qa/dev7.1/. Real MySQL/LocalWP writer still NOT TESTED.

Asked async operator permission for isolated disposable MySQL8.4 tests in cloud,
synthetic data only, separate from LocalWP/production. No affirmative response yet;
DO NOT treat silence or code development approval as permission for real DB writes.
Plan: docs/NATIVE_MYSQL_TEST_PLAN.md. Runtime Docker skill read; explicit managed
unix socket check with endpoint/TLS/context selectors cleared succeeded (29.9.2),
user UID1000; official mysql8.4 image absent. No daemon/image/container/database
started, no secrets inspected/printed. Resource plan1CPU/1GiB and local-only port.
Need permission first, then install trusted test dependencies/pull official image,
run native SQL/lock tests under WP stubs, retain logs and remove own test container.
Label native MySQL under stubs separately from actual WordPress/LocalWP PASS.

Package7.1 + guide via standing GitHub authorization. Do not tell operator to run
store now: source/doc data not available/approved, native test gate open. Existing
demo extract remains read-only. No need install just for cloud network access.
M2 extraction worker, HTML/CSV parser, M3 review, post-commit revoke and M4 publisher
not complete. No real profiles enriched. Before LocalWP writes, review concrete
stage impact and obtain separate approval+verified backup. Native disposable
permission, if later granted, never authorizes LocalWP or production writes.
Rollback code to7.0 needs no migration; preserve any receipts/rows and use7.1 for
diagnosis. No post-commit delete/revoke implemented; full local publisher rollback
still future. Original R4a/Directory data and prior artifacts preserved.

Dev.7.1 package+guide pushed and remote ref verified at 507593aa5435c68cdd684ac3723cf7a61a626d5b (delivery/m2-pending-dev7.1). Prior artifacts preserved. Native disposable test consent still pending; no real DB/container created. Government source budget remains18; no new probes.


## 2026-11-10 — dev.7.1.1 WP-CLI dry-run hotfix

Operator reported invalid synopsis part --dry-run, unknown parameter for exact
extract --demo --dry-run. Our PHPDoc declared a mandatory boolean, which official
WP-CLI does not support. Earlier direct handler tests missed framework parsing.
Fixed extract/stage synopsis to [--dry-run]; handler requires boolean true, so
missing/negative flags still fail safely. Stage valued arguments documented.
No schema/writer/source/legacy/publisher changes or new runtime dependencies.

Added unmodified upstream WP-CLI v2.12.0 parser/validator/docparser/dispatcher
classes, pinned commit03d30d4138d12b4bffd8b507b82e56e129e0523f, MIT LICENSE and
per-file hashes in tests/vendor/wp-cli-2.12.0/UPSTREAM.json. Test-only; never loaded
by plugin runtime. New50 checks reproduce old error and invoke fixed handlers
through official factory/subcommand, scan all command synopses and check missing/
negative flag, CRLF and alias behavior. WP/config/help renderer/DB remain stubs;
this is NOT a complete WP-CLI binary or native WordPress/MySQL test.

16 suites,745 checks PASS each PHP8.2.32/8.4.24;55 PHP files lint each. All84
baseline hashes and6 original regression files unchanged. Logs/diff/error report
at docs/qa/dev7.1.1/. Native LocalWP hotfix retry NOT TESTED pending user output.
Previous preview error did not demonstrate any data change. Demo remains
FIXTURE_ONLY_READ_ONLY with3 synthetic candidates and0 writes/HTTP. No school
facts enriched. Native disposable MySQL consent still pending; no real DB or
container created. Catalog budget remains18, no new probes. Official tooling
source download does not consume the scoped school catalog request budget.

Delivery dev7.1.1 via previously authorized GitHub artifact branch. Install only
Discovery locally after backup, rerun exact demo command; no store/production.
Rollback plugin files needs no migration; preserve all data. M2 native writer
validation, source acquisition, extraction worker, M3 review and publisher gates
remain outstanding as above. No automatic publishing or production operation.

Dev.7.1.1 ZIP+guide pushed and remote ref verified at 91f2733430ae8ea655e9cf3af93e1133ab202b70 (delivery/m2-pending-dev7.1.1). Previous artifacts preserved; main and production untouched.


## 2026-11-10 — operator LocalWP demo retry PASS

User pasted successful exact command: wp --user="admin" ade pilot extract --demo
--dry-run. No invalid synopsis/unknown parameter error. Output mode
FIXTURE_ONLY_READ_ONLY, fixture_only true, school_id913/NPSN20268071,3 evidence
and3 candidates, all persisted false, approved_value null, not_ready. Reported
network_requests0/database_writes0/publication_enabled false. Expected fixture
blocks: unverified identity/permission, admin review, synthetic facts and stale
2020 evidence. These are intended gates, not a command failure. Sanitized output
and input hash: docs/qa/localwp-extract-demo-user-report.json. Installed version
not printed; do not claim independently verified version. This establishes only
operator-observed native demo preview success, not real extraction, native store
transactions, real school enrichment or publisher safety. No network/database
operations performed by cloud agent. No need rerun the same demo. Next: source
acquisition gate and native isolated MySQL validation (permission still pending);
continue safe offline milestones independently, never store fixture data.

## 2026-11-10 — dev.7.2 editorial draft + native MySQL validation

DONE (offline/native-under-stubs): new ADE_Article_Preview and pilot article
--demo|--evidence-file --dry-run. Builds escaped, evidence-linked HTML/string
preview, identity from existing unique NPSN index with frozen200scope validation,
three supported literal topics (programs/curriculum/hours), citations including
quotes/URL/fingerprint/time, metadata suggestions unapplied, twelve-topic editorial
checklist.9topics unassessed by adapter are explicit gaps, not assertions that
legacy data is empty. Every document claim unverified, approved count0; fixture
watermark embedded in HTML, original source/permission/stale/review blocks remain.
No profile_description candidate/write, no claims of full profile completeness.
One indexed school SELECT, no frontend hook/SEO duplication or auto work.

Changed runtime: new includes/class-ade-article-preview.php; main loads class and
version7.2; CLI shares bounded preview-file loader and adds article method. Writer,
Schema1/seven definitions, crawler, flags and legacy Directory unchanged. Added
article tests, updated official dispatcher tests, docs/M2_ARTICLE.md,
CONTENT_QUALITY.md, NATIVE_MYSQL.md and native opt-in harness. SHA-pinned upstream
WP-CLI files unchanged. SQLi/XSS/SSRF protection inherited document validation plus
HTML/attribute escaping, bidi/control/name bounds, strict identity, no Markdown
execution, explicit dry-run/capability/LocalWP guards. No new admin mutation/nonce
surface; article viewer/review UI is not implemented.

Operator answered explicit async "Izinkan uji MySQL sementara" this turn. This
supersedes pending disposable consent entries above; authorization covers only
isolated cloud synthetic test DB, NOT real LocalWP/production data. Read runtime
Docker/packages/network docs, confirmed managed socket29.9.2, pulled official
mysql8.4 with normal digest/TLS checks, installed signed Debian php8.2-mysql
locally. No global/runtime plugin dependencies. Password random ephemeral,
not printed or written to repository. Never read wp-config or user secrets.

Native tests PASS70checks on MySQL8.4.13, PHP8.2.32, actual Schema::create_sql and
InnoDB; wpdb adapter, WP/auth/local/preflight still stubs. Fixed database
ahda_m2_disposable, unique fresh container,1CPU/1GiB,512MiB tmpfs, loopback port,
no existing volume. Actual atomic writes/rollback all10positions, receipt replay,
actual committed state+simulated acknowledgment loss, evidence version advance,
two-session application lock and NOWAIT row lock, review change/stale plan,
reviewed row+links unchanged, current snapshot changed, quoted SQL literal and
legacy/source/review hash preservation tested. Article indexed read also tested.
Re-ran via packaged reusable opt-in Python harness to verify reproducibility;
70checks PASS again. Final harness cleanup hardening was retested (70PASS);
all three own containers/storage removed. Official image cache
retained. No other containers manipulated or daemon restart. Logs/digest/cleanup
at docs/qa/dev7.2/native-mysql-*. Output hash/raw schemas checked by native test.
Full WordPress/LocalWP writer/queue/publisher and real connection-failure behavior
remain NOT TESTED. Do not generalize native-under-stubs PASS to full WordPress.

17offline suites PASS on PHP8.2.32 and8.4.24:822checks each,58PHPfiles lint each.
New article suite72checks, official dispatcher55checks including exact article
flags. All84baseline hashes and6original R2/R3/R4a regression files unchanged.
Final logs/diff/baseline metadata at docs/qa/dev7.2/. No student personal data.

SEO source audit: baseline class-ahda-public.php already emits description,
canonical and School JSON-LD; sitemap/robots separate baseline modules. Preserved
all baseline hashes. No head hooks added, no fake last-updated/ratings/FAQ schema,
no automatic indexing/submission or ranking/AI recommendation promise. Existing
SEO/theme integration/rendering and VPS resource behavior remain untested.
Quality checklist includes admissions/fees/periods/facilities/accreditation/contact
and privacy rules.365day normalizer threshold not proof volatile facts valid.

IN_PROGRESS/BLOCKED: no real school documents sourced or profiles enriched.
Cloud environment refreshed: restricted/enforced, custom allowed_hosts empty;
reference domains still not permitted. No new catalog probes, remaining18of20.
Existing scoped operator research permission remains valid. Need environment
settings to add referensi.data.kemendikdasmen.go.id and
referensi.data.kemdikbud.go.id; saved draft persistence previously unconfirmed,
unknown saved allowlist must not be overwritten. No bypass or duplicate consent.
After policy actually applies, validate fresh allowed connection and bounded
robots/ToS-first research. Offline saved HTML/CSV adapter, multi-source conflicts,
extraction worker, M3admin review and M4publisher still outstanding. Extend only
actual Directory target allowlists, validate native and offline incrementally.

Delivery: package7.2 + guide via standing GitHub artifact permission, no main merge.
Operator can install Discovery locally after backup and run article demo only;
no store requested. Preserve Directory and all existing data. Rollback Discovery
files to7.1.1 requires no migration. LocalWP real writes need separate concrete
stage review/approval/backup; production excluded. Native harness is never invoked
by offline runner/plugin. Session checkpoint and evidence included in ZIP.

Dev.7.2 ZIP+guide pushed and remote ref verified at a2380cc16ff997741934d17fa28e39ae38f530b9 (delivery/m2-article-dev7.2). All earlier artifacts retained, main unchanged. Native test permission received and tests complete; no LocalWP/production writes authorized or performed.


## 2026-11-10 — operator LocalWP article demo PASS

Received successful wp --user="admin" ade pilot article --demo --dry-run output.
Mode EDITORIAL_DRAFT_READ_ONLY; fixture_only true; school_id913/NPSN20268071,
name read from existing index SMPN SATU ATAP 2 KARANGNUNGGAL, KAB.TASIKMALAYA.
3sections/3citations with valid internal links,9not_assessed_by_this_adapter gaps,
12topic checklist and approved0. HTML contains synthetic watermark. All sections
unverified/approved false; persisted false; network0/writes0/publication false.
Metadata not applied, canonical/schema not emitted. Expected source/review/fixture/
stale/full-profile blocking reasons retained; these do not mean CLI failed.
Sanitized output/hash: docs/qa/localwp-article-demo-user-report.json. Installed
version not printed; avoid claiming independent version verification.

Native operator-observed article demo command PASS only; no real school facts
extracted or profiles enriched, no public frontend/SEO/store/review test proven.
No need repeat demo or install another hotfix. Next: permitted source acquisition
(policy domain additions still needed) and offline parser/worker/M3 development.
Cloud disposable MySQL consent and completed70checks remain valid evidence as
previously scoped; not authorization for LocalWP/production writes. No network
or real database operation performed by cloud agent when recording this report.

## 2026-11-10 — dev.7.3 offline CSV/HTML adapters

DONE: ADE_Document_Parser plus pilot parse --format=csv|html --demo|--document-file
--dry-run. No HTTP/DNS/model/export/write/publish. Native read-only preview binds
frozen pilot identity/classification and existing verified meta snapshots. Output
raw_document_sha256, normalization version, structured_document and unverified M2
preview. Quotes refer to decoded/normalized records, NOT original raw HTML byte
slices. Raw original hash remains preview only; retain file/report together.
No source authority/permission verification or raw archive DB migration added.

CSV exact npsn,target_key,value header; UTF8/BOM,strict quoting/comma/CRLF/LF and
multiline support; no permissive broken-quote recovery, formula-leading cells,
extra columns, unsupported targets, mixed NPSNs, conflicting values.64KiB/20rows/
500byte values. Same old three target fields only; no arbitrary catalog schema
inference or teacher/student/private data collection. Structured CSV interchange
is not an adapter for every official dataset.

HTML actual PHP DOM,256KiB/10000nodes/depth32/20tables/64rows/20claims. Requires one
unambiguous non-nested two-column profile table containing expected NPSN. Exact
label map for programs/curriculum/hours only; ignored labels counted, not emitted.
Other visible named NPSN/duplicate identity/merged cells/multiple profiles block.
Inert HTML5 doctype allowed; XML/DTD/ENTITY/processing declarations rejected before
DOM parsing. NONET without NOENT/DTDLOAD, scripts/styles/noncontent/explicitly
hidden nodes removed, no assets fetched or script executed. External resource
resolver sentinel in tests observed0loads. CSS classes/stylesheets/JS/complex
layouts and DOM repairs still require human inspection; don't claim all hidden
text or every website layout is handled. Source content normalized explicitly.
Missing DOM returns M2_HTML_DOM_EXTENSION_REQUIRED before output, CSV unaffected.
Plugin boot/frontend does not invoke parser or add hooks. No schema/flags/writer/
Directory change. RequiresPHP7.4 header unchanged; tested PHP8.2/8.4 only.

Changed: new includes/class-ade-document-parser.php, CLIparse/main version7.3,
2synthetic fixtures, parser test, official dispatcher test, native test/harness,
optional local PHP_DOM_EXTENSION test runner support, readme/docs. No generated
SQL target expansion. Article7.2 and old extract unchanged. Source layouts/files
must be legally obtained by operator; source_url/time/reference are declarations,
not proof. Don't change fixture flag to turn demo into purported school facts.

18suites/945checks PASS each PHP8.2.32 and8.4.24 WITH actual DOM;60PHPfiles lint
both.18suites/892checks each WITHOUT DOM; HTML extraction explicitly NOT RUN there,
missing-extension guard verified (not counted as extraction PASS). Parser suite
116checks with DOM, official dispatcher62including both exact parse commands.
New suite tests formula/quote/identity/conflict/caps, XXE/external resolution,
hidden content, ambiguity, cell/depth/node/table/row/claim budgets, current scope,
capability/dry-run/local and no-write paths. Original84baseline hashes and6original
R2/R3/R4a suites unchanged. Standalone parser security suite observed0.038s and
19496KiBpeak RSS PHP8.2 cloud, not a VPS/frontend/batch performance guarantee.

Standing explicit operator disposable-MySQL consent reused, no repeated approval.
Read runtime Docker/packages/network references; daemon local29.9.2 confirmed.
Official signed Debian PHP8.2/8.4XML packages downloaded/extracted user-locally
under ahda-tools, no global/site installation. Default proxy/TLS/signatures kept.
No new catalog probes. Cached pinned official MySQL image reused,1CPU/1GiB,
512MiBtmpfs,random ephemeral password/loopback port, unique own containerIDs.
Native88checks PASS MySQL8.4.13/PHP8.2 with actual DOM/SQL/InnoDB and WP/wpdb/
preflight stubs, including CSV and HTML->stage->atomic pending writer->receipt
replay plus original70lock/rollback/review/snapshot/preservation checks. Final
native harness module-precondition hardening retested,88PASS. Both own disposable
containers/storage removed. Tests/scripts refuse missing opt-in; DOM/mysqli/
mysqlnd modules required before server creation. No other container touched,
secrets inspected, LocalWP/production operations or permissions inferred.
Final logs/digest/status/cleanup/diff at docs/qa/dev7.3/.

IN_PROGRESS/BLOCKED: no real school source fetched or profile enriched. Refreshed
runtime policy still enforced/restricted/custom allowed_hosts empty; two approved
reference domains not available, remaining research18/20 unchanged. No bypass or
duplicate operator research consent. Need saved domain additions/applied policy,
then bounded robots/ToS checks. No confirmed draft persistence. Sources must be
real/authorized before actual candidates can be useful. Parser breadth, raw
archive binding, resumable M2worker, M3review/dashboard and M4publisher/rollback
still outstanding. Native/full WordPress/LocalWP parser and frontend SEO tests
NOT TESTED. Canonical/School schema/Directory source unchanged; no ranking/AI
recommendation claims. See M2_DOCUMENT_PARSER.md and latest quality/security docs.

Delivery7.3 via standing GitHub permission, ZIP/guide on new artifact branch only.
Local demo tests optional after Discovery-only replacement+backup; don't rerun
older successful article demo, reimport, rebuild or install schema. No store or
production request. Rollback files to7.2 without migration; preserve all tables.
Next safe work: source-specific validation/archives and extraction worker or M3
review using synthetic tests, preserving source/review/publisher separation.

Dev.7.3 ZIP+guide pushed and remote ref verified at 5c7264b667f4ee52a574736ad1fb6c21be848425 (delivery/m2-parsers-dev7.3). Earlier artifacts preserved; main/production unchanged. Both own disposable test containers removed; LocalWP parser retry remains NOT TESTED pending operator output.


## 2026-11-10 — operator LocalWP CSV and HTML demos PASS

User output confirms both pilot parse --format=csv|html --demo --dry-run succeed,
3candidates each, fixture true, school_id913, zero network/writes and publication
false. No warning/error. Installed version not printed; not independently proved.
Sanitized evidence at docs/qa/localwp-parser-demo-user-report.json. No need repeat
old demos/install another parser hotfix. Not real sources/enrichment/native writer
or frontend/SEO PASS. Continue M3 read-only candidate inspector safely, keeping
review decisions/publisher separate and disabled.

## 2026-11-10 — dev.7.4 M3 read-only candidate inspector

DONE (M3 read-only foundation, NOT decision workflow): WP Admin AHDA Discovery >
Kandidat (baca-saja). Server local site/current actor/ade_review_candidates guard
on controller AND service, dependency/schema/safe-flags preflight, frozen pilot
identity/classification recheck. No operational feature flags enabled, migrations,
new options/roles, POST/action/AJAX/REST/nonce mutation endpoints or writes added.
No source requests, cron, full-directory COUNT/OFFSET scans or frontend SEO hooks.
Empty chooser reads bundled200reference only; no candidate/schema query until
school selected. One indexed school lookup, M2types only, existing target3allowlist.

Candidate list20+1 keyset, optional status filter. Details bind candidateID AND
schoolID/type; comparison current VERIFIED meta vs original snapshot/proposal/
stored approved value. Current hash uses exact M2namespace; conflict warning only,
never overwrite. Evidence20+1 keyset with same-school/target/value/type/parse/scope
checks. Corrupt cross-school links block, raw observed JSON/private notes omitted.
HTTPS URL validated/redacted if credential/IP/token-query; no DNS or fetch. Quotes,
time and source relationship/status shown escaped. Warnings for missing/pending/
stale/invalid source conditions, permission always independently unverified.
Readiness reasons capped/page-scoped, not full source certification. View multi-
query reads not atomic; any future mutation must revalidate transactionally.
No approve/edit/reject/defer/audit append/publish controls or handlers exist.
No ranking/confidence/complete-profile claims. CLI demos don't populate this UI;
empty list expected, never store synthetic facts just to fill dashboard.

Runtime changes: new includes/class-ade-candidate-inspector.php and
admin/class-ade-admin-review.php; main version7.4 loads service; existing bootstrap
loads view only in admin, existing menu adds submenu. Registration has no query/
network/write side effects. Old CLI/schema/queue/store/parser/Directory preserved.
Test changes: new m3-inspector-tests.php, toggleable ready flag in fake preflight
helper, extended native SQL tests, opt-in standalone browser fixture/generator/
Playwright tests. Source/SQL targets still only Discovery reads + exact verified
legacy meta read. No production access, credentials or wp-config read.

19offline suites PASS each PHP8.2.32/8.4.24 WITH DOM:1010checks each,65PHPfiles
lint each. Without DOM957checks each; HTML extraction explicitly not run there.
Inspector suite65checks covers caps/local/preflight/scope/IDOR/pagination,
current-value conflicts, overflow/duplicate current, corrupt evidence, URL/token
redaction, XSS across name/proposal/snapshot/quote, unsafe GET and SQL error hiding.
84baseline file hashes and6original R2/R3/R4a suites unchanged. Final QA at
/docs/qa/dev7.4. An initial QA log output directory reused7.3; current logs moved
to7.4 and original7.3 logs restored byte-for-byte from delivered ZIP before release.
No historical artifact changed or rewritten.

Native110checks PASS MySQL8.4.13/PHP8.2 actual SQL/schema/InnoDB under WP/wpdb/
preflight stubs, previous88 plus inspector list/status/cursor/detail/hash/current
conflict/IDOR/cross-school evidence/token URL masking and all9synthetic table row
hash preservation. Reused existing explicit disposable consent, pinned cached
image and managed socket29.9.2;1CPU/1GiB/512MiBtmpfs, random password/loopback port,
own unique containerID. Test container/storage removed, no other container or
LocalWP/production touched. Native WordPress preflight/role/menu execution still
NOT TESTED. No stronger integration claim than SQL under stubs.

Browser16checks PASS actual PHP view in headless system Chromium via existing
Playwright, synthetic WordPress/backend/data stubs + minimal CSS. GET school
selection/list/detail, citations, conflicts, empty state, script nonexecution,
no POST forms, unauthorized/site403, desktop1280/mobile390 and no page overflow/
external requests. Screenshots in qa/dev7.4, manually inspected desktop. All
nonloopback browser requests aborted by harness; zero attempts observed. Initial
bundled Playwright browser path missing, resolved to existing /usr/bin/chromium
without downloading. Initial fixture403 response buffering fixed in test harness,
not product capability guard; final16PASS. Fixture requires cli-server+explicit
synthetic env flag, normal web/PHP-FPM requests404; generator CLI+optin only.
Standalone test server stopped. Not real WordPress/LocalWP admin/theme rendering.

IN_PROGRESS/BLOCKED: no real source or school profile enriched; source domain
policy unchanged/enforced/custom allowlist empty, remaining catalog research18/20.
No new probes or configuration claims. Existing scoped research permission stays
valid; policy additions needed before robots/ToS-first requests. M3decision/audit/
identity-permission verification, raw document archive binding, M2resumable worker,
broader fields and M4publisher/rollback remain outstanding. Must not approve on
literal quote or snapshot alone. Sources/documents untrusted; no private student
data. Full native LocalWP inspector and VPS/frontend SEO/WordPress plugin-theme
integration not tested. Previous user CSV/HTML demo PASS scoped to those commands.

Delivery7.4 ZIP+guide via existing GitHub artifact authorization, no main merge or
production deployment. Local operator may replace Discovery after backup then
open new read-only menu; no need repeat successful CLI demos or modify DB. Missing
menu/cap/blocked preflight should be reported, not silently remedied with role/
option writes. Rollback Discovery files to7.3 without migration; preserve all data.
Checkpoint/evidence/screenshots included for next session to continue safe M3
workflow/source contracts and tests without re-auditing the completed foundations.

Dev.7.4 ZIP+guide pushed and remote ref verified at 36693bd7f9dc6de427210304e846118605d3d934 (delivery/m3-inspector-dev7.4). Previous artifacts/main preserved. Own native container and browser fixture server stopped; no LocalWP/production write performed. User LocalWP inspector render remains pending.

## 2026-11-10 — dev.7.5 negative review foundation (default OFF)

DONE/tested under isolated stubs: reject/defer service, actor/action/version-bound
plan, WP nonce verification API, POST controller, strict request schema/reasons/
plain500byte note, scoped pilot/capability/current actor/local/preflight/backup+
per-action confirmation. Negative transitions only new/deferred->deferred/rejected;
rejected terminal, approve/edit/publish/reopen always unavailable. No permission/
source verification or profile/evidence/proposal/base hash/approved field mutation.

Standard package leaves ADE_LOCAL_NEGATIVE_REVIEW_ENABLED undefined/OFF; no new
write handler registered, no forms unless separately opted in. No options/caps/
wp-config changes. Existing automatic flags stay OFF. Inspector default remains
read-only and adds paginated negative audit history. Do not enable real writes
now; future LocalWP gate requires concrete candidate impact, real nonce/role/
preflight integration, backup and separate operator approval. Never production.

Plan digest binds current candidate values/version/base/snapshot SHA and actor,
action, frozen scope. Same application lock as M2 per-school, GET_LOCK0 plus
FOR UPDATE NOWAIT; transaction rechecks candidate/scope and CAS version/status/
approval-null fence. Changes exactly one candidate status/version/updated_at,
appends one reviews row and one completed jobs receipt. No audit UPDATE/DELETE.
Audit holds reason/actor/time/before/after/version/note; nonce not persisted.
Receipt operation namespace unique, request hash and result hash; replay validates
referenced audit fields/operation/notes too. Exact retry returns historical result
without duplicate audit, including after a later negative decision. Failed status/
audit/receipt/commit rolls back. Actual COMMIT followed by simulated acknowledgment
loss resolves via receipt; controller warns unknown results require status/history
check. No post-commit undo/reopen implemented; do not delete/rewrite audits.

Controller POST only, typed IDs, wp_unslash once, feature+cap+site+nonce+confirm in
service, fixed wp_safe_redirect to re-read state (no GET success flag trust),405GET/
403invalid/409stale or busy/503internal uncertain outcome. Conditional forms have
separate scoped nonce/reason/note/backup+impact confirmations, no approve/publish.
Labels/banner/menu accurately distinguish enabled synthetic-test negative mode
from default readonly. Audit notes escaped; no raw JSON/private source notes sent
to frontend or public profiles. Source URL rendering unchanged. History20+1 keyset.
Tunda does NOT automatically resume M2: reviewed candidates frozen against hidden
evidence additions. Explicit audited reopening is future work, not manual SQL.

Runtime: new includes/class-ade-review-decisions.php, main7.5 include; inspector
reports negative enable state + approvalfalse, admin review conditionally registers
handler/forms/history, bootstrap invokes no-op register when OFF. Existing store,
parser, schema1/seven definitions/Directory untouched. Test helper actor toggles
only in stubs; new m3-decisions-tests and CLI child handler fixture, native SQL and
browser opt-in fixture extended. Default bootstrap regression proves no additional
write hook, source/cron/network/schema activity. All84baseline hashes and6original
R2/R3/R4a suite files unchanged.

20offline suites PASS each PHP8.2.32/8.4.24 WITH DOM:1121checks each;68PHPfiles lint
each. Without DOM1068checks, HTML extraction explicitly not run there. Negative
suite111checks includes disabled/roles/nonce actor+action/version/plan actor,
types/reasons/plaintext/scope/IDOR/stale content/version, locked approvals/states,
rollback audit/receipt/CAS/commit, unknown outcome, receipt/audit corruption and
separate controller child requests typedIDs/unslash/redirect/GET405/invalid403/
stale409/approve refusal. Fake nonce provider is NOT real WordPress HMAC/session.

Native146checks PASS MySQL8.4.13/PHP8.2, actual schema/SQL/InnoDB, under WP/wpdb/
preflight/nonce stubs. New decisions/status/audit/receipt/replay/history/terminal
reject/forbiddenapprove, audit and receipt insert rollback, stale external version,
M2/M3 shared GET_LOCK, NOWAIT two-session conflict, actual commit+simulated ack
loss, unchanged legacy/source/evidence and M2 leaving reviewed rows/links alone.
Two own disposable containers used (initial141 then final146 expanded coverage),
both storage/containers removed; cached pinned image retained. Standing explicit
synthetic MySQL consent reused;1CPU/1GiB/512MiBtmpfs, own generated secrets/port,
managed socket29.9.2. No real LocalWP DB, production, wp-config or secrets read.
No altered daemon/other containers. Logs/digest/cleanup at docs/qa/dev7.5.

Chromium21checks PASS actual PHP template, synthetic WP/service/data stubs/minimal
CSS, desktop/mobile/default and opt-in negative forms with nonce and required two
confirmations. No POST actually sent by browser; controller positive/negative
covered separately under fake WP/DB. XSS nonexecution also for historical note;
no external requests. Screenshots synthetic and manually inspected. Browser fixture
case flag only exists in guarded cli-server test file; cannot enable real plugin
with GET. Own fixture server stopped. Full native WordPress admin routing/cookie/
nonce/session expiry/capability/preflight and LocalWP writes still NOT TESTED.

IN_PROGRESS/BLOCKED: full M3approval/source permission/identity verification,
compensating reopen, raw source archive binding, resumable M2worker and broader
content fields, M4publisher/rollback all outstanding. No school facts/profile
enriched, no public SEO changes. Runtime refreshed restricted/enforced/custom0;
reference catalogs still unallowed; no new probes, research budget18/20 remains.
Existing scoped operator research permission not re-requested. No confirmed draft
policy change and no bypass. Need source availability/permission before real
content, full WordPress write validation before local operator write trial.

Delivery7.5 ZIP+guide via standing GitHub authorization; no main merge/deployment.
No new CLI demo needed, no requirement to reinstall immediately. If installed,
default remains read-only, empty history normal. Do not enable constant/roles/
options or modify wp-config for a real write now. Rollback files to7.4 without
migration; preserve audits/receipts/data. Checkpoint/QA docs for next session.

Dev.7.5 ZIP+guide pushed and remote ref verified at eafc1a2f0d4bba8706cd2c39aa9aad6de3943044 (delivery/m3-negative-dev7.5). Prior artifacts/main preserved. Both own disposable native containers and browser fixture server stopped. Default review writes OFF; no user LocalWP/production operations performed.

## 2026-11-10 — dev.7.6 real WordPress integration validation

DONE: reproducible real WordPress7.1.4 + Directory0.8.9 + Discovery7.6 synthetic
admin integration. Actual WP login/cookies/roles/capabilities, wp_verify_nonce from
wp-includes/pluggable.php, actual wpdb and admin-post controller routing. No stubs
for those subjects. Official WordPress dependency tag7.1.4 pinned Git SHA
 db96f5eaa77a8d3e8eec8923a518fa2326f0d46a, obtained via allowed HTTPS Git tooling,
cache /workspace/ahda-tools/wordpress-7.1.4 unchanged. Core dependency not bundled.
Signed Debian PHP8.2-common previously downloaded extracted locally for ctype/
iconv/fileinfo; DOM/mysqlnd/mysqli already local. No global or user-site install.

New tests/wordpress/bootstrap.php, control.php, run-isolated.py, e2e.spec.cjs and
README, docs/WORDPRESS_INTEGRATION.md. No user wp-config read/write/generated.
Only owned TEMP core wp-load.php copy shim calls environment bootstrap + real
wp-settings. Original Core cache unchanged, post-run no-config assertion PASS.
Standard actual plugins copied/activated; Directory creates fresh EMPTY legacy
schema in NEW isolated DB, actual R1 installer creates7Discovery tables.2synthetic
schools +3M2-shaped pending candidates/evidence seeded via actual wpdb, not the
M2CLI/store API (do not claim that end-to-end path). No555460profile import/rebuild,
no actual user data/DB/config/production. Mail and ALL background HTTP blocked via
real early WP filters, cron/updaters/file modifications/search indexing disabled.

Test admin siteurl owned127.0.0.1 port, home alias ahda.local only for unchanged
local-host guard. No connection to real user ahda.local: browser route aborts
non-owned origins, all API POSTs fixed loopback/maxRedirects0. Test-only rest_url
maps Core self REST URLs to owned loopback; allowed_redirect_hosts permits127
for this split-URL setup. Not a production configuration recommendation. WP
functions remain real. Actual user Windows/LocalWP config remains untested.

Five owned disposable DB/site/server runs: first2 failed strict external-attempt
assert (Core REST chose home alias), all attempted alias requests ABORTED before
connection. Harness REST origin corrected, no plugin behavior workaround. Third
33checksPASS, fourth39expandedchecksPASS, final39PASS with provenance/cache/
no-config assertions. Earlier FAIL evidence retained with cleanup states in
qa/dev7.6/attempt01 and attempt02, earlier successes separately. No failures
relabeled. Each owned DB/container/temp site/server fully removed in finally.
Cached official MySQL digest reused,1CPU/1GiB/512MiBtmpfs, ephemeral loopback
ports/secrets. Standing explicit cloud synthetic MySQL consent reused; no fresh
operator permission inferred for LocalWP/production. No other daemon/container
modified/restarted. WordPressmail suppressed before install; no messages sent.

Final39real WP checks PASS: real preflight/role grants/admin authentication,
anonymous redirects/POST400, editor view+write403, default no handler/forms,
controlled test-only switch ON/OFF, nonce generation/invalid/action/login-session
binding, backup acknowledgment, unconditional approve refusal, untrusted redirect
ignored/safe target, actual status/audit/receipt/quoted SQL-looking backslash note
roundtrip, HTTP replay idempotence, audit rendering, defer->reject/terminal,
stale version409/no audit, cross-school IDOR, stored quote/proposal XSS escaping
actualWP, desktop/mobile no page overflow, approved/publication NULL/not_ready,
source/evidence/link and ALL25synthetic AHDA legacy table row hashes unchanged.
No external attempts on final run. Nonceprovider/adapter provenance recorded,
actual WordPressadmin screenshots manually inspected. Synthetic warning prominent;
opt-in screenshot does NOT mean feature enabled in user site. Raw passwords,
auth seed/cookies/nonce form bodies not saved to reports. Safe own logs only.

20offline suites1121checks each PHP8.2.32/8.4.24 WITH DOM;1068without DOM (HTML
not run there),70PHPfiles lint each, all84baseline hashes/6original regression
files unchanged. Runtime PHP compared byte-for-byte against7.5 ZIP: main header/
version7.6 only, all other root/includes/admin files identical. Review defaults
OFF, same behavior; no new fields/approval/publisher/network/automatic jobs.
Previous146native-SQL-under-stubs/21fixture-browser evidence retained as prior
version scope; not rerun/recast as new checks. Final proof in docs/qa/dev7.6.

LIMITS: isolated real WP with custom bootstrap/home/REST alias != user LocalWP
end-to-end, third-party plugins/public theme/frontend SEO/VPS load untested.
WPnonce expiry clock stress, real TCP commit failure/deadlock/load not exercised.
M2fullCLI/storeWP bootstrap not tested; fixtures intentionally use wpdb setup.
Positive approval/source permission/identity attestation, raw archive binding,
resumable worker/broader fields, compensating reopen and M4publisher/rollback
remain outstanding. Real source/catalog access still restricted/enforced/custom0;
no new probes, remaining research18/20, standing scoped permission preserved.
No factual profiles enriched or ranking/AI recommendation promise.

Deliver7.6 source/harness/QA ZIP+guide via existing GitHub permission, no main merge.
No immediate reinstall/repeated demo required: this update supplies test evidence,
keeps actual site write feature OFF. Before any real LocalWP change need concrete
candidate plan+backup+separate operator approval. Preserve all old data/audits;
rollback files to7.5 needs no migration. Next safe development: source/archive
contract and worker or audited reopen, then approval/publisher only with evidence.
