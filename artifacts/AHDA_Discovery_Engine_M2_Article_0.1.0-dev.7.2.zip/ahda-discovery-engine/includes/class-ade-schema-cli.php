<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** WP-CLI entrypoint. No schema changes on registration or during preflight. */
final class ADE_Schema_CLI {
    /**
     * Read-only check: current environment, legacy metadata and discovery schema.
     *
     * ## EXAMPLES
     *
     *     wp ade schema preflight
     */
    public function preflight( $args, $assoc_args ): void {
        $this->print_report( ADE_Schema::report() );
    }

    /**
     * Explicit R1 create-only install on ahda.local. No legacy table writes.
     *
     * ## OPTIONS
     *
     * [--backup-confirmed=<value>]
     * : Must be YES after a restorable LocalWP backup has been verified.
     *
     * [--confirm=<value>]
     * : Must be INSTALL_R1.
     *
     * [--resume=<value>]
     * : Must be YES to resume a partial or interrupted R1 installation.
     *
     * ## EXAMPLES
     *
     *     wp ade schema install --backup-confirmed=YES --confirm=INSTALL_R1
     *     wp ade schema install --backup-confirmed=YES --confirm=INSTALL_R1 --resume=YES
     */
    public function install( $args, $assoc_args ): void {
        if ( ! isset( $assoc_args['backup-confirmed'] ) || $assoc_args['backup-confirmed'] !== 'YES' ) {
            WP_CLI::error( 'Backup LocalWP perlu dibuat, diperiksa, dan diakui dengan --backup-confirmed=YES.' );
        }
        if ( ! isset( $assoc_args['confirm'] ) || $assoc_args['confirm'] !== 'INSTALL_R1' ) {
            WP_CLI::error( 'Tindakan pemasangan schema eksplisit memerlukan --confirm=INSTALL_R1.' );
        }
        $resume = isset( $assoc_args['resume'] ) && $assoc_args['resume'] === 'YES';
        if ( isset( $assoc_args['resume'] ) && ! $resume ) { WP_CLI::error( 'Nilai --resume hanya menerima YES.' ); }
        $before = ADE_Schema::report();
        WP_CLI::log( 'Preflight state: ' . $before['state'] );
        foreach ( $before['issues'] as $issue ) { WP_CLI::warning( $issue ); }
        if ( $before['issues'] || ! in_array( $before['state'], $resume ? array( 'READY', 'RESUMABLE', 'NEEDS_FINALIZATION', 'INSTALLED' ) : array( 'READY', 'INSTALLED' ), true ) ) {
            WP_CLI::error( 'Preflight belum mengizinkan instalasi. Jalankan wp ade schema preflight.' );
        }
        try {
            $result = ADE_Schema::install( $resume );
        } catch ( Throwable $e ) {
            WP_CLI::error( 'Install R1 belum selesai: ' . $e->getMessage() . ' Periksa postflight; jangan menghapus tabel atau mengulang tanpa --resume=YES bila partial.' );
        }
        foreach ( $result['created'] as $table ) { WP_CLI::log( 'Created: ' . $table ); }
        if ( $result['already_installed'] ) { WP_CLI::success( 'Schema R1 sudah dipasang; tidak ada perubahan.' ); }
        else { WP_CLI::success( 'Schema R1 selesai. Jalankan wp ade schema postflight.' ); }
    }

    /**
     * Read-only verification; never fixes errors silently.
     *
     * ## EXAMPLES
     *
     *     wp ade schema postflight
     */
    public function postflight( $args, $assoc_args ): void {
        $this->print_report( ADE_Schema::report(), true );
    }

    /**
     * Recover an install lock at least 30 minutes old (does not delete tables).
     *
     * ## OPTIONS
     *
     * [--confirm=<value>]
     * : Must be UNLOCK_R1. Check that installer process is no longer running.
     */
    public function unlock( $args, $assoc_args ): void {
        if ( ! isset( $assoc_args['confirm'] ) || $assoc_args['confirm'] !== 'UNLOCK_R1' ) {
            WP_CLI::error( 'Memerlukan --confirm=UNLOCK_R1; pastikan tidak ada proses installer aktif.' );
        }
        if ( ! ADE_Schema::is_allowed_local() ) { WP_CLI::error( 'Unlock R1 hanya pada ahda.local.' ); }
        try {
            $removed = ADE_Schema::release_stale_lock();
        } catch ( Throwable $e ) {
            WP_CLI::error( $e->getMessage() );
        }
        if ( $removed ) { WP_CLI::success( 'Lock lama dilepas. Jalankan preflight sebelum resume.' ); }
        else { WP_CLI::log( 'Tidak ada lock yang perlu dilepas.' ); }
    }

    private function print_report( array $report, bool $require_installed = false ): void {
        WP_CLI::log( '=== AHDA DISCOVERY R1 SCHEMA ' . ( $require_installed ? 'POSTFLIGHT' : 'PREFLIGHT' ) . ' — READ ONLY ===' );
        WP_CLI::log( 'Site: ' . home_url( '/' ) );
        WP_CLI::log( 'Companion version: ' . ADE_VERSION );
        WP_CLI::log( 'Schema state: ' . $report['state'] );
        WP_CLI::log( 'Schema version option: ' . ( null === $report['schema_version'] ? '(unset)' : (string) $report['schema_version'] ) );
        WP_CLI::log( 'Install state: ' . ( null === $report['install_state'] ? '(unset)' : (string) $report['install_state'] ) );
        $lock = get_option( 'ade_schema_install_lock', null );
        WP_CLI::log( 'Install lock: ' . ( is_array( $lock ) ? 'ACTIVE (possible ongoing or stale installer)' : 'none' ) );
        WP_CLI::log( 'Existing Discovery tables: ' . count( $report['existing_discovery'] ) );
        WP_CLI::log( 'Missing Discovery tables: ' . count( $report['missing_discovery'] ) );
        WP_CLI::log( 'Legacy metadata SHA-256: ' . ( null === $report['legacy_hash'] ? '(unavailable)' : $report['legacy_hash'] ) );
        foreach ( $report['missing_discovery'] as $table ) { WP_CLI::log( ' - missing: ' . $table ); }
        foreach ( $report['issues'] as $issue ) { WP_CLI::warning( $issue ); }
        if ( $report['issues'] ) { WP_CLI::error( 'Pemeriksaan R1 ditolak karena masalah metadata atau lingkungan.' ); }
        if ( $require_installed && $report['state'] !== 'INSTALLED' ) { WP_CLI::error( 'Postflight: 7 tabel valid dan versi 1 belum lengkap.' ); }
        if ( ! $require_installed && ! in_array( $report['state'], array( 'READY', 'INSTALLED' ), true ) ) {
            WP_CLI::warning( 'Pemasangan tidak boleh dilakukan sebelum masalah preflight diselesaikan atau --resume dikonfirmasi pada pemasangan partial.' );
        }
        WP_CLI::success( 'Pemeriksaan baca-saja selesai, state=' . $report['state'] );
    }
}
