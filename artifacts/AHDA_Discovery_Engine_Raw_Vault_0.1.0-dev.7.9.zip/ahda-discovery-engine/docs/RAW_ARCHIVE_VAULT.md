# Penyimpanan raw-pending lokal — dev.7.9

Fitur ini menyimpan arsip mentah **satu sekolah** dengan jejak ekstraksi dan hash
sebagai satu record Discovery jobs. Default OFF. Bukan penyimpanan kandidat/bukti
pada tabel evidence/candidates, bukan verifikasi identitas/izin, bukan publisher.
Tidak ada operasi pada database asli pengguna dari pengembangan sesi ini.

## Hasil LocalWP yang sudah diterima

Operator mengirim hasil7.8:
`wp --user="admin" ade pilot inspect --demo --npsn=20210711 --dry-run`.
Terlihat preview_needs_review,2dokumen/3kandidat/6bukti,3bagian/9topik belum dinilai,
errors/conflicts kosong, write/network0 dan semua flag store/approval/publish false.
Ini sesuai contoh. missing_operator_binding, FIXTURE_NOT_SCHOOL_FACTS dan
STALE_EVIDENCE benar; bukan error yang perlu dinonaktifkan. Bukti ringkas dengan
hash file asli: docs/qa/localwp-inspect-demo-user-report.json. Itu laporan pengguna,
bukan eksekusi cloud/tes write/tes sumber nyata. Jangan mengulang demo untuk modul ini.

## Batas dan data yang disimpan

Input tetap arsip beku200 Tasikmalaya yang sama. Hanya dokumen untuk NPSN yang
dipilih masuk record, maksimal3dokumen; raw dari199sekolah lain tidak ikut.
Metadata pilihan200 NPSN tetap disertakan agar kontrak/hash dapat divalidasi ulang.
Envelope JSON **maksimal1MiB setelah encoding**, termasuk raw terpilih, bindings,
jejak klaim/evidence, nilai snapshot, hash rencana, actor, waktu capture, konfirmasi
privacy dan token preview. ASCII escaping/Unicode/JSON overhead dihitung sebelum
insert; maksimum raw dokumen tidak otomatis berarti envelope akan muat.

Satu insert ke `$wpdb->prefix . ahda_discovery_jobs`, job_type
`m2_raw_archive_pending`, status completed. Completed berarti **penyimpanan arsip
selesai**, bukan evidence verified/approved/published. Label raw_pending_unverified;
permission_attested=false, identity_attested=false, approval/publication=false.
Tidak menulis source/relation/evidence/candidate/link/review/profile/meta/nama/NPSN/
verified badge. Tidak ada schema/table/index/options/role baru atau cron/network.
Tipe job khusus terpisah dari worker simulasi R2 dan antrean M1; tidak auto-run.

Dokumen raw dianggap tidak tepercaya dan tidak dirender sebagai HTML. Receipt CLI
mengeluarkan metadata/hash/ukuran saja, tidak raw atau token preview. Tidak ada
viewer/download web/raw content endpoint. Record tidak diperbarui oleh modul ini;
revision baru memakai operasi baru. Hash membuktikan konsistensi byte, **bukan
keaslian sumber atau tanda tangan**. Admin database yang dapat menulis ulang payload
beserta hash tidak berada di bawah perlindungan checksum ini.

## Pengamanan sebelum menyimpan

- Site Shell lokal, preflight siap, ade_manage_jobs + ade_review_candidates, actor WordPress positif.
- Raw harus non-fixture, tidak kedaluwarsa, NPSN cocok, klaim tanpa konflik/error, semua sumber terikat ke relasi terdaftar yang lolos kebijakan pending.
- Token segar dari vault_stage; token inspect/work atau checkpoint bukan pengganti.
- Flag kode `ADE_LOCAL_ARCHIVE_STORAGE_ENABLED` harus boolean true; default tidak didefinisikan/OFF.
- Konfirmasi literal STORE_RAW_PENDING, backup-confirmed YES, privacy-reviewed YES.

Privacy-reviewed adalah pernyataan operator, bukan scanner otomatis. Operator wajib
memeriksa hak penyimpanan, redaksi data pribadi murid/kontak pribadi/secret/token
pada raw, dan backup sebelum memberi izin. Tidak ada crawler/akses baru, raw tidak
dikirim ke AI atau layanan lain. Izin network bukan izin menyimpan semua konten.

**Jangan aktifkan flag atau menjalankan write pada LocalWP Anda sekarang.** Sesi
ini tidak meminta operasi data nyata, sumber sah untuk pilot belum terkumpul.
Tidak ada perubahan wp-config atau instruksi mengakali gate. Test harness hanya
mendefinisikan flag di proses sintetis sekali pakai. Penulisan nyata perlu rencana
konkret dari dokumen sah/backup/izin operator terpisah sesuai AGENTS.md.

## CLI yang tersedia

Nama WP-CLI mengikuti underscore:

- `wp ade pilot vault_stage` membaca dan memperlihatkan rencana satu row, tanpa write. Wajib archive-file, bindings-file, npsn dan --dry-run.
- `wp ade pilot vault_store` mutasi raw-only dengan guard di atas. --dry-run tidak menjalankan write; gunakan vault_stage untuk preview.
- `wp ade pilot vault_receipt --receipt-id=ID` memeriksa byte/hash record historis dan mengembalikan metadata saja.

Bindings memakai kontrak docs/ARCHIVE_REVIEW.md. Semua input file lokal .json dengan
cap ukuran. Demo tidak diterima untuk penyimpanan; jangan mengubah fixture_only
pada dokumen contoh demi melewati penolakan. Perintah write lengkap sengaja tidak
dijadikan langkah uji pengguna; parameter tersedia di wp help dan kode untuk review.
Stage tetap bisa dipakai saat module OFF untuk menyusun rencana nyata yang nanti
memerlukan izin. estimated_jobs_rows_created1 (atau0 untuk replay), payload byte
count, source/document count dan token ditampilkan; tidak menulis file/database.

## Atomicity, idempotensi, rollback

Mutex sama dengan M2/M3, per prefix+school_id, GET_LOCK0. Transaksi pendek tanpa
network. Build ulang rencana/identitas/snapshot dan raw; lock source/relasi dengan
FOR UPDATE NOWAIT, periksa ID/canonicalkey/URL/host/status aktual. Lock receipt
Discovery. Token berbeda -> abort. Satu insert menyimpan payload+receipt dalam row
yang sama, COMMIT; insert/commit error -> ROLLBACK dan release mutex. Tak ada partial
raw/evidence/candidate karena modul ini tidak menyisipkan baris lainnya.

Operation key mengikat scope, manifest sumber, school_id/NPSN dan bundle terpilih.
Retry identik oleh actor yang sama membaca receipt, rows_created0; kasus commit
berhasil tetapi acknowledgment hilang dipulihkan lewat receipt. Replay bersifat
historis, tidak memperbarui snapshot/raw/sumber. Actor berbeda ditolak untuk replay
write; receipt metadata dapat dibaca reviewer lokal yang berwenang. Perubahan
manifest sekolah lain juga membuat revision arsip baru, bukan overwrite diam-diam.

Snapshot/klasifikasi lama hanya pembacaan saat capture; tidak ada lock/penulisan
tabel lama atau jaminan serialisasi atas editor legacy yang tidak memakai mutex.
Karena belum menerapkan profil, snapshot bukan izin publish; writer kandidat dan
publisher masa depan wajib memeriksa ulang kondisi saat operasi sebenarnya.

Rollback kode ke7.8 tidak menghapus row raw yang telah disetujui/dibuat. Jangan
DELETE tabel/row lama otomatis. Retensi/export/purge arsip pasca-commit belum dibuat.
Belum ada enkripsi raw pada aplikasi, kuota total penyimpanan atau penghapusan
privasi terotomatisasi. DB permission, backup dan kebijakan retensi operator tetap
penting. Cap1MiB/per-operation dan dedupe membatasi satu aksi, bukan keseluruhan
disk; banyak revision menambah storage. Feature OFF sampai kebijakan dan izin siap.

## Bukti dan kekurangan

23suite offline1416checks PHP8.2.32/8.4.24 dengan DOM;1348tanpaDOM, HTML NOT RUN.
78filePHP lint,84hash baseline dan6file regresi asli utuh. Suitevault37checksDOM/
36tanpaDOM mencakup defaultOFF/fixture/stale/consent/current/source-race/one-school
selection/receipt/tamper/retry/rollback/commit-ack loss dan encoded size capDOM.
OfficialWPCLI94checksDOM/92tanpaDOM termasuk dispatch write defaultOFF sebelum
file dibaca. Semua ini memakai facade/fakeDB, bukan database pengguna.

195checks actual MySQL8.4.13 (164regresi sebelumnya+31vault) dengan adapter WP/wpdb
stub, data sintetis disposable: native1raw row/receipt, bytes/hash, dedupe, insert
failure rollback, mutex2session, NOWAIT source lock, stale snapshot, acknowledgment
loss after actualCOMMIT, corruption detection, semua8tabel uji non-jobs utuh.
Container sendiri1CPU/1GiB/512MiBtmpfs dihapus. Tidak ada situs/database pengguna.
Lihat docs/qa/dev7.9. `fixture_only=false` dalam tes hanya data sintetis terisolasi,
bukan izin mengubah fixture pengguna. User LocalWP raw write **NOT TESTED**.

Belum ada receipt->evidence/candidate writer terikat raw, approval positif,
permission/identity attestation, durable extraction worker/lease/fencing,
publisher lokal/rollback publikasi. Tidak ada artikel faktual baru di profil asli.
Akses katalog resmi tetap diblokir kebijakan jaringan cloud; sisa riset18/20request
untuk10sekolah awal, tanpa percobaan baru/bypass. Tidak menjanjikan ranking/AI.
