<?php
/** Real selected NPSNs/classification, SYNTHETIC school IDs and fake DB only. */
require_once __DIR__ . '/support/m1-fake-db.php';
require_once dirname(__DIR__) . '/includes/class-ade-identity.php';
require_once dirname(__DIR__) . '/includes/class-ade-source-urls.php';
require_once dirname(__DIR__) . '/includes/class-ade-sources.php';
require_once dirname(__DIR__) . '/includes/class-ade-pilot-scope.php';
require_once dirname(__DIR__) . '/includes/class-ade-pilot.php';
require_once dirname(__DIR__) . '/includes/class-ade-pilot-jobs.php';
$wpdb=new FakeDB;
$n=0;
function ck($ok,$label){global $n;++$n;if(!$ok){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$label){$caught=false;try{$fn();}catch(RuntimeException|InvalidArgumentException $e){$caught=true;}ck($caught,$label);}
$reference=ADE_Pilot_Scope::reference();$npsns=[];$id=0;
foreach($reference as $code=>$ref){
    $code=(string)$code;$npsns[]=$code;
    $wpdb->schools[$code]=array_merge($ref,['id'=>++$id,'name'=>'Offline fixture','education_level'=>'fixture','district_raw'=>'fixture','village_raw'=>'fixture','visibility'=>'publish']);
}
ck(count($reference)===200,'200 checksum-verified reference entries');
ck(hash('sha256',file_get_contents(dirname(__DIR__).'/data/pilots/tasikmalaya-200.txt'))==='42aaa7c51d5e0163c08146d1c46df70e260496639b9a3cc55e34f58781b1af20','bundled list matches selected user file');
$forms=array_count_values(array_column(array_values($reference),'school_form'));
ck($forms['SMP']===159 && $forms['MTS']===18 && $forms['SMA']===21 && $forms['SMK']===2,'priority/topping totals preserved');
$a=ADE_Pilot::audit_selection($npsns);ck($a['all_valid'] && $a['checked']===200 && $a['unrun']===0,'full read-only audit fixture');ck($wpdb->jobs===[],'audit creates no jobs');
$m=ADE_Pilot::freeze($npsns,ADE_Pilot_Scope::NAME);ck($m['version']===2 && $m['scope']===ADE_Pilot_Scope::NAME,'scoped metadata version, not DB schema');
ck($m===ADE_Pilot::freeze(array_reverse($npsns),ADE_Pilot_Scope::NAME),'order-independent DB manifest');
$code=$npsns[0];$original=$wpdb->schools[$code];
foreach(['ownership_status'=>'SWASTA','regency_raw'=>'KAB. CILACAP','school_form'=>'SD','visibility'=>'draft'] as $field=>$bad){
    $wpdb->schools[$code][$field]=$bad;
    blocked(fn()=>ADE_Pilot::freeze($npsns,ADE_Pilot_Scope::NAME),'freeze conflict '.$field);
    blocked(fn()=>ADE_Pilot::batch($m),'batch rechecks '.$field);
    $audit=ADE_Pilot::audit_selection($npsns);ck(!$audit['all_valid'] && $audit['checked']===200 && $audit['failed']===1,'audit structured conflict '.$field);
    $wpdb->schools[$code]=$original;
}
// The last district is rechecked too, not only the first school.
$last=$npsns[199];$saved=$wpdb->schools[$last]['ownership_status'];$wpdb->schools[$last]['ownership_status']='SWASTA';
ck(ADE_Pilot::audit_selection($npsns)['passed']===199,'tail conflict not hidden by first-batch preview');$wpdb->schools[$last]['ownership_status']=$saved;
$wpdb->schools[$code]['id']=9999;blocked(fn()=>ADE_Pilot::batch($m),'changed school ID blocked');$wpdb->schools[$code]=$original;
$wpdb->schools[$code]['ownership_status']=null;blocked(fn()=>ADE_Pilot::batch($m),'unknown ownership cannot be inferred from name');$wpdb->schools[$code]=$original;
$wpdb->schools[$code]['school_form']='SMA';blocked(fn()=>ADE_Pilot::batch($m),'allowed form different from frozen form rejected');$wpdb->schools[$code]=$original;
$old_prefix=$wpdb->prefix;$wpdb->prefix="x`; DROP TABLE y; --";blocked(fn()=>ADE_Identity::lookup_pilot($code),'SQL identifier injection rejected');$wpdb->prefix=$old_prefix;
blocked(fn()=>ADE_Identity::lookup_pilot("12345678' OR 1=1"),'NPSN SQL payload rejected');
blocked(fn()=>ADE_Pilot::freeze(['12345678'],ADE_Pilot_Scope::NAME),'outside selection blocked before lookup');
blocked(fn()=>ADE_Pilot::audit_selection(array_slice($npsns,0,199)),'199 is not full audit');
$bad=$m;$bad['scope_hash']=str_repeat('a',64);blocked(fn()=>ADE_Pilot::validate_manifest($bad),'scope fingerprint cannot change');
$bad=$m;$bad['scope']='another-province';blocked(fn()=>ADE_Pilot::validate_manifest($bad),'scope switch blocked');
$bad=$m;$bad['schools'][0]['npsn']='12345678';blocked(fn()=>ADE_Pilot::validate_manifest($bad),'rehashed outside school still blocked');
$wpdb->read_failure=true;unset($wpdb->schools[$code]);$audit=ADE_Pilot::audit_selection($npsns);ck(!$audit['all_valid'] && $audit['issues'][0]['code']==='PILOT_LOOKUP_FAILED','read failure is not an eligibility pass');$wpdb->read_failure=false;$wpdb->schools[$code]=$original;
$created=ADE_Pilot_Jobs::enqueue($m,'ENQUEUE_M1_PLAN');$again=ADE_Pilot_Jobs::enqueue($m,'ENQUEUE_M1_PLAN');ck($created['created'] && !$again['created'],'scoped enqueue dedupe');
$job_id=$created['job']['id'];
$wpdb->schools[$code]['ownership_status']='SWASTA';blocked(fn()=>ADE_Pilot_Jobs::step($job_id,'RUN_M1_PLAN'),'worker conflict failure');
ck($wpdb->jobs[$job_id]['cursor_school_id']===null && $wpdb->jobs[$job_id]['stats_payload']===null,'conflict cannot advance checkpoint');
$wpdb->schools[$code]=$original;$wpdb->jobs[$job_id]['next_run_at']=null;
for($i=0;$i<20;++$i){$result=ADE_Pilot_Jobs::step($job_id,'RUN_M1_PLAN');}
ck($result['status']==='completed','all 200 fixtures resumable over 20 batches');
ck(ADE_Pilot_Jobs::integrity($job_id)['committed']===200,'scoped result integrity');
$stats=json_decode($wpdb->jobs[$job_id]['stats_payload'],true);ck(array_column($stats,'npsn')===array_column($m['schools'],'npsn'),'no substitutions in completed pilot');
foreach($wpdb->sql as [$sql,$args]){if(strpos($sql,'UPDATE ')===0){ck(strpos($sql,'UPDATE custom_ahda_discovery_jobs ')===0,'writes only Discovery job checkpoints');}}
echo "PASS: $n frozen Tasikmalaya scope checks (selected identifiers, fake DB and synthetic IDs; NOT LocalWP).\n";
