> dev7.10: receipt-to-pending-evidence/candidate module exists, default OFF.
> No real-data write approved/enabled; see ARCHIVE_CANDIDATES.md.
> Statements below retain their original version scope.

> dev7.9: raw-only archive vault now available but default OFF. This command
> remains read-only; raw-receipt to evidence/candidate storage is not implemented.
> See RAW_ARCHIVE_VAULT.md. Historical statements below retain their version scope.

# Worker pratinjau arsip lokal — dev.7.7

Status: implementasi offline/read-only. Belum worker penyimpanan transaksional,
belum crawler aktif, bukan approval/publikasi. Profil sekolah tidak berubah.
Daftar tetap 200 sekolah negeri Kab/Kota Tasikmalaya, Jawa Barat, dari pilihan
operator sebelumnya (177 SMP/MTs +23 SMA/SMK). Tidak memilih ulang/nasional.

## Fungsi dan batas

`wp ade pilot archive --demo --dry-run` mencetak JSON arsip sintetis.
`wp ade pilot work --demo --batch-size=10 --dry-run` memproses paling banyak10
sekolah, urut NPSN. Urutan/cursor ini **berbeda dari cursor school_id M1**;
checkpoint M1 lama tidak dapat dipakai di sini. `work` memerlukan CLI, LocalWP,
preflight siap, capability ade_manage_jobs dan ade_review_candidates. Tidak ada
endpoint web/cron baru. SQL hanya lookup identitas melalui prepared query lama.

CSV/HTML memakai parser dev7.3. JSON memakai kontrak structured evidence dev7.1.
Hanya program/kurikulum/jam layanan yang didukung. NPSN dokumen harus sama dengan
sekolah pilihan; CLI memeriksa ulang identitas/klasifikasi live setiap sekolah
baru/retry. Klaim berbeda untuk target sama dari beberapa dokumen menghasilkan
`conflicting_claims`, tanpa memilih nilai otomatis. Satu dokumen gagal membuat
sekolah `document_blocked` tanpa kandidat parsial; sekolah berikutnya tetap jalan.
Klaim sama digabung dengan referensi bukti setiap dokumen dan hash raw tersendiri.

Batas: arsip JSON4MiB, tepat200 NPSN unik dalam daftar beku, <=200dokumen total,
<=3dokumen/sekolah, CSV/JSON64KiB dan HTML256KiB/dokumen. Tidak berbagi satu
kunci dokumen antar sekolah; dokumen tak terpakai ditolak. Konten inline UTF8,
URL HTTPS kanonik tanpa credential/token; metadata tanggal UTC/reference wajib.
JSON depth16 dan <=50000 tanda struktural di luar string, duplicate keys termasuk
escape Unicode ditolak. HTML tetap DOM NONET, tanpa DTD/entitas/aset/script fetch.
Deadline5detik diperiksa **antar sekolah**, bukan hard interrupt; validasi arsip
terjadi sebelum deadline. Batas dokumen/parser/10sekolah tetap berlaku.

## Bentuk arsip

Root tepat: schema_version=1, scope_hash=SHA256 daftar beku, fixture_only boolean,
documents map, schools list. Setiap sekolah: npsn string dan document_keys list.
Setiap dokumen: format(csv/html/json), raw_sha256, source_url, checked_at UTC
`YYYY-MM-DDTHH:MM:SSZ`, permission_reference ASCII3..80, content string.

`ADE_Local_Archive::document()` membangun entry dan key dari format/raw hash/URL/
tanggal/reference. `freeze()` memeriksa semuanya, mengurutkan sekolah/dokumen dan
menghasilkan manifest_sha256 kanonik serta input_sha256 byte asli. CLI archive
memberi contoh lengkap format ini, **isinya sintetis, bukan fakta sekolah**.
Hash melindungi konsistensi byte/metadata di dalam bundle, bukan membuktikan asal,
keaslian sumber, waktu pengambilan, atau izin. `permission_reference` hanya teks
operator. Tidak ada downloader atau penyimpanan raw immutable tepercaya di sini.
Tidak menyimpan path file arbitrary dalam dokumen, tidak membaca file dari HTML.

## Melanjutkan batch di Windows LocalWP

Opsional setelah memasang7.7 di ahda.local; tidak perlu mengulang demo lama.
Buka Local > ahda > Open Site Shell. Contoh direktori di luar document root:

```bat
mkdir "C:\Users\user\Documents\AHDA-preview"
wp --user="admin" ade pilot work --demo --batch-size=10 --dry-run > "C:\Users\user\Documents\AHDA-preview\batch-01.json"
wp --user="admin" ade pilot work --demo --checkpoint-file="C:\Users\user\Documents\AHDA-preview\batch-01.json" --batch-size=10 --dry-run > "C:\Users\user\Documents\AHDA-preview\batch-02.json"
```

Periksa setiap output dan exit code sebelum lanjut. File keluaran harus berbeda
setiap panggilan: jangan redirect ke file checkpoint input yang sama karena shell
akan mengosongkannya sebelum dibaca. CLI sendiri tidak menyimpan file. Redirection
shell adalah aksi penyimpanan operator. Jangan meletakkan arsip/report di webroot
atau GitHub jika berisi sumber privat/data pribadi; demo aman dan sintetis.

Output cursor10 lalu20; `results` hanya batch panggilan ini. `summary` menghitung
seluruh prefix selesai, checkpoint berisi ringkasan/hash tiap hasil, **bukan seluruh
teks kandidat batch sebelumnya**. Simpan setiap report bila perlu membaca hasil
lama. Setelah20panggilan tanpa deadline, cursor200/complete=true berarti200telah
**diperiksa**, bukan200artikel lengkap/terverifikasi. Demo dengan DOM:1preview,
1konflik,1dokumen salahNPSN,197needs_source. Tanpa DOM: HTML ditolak, tidak ada
fallback yang mengklaim ekstraksi HTML berhasil. Fixture/staleness tetap blok.

Untuk arsip operator yang telah disiapkan sah, ganti `--demo` dengan
`--archive-file="C:\...\arsip.json"`; jangan gabungkan keduanya. Ini tetap hanya
membaca/menghasilkan preview. Persiapan/pengambilan sumber nyata masih harus
mematuhi persetujuan jaringan, robots/ToS, batas request dan kebijakan sumber.

`--checkpoint-file` menerima objek checkpoint atau report sebelumnya <=512KiB.
Jika report besar, simpan hanya properti checkpoint menjadi JSON (jangan ubah
nilainya). Keutuhan prefix, manifest/pipeline/scope, cursor dan checksum diperiksa.
Checkpoint portabel **operator-controlled, bukan HMAC/signature/receipt commit**.
Operator dapat menghitung ulang checksum; tidak memberi otoritas approval/store.
Memakai file checkpoint lama boleh menghitung ulang batch; tidak ada exactly-once
DB guarantee, lock/lease/scheduler multiworker atau checkpoint-after-DB-commit.

`--retry-npsn=<NPSN>` dengan checkpoint hanya mengulang satu hasil document_blocked,
identity_blocked, atau conflicting_claims; maksimal3attempts, cursor/prefix lain
tetap. needs_source/sukses/unprocessed ditolak. Perubahan isi arsip mengubah
manifest: mulai preview baru, bukan mengubah kontrak retry diam-diam.

## Verifikasi dan rollback

21suite offline:1230checks masing-masing PHP8.2.32/8.4.24 dengan DOM;1166tanpa DOM
(ekstraksi HTML NOT RUN).74file PHP lint,84hash baseline dan6file regresi asli utuh.
Official WP-CLI2.12 parser/dispatcher menjalankan command baru dengan facade WP/
fakeDB, termasuk local-file resume/capability/local gate. Tidak ada MySQL nyata
untuk worker ini. Integrasi WordPress39checks dev7.6 tetap bukti versi sebelumnya;
**worker7.7 belum diuji pada WordPress/LocalWP pengguna**. Tidak ada operasi
produksi atau pengayaan fakta sekolah. Bukti: docs/qa/dev7.7.

Uji sintetis PHP8.2, memory_limit128M:200dokumen dalam arsip3,322,738byte;
batch10HTML200KB,0.423detik,peakPHP13,971,456byte pada cloud sesi ini. Angka ini
bukan RSS seluruh WordPress atau jaminan konsumsi VPS1GB/SEO/peringkat.

Rollback: kembalikan folder plugin7.6; tidak ada migrasi/tabel/opsi/role baru.
Arsip/report buatan operator tetap miliknya; kode tidak menghapusnya. Database lama
utuh. Review write/publisher/network tetap OFF. Jangan memasukkan output work ke
store/stage secara otomatis; belum ada durable raw-evidence/review authority bridge.

Berikutnya: arsip asal sah dan ikatan raw-evidence ke storage Discovery dengan
preview persetujuan terpisah; lalu worker transaksional dengan lease/fencing dan
checkpoint setelah commit. Positive approval/publisher lokal/rollback publikasi
masih belum selesai. Akses katalog resmi masih dibatasi kebijakan cloud; tidak
diulang atau dilewati, sisa izin riset18/20request untuk10sekolah awal saja.
