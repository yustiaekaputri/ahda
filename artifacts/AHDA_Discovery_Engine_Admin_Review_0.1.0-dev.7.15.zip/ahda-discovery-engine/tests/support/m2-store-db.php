<?php
if(PHP_SAPI!=='cli'){exit(2);}
final class StoreDB {
 public $prefix='custom_',$last_error='',$insert_id=0,$inner,$meta=[],$tables=[],$next=[],$held=false,$snapshot=null,$writes=0,$queries=[],$read_fail=false,$fail_insert_at=0,$commit_fail=false,$commit_ack_lost=false,$version_conflict=false;
 public $relation=['source_id'=>7,'relation_id'=>8,'source_type'=>'website','access_state'=>'manual_only','source_status'=>'discovered','identity_status'=>'pending','relationship_type'=>'pending'];
 public function __construct(){ $this->inner=new FakeDB;foreach(['evidence','candidates','candidate_evidence','jobs'] as $table){$this->tables[$table]=[];$this->next[$table]=1;} }
 public function prepare($sql,...$args){return $this->inner->prepare($sql,...$args);}
 public function get_results($key,$kind){
  [$sql,$args]=$this->inner->prepared[$key]??[$key,[]];$this->queries[]=[$sql,$args];
  if($this->read_fail){$this->last_error='Injected read error';return null;}
  if(strpos($sql,'GET_LOCK(')!==false){if($this->held){return [['acquired'=>0]];}$this->held=true;return [['acquired'=>1]];}
  if(strpos($sql,'RELEASE_LOCK(')!==false){$this->held=false;return [['released'=>1]];}
  if(strpos($sql,'FROM custom_ahda_schools ')!==false){$out=$this->inner->get_results($key,$kind);$this->last_error=$this->inner->last_error;return $out;}
  if(strpos($sql,'FROM custom_ahda_school_meta ')!==false){if($args[1]!=='verified'||strpos($sql,'LEFT(meta_value,16385)')===false){throw new RuntimeException('Unsafe old-table read');}return $this->meta;}
  if(strpos($sql,'FROM custom_ahda_discovery_sources ')!==false){$expected=ADE_Source_URLs::canonicalize('https://example.org/')['canonical_key'];return $this->relation && $args[0]===913 && $args[1]===$expected?[$this->relation]:[];}
  foreach(['candidates','evidence','candidate_evidence','jobs'] as $suffix){
   if(strpos($sql,'FROM custom_ahda_discovery_'.$suffix.' ')===false){continue;}
   foreach($this->tables[$suffix] as $row){
    $match=$suffix==='candidates'?$row['dedupe_key']===$args[0]:($suffix==='evidence'?$row['evidence_key']===$args[0]:($suffix==='candidate_evidence'?($row['candidate_id']===$args[0]&&$row['evidence_id']===$args[1]):(strpos($sql,'WHERE id=%d')!==false?$row['id']===$args[0]:$row['job_key']===$args[0])));
    if($suffix==='jobs'){$match=$match&&$row['job_type']===$args[1];}
    if($match){if($suffix==='jobs'){$row['scope_bytes']=strlen($row['scope_filter']);$row['stats_bytes']=strlen($row['stats_payload']);}if($suffix==='candidates'){$row['proposed_bytes']=strlen($row['proposed_value']);$row['has_approved']=$row['approved_value']!==null?1:0;}return [$row];}
   }
   return [];
  }
  throw new RuntimeException('Unexpected read SQL '.$sql);
 }
 public function insert($table,$values){
  $suffix=substr($table,strlen('custom_ahda_discovery_'));
  if(!isset($this->tables[$suffix])||$table!=='custom_ahda_discovery_'.$suffix){throw new RuntimeException('Non-Discovery write');}
  ++$this->writes;if($this->fail_insert_at===$this->writes){$this->last_error='Injected insertion failure';return false;}
  foreach($this->tables[$suffix] as $old){
   $duplicate=$suffix==='candidate_evidence'?($old['candidate_id']===$values['candidate_id']&&$old['evidence_id']===$values['evidence_id']):$old[$suffix==='candidates'?'dedupe_key':($suffix==='evidence'?'evidence_key':'job_key')]===$values[$suffix==='candidates'?'dedupe_key':($suffix==='evidence'?'evidence_key':'job_key')];
   if($duplicate){$this->last_error='Duplicate key';return false;}
  }
  $id=$this->next[$suffix]++;$values['id']=$id;$this->tables[$suffix][$id]=$values;$this->insert_id=$id;return 1;
 }
 public function query($key){
  [$sql,$args]=$this->inner->prepared[$key]??[$key,[]];$this->queries[]=[$sql,$args];
  if($sql==='START TRANSACTION'){if($this->snapshot!==null){throw new RuntimeException('Nested transaction');}$this->snapshot=[$this->tables,$this->next];return 0;}
  if($sql==='ROLLBACK'){if($this->snapshot!==null){[$this->tables,$this->next]=$this->snapshot;}$this->snapshot=null;return 0;}
  if($sql==='COMMIT'){if($this->commit_ack_lost){$this->snapshot=null;$this->last_error='Acknowledgment lost';return false;}if($this->commit_fail){$this->last_error='Commit failed';return false;}$this->snapshot=null;return 0;}
  if(strpos($sql,'UPDATE custom_ahda_discovery_candidates SET row_version=row_version+1,updated_at=%s')===0){
   [$now,$id,$school,$version]=$args;$row=&$this->tables['candidates'][$id];
   if($this->version_conflict || $row['school_id']!==$school||$row['row_version']!==$version||$row['review_status']!=='new'||$row['publish_status']!=='not_ready'||$row['approved_value']!==null||$row['approved_by_user_id']!==null||$row['approved_at']!==null||$row['published_local_at']!==null){return 0;}
   ++$row['row_version'];$row['updated_at']=$now;return 1;
  }
  throw new RuntimeException('Forbidden/unknown SQL mutation '.$sql);
 }
}
