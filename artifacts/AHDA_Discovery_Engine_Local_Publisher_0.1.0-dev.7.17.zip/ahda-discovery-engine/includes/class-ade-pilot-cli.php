<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** M1 operator-only planning CLI. No command in this group fetches the network. */
final class ADE_Pilot_CLI {
    private function npsns( array $assoc ): array {
        ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
        $path = ! isset( $assoc['npsn-file'] ) ? dirname( __DIR__ ) . '/data/pilots/tasikmalaya-200.txt' :
            ( is_string( $assoc['npsn-file'] ) ? realpath( $assoc['npsn-file'] ) : false );
        if ( false === $path || ! is_file( $path ) || ! is_readable( $path ) || filesize( $path ) > 4096 || substr( $path, -4 ) !== '.txt' ) {
            throw new InvalidArgumentException( 'Use a local .txt file, one NPSN per line, maximum 4096 bytes.' );
        }
        $input = file_get_contents( $path, false, null, 0, 4097 );
        if ( false === $input ) { throw new RuntimeException( 'PILOT_READ_FAILED' ); }
        return ADE_Pilot::parse( $input );
    }

    private function input( array $assoc ): array {
        return ADE_Pilot::freeze( $this->npsns( $assoc ), ADE_Pilot_Scope::NAME );
    }

    private function number( array $assoc, string $key, int $default ): int {
        if ( ! isset( $assoc[$key] ) ) { return $default; }
        if ( ! is_string( $assoc[$key] ) || ! preg_match( '/^[0-9]{1,18}$/D', $assoc[$key] ) ) { throw new InvalidArgumentException( 'Invalid --' . $key ); }
        return (int) $assoc[$key];
    }

    private function require_write( array $assoc, string $expected ): string {
        if ( isset( $assoc['dry-run'] ) ) { throw new InvalidArgumentException( 'DRY_RUN_REQUIRES_PREVIEW; this command changes job state.' ); }
        if ( ! isset( $assoc['confirm'] ) || ! is_string( $assoc['confirm'] ) || $assoc['confirm'] !== $expected ) {
            throw new InvalidArgumentException( 'Explicit --confirm=' . $expected . ' required.' );
        }
        return $assoc['confirm'];
    }

    private function output( array $value ): void {
        WP_CLI::log( json_encode( $value, JSON_PRETTY_PRINT | JSON_HEX_TAG | JSON_HEX_AMP | JSON_THROW_ON_ERROR ) );
    }

    /**
     * Audit all frozen Tasikmalaya identities against LocalWP; SELECT only.
     *
     * ## OPTIONS
     * [--npsn-file=<path>]
     * : Defaults to the bundled frozen list; custom files must contain the same 200.
     */
    public function preflight( $args, $assoc ): void {
        try {
            $report = ADE_Pilot::audit_selection( $this->npsns( $assoc ) );
            $this->output( $report );
            if ( ! $report['all_valid'] ) { WP_CLI::error( 'PILOT_PREFLIGHT_BLOCKED; no job or source was changed.' ); }
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Validate frozen Tasikmalaya state-school selection; preview one batch, no writes.
     *
     * ## OPTIONS
     * [--npsn-file=<path>]
     * [--after=<school-id>]
     * [--batch-size=<1-20>]
     * [--dry-run]
     */
    public function preview( $args, $assoc ): void {
        try {
            $manifest = $this->input( $assoc );
            $this->output( array( 'mode' => 'READ_ONLY_NO_FETCH', 'scope' => $manifest['scope'], 'scope_hash' => $manifest['scope_hash'], 'selection_count' => count( $manifest['schools'] ),
                'batch' => ADE_Pilot::batch( $manifest, $this->number( $assoc, 'after', 0 ), $this->number( $assoc, 'batch-size', 10 ) ) ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Inspect existing verified Directory URL fields; never fetch or store sources.
     *
     * ## OPTIONS
     * [--npsn-file=<path>]
     * [--after=<school-id>]
     * [--batch-size=<1-20>]
     * [--dry-run]
     */
    public function source_preview( $args, $assoc ): void {
        try {
            $manifest = $this->input( $assoc );
            $this->output( ADE_Source_Inventory::preview( $manifest, $this->number( $assoc, 'after', 0 ), $this->number( $assoc, 'batch-size', 10 ) ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Preview literal evidence/candidates from a local structured JSON document.
     *
     * ## OPTIONS
     * [--evidence-file=<path>]
     * : Local .json file, at most64KiB, schema documented in docs/M2_PREVIEW.md.
     * [--demo]
     * : Use bundled synthetic data; never represents facts about the school.
     * [--dry-run]
     * : Mandatory; this command previews only and never writes evidence/candidates.
     */
    public function extract( $args, $assoc ): void {
        try {
            ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
            if ( ( $assoc['dry-run'] ?? null ) !== true ) { throw new InvalidArgumentException( 'M2_PREVIEW_REQUIRES_DRY_RUN' ); }
            $raw = $this->preview_file( $assoc );
            $this->output( ADE_Enrichment_Preview::preview( $raw ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    private function preview_file( array $assoc ): string {
        if ( isset( $assoc['demo'] ) ) {
            if ( $assoc['demo'] !== true || isset( $assoc['evidence-file'] ) ) { throw new InvalidArgumentException( 'M2_INPUT_AMBIGUOUS' ); }
            $path = dirname( __DIR__ ) . '/data/examples/m2-structured-fixture.json';
        } else {
            $path = isset( $assoc['evidence-file'] ) && is_string( $assoc['evidence-file'] ) ? realpath( $assoc['evidence-file'] ) : false;
        }
        if ( false === $path || ! is_file( $path ) || ! is_readable( $path ) || substr( $path, -5 ) !== '.json' ||
            filesize( $path ) > ADE_Enrichment_Preview::MAX_INPUT_BYTES ) { throw new InvalidArgumentException( 'M2_LOCAL_JSON_REQUIRED' ); }
        $raw = file_get_contents( $path, false, null, 0, ADE_Enrichment_Preview::MAX_INPUT_BYTES + 1 );
        if ( false === $raw ) { throw new RuntimeException( 'M2_INPUT_READ_FAILED' ); }
        return $raw;
    }

    /**
     * Preview an evidence-linked article and editorial gaps; never publish or store.
     *
     * ## OPTIONS
     * [--evidence-file=<path>]
     * : Local structured JSON, same schema and limits as extract.
     * [--demo]
     * : Use synthetic fixture data, prominently marked as nonfactual.
     * [--dry-run]
     * : Required by handler; no network or database changes.
     */
    public function article( $args, $assoc ): void {
        try {
            ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
            if ( ( $assoc['dry-run'] ?? null ) !== true ) { throw new InvalidArgumentException( 'M2_ARTICLE_REQUIRES_DRY_RUN' ); }
            $this->output( ADE_Article_Preview::preview( $this->preview_file( $assoc ) ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Parse a saved CSV or supported HTML table; read-only, no fetch/export/write.
     *
     * ## OPTIONS
     * --format=<html|csv>
     * : Explicit local document format.
     * [--demo]
     * : Use bundled synthetic document and fixed metadata.
     * [--document-file=<path>]
     * : Local .html/.htm or .csv, required when not demo.
     * [--npsn=<code>]
     * : Intended frozen pilot NPSN, required when not demo.
     * [--source-url=<url>]
     * : Actual source HTTPS URL, required when not demo; never fetched.
     * [--checked-at=<utc>]
     * : Actual UTC document observation time, required when not demo.
     * [--permission-reference=<reference>]
     * : Operator reference, required when not demo; does not certify permission.
     * [--dry-run]
     * : Required boolean true; cannot save evidence or publish.
     */
    public function parse( $args, $assoc ): void {
        try {
            ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
            if ( ( $assoc['dry-run'] ?? null ) !== true ) { throw new InvalidArgumentException( 'M2_PARSE_REQUIRES_DRY_RUN' ); }
            $format = $this->m2_string( $assoc, 'format' );
            if ( ! in_array( $format, array( 'html', 'csv' ), true ) ) { throw new InvalidArgumentException( 'M2_DOCUMENT_FORMAT_UNSUPPORTED' ); }
            if ( isset( $assoc['demo'] ) ) {
                if ( true !== $assoc['demo'] || array_intersect( array_keys( $assoc ), array( 'document-file', 'npsn', 'source-url', 'checked-at', 'permission-reference' ) ) ) { throw new InvalidArgumentException( 'M2_INPUT_AMBIGUOUS' ); }
                $path = dirname( __DIR__ ) . '/data/examples/m2-profile-fixture.' . $format;
                $npsn = '20268071';
                $metadata = array( 'fixture_only' => true, 'source_url' => 'https://example.org/ahda-fixture-only', 'checked_at' => '2020-01-01T00:00:00Z', 'permission_reference' => 'fixture-only-not-a-permission' );
            } else {
                $path = isset( $assoc['document-file'] ) && is_string( $assoc['document-file'] ) ? realpath( $assoc['document-file'] ) : false;
                $npsn = $this->m2_string( $assoc, 'npsn' );
                $metadata = array( 'fixture_only' => false, 'source_url' => $this->m2_string( $assoc, 'source-url' ),
                    'checked_at' => $this->m2_string( $assoc, 'checked-at' ), 'permission_reference' => $this->m2_string( $assoc, 'permission-reference' ) );
            }
            $limit = 'html' === $format ? ADE_Document_Parser::MAX_HTML_BYTES : ADE_Document_Parser::MAX_CSV_BYTES;
            $extension = false === $path ? '' : strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
            if ( false === $path || ! is_file( $path ) || ! is_readable( $path ) || ! in_array( $extension, 'html' === $format ? array( 'html', 'htm' ) : array( 'csv' ), true ) || filesize( $path ) > $limit ) { throw new InvalidArgumentException( 'M2_LOCAL_DOCUMENT_REQUIRED' ); }
            $raw = file_get_contents( $path, false, null, 0, $limit + 1 );
            if ( false === $raw ) { throw new RuntimeException( 'M2_INPUT_READ_FAILED' ); }
            $this->output( ADE_Document_Parser::preview( $raw, $format, $npsn, $metadata ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    private function local_json( array $assoc, string $key, int $limit ): string {
        $path = isset( $assoc[$key] ) && is_string( $assoc[$key] ) ? realpath( $assoc[$key] ) : false;
        if ( false === $path || ! is_file( $path ) || ! is_readable( $path ) || strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) !== 'json' || filesize( $path ) > $limit ) { throw new InvalidArgumentException( 'WORKER_LOCAL_JSON_REQUIRED' ); }
        $raw = file_get_contents( $path, false, null, 0, $limit + 1 );
        if ( false === $raw ) { throw new RuntimeException( 'WORKER_INPUT_READ_FAILED' ); }
        return $raw;
    }

    /**
     * Print a synthetic portable archive; no file, database or network write.
     *
     * ## OPTIONS
     * [--demo]
     * : Required; generates synthetic data only, not school facts.
     * [--dry-run]
     * : Required boolean true.
     */
    public function archive( $args, $assoc ): void {
        try {
            ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
            if ( ( $assoc['demo'] ?? null ) !== true || ( $assoc['dry-run'] ?? null ) !== true || ! current_user_can( 'ade_review_candidates' ) ) { throw new InvalidArgumentException( 'WORKER_DEMO_DRY_RUN_REQUIRED' ); }
            $this->output( ADE_Local_Archive::freeze( ADE_Local_Archive::demo() )['bundle'] );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Process a resumable local archive preview; never store or fetch.
     *
     * ## OPTIONS
     * [--demo]
     * : Use the immutable synthetic archive instead of a file.
     * [--archive-file=<path>]
     * : Local JSON archive at most4MiB, required unless demo.
     * [--checkpoint-file=<path>]
     * : Local JSON checkpoint or previous work report, at most512KiB.
     * [--batch-size=<1-10>]
     * : Default10, maximum10 schools per call.
     * [--retry-npsn=<code>]
     * : Retry one already processed failure, maximum3 attempts.
     * [--dry-run]
     * : Required boolean true; all output is unverified/read-only.
     */
    public function work( $args, $assoc ): void {
        try {
            ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
            if ( ( $assoc['dry-run'] ?? null ) !== true || ! current_user_can( 'ade_review_candidates' ) ) { throw new InvalidArgumentException( 'WORKER_DRY_RUN_REVIEW_REQUIRED' ); }
            if ( isset( $assoc['demo'] ) && ( $assoc['demo'] !== true || isset( $assoc['archive-file'] ) ) ) { throw new InvalidArgumentException( 'M2_INPUT_AMBIGUOUS' ); }
            $raw = isset( $assoc['demo'] ) ? ADE_Local_Archive::demo() : $this->local_json( $assoc, 'archive-file', ADE_Local_Archive::MAX_BYTES );
            $checkpoint = isset( $assoc['checkpoint-file'] ) ? $this->local_json( $assoc, 'checkpoint-file', 524288 ) : null;
            $retry = isset( $assoc['retry-npsn'] ) ? $this->m2_string( $assoc, 'retry-npsn' ) : null;
            $resolve = static function( string $code ): array { return ADE_Identity::lookup_pilot( $code ); };
            $this->output( ADE_Local_Worker::run( $raw, $checkpoint, $this->number( $assoc, 'batch-size', 10 ), time(), $resolve, null, $retry ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Reparse one school's archive and show source bindings/current values/draft.
     *
     * ## OPTIONS
     * --npsn=<code>
     * : One identifier from the frozen pilot selection.
     * [--demo]
     * : Synthetic archive only, instead of archive-file.
     * [--archive-file=<path>]
     * : Local JSON archive at most4MiB.
     * [--bindings-file=<path>]
     * : Local JSON map document_key to registered website URL, at most16KiB.
     * [--dry-run]
     * : Required true; no store, approval, fetch or publication.
     */
    public function inspect( $args, $assoc ): void {
        try {
            ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
            if ( ( $assoc['dry-run'] ?? null ) !== true || ! current_user_can( 'ade_review_candidates' ) ) { throw new InvalidArgumentException( 'ARCHIVE_REVIEW_DRY_RUN_REQUIRED' ); }
            if ( isset( $assoc['demo'] ) && ( $assoc['demo'] !== true || isset( $assoc['archive-file'] ) ) ) { throw new InvalidArgumentException( 'M2_INPUT_AMBIGUOUS' ); }
            $raw = isset( $assoc['demo'] ) ? ADE_Local_Archive::demo() : $this->local_json( $assoc, 'archive-file', ADE_Local_Archive::MAX_BYTES );
            $bindings = isset( $assoc['bindings-file'] ) ? ADE_Strict_JSON::decode( $this->local_json( $assoc, 'bindings-file', 16384 ), 16384 ) : array();
            $this->output( ADE_Archive_Review::plan( $raw, $this->m2_string( $assoc, 'npsn' ), $bindings ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    private function vault_input( array $assoc ): array {
        ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
        if ( isset( $assoc['demo'] ) || ! current_user_can( 'ade_review_candidates' ) ) { throw new RuntimeException( 'VAULT_REAL_INPUT_REQUIRED' ); }
        $raw = $this->local_json( $assoc, 'archive-file', ADE_Local_Archive::MAX_BYTES );
        $bindings = ADE_Strict_JSON::decode( $this->local_json( $assoc, 'bindings-file', 16384 ), 16384 );
        return array( $raw, $this->m2_string( $assoc, 'npsn' ), $bindings );
    }

    /**
     * Preview one raw archive insert; no database write. Real documents only.
     *
     * ## OPTIONS
     * --archive-file=<path>
     * : Local operator archive JSON, not a demo/report/checkpoint.
     * --bindings-file=<path>
     * : Document-key to registered website URL JSON map.
     * --npsn=<code>
     * : Selected school.
     * [--dry-run]
     * : Required true.
     */
    public function vault_stage( $args, $assoc ): void {
        try {
            if ( ( $assoc['dry-run'] ?? null ) !== true ) { throw new RuntimeException( 'VAULT_STAGE_REQUIRES_DRY_RUN' ); }
            $input = $this->vault_input( $assoc ); $this->output( ADE_Archive_Vault::stage( $input[0], $input[1], $input[2] ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Opt-in raw-pending archive only. Disabled by default; operator DB consent required.
     *
     * ## OPTIONS
     * --archive-file=<path>
     * : Real local operator archive.
     * --bindings-file=<path>
     * : Registered source binding map.
     * --npsn=<code>
     * : Selected school.
     * --preview-token=<hash>
     * : Fresh vault_stage token.
     * --backup-confirmed=<YES>
     * : Operator confirms backup.
     * --privacy-reviewed=<YES>
     * : Operator confirms raw content cleared of private/student data and secrets.
     * --confirm=<STORE_RAW_PENDING>
     * : Explicit raw-only storage approval; not evidence/approval/publication.
     */
    public function vault_store( $args, $assoc ): void {
        try {
            if ( ! ADE_Archive_Vault::enabled() ) { throw new RuntimeException( 'VAULT_STORAGE_DISABLED' ); }
            $confirm = $this->require_write( $assoc, 'STORE_RAW_PENDING' ); $input = $this->vault_input( $assoc );
            $this->output( ADE_Archive_Vault::record( $input[0], $input[1], $input[2], $this->m2_string( $assoc, 'preview-token' ), $confirm, $this->m2_string( $assoc, 'backup-confirmed' ), $this->m2_string( $assoc, 'privacy-reviewed' ) ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Read historical raw archive metadata/hash only, never return raw HTML/content.
     *
     * ## OPTIONS
     * --receipt-id=<id>
     * : Existing raw archive receipt.
     */
    public function vault_receipt( $args, $assoc ): void {
        try { $this->output( ADE_Archive_Vault::receipt( $this->number( $assoc, 'receipt-id', 0 ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Plan pending evidence/candidates from an existing raw receipt; read only.
     *
     * ## OPTIONS
     * --raw-receipt-id=<id>
     * : Completed raw archive receipt, not a report/checkpoint/file.
     * --npsn=<code>
     * : Matching frozen school.
     * [--dry-run]
     * : Required true.
     */
    public function archive_stage( $args, $assoc ): void {
        try {
            if ( ( $assoc['dry-run'] ?? null ) !== true ) { throw new RuntimeException( 'AC_STAGE_REQUIRES_DRY_RUN' ); }
            $this->output( ADE_Archive_Candidates::stage( $this->number( $assoc, 'raw-receipt-id', 0 ), $this->m2_string( $assoc, 'npsn' ) ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Explicit opt-in pending-only archive evidence/candidates. Default OFF.
     *
     * ## OPTIONS
     * --raw-receipt-id=<id>
     * : Existing local raw receipt.
     * --npsn=<code>
     * : Matching school.
     * --preview-token=<hash>
     * : Fresh archive_stage token.
     * --backup-confirmed=<YES>
     * : Operator confirms backup.
     * --confirm=<STORE_ARCHIVE_CANDIDATES>
     * : Explicit database approval, never approval/publication of claims.
     */
    public function archive_store( $args, $assoc ): void {
        try {
            if ( ! ADE_Archive_Candidates::enabled() ) { throw new RuntimeException( 'AC_STORAGE_DISABLED' ); }
            $confirm = $this->require_write( $assoc, 'STORE_ARCHIVE_CANDIDATES' );
            $this->output( ADE_Archive_Candidates::record( $this->number( $assoc, 'raw-receipt-id', 0 ), $this->m2_string( $assoc, 'npsn' ), $this->m2_string( $assoc, 'preview-token' ), $confirm, $this->m2_string( $assoc, 'backup-confirmed' ) ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Read historical archive candidate operation metadata; not approval.
     *
     * ## OPTIONS
     * --receipt-id=<id>
     * : Existing archive candidate operation receipt.
     */
    public function archive_receipt( $args, $assoc ): void {
        try { $this->output( ADE_Archive_Candidates::receipt( $this->number( $assoc, 'receipt-id', 0 ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Recheck one stored archive evidence against raw bytes and current candidate.
     *
     * ## OPTIONS
     * --npsn=<code>
     * : School from the frozen selection.
     * --candidate-id=<id>
     * : Stored candidate for that school.
     * --evidence-id=<id>
     * : Linked archive evidence to check.
     * [--dry-run]
     * : Required true; no write, approval or publication.
     */
    public function archive_verify( $args, $assoc ): void {
        try {
            ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
            if ( ( $assoc['dry-run'] ?? null ) !== true ) { throw new RuntimeException( 'RAW_VERIFY_DRY_RUN_REQUIRED' ); }
            $this->output( ADE_Archive_Verifier::verify( $this->m2_string( $assoc, 'npsn' ), $this->number( $assoc, 'candidate-id', 0 ), $this->number( $assoc, 'evidence-id', 0 ) ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Preview one approved local claim and its visible citation, no writes.
     *
     * ## OPTIONS
     * --npsn=<code>
     * --candidate-id=<id>
     * --evidence-id=<id>
     * --attestation-id=<id>
     * [--dry-run]
     * : Required true.
     */
    public function publish_stage( $args, $assoc ): void {
        try { if ( ( $assoc['dry-run'] ?? null ) !== true ) { throw new RuntimeException( 'PUB_DRY_RUN_REQUIRED' ); } $this->output( ADE_Local_Publication::plan( $this->m2_string( $assoc, 'npsn' ), $this->number( $assoc, 'candidate-id', 0 ), $this->number( $assoc, 'evidence-id', 0 ), $this->number( $assoc, 'attestation-id', 0 ) ) ); } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }
    /**
     * Apply one local claim plus source, default OFF and one configured school only.
     *
     * ## OPTIONS
     * --request-file=<path>
     * : Strict JSON npsn,candidate_id,evidence_id,attestation_id,row_version,preview_token,note.
     * --backup-confirmed=<YES>
     * --confirm=<PUBLISH_LOCAL_CLAIM_WITH_SOURCE>
     */
    public function publish_apply( $args, $assoc ): void {
        try { if ( ! ADE_Local_Publication::enabled() ) { throw new RuntimeException( 'PUB_WRITES_DISABLED' ); } $confirm = $this->require_write( $assoc, 'PUBLISH_LOCAL_CLAIM_WITH_SOURCE' ); $r = ADE_Strict_JSON::decode( $this->local_json( $assoc, 'request-file', 8192 ), 8192 ); $this->output( ADE_Local_Publication::apply( $r, $confirm, $this->m2_string( $assoc, 'backup-confirmed' ) ) ); } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }
    /**
     * Preview restoration of one owned publication, reverse order per school.
     *
     * ## OPTIONS
     * --publication-id=<id>
     * [--dry-run]
     * : Required true.
     */
    public function publish_undo_stage( $args, $assoc ): void {
        try { if ( ( $assoc['dry-run'] ?? null ) !== true ) { throw new RuntimeException( 'PUB_DRY_RUN_REQUIRED' ); } $this->output( ADE_Local_Publication::undo_plan( $this->number( $assoc, 'publication-id', 0 ) ) ); } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }
    /**
     * Restore exact owned before images, never production; default OFF.
     *
     * ## OPTIONS
     * --publication-id=<id>
     * --preview-token=<hash>
     * --backup-confirmed=<YES>
     * --confirm=<UNDO_ONE_LOCAL_PUBLICATION>
     */
    public function publish_undo( $args, $assoc ): void {
        try { if ( ! ADE_Local_Publication::enabled() ) { throw new RuntimeException( 'PUB_WRITES_DISABLED' ); } $confirm = $this->require_write( $assoc, 'UNDO_ONE_LOCAL_PUBLICATION' ); $this->output( ADE_Local_Publication::undo( $this->number( $assoc, 'publication-id', 0 ), $this->m2_string( $assoc, 'preview-token' ), $confirm, $this->m2_string( $assoc, 'backup-confirmed' ) ) ); } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }
    /**
     * Read historical publication receipt without backup plaintext or authorization.
     *
     * ## OPTIONS
     * --receipt-id=<id>
     * [--undo]
     * : Read an undo receipt instead of apply.
     */
    public function publish_receipt( $args, $assoc ): void {
        try { $this->output( ADE_Local_Publication::receipt( $this->number( $assoc, 'receipt-id', 0 ), ( $assoc['undo'] ?? false ) === true ) ); } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Preview a frozen local raw receipt batch, no raw reads or writes.
     *
     * ## OPTIONS
     * --request-file=<path>
     * [--dry-run]
     * : Required true.
     */
    public function batch_stage( $args, $assoc ): void {
        try { if ( ( $assoc['dry-run'] ?? null ) !== true ) { throw new RuntimeException( 'AB_DRY_RUN_REQUIRED' ); } $this->output( ADE_Archive_Batch::stage( $this->local_json( $assoc, 'request-file', 32768 ) ) ); } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }
    /**
     * Enqueue explicitly selected local archives; never fetch or approve.
     *
     * ## OPTIONS
     * --request-file=<path>
     * --preview-token=<hash>
     * --backup-confirmed=<YES>
     * --confirm=<ENQUEUE_ARCHIVE_BATCH>
     */
    public function batch_enqueue( $args, $assoc ): void {
        try { if ( ! ADE_Archive_Batch::enabled() ) { throw new RuntimeException( 'AB_WRITES_DISABLED' ); } $confirm = $this->require_write( $assoc, 'ENQUEUE_ARCHIVE_BATCH' ); $this->output( ADE_Archive_Batch::enqueue( $this->local_json( $assoc, 'request-file', 32768 ), $this->m2_string( $assoc, 'preview-token' ), $confirm, $this->m2_string( $assoc, 'backup-confirmed' ) ) ); } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }
    /**
     * Process at most three local archives, same-transaction checkpoint.
     *
     * ## OPTIONS
     * --job-id=<id>
     * --backup-confirmed=<YES>
     * --confirm=<RUN_ARCHIVE_BATCH>
     */
    public function batch_run( $args, $assoc ): void {
        try { if ( ! ADE_Archive_Batch::enabled() ) { throw new RuntimeException( 'AB_WRITES_DISABLED' ); } $confirm = $this->require_write( $assoc, 'RUN_ARCHIVE_BATCH' ); $this->output( ADE_Archive_Batch::run( $this->number( $assoc, 'job-id', 0 ), $confirm, $this->m2_string( $assoc, 'backup-confirmed' ) ) ); } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }
    /**
     * Read local archive batch status, omitting lease secrets/raw/manifest.
     *
     * ## OPTIONS
     * --job-id=<id>
     */
    public function batch_status( $args, $assoc ): void {
        try { $this->output( ADE_Archive_Batch::status( $this->number( $assoc, 'job-id', 0 ) ) ); } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }
    /**
     * Recover expired lease, retry failed batch, or cancel remaining entries.
     *
     * ## OPTIONS
     * --job-id=<id>
     * --operation=<recover|retry|cancel>
     * --backup-confirmed=<YES>
     * --confirm=<action>
     * : RECOVER_ARCHIVE_BATCH, RETRY_ARCHIVE_BATCH or CANCEL_ARCHIVE_BATCH.
     */
    public function batch_control( $args, $assoc ): void {
        try { if ( ! ADE_Archive_Batch::enabled() ) { throw new RuntimeException( 'AB_WRITES_DISABLED' ); } $op = $this->m2_string( $assoc, 'operation' ); if ( ! in_array( $op, array( 'recover', 'retry', 'cancel' ), true ) ) { throw new InvalidArgumentException( 'AB_CONTROL_INVALID' ); } $confirm = $this->require_write( $assoc, strtoupper( $op ) . '_ARCHIVE_BATCH' ); $this->output( ADE_Archive_Batch::control( $this->number( $assoc, 'job-id', 0 ), $op, $confirm, $this->m2_string( $assoc, 'backup-confirmed' ) ) ); } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Preview approval of one raw-backed candidate with a current operator declaration.
     *
     * ## OPTIONS
     * --npsn=<code>
     * --candidate-id=<id>
     * --evidence-id=<id>
     * --attestation-id=<id>
     * [--dry-run]
     * : Required true; no approval written.
     */
    public function approve_stage( $args, $assoc ): void {
        try { if ( ( $assoc['dry-run'] ?? null ) !== true ) { throw new RuntimeException( 'APPROVE_STAGE_REQUIRES_DRY_RUN' ); } ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' ); $this->output( ADE_Positive_Review::plan( $this->m2_string( $assoc, 'npsn' ), $this->number( $assoc, 'candidate-id', 0 ), $this->number( $assoc, 'evidence-id', 0 ), $this->number( $assoc, 'attestation-id', 0 ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Approve one unchanged claim; local-only, default OFF, never publish.
     *
     * ## OPTIONS
     * --request-file=<path>
     * : Strict JSON with npsn, candidate_id, evidence_id, attestation_id, row_version, note, preview_token.
     * --backup-confirmed=<YES>
     * --confirm=<APPROVE_ONE_CLAIM>
     */
    public function approve_record( $args, $assoc ): void {
        try {
            if ( ! ADE_Positive_Review::enabled() ) { throw new RuntimeException( 'APPROVE_WRITES_DISABLED' ); }
            $confirm = $this->require_write( $assoc, 'APPROVE_ONE_CLAIM' ); ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
            $r = ADE_Strict_JSON::decode( $this->local_json( $assoc, 'request-file', 8192 ), 8192 );
            ADE_Local_Archive::keys( $r, array( 'npsn', 'candidate_id', 'evidence_id', 'attestation_id', 'row_version', 'note', 'preview_token' ) );
            foreach ( array( 'candidate_id', 'row_version', 'attestation_id' ) as $key ) { if ( ! is_int( $r[$key] ) || $r[$key] < 1 ) { throw new InvalidArgumentException( 'APPROVE_REQUEST_INVALID' ); } }
            // CLI guard already enforces an explicit local operator; web callers must supply their own nonce.
            $r['nonce'] = wp_create_nonce( ADE_Positive_Review::nonce_action( $r['candidate_id'], $r['row_version'], $r['attestation_id'] ) );
            $r['confirm'] = $confirm; $r['backup_confirmed'] = $this->m2_string( $assoc, 'backup-confirmed' ); $this->output( ADE_Positive_Review::record( $r ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Preview an operator source declaration; no data write.
     *
     * ## OPTIONS
     * --request-file=<path>
     * : Local strict JSON declaration, max16KiB.
     * [--dry-run]
     * : Required true.
     */
    public function attest_stage( $args, $assoc ): void {
        try { if ( ( $assoc['dry-run'] ?? null ) !== true ) { throw new RuntimeException( 'ATTEST_STAGE_REQUIRES_DRY_RUN' ); } ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' ); $this->output( ADE_Source_Attestation::plan( $this->local_json( $assoc, 'request-file', 16384 ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Record one operator declaration. Default OFF, not candidate approval.
     *
     * ## OPTIONS
     * --request-file=<path>
     * : Strict local declaration JSON.
     * --preview-token=<hash>
     * : Fresh attest_stage token.
     * --backup-confirmed=<YES>
     * : Operator backup acknowledgment.
     * --confirm=<RECORD_SOURCE_ATTESTATION>
     * : Explicit declaration database write consent.
     */
    public function attest_record( $args, $assoc ): void {
        try { if ( ! ADE_Source_Attestation::enabled() ) { throw new RuntimeException( 'ATTEST_WRITES_DISABLED' ); } $confirm = $this->require_write( $assoc, 'RECORD_SOURCE_ATTESTATION' ); ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' ); $this->output( ADE_Source_Attestation::record( $this->local_json( $assoc, 'request-file', 16384 ), $this->m2_string( $assoc, 'preview-token' ), $confirm, $this->m2_string( $assoc, 'backup-confirmed' ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Check whether one operator statement is current; no independent verification.
     *
     * ## OPTIONS
     * --attestation-id=<id>
     * : Stored grant ID.
     */
    public function attest_status( $args, $assoc ): void {
        try { ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' ); $this->output( ADE_Source_Attestation::current( $this->number( $assoc, 'attestation-id', 0 ) ) ); } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Preview withdrawal of one operator declaration.
     *
     * ## OPTIONS
     * --attestation-id=<id>
     * : Grant to revoke.
     * --reason=<code>
     * : WITHDRAWN_PERMISSION, IDENTITY_DOUBT or OPERATOR_CORRECTION.
     * --note=<text>
     * : Operator explanation,10to500bytes.
     * [--dry-run]
     * : Required true.
     */
    public function attest_revoke_stage( $args, $assoc ): void {
        try { if ( ( $assoc['dry-run'] ?? null ) !== true ) { throw new RuntimeException( 'ATTEST_STAGE_REQUIRES_DRY_RUN' ); } ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' ); $this->output( ADE_Source_Attestation::revoke_plan( $this->number( $assoc, 'attestation-id', 0 ), $this->m2_string( $assoc, 'reason' ), $this->m2_string( $assoc, 'note' ) ) ); } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Append a withdrawal event. Default OFF; no raw/source/candidate update.
     *
     * ## OPTIONS
     * --attestation-id=<id>
     * : Grant ID.
     * --reason=<code>
     * : Recognized withdrawal reason.
     * --note=<text>
     * : Operator explanation.
     * --preview-token=<hash>
     * : Fresh attest_revoke_stage token.
     * --backup-confirmed=<YES>
     * : Backup acknowledgment.
     * --confirm=<REVOKE_SOURCE_ATTESTATION>
     * : Explicit withdrawal write consent.
     */
    public function attest_revoke( $args, $assoc ): void {
        try { if ( ! ADE_Source_Attestation::enabled() ) { throw new RuntimeException( 'ATTEST_WRITES_DISABLED' ); } $confirm = $this->require_write( $assoc, 'REVOKE_SOURCE_ATTESTATION' ); ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' ); $this->output( ADE_Source_Attestation::revoke( $this->number( $assoc, 'attestation-id', 0 ), $this->m2_string( $assoc, 'reason' ), $this->m2_string( $assoc, 'note' ), $this->m2_string( $assoc, 'preview-token' ), $confirm, $this->m2_string( $assoc, 'backup-confirmed' ) ) ); } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    private function m2_file( array $assoc ): string {
        ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
        if ( ! current_user_can( 'ade_review_candidates' ) || isset( $assoc['demo'] ) ) { throw new RuntimeException( 'M2_REAL_DOCUMENT_AND_REVIEW_CAP_REQUIRED' ); }
        $path = isset( $assoc['evidence-file'] ) && is_string( $assoc['evidence-file'] ) ? realpath( $assoc['evidence-file'] ) : false;
        if ( false === $path || ! is_file( $path ) || ! is_readable( $path ) || substr( $path, -5 ) !== '.json' || filesize( $path ) > ADE_Enrichment_Preview::MAX_INPUT_BYTES ) {
            throw new InvalidArgumentException( 'M2_LOCAL_JSON_REQUIRED' );
        }
        $raw = file_get_contents( $path, false, null, 0, ADE_Enrichment_Preview::MAX_INPUT_BYTES + 1 );
        if ( false === $raw ) { throw new RuntimeException( 'M2_INPUT_READ_FAILED' ); }
        return $raw;
    }

    private function m2_string( array $assoc, string $key ): string {
        if ( ! isset( $assoc[$key] ) || ! is_string( $assoc[$key] ) || '' === trim( $assoc[$key] ) ) { throw new InvalidArgumentException( 'M2_PARAMETER_REQUIRED_' . strtoupper( $key ) ); }
        return trim( $assoc[$key] );
    }

    /**
     * Stage a real manual document against a pre-existing pending source; SELECT only.
     *
     * ## OPTIONS
     * --evidence-file=<path>
     * : Local real structured evidence document.
     * --source-url=<registered-website-url>
     * : Existing school-associated website URL.
     * [--dry-run]
     * : Required by the handler; WP-CLI boolean flags use optional synopsis syntax.
     */
    public function stage( $args, $assoc ): void {
        try {
            if ( ( $assoc['dry-run'] ?? null ) !== true ) { throw new InvalidArgumentException( 'M2_STAGE_REQUIRES_DRY_RUN' ); }
            $this->output( ADE_Enrichment_Store::stage( $this->m2_file( $assoc ), $this->m2_string( $assoc, 'source-url' ) ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Explicit local pending-only write. Operator DB approval and backup required.
     *
     * ## OPTIONS
     * --evidence-file=<path>
     * --source-url=<registered-website-url>
     * --preview-token=<hash>
     * --backup-confirmed=<YES>
     * --confirm=<STORE_M2_PENDING>
     */
    public function store( $args, $assoc ): void {
        try {
            $confirmation = $this->require_write( $assoc, 'STORE_M2_PENDING' );
            $backup = $this->m2_string( $assoc, 'backup-confirmed' );
            if ( $backup !== 'YES' ) { throw new RuntimeException( 'M2_BACKUP_ACK_REQUIRED' ); }
            $this->output( ADE_Enrichment_Store::record( $this->m2_file( $assoc ), $this->m2_string( $assoc, 'source-url' ), $this->m2_string( $assoc, 'preview-token' ), $confirmation, $backup ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Read a completed M2 operation receipt; historical, not approval/publication.
     *
     * ## OPTIONS
     * --receipt-id=<id>
     */
    public function receipt( $args, $assoc ): void {
        try { $this->output( ADE_Enrichment_Store::receipt( $this->number( $assoc, 'receipt-id', 0 ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Store one frozen planning job for exactly 200 schools (Discovery jobs only).
     *
     * ## OPTIONS
     * [--npsn-file=<path>]
     * --confirm=<ENQUEUE_M1_PLAN>
     */
    public function enqueue( $args, $assoc ): void {
        try {
            $confirmation = $this->require_write( $assoc, 'ENQUEUE_M1_PLAN' );
            ADE_Pilot_Jobs::guard( $confirmation, 'ENQUEUE_M1_PLAN' );
            $this->output( ADE_Pilot_Jobs::enqueue( $this->input( $assoc ), $confirmation ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Run one source-planning batch, maximum ten schools, no fetch.
     *
     * ## OPTIONS
     * --job-id=<id>
     * --confirm=<RUN_M1_PLAN>
     */
    public function run_one_batch( $args, $assoc ): void {
        try {
            $confirmation = $this->require_write( $assoc, 'RUN_M1_PLAN' );
            $id = $this->number( $assoc, 'job-id', 0 );
            $job = ADE_Pilot_Jobs::status( $id );
            $manifest = json_decode( $job['scope_filter'], true, 16, JSON_THROW_ON_ERROR );
            if ( ( $manifest['version'] ?? null ) !== 2 ) { throw new RuntimeException( 'LEGACY_UNSCOPED_JOB_REQUIRES_SEPARATE_REVIEW' ); }
            ADE_Pilot::validate_manifest( $manifest );
            $this->output( ADE_Pilot_Jobs::step( $id, $confirmation ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Read-only job status and committed results; omits lease token and manifest.
     *
     * ## OPTIONS
     * --job-id=<id>
     */
    public function status( $args, $assoc ): void {
        try {
            $row = ADE_Pilot_Jobs::status( $this->number( $assoc, 'job-id', 0 ) );
            $manifest = json_decode( $row['scope_filter'], true, 16, JSON_THROW_ON_ERROR );
            $row['selection_scope'] = $manifest['scope'] ?? 'legacy-v1-unscoped';
            unset( $row['lease_token'], $row['scope_filter'] );
            $this->output( $row );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Recover expired M1 planning leases only.
     *
     * ## OPTIONS
     * --confirm=<RECOVER_M1_PLAN>
     */
    public function recover( $args, $assoc ): void {
        try { $this->output( array( 'recovered' => ADE_Pilot_Jobs::recover( $this->require_write( $assoc, 'RECOVER_M1_PLAN' ) ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Cancel a non-running M1 planning job; never deletes it.
     *
     * ## OPTIONS
     * --job-id=<id>
     * --confirm=<CANCEL_M1_PLAN>
     */
    public function cancel( $args, $assoc ): void {
        try { $this->output( array( 'cancelled' => ADE_Pilot_Jobs::cancel( $this->number( $assoc, 'job-id', 0 ), $this->require_write( $assoc, 'CANCEL_M1_PLAN' ) ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }
    /**
     * Read-only manifest, cursor, and committed outcome consistency check.
     *
     * ## OPTIONS
     * --job-id=<id>
     */
    public function integrity_check( $args, $assoc ): void {
        try { $this->output( ADE_Pilot_Jobs::integrity( $this->number( $assoc, 'job-id', 0 ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Retry a failed planning job without clearing committed results.
     *
     * ## OPTIONS
     * --job-id=<id>
     * --confirm=<RETRY_M1_PLAN>
     */
    public function retry_failed( $args, $assoc ): void {
        try { $this->output( array( 'retried' => ADE_Pilot_Jobs::retry_failed( $this->number( $assoc, 'job-id', 0 ), $this->require_write( $assoc, 'RETRY_M1_PLAN' ) ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

}
