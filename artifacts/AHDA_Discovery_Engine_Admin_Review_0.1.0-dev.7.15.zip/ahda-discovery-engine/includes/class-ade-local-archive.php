<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
require_once __DIR__ . '/class-ade-strict-json.php';

/** Portable operator-supplied bundle, not a trusted origin/permission archive. */
final class ADE_Local_Archive {
    public const MAX_BYTES = 4194304;
    public static function digest( array $value ): string { return hash( 'sha256', json_encode( $value, JSON_THROW_ON_ERROR ) ); }
    public static function keys( array $data, array $keys ): void {
        if ( array_diff( array_keys( $data ), $keys ) || array_diff( $keys, array_keys( $data ) ) ) { throw new InvalidArgumentException( 'ARCHIVE_KEYS_INVALID' ); }
    }
    public static function document( string $content, string $format, string $url, string $checked, string $reference ): array {
        if ( ! in_array( $format, array( 'csv', 'html', 'json' ), true ) || strlen( $content ) < 1 || strlen( $content ) > ( $format === 'html' ? 262144 : 65536 ) || ! preg_match( '//u', $content ) ) { throw new InvalidArgumentException( 'ARCHIVE_DOCUMENT_INVALID' ); }
        $canonical = ADE_Evidence_URLs::canonicalize( $url );
        if ( $url !== $canonical || parse_url( $url, PHP_URL_SCHEME ) !== 'https' ) { throw new InvalidArgumentException( 'ARCHIVE_CANONICAL_HTTPS_REQUIRED' ); }
        foreach ( explode( '&', (string) parse_url( $url, PHP_URL_QUERY ) ) as $pair ) {
            $key = rawurldecode( explode( '=', $pair, 2 )[0] );
            if ( strtolower( $key ) === 'key' || preg_match( '/token|secret|password|authorization|credential|signature|nonce|api[_-]?key/i', $key ) ) { throw new InvalidArgumentException( 'ARCHIVE_SENSITIVE_URL' ); }
        }
        $date = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i:s\Z', $checked, new DateTimeZone( 'UTC' ) );
        if ( ! $date || $date->format( 'Y-m-d\TH:i:s\Z' ) !== $checked || ! preg_match( '/^[a-zA-Z0-9_-]{3,80}$/D', $reference ) ) { throw new InvalidArgumentException( 'ARCHIVE_METADATA_INVALID' ); }
        $entry = array( 'format' => $format, 'raw_sha256' => hash( 'sha256', $content ), 'source_url' => $url, 'checked_at' => $checked, 'permission_reference' => $reference, 'content' => $content );
        $key = self::digest( array( 'ade-local-document-v1', $format, $entry['raw_sha256'], $url, $checked, $reference ) );
        return array( 'key' => $key, 'entry' => $entry );
    }
    public static function freeze( string $raw ): array {
        $data = ADE_Strict_JSON::decode( $raw, self::MAX_BYTES );
        self::keys( $data, array( 'schema_version', 'scope_hash', 'fixture_only', 'documents', 'schools' ) );
        if ( $data['schema_version'] !== 1 || $data['scope_hash'] !== ADE_Pilot_Scope::SHA256 || ! is_bool( $data['fixture_only'] ) || ! is_array( $data['documents'] ) || count( $data['documents'] ) > 200 || ! is_array( $data['schools'] ) || count( $data['schools'] ) !== 200 || array_keys( $data['schools'] ) !== range( 0, 199 ) ) { throw new InvalidArgumentException( 'ARCHIVE_SCOPE_INVALID' ); }
        $documents = array();
        foreach ( $data['documents'] as $key => $entry ) {
            if ( ! is_string( $key ) || ! preg_match( '/^[a-f0-9]{64}$/D', $key ) || ! is_array( $entry ) ) { throw new InvalidArgumentException( 'ARCHIVE_DOCUMENT_INVALID' ); }
            self::keys( $entry, array( 'format', 'raw_sha256', 'source_url', 'checked_at', 'permission_reference', 'content' ) );
            foreach ( $entry as $value ) { if ( ! is_string( $value ) ) { throw new InvalidArgumentException( 'ARCHIVE_DOCUMENT_INVALID' ); } }
            $verified = self::document( $entry['content'], $entry['format'], $entry['source_url'], $entry['checked_at'], $entry['permission_reference'] );
            if ( ! hash_equals( $verified['key'], $key ) || ! hash_equals( $verified['entry']['raw_sha256'], $entry['raw_sha256'] ) ) { throw new InvalidArgumentException( 'ARCHIVE_DOCUMENT_HASH_MISMATCH' ); }
            $documents[$key] = $verified['entry'];
        }
        $schools = array(); $owners = array();
        foreach ( $data['schools'] as $school ) {
            if ( ! is_array( $school ) ) { throw new InvalidArgumentException( 'ARCHIVE_SCHOOL_INVALID' ); }
            self::keys( $school, array( 'npsn', 'document_keys' ) );
            if ( ! is_string( $school['npsn'] ) || ! ADE_Pilot_Scope::contains( $school['npsn'] ) || isset( $schools[$school['npsn']] ) || ! is_array( $school['document_keys'] ) || count( $school['document_keys'] ) > 3 || array_values( $school['document_keys'] ) !== $school['document_keys'] ) { throw new InvalidArgumentException( 'ARCHIVE_SCHOOL_INVALID' ); }
            $seen = array();
            foreach ( $school['document_keys'] as $key ) {
                if ( ! is_string( $key ) || ! isset( $documents[$key] ) || isset( $seen[$key] ) || ( isset( $owners[$key] ) && $owners[$key] !== $school['npsn'] ) ) { throw new InvalidArgumentException( 'ARCHIVE_DOCUMENT_BINDING_INVALID' ); }
                $seen[$key] = true; $owners[$key] = $school['npsn'];
            }
            sort( $school['document_keys'], SORT_STRING ); $schools[$school['npsn']] = $school;
        }
        if ( count( $owners ) !== count( $documents ) ) { throw new InvalidArgumentException( 'ARCHIVE_UNREFERENCED_DOCUMENT' ); }
        ksort( $documents, SORT_STRING ); ksort( $schools, SORT_STRING );
        $canonical = array( 'schema_version' => 1, 'scope_hash' => ADE_Pilot_Scope::SHA256, 'fixture_only' => $data['fixture_only'], 'documents' => $documents, 'schools' => array_values( $schools ) );
        return array( 'manifest_sha256' => self::digest( $canonical ), 'input_sha256' => hash( 'sha256', $raw ), 'bundle' => $canonical );
    }
    public static function demo(): string {
        $codes = array_map( 'strval', array_keys( ADE_Pilot_Scope::reference() ) ); sort( $codes, SORT_STRING );
        $schools = array(); foreach ( $codes as $npsn ) { $schools[$npsn] = array( 'npsn' => $npsn, 'document_keys' => array() ); }
        $csv = file_get_contents( dirname( __DIR__ ) . '/data/examples/m2-profile-fixture.csv' );
        $html = file_get_contents( dirname( __DIR__ ) . '/data/examples/m2-profile-fixture.html' );
        $documents = array();
        foreach ( array( array(0,'csv',$csv), array(0,'html',$html), array(1,'csv',$csv), array(1,'html',str_replace('PROGRAM CONTOH UJI','PROGRAM KONFLIK UJI',$html)), array(2,'csv',str_replace('20268071','00000000',$csv)) ) as $spec ) {
            list( $index, $format, $content ) = $spec; $content = str_replace( '20268071', $codes[$index], $content );
            $doc = self::document( $content, $format, 'https://example.org/synthetic-only', '2020-01-01T00:00:00Z', 'fixture-only-not-a-permission' );
            $documents[$doc['key']] = $doc['entry']; $schools[$codes[$index]]['document_keys'][] = $doc['key'];
        }
        return json_encode( array( 'schema_version' => 1, 'scope_hash' => ADE_Pilot_Scope::SHA256, 'fixture_only' => true, 'documents' => $documents, 'schools' => array_values( $schools ) ), JSON_THROW_ON_ERROR );
    }
}
