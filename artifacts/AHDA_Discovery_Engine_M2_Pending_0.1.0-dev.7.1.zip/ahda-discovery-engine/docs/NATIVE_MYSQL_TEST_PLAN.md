# Rencana pengujian MySQL native — menunggu persetujuan

Tujuan: menguji SQL, transaksi dan lock M2 dengan engine MySQL8.4 sungguhan,
terpisah dari LocalWP dan seluruh data pengguna. Pengujian belum dijalankan.

- Managed Docker lokal telah diperiksa melalui unix:///var/run/docker.sock;
  daemon berjalan. Tidak memakai endpoint/context Docker eksternal.
- Image official mysql:8.4 belum tersedia lokal; akan diunduh dengan verifikasi
  TLS/digest normal setelah persetujuan. Tidak menonaktifkan verifikasi.
- Container baru khusus pengujian, nama unik, maksimum1CPU/1GiB, temporary storage,
  port hanya loopback dengan nomor ephemeral; tidak memakai volume yang sudah ada.
- Database hanya `ahda_m2_disposable`, prefix khusus uji, tabel Discovery dari
  definisi actual plugin dan metadata/identitas legacy sintetis yang diperlukan.
- Tidak memakai wp-config.php, user credential, database LocalWP, VPS, backup
  atau data555460 sekolah. Tidak mengunduh sumber sekolah atau melakukan publish.
- Password uji acak/ephemeral lewat process environment, tidak dicetak, disimpan
  pada instruksi/repo/log atau dikirim ke situs luar.
- Adapter wpdb/WordPress context untuk pengujian tetap stub; hasil akan disebut
  native MySQL integration under WP stubs, bukan PASS LocalWP/WordPress penuh.
- Kasus: pending inserts, replay idempotent, inject failure rollback, stale plan,
  review/version conflict, lock contention/NOWAIT, receipt hash and commit outcome.
- Simpan exit status/log aman, hapus hanya container/storage khusus yang dibuat
  pengujian ini. Jangan restart daemon atau menyentuh container lain.

Persetujuan operator diminta melalui pertanyaan async. Tanpa jawaban afirmatif,
tidak ada server/database uji yang dibuat atau ditulis. Pilihan tetap fake DB
berarti native SQL tests berstatus NOT TESTED; tidak mengubah batas keselamatan.
