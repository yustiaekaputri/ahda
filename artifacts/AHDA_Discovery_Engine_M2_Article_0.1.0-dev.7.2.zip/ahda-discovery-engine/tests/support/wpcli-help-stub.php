<?php
namespace WP_CLI\Utils;
/** Test-only help-template renderer; argument parsing/dispatch classes are upstream. */
function mustache_render($template,$binding){return '';}
