# M2 editorial article preview — dev.7.2

`wp --user="admin" ade pilot article --demo --dry-run`

Read-only LocalWP command using the same document schema as extract. To use an
operator-supplied structured JSON file, replace --demo with --evidence-file=<path>.
Demo and file are mutually exclusive. --dry-run must be explicit boolean true.
Only local files<=64KiB; no network. Do not call this on production.

Returns mode EDITORIAL_DRAFT_READ_ONLY, label, draft title/introduction, sections,
citations, escaped article_html, information_gaps, coverage and metadata draft.
Example has3sections/3citations/9unassessed topics. Every section references its
candidate and supporting evidence keys. Baseline identity is read via unique NPSN
index, checked against frozen200scope. Legacy name is not changed. Conflicting
NPSN/classification, unsupported targets, nonliteral claims, unsafe URLs,
malformed/oversized JSON, unsafe name or hidden bidirectional text are rejected.
All text/URL attributes HTML-escaped. No untrusted Markdown is converted to links.

Output is unverified even for nonfixture input. Literal containment does not
establish source authority, permission or factual correctness. Demo data is
prominently watermarked inside HTML; stale/fixture/review blocking reasons remain.
No database persistence, publication, approval or SEO hooks. Full legacy profile
not read/assessed; missing topics do not prove absent information. The article is
an editorial aid and has no write target; it cannot be passed to store/publisher
as an approved profile_description. Store still accepts only three allowed meta
fields. The HTML should never be copied to the public site before factual review.

Metadata title/description suggestions remain unapplied. No JSON-LD/canonical
emission; Directory already owns these. No fabricated dateModified, awards,
ratings, keywords or FAQs. No claim of Google ranking or AI recommendation.
See CONTENT_QUALITY.md for editorial requirements and missing adapters.

Tests include pure/fake DB article cases, official WP-CLI dispatcher invocation
and a native indexed identity read under WP stubs. User LocalWP article command
and frontend display remain NOT TESTED. Native MySQL pending writer separately
passed70checks under stubs, not full WordPress. See NATIVE_MYSQL.md.

Rollback: replace Discovery files with dev7.1.1; no DB migration needed. Preserve
all tables and existing data. No automatic frontend/plugin lifecycle action was
added. New method is registered by existing pilot command group.
