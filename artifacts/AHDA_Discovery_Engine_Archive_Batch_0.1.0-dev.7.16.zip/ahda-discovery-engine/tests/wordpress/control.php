<?php
if(PHP_SAPI!=='cli'||getenv('AHDA_WP_E2E_ONLY')!=='SYNTHETIC_ISOLATED'){exit(2);}
$command=$argv[1]??'';
if($command==='install'){define('WP_INSTALLING',true);}
define('WP_CLI',true); // Actual PHP CLI installer API; not a WP-CLI dispatcher test.
require __DIR__.'/bootstrap.php';
function check_result($ok,$message){if(!$ok){throw new RuntimeException($message);}}
function ahda_hash($table){global $wpdb;$rows=$wpdb->get_results("SELECT * FROM {$table} ORDER BY id",ARRAY_A);check_result(is_array($rows)&&!$wpdb->last_error,'Synthetic table snapshot failed');return hash('sha256',json_encode($rows,JSON_THROW_ON_ERROR));}
function inspect_state(){global $wpdb;$p=$wpdb->prefix;$out=['wordpress'=>get_bloginfo('version'),'companion'=>defined('ADE_VERSION')?ADE_VERSION:null,'preflight'=>class_exists('ADE_Jobs')?ADE_Jobs::preflight()['ready']:false,'negative_enabled'=>class_exists('ADE_Review_Decisions')?ADE_Review_Decisions::enabled():false];
 $out['candidates']=$wpdb->get_results("SELECT id,school_id,target_key,proposed_value,review_status,publish_status,row_version,approved_value FROM {$p}ahda_discovery_candidates ORDER BY id",ARRAY_A);
 $out['audit_count']=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$p}ahda_discovery_reviews");
 $out['receipt_count']=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$p}ahda_discovery_jobs WHERE job_type=%s",ADE_Review_Decisions::TYPE));
 $out['positive_receipt_count']=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$p}ahda_discovery_jobs WHERE job_type=%s",ADE_Positive_Review::TYPE));
 $out['last_note']=null;$note=$wpdb->get_var("SELECT review_notes FROM {$p}ahda_discovery_reviews ORDER BY id DESC LIMIT 1");if($note){$out['last_note']=json_decode($note,true,8,JSON_THROW_ON_ERROR)['note']??null;}
 $out['hashes']=[];foreach(['schools','school_meta','discovery_sources','discovery_school_sources','discovery_evidence','discovery_candidate_evidence'] as $suffix){$out['hashes'][$suffix]=ahda_hash($p.'ahda_'.$suffix);}
 $out['legacy_hashes']=[];$tables=$wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($p.'ahda_').'%'));
 foreach($tables as $table){if(strpos($table,$p.'ahda_discovery_')===0){continue;}check_result(preg_match('/^[a-zA-Z0-9_]+$/D',$table)===1,'Unsafe synthetic table identifier');$data=$wpdb->get_results("SELECT * FROM {$table}",ARRAY_A);check_result(is_array($data)&&!$wpdb->last_error,'Synthetic legacy snapshot failed');usort($data,fn($a,$b)=>strcmp(json_encode($a),json_encode($b)));$out['legacy_hashes'][$table]=hash('sha256',json_encode($data,JSON_THROW_ON_ERROR));}
 return $out;
}
try{
 if($command==='install'){
  require_once ABSPATH.'wp-admin/includes/upgrade.php';require_once ABSPATH.'wp-admin/includes/plugin.php';
  $result=wp_install('AHDA Synthetic Integration','ahda_e2e_admin','admin@example.org',false,'',getenv('AHDA_WP_E2E_ADMIN_PASSWORD'),'en_US');
  check_result(!is_wp_error($result)&&isset($result['user_id']),'WordPress installation failed');$admin=(int)$result['user_id'];wp_set_current_user($admin);
  update_option('show_avatars',0);update_option('blog_public',0);
  $editor=wp_insert_user(['user_login'=>'ahda_e2e_editor','user_pass'=>getenv('AHDA_WP_E2E_EDITOR_PASSWORD'),'user_email'=>'editor@example.org','role'=>'editor']);check_result(!is_wp_error($editor),'Editor fixture failed');
  foreach(['ahda-school-directory/ahda-school-directory.php','ahda-discovery-engine/ahda-discovery-engine.php'] as $plugin){$activated=activate_plugin($plugin);check_result(!is_wp_error($activated),'Actual plugin activation failed');}
  $schema=ADE_Schema::install();check_result(count($schema['created'])===7,'Actual Discovery installer did not create seven tables');
  global $wpdb;$p=$wpdb->prefix;$now=current_time('mysql',true);
  foreach(['20268071'=>913,'20268073'=>914,'20262702'=>915,'20210807'=>916] as $code=>$id){$ref=ADE_Pilot_Scope::reference()[(string)$code];check_result($wpdb->insert($p.'ahda_schools',['id'=>$id,'npsn'=>(string)$code,'name'=>'DATA SINTETIS SEKOLAH UJI '.$id,'slug'=>'synthetic-'.$id,'school_form'=>$ref['school_form'],'education_level'=>'fixture','ownership_status'=>'NEGERI','regency_raw'=>$ref['regency_raw'],'district_raw'=>'Fixture','village_raw'=>'Fixture','visibility'=>'publish','created_at'=>$now,'updated_at'=>$now])!==false,'Synthetic school insert failed');}
  $url='https://example.org/';$canonical=ADE_Source_URLs::canonicalize($url);
  check_result($wpdb->insert(ADE_Schema::table_name('sources'),['id'=>7,'source_type'=>'website','canonical_url'=>$url,'canonical_key'=>$canonical['canonical_key'],'normalized_host'=>$canonical['normalized_host'],'access_state'=>'manual_only','source_status'=>'discovered','created_at'=>$now,'updated_at'=>$now])!==false,'Synthetic source insert failed');
  check_result($wpdb->insert(ADE_Schema::table_name('school_sources'),['id'=>8,'school_id'=>913,'source_id'=>7,'relationship_type'=>'pending','identity_status'=>'pending','created_at'=>$now,'updated_at'=>$now])!==false,'Synthetic source relation failed');
  // Seed controlled M2-shaped rows using actual wpdb; not a CLI/store API test.
  foreach(['profile_programs'=>'PROGRAM SINTETIS UJI','profile_curriculum'=>'KURIKULUM SINTETIS UJI','profile_hours'=>'JAM SINTETIS UJI'] as $target=>$value){
   $base=hash('sha256',json_encode(['m2-meta-snapshot-v1',913,$target,null],JSON_THROW_ON_ERROR));
   check_result($wpdb->insert(ADE_Schema::table_name('candidates'),['school_id'=>913,'candidate_type'=>'m2_meta_text_v1','target_type'=>'school_meta','target_key'=>$target,'dedupe_key'=>hash('sha256','e2e-candidate-'.$target),'proposed_value'=>$value,'current_value_snapshot'=>null,'base_target_hash'=>$base,'review_status'=>'new','publish_status'=>'not_ready','row_version'=>1,'created_at'=>$now,'updated_at'=>$now])!==false,'Synthetic candidate insert failed');$candidate=(int)$wpdb->insert_id;
   check_result($wpdb->insert(ADE_Schema::table_name('evidence'),['school_id'=>913,'source_id'=>7,'evidence_type'=>'document','attribute_hint'=>$target,'evidence_url'=>'https://example.org/synthetic-only','evidence_key'=>hash('sha256','e2e-evidence-'.$target),'snippet_text'=>$value,'observed_value'=>wp_json_encode(['value'=>$value,'scope_hash'=>ADE_Pilot_Scope::SHA256]),'parse_status'=>'m2_manual_unverified','checked_at'=>$now,'created_at'=>$now])!==false,'Synthetic evidence insert failed');$evidence=(int)$wpdb->insert_id;
   check_result($wpdb->insert(ADE_Schema::table_name('candidate_evidence'),['candidate_id'=>$candidate,'evidence_id'=>$evidence,'relation_type'=>'supports','weight_score'=>0,'created_at'=>$now])!==false,'Synthetic evidence link failed');
  }
  echo json_encode(['status'=>'INSTALLED','wordpress'=>get_bloginfo('version'),'directory'=>AHDA_DIRECTORY_VERSION,'companion'=>ADE_VERSION,'preflight'=>ADE_Jobs::preflight(),'admin_id'=>$admin,'editor_id'=>(int)$editor,'database_adapter'=>get_class($wpdb),'nonce_provider'=>str_replace(ABSPATH,'',(new ReflectionFunction('wp_verify_nonce'))->getFileName())],JSON_THROW_ON_ERROR);
 }elseif($command==='snapshot'){echo json_encode(inspect_state(),JSON_THROW_ON_ERROR);}
 elseif($command==='bump'){$id=(int)($argv[2]??0);check_result($id>0,'Invalid synthetic ID');global $wpdb;check_result($wpdb->query($wpdb->prepare('UPDATE '.ADE_Schema::table_name('candidates').' SET row_version=row_version+1 WHERE id=%d',$id))===1,'Synthetic version bump failed');echo json_encode(['status'=>'BUMPED']);}
 elseif($command==='poison'){
  global $wpdb;$id=(int)($argv[2]??0);check_result($id>0,'Invalid synthetic poison ID');$ct=ADE_Schema::table_name('candidates');$et=ADE_Schema::table_name('evidence');$lt=ADE_Schema::table_name('candidate_evidence');
  $candidate=$wpdb->get_row($wpdb->prepare("SELECT id,proposed_value FROM {$ct} WHERE id=%d",$id),ARRAY_A);$evidence=$wpdb->get_row($wpdb->prepare("SELECT e.id,e.snippet_text,e.observed_value FROM {$et} e JOIN {$lt} l ON l.evidence_id=e.id WHERE l.candidate_id=%d LIMIT 1",$id),ARRAY_A);check_result($candidate&&$evidence,'Synthetic fixture rows required');
  file_put_contents(getenv('AHDA_WP_E2E_STATE').'/xss-original.json',json_encode(['candidate'=>$candidate,'evidence'=>$evidence],JSON_THROW_ON_ERROR));
  $payload='<script>window.__AHDA_XSS=1</script><img src="https://untrusted.example/x" onerror="window.__AHDA_XSS=1">';$observed=json_decode($evidence['observed_value'],true);$observed['value']=$payload;
  check_result($wpdb->update($ct,['proposed_value'=>$payload],['id'=>$id])===1,'Synthetic candidate poison failed');check_result($wpdb->update($et,['snippet_text'=>$payload,'observed_value'=>wp_json_encode($observed)],['id'=>$evidence['id']])===1,'Synthetic quote poison failed');echo json_encode(['status'=>'SYNTHETIC_XSS_FIXTURE']);
 }
 elseif($command==='restore'){
  global $wpdb;$data=json_decode(file_get_contents(getenv('AHDA_WP_E2E_STATE').'/xss-original.json'),true,8,JSON_THROW_ON_ERROR);$c=$data['candidate'];$e=$data['evidence'];check_result($wpdb->update(ADE_Schema::table_name('candidates'),['proposed_value'=>$c['proposed_value']],['id'=>$c['id']])===1,'Synthetic candidate restore failed');check_result($wpdb->update(ADE_Schema::table_name('evidence'),['snippet_text'=>$e['snippet_text'],'observed_value'=>$e['observed_value']],['id'=>$e['id']])===1,'Synthetic evidence restore failed');echo json_encode(['status'=>'RESTORED']);
 }
 elseif($command==='bridge_pipeline'){
  require __DIR__.'/bridge-pipeline.php';
 }
 elseif($command==='positive_fixture'){
  require __DIR__.'/positive-fixture.php';
 }
 elseif($command==='positive_enable'){file_put_contents(getenv('AHDA_WP_E2E_STATE').'/positive-enabled','synthetic-only');echo json_encode(['enabled_next_request'=>true]);}
 elseif($command==='positive_disable'){unlink(getenv('AHDA_WP_E2E_STATE').'/positive-enabled');echo json_encode(['disabled_next_request'=>true]);}
 elseif($command==='positive_withdraw'){
  if(!class_exists('WP_CLI',false)){class WP_CLI{}}
  define('ADE_LOCAL_SOURCE_ATTESTATION_ENABLED',true);$admin=get_user_by('login','ahda_e2e_admin');wp_set_current_user($admin->ID);$id=(int)($argv[2]??0);$note='Synthetic UI withdrawal after preview, no actual rights granted.';$plan=ADE_Source_Attestation::revoke_plan($id,'WITHDRAWN_PERMISSION',$note);echo json_encode(ADE_Source_Attestation::revoke($id,'WITHDRAWN_PERMISSION',$note,$plan['preview_token'],'REVOKE_SOURCE_ATTESTATION','YES'));
 }
 elseif($command==='http_metrics'){$method=strtolower($argv[2]??'');check_result(in_array($method,['','get','post'],true),'Invalid metric method');echo file_get_contents(getenv('AHDA_WP_E2E_STATE').'/http-metrics'.($method?'-'.$method:'').'.json');}
 elseif($command==='disable'){unlink(getenv('AHDA_WP_E2E_STATE').'/negative-enabled');echo json_encode(['disabled_next_request'=>true]);}
 elseif($command==='enable'){file_put_contents(getenv('AHDA_WP_E2E_STATE').'/negative-enabled','synthetic-only');echo json_encode(['enabled_next_request'=>true]);}
 else{throw new RuntimeException('Unknown isolated test command');}
}catch(Throwable $e){fwrite(STDERR,'WORDPRESS_E2E_CONTROL_FAILED: '.$e->getMessage()."\n");exit(1);}
