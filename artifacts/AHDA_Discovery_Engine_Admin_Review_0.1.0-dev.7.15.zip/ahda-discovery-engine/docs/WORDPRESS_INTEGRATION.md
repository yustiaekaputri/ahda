> dev7.11 adds actual WordPress raw/candidate service integration and updated
> admin checks; see WORDPRESS_ARCHIVE_BRIDGE.md. This document retains dev7.6 scope.

# Real WordPress admin integration — dev.7.6

Target: official WordPress7.1.4, Directory0.8.9 and actual Discovery7.6 source,
PHP8.2.32/MySQL8.4.13. Source pin WordPress/WordPress tag7.1.4 commit
`db96f5eaa77a8d3e8eec8923a518fa2326f0d46a` over normal HTTPS Git proxy. Core not
bundled in plugin ZIP. Local source cache remains unchanged. Runtime review code
matches7.5;7.6 adds reproducible integration harness, evidence and version metadata.
Negative review remains OFF in standard package. No operator/site enablement.

## Isolation and bootstrap scope

Operator's existing explicit disposable cloud MySQL permission used only for a
new owned database/container and synthetic WP users/schools.1CPU/1GiB,512MiBtmpfs,
ephemeral loopback-only ports, random credentials in process environment, no live
LocalWP/VPS/user DB/config/secrets. Both actual plugins activated in fresh site;
Directory installs its own fresh empty schema, real R1 installer creates Discovery
seven tables. Two synthetic school identities and three pending M2-shaped fixture
rows seeded by actual wpdb. This is not national import/rebuild or M2 CLI/store
API verification. Legacy tables contain only synthetic/default test setup data.

No wp-config.php is read/generated/modified. A custom test bootstrap defines
configuration from ephemeral environment and calls real wp-settings.php. Only
wp-load.php in the TEMPORARY core copy is a shim to that bootstrap; official cache
unmodified. Real WordPress functions/roles/cookies/nonces/wpdb/admin-post scripts
are used, not stubs. Real wp_verify_nonce reflection points to
wp-includes/pluggable.php; adapter class is wpdb. Full WP-CLI dispatcher install is
not exercised: R1 installer invoked by controlled PHP CLI with WP_CLI context.

Admin siteurl uses owned127.0.0.1 port; WP_HOME alias ahda.local satisfies unchanged
plugin local-host guard without contacting actual user ahda.local. Test-only
rest_url filter maps Core REST to owned loopback; allowed_redirect_hosts permits
127.0.0.1 for this split-URL setup. These are fixture configuration, not production
recommendations or plugin runtime changes. No proxy/DNS/TLS bypass used. Browser
blocks every non-owned origin and PHP pre_http_request blocks all background HTTP;
pre_wp_mail suppresses email before installation. Cron/updaters/file editing off,
search visibility off, avatars off. Actual WordPress REST functions remain real.

## Checks

Real admin login/cookies, anonymous login redirect and admin-post refusal, actual
editor capability denial, default unregistered write handler/no POST forms;
controlled test opt-in, real nonce generation/invalid/action/session binding,
backup confirmation, approve refusal, arbitrary redirect ignored, real safe redirect,
status+audit+receipt persistence, quoted/slashed SQL-looking note roundtrip, HTTP
replay/no duplicate audit, audit view, defer->reject/terminal state, stale version409,
cross-school IDOR refusal, stored proposal/quote XSS nonexecution through actual
WordPress esc functions, desktop/mobile no document overflow, source/evidence/
links/approved/publication preservation, full synthetic legacy row hashes and
switch-OFF unregistering the handler again. No real profile publication.

Final count/result and screenshots: docs/qa/dev7.6/wordpress-browser-result.json,
wordpress-e2e-result.json and wordpress-admin-*.png. Prior attempt reports retained:
first runs deliberately failed external-request assertion because home alias was
used by Core REST; all such requests aborted BEFORE any real connection. Test REST
origin corrected; final runs zero external attempts. Earlier successful33check run
then expanded39checks retained separately. Failure evidence not relabeled PASS.
All own DB/storage/site/server removed in runner finally, official cache retained.

## Limits and next gate

This proves tested admin flows with real WP7.1.4 under owned synthetic bootstrap;
it is NOT a test of the user's LocalWP configuration, Windows/PHP8.2.29/MySQL8.4.0,
third-party plugins, public theme/frontend SEO or real source enrichment. No actual
WordPress nonce expiry clock-window stress/deadlock/load/real TCP commit loss test;
previous native SQL simulations cover different failure paths. M2 CLI real bootstrap
and end-to-end source pipeline still incomplete. Positive approval/permissions,
raw archive, resumable worker, compensating reopen and publisher not implemented.

Before real LocalWP writes: concrete candidate plan, valid backup, separate
operator approval and controlled one-candidate trial. Do not enable technical
constant or modify wp-config now. Real sources remain unavailable under current
catalog network policy. No Google/AI ranking promise, production readiness claim
or deployment to ahda.sch.id. No need repeat old demos just for this QA update.
