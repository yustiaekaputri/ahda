# Real WordPress validation scope

Actual Core7.1.4 auth cookies/session-bound nonce/action nonce, capability denial,
anonymous/nonprivileged admin-post protection and plugin nonce/backup/CAS receipt
controller behavior verified against actual wpdb/MySQL8.4. Source/quote stored
XSS exercised through real WP escaping, not fake esc helpers. Normalized SQL-like
note/backslash passes without query injection. Cross-school access blocked.25
synthetic AHDA legacy table row hashes and source/evidence/link data unchanged.

Custom bootstrap shim replaces only temp-copy wp-load; home/REST alias and local
redirect allowance configure isolated origin. Network/mail/cron disabled, all
non-owned browser origins aborted. No user config, live site, real school data or
production. Real WP-CLI dispatcher/store, actual user plugin/theme configuration,
TLS/load/deadlocks/real lost TCP commit and nonce expiry stress outside current
scope. Prior native/fake failures separately documented. Default runtime actions
remain OFF; no new state transitions or permission/source approval. Next real
operator write still requires concrete plan, backup and explicit permission.
