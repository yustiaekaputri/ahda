# Actual-source research still blocked — 2026-11-10

Existing operator consent: first10 pilot schools, catalog only at the two exact
HTTPS hosts below,20 requests TOTAL, one process, minimum5s/host, obey robots/ToS;
no social accounts, user DB writes, real publication or production access.
Prior2 robots requests were denied;18 remain. No new catalog request this turn.

Required custom domain ADDITIONS (preserve existing domains/presets):

- referensi.data.kemendikdasmen.go.id
- referensi.data.kemdikbud.go.id

Latest runtime status: current observations, restricted/enforced, customhosts[].
Draft read failed twice after status refresh: "The current environment draft could
not be verified. Retry the read before editing the configuration." No config write
attempted; saving/persistence/publication UNCONFIRMED, not claimed successful.
Live runtime permission is not proof of latest editable draft contents. Do not
replace an unknown draft list, bypass proxy/DNS/TLS, or repeatedly probe deniedhosts.

Skill cloud-environment-onboarding:setup SKILL.md instruction:
"If an existing network allowlist is unavailable, report the required domain
additions for environment settings rather than replacing an unknown list."
Source: skill://plugin_connector_1p_ed5feb9070a08191b08c81c47947bc16/setup/SKILL.md

Operator action: add these exact hosts in cloud environment network settings while
preserving existing entries/presets, then save through the product's supported
flow. After confirmed runtime change, refresh status and use fresh connection;
resume existing scoped research consent, not a new quota. No credentials needed.
This is not permission to fetch third-party school sites found in the catalog.

Before claiming actual content completion: lawful sources/rights and privacy,
real parser fixtures, bounded approved capture, actual one-school LocalWP operator
approval and publish/undo acceptance. Current actual factual enrichment0/200.
Code-only latest gates/tests/checkpoint are in docs/PROGRESS.md.
