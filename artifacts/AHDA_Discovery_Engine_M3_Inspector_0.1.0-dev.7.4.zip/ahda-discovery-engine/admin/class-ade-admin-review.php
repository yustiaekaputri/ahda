<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Read-only GET inspector. No POST/action/nonce/mutation endpoint is registered. */
final class ADE_Admin_Review {
    public static function menu(): void {
        add_submenu_page( 'ahda-discovery-status', 'Pemeriksaan kandidat AHDA', 'Kandidat (baca-saja)',
            'ade_review_candidates', 'ahda-discovery-candidates', array( __CLASS__, 'render' ) );
    }

    private static function input( string $key, string $default = '' ): string {
        if ( ! isset( $_GET[$key] ) ) { return $default; }
        if ( ! is_string( $_GET[$key] ) || strlen( $_GET[$key] ) > 40 ) { throw new InvalidArgumentException( 'M3_FILTER_INVALID' ); }
        return wp_unslash( $_GET[$key] );
    }

    private static function number( string $key ): int {
        $value = self::input( $key, '0' );
        if ( ! preg_match( '/^[0-9]{1,18}$/D', $value ) ) { throw new InvalidArgumentException( 'M3_ID_INVALID' ); }
        return (int) $value;
    }

    private static function url( array $args ): string {
        return add_query_arg( array_merge( array( 'page' => 'ahda-discovery-candidates' ), $args ), admin_url( 'admin.php' ) );
    }

    private static function target( string $key ): string { return array( 'profile_programs' => 'Program pendidikan', 'profile_curriculum' => 'Kurikulum', 'profile_hours' => 'Jam layanan' )[$key] ?? $key; }

    private static function value( $value ): string { return null === $value ? '(belum tersedia)' : (string) $value; }

    public static function render(): void {
        if ( ! current_user_can( 'ade_review_candidates' ) || get_current_user_id() < 1 || ! ADE_Schema::is_allowed_local() ) {
            wp_die( 'Pemeriksaan ini hanya tersedia untuk reviewer di ahda.local.', '', array( 'response' => 403 ) ); return;
        }
        echo '<div class="wrap"><h1>Pemeriksaan kandidat sekolah</h1>';
        echo '<div class="notice notice-info inline"><p><strong>Baca-saja.</strong> Tidak menyimpan keputusan, mengakses sumber, atau menerbitkan profil. Kandidat bukan fakta terverifikasi. Demo CLI tidak disimpan sehingga daftar dapat kosong.</p></div>';
        try {
            $npsn = self::input( 'npsn' ); $status = self::input( 'status', 'all' ); $after = self::number( 'after' );
            $id = self::number( 'candidate' ); $evidence_after = self::number( 'evidence_after' );
            if ( ! in_array( $status, array( 'all', 'new', 'approved', 'rejected', 'deferred' ), true ) || ( '' !== $npsn && ! preg_match( '/^[0-9]{8}$/D', $npsn ) ) ) { throw new InvalidArgumentException( 'M3_FILTER_INVALID' ); }
            echo '<form method="get" action="' . esc_url( admin_url( 'admin.php' ) ) . '"><input type="hidden" name="page" value="ahda-discovery-candidates">';
            echo '<p><label for="ade-npsn">NPSN sekolah pilot </label><select id="ade-npsn" name="npsn" style="max-width:100%"><option value="">Pilih sekolah</option>';
            foreach ( ADE_Pilot_Scope::reference() as $code => $school ) {
                echo '<option value="' . esc_attr( (string) $code ) . '"' . ( (string) $code === $npsn ? ' selected' : '' ) . '>' . esc_html( $code . ' · ' . $school['school_form'] . ' · ' . $school['regency_raw'] ) . '</option>';
            }
            echo '</select> <label for="ade-status">Status </label><select id="ade-status" name="status">';
            foreach ( array( 'all' => 'Semua', 'new' => 'Baru', 'approved' => 'Disetujui', 'rejected' => 'Ditolak', 'deferred' => 'Ditunda' ) as $value => $label ) {
                echo '<option value="' . esc_attr( $value ) . '"' . ( $value === $status ? ' selected' : '' ) . '>' . esc_html( $label ) . '</option>';
            }
            echo '</select> <button class="button button-primary" type="submit">Tampilkan</button></p></form>';
            if ( '' === $npsn ) { echo '<p>Pilih satu NPSN untuk memeriksa kandidat tersimpan. Tidak ada pemindaian seluruh direktori.</p>'; }
            elseif ( $id > 0 ) { self::detail( ADE_Candidate_Inspector::detail( $npsn, $id, $evidence_after ) ); }
            else { self::listing( ADE_Candidate_Inspector::listing( $npsn, $status, $after ) ); }
        } catch ( Throwable $e ) {
            $code = preg_match( '/^[A-Z0-9_]{1,80}$/D', $e->getMessage() ) ? $e->getMessage() : 'M3_INSPECTOR_UNAVAILABLE';
            echo '<div class="notice notice-error inline"><p>Pemeriksaan belum dapat dimuat. Kode: <code>' . esc_html( $code ) . '</code>. Tidak ada data diubah.</p></div>';
        }
        echo '</div>';
    }

    private static function listing( array $report ): void {
        $school = $report['school'];
        echo '<h2>' . esc_html( (string) $school['name'] ) . '</h2><p>' . esc_html( $school['npsn'] . ' · ' . $school['regency_raw'] ) . '</p>';
        if ( ! $report['candidates'] ) { echo '<p>Belum ada kandidat tersimpan untuk pilihan ini. Hasil demo/preview CLI memang tidak masuk database. Jangan menyimpan demo untuk mengisi daftar.</p>'; return; }
        echo '<div style="max-width:100%;overflow-x:auto"><table class="widefat striped" style="min-width:640px"><caption>Usulan tersimpan; bukan keputusan publikasi</caption><thead><tr><th scope="col">ID / bidang</th><th scope="col">Ringkasan usulan</th><th scope="col">Status</th><th scope="col">Versi</th><th scope="col">Pemeriksaan</th></tr></thead><tbody>';
        foreach ( $report['candidates'] as $row ) {
            echo '<tr><td>' . esc_html( $row['id'] . ' · ' . self::target( $row['target_key'] ) ) . '</td><td style="overflow-wrap:anywhere">' . esc_html( $row['proposed_excerpt'] ) . '</td><td>' . esc_html( $row['review_status'] . ' / ' . $row['publish_status'] ) . '</td><td>' . esc_html( (string) $row['row_version'] ) . '</td><td><a href="' . esc_url( self::url( array( 'npsn' => $school['npsn'], 'candidate' => $row['id'] ) ) ) . '">Lihat nilai dan evidence</a></td></tr>';
        }
        echo '</tbody></table></div>';
        if ( null !== $report['next_after'] ) { echo '<p><a class="button" href="' . esc_url( self::url( array( 'npsn' => $school['npsn'], 'status' => $report['status_filter'], 'after' => $report['next_after'] ) ) ) . '">20 kandidat berikutnya</a></p>'; }
    }

    private static function detail( array $report ): void {
        $row = $report['candidate']; $school = $report['school'];
        echo '<p><a href="' . esc_url( self::url( array( 'npsn' => $school['npsn'] ) ) ) . '">Kembali ke daftar sekolah ini</a></p>';
        echo '<h2>' . esc_html( $school['name'] . ' — ' . self::target( $row['target_key'] ) ) . '</h2><p>' . esc_html( 'NPSN ' . $school['npsn'] . ' · Kandidat ' . $row['id'] . ' · Versi ' . $row['row_version'] . ' · ' . $row['review_status'] . ' / ' . $row['publish_status'] ) . '</p>';
        if ( $report['current_value_conflict'] ) { echo '<div class="notice notice-warning inline"><p><strong>Konflik nilai saat ini.</strong> Nilai terverifikasi berubah atau hash dasar tidak cocok. Jangan menerapkan usulan tanpa pemeriksaan ulang.</p></div>'; }
        echo '<div style="max-width:100%;overflow-x:auto"><table class="widefat striped" style="min-width:640px"><caption>Perbandingan nilai; semua teks diperlakukan sebagai data</caption><thead><tr><th scope="col">Nilai terverifikasi saat ini</th><th scope="col">Nilai saat usulan dibuat</th><th scope="col">Usulan</th><th scope="col">Nilai disetujui tersimpan</th></tr></thead><tbody><tr>';
        foreach ( array( $report['current_verified_value'], $row['current_value_snapshot'], $row['proposed_value'], $row['approved_value'] ) as $value ) { echo '<td><div style="white-space:pre-wrap;overflow-wrap:anywhere">' . esc_html( self::value( $value ) ) . '</div></td>'; }
        echo '</tr></tbody></table></div><h2>Evidence halaman ini</h2><p>Literal kutipan bukan bukti otoritas atau izin sumber. Halaman ini tidak mengakses URL. Waktu cek bukan tanggal pembaruan profil.</p>';
        if ( ! $report['evidence'] ) { echo '<p>Tidak ada evidence pada halaman ini.</p>'; }
        foreach ( $report['evidence'] as $entry ) {
            echo '<section><h3>Evidence ' . esc_html( (string) $entry['id'] ) . '</h3>';
            if ( null !== $entry['url'] ) { echo '<p><a rel="noreferrer noopener nofollow" target="_blank" href="' . esc_url( $entry['url'] ) . '">' . esc_html( $entry['url'] ) . '</a></p>'; }
            else { echo '<p>URL sumber diblokir dari tampilan karena tidak aman atau berisi parameter sensitif.</p>'; }
            echo '<blockquote style="white-space:pre-wrap;overflow-wrap:anywhere">' . esc_html( $entry['snippet_text'] ) . '</blockquote><p>' . esc_html( 'Waktu cek UTC: ' . $entry['checked_at'] . ' · Identitas: ' . self::value( $entry['identity_status'] ) . ' · Hubungan: ' . self::value( $entry['relationship_type'] ) . ' · Akses: ' . self::value( $entry['access_state'] ) . ' · Sumber: ' . self::value( $entry['source_status'] ) ) . '</p></section>';
        }
        if ( null !== $report['next_evidence_after'] ) { echo '<p><a class="button" href="' . esc_url( self::url( array( 'npsn' => $school['npsn'], 'candidate' => $row['id'], 'evidence_after' => $report['next_evidence_after'] ) ) ) . '">20 evidence berikutnya</a></p>'; }
        echo '<h2>Alasan perlu pemeriksaan</h2><ul>';
        $labels = array( 'REVIEW_ACTIONS_NOT_IMPLEMENTED' => 'Panel ini belum menerima keputusan review.', 'PUBLISHER_DISABLED' => 'Penerbitan profil belum diaktifkan.',
            'CURRENT_VALUE_CHANGED_OR_BASE_HASH_INVALID' => 'Nilai saat ini berbeda atau dasar perbandingan perlu diperiksa.', 'SOURCE_URL_BLOCKED' => 'URL tidak aman atau berparameter sensitif disembunyikan.',
            'SOURCE_IDENTITY_NOT_VERIFIED' => 'Identitas dan hubungan resmi sumber belum diverifikasi.', 'SOURCE_PERMISSION_NOT_INDEPENDENTLY_VERIFIED' => 'Izin sumber belum diverifikasi secara independen.',
            'SOURCE_STATE_REQUIRES_REVIEW' => 'Status akses atau sumber perlu diperiksa.', 'EVIDENCE_TIMESTAMP_INVALID' => 'Waktu pemeriksaan evidence tidak valid.', 'STALE_EVIDENCE' => 'Evidence lebih dari 365 hari; periksa kembali sesuai periode informasinya.',
            'NO_MORE_EVIDENCE_ON_THIS_PAGE' => 'Tidak ada evidence lagi pada halaman ini.', 'EVIDENCE_MISSING' => 'Kandidat belum memiliki evidence.' );
        foreach ( $report['readiness_reasons'] as $reason ) { echo '<li>' . esc_html( $labels[$reason] ?? 'Pemeriksaan tambahan diperlukan.' ) . '</li>'; }
        echo '</ul><p>Daftar alasan berlaku untuk evidence yang dimuat pada halaman ini. Tidak ada tombol approve, edit, reject atau publish pada versi baca-saja ini.</p>';
    }
}
