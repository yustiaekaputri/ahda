<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** R4a: manual immutable evidence entries, no automatic identity promotion or fetching. */
final class ADE_Evidence {
    private const TYPES = array( 'profile_page', 'post', 'video', 'news_article', 'document', 'manual_review' );
    private const HINTS = array( 'source_identity', 'school_relationship' );

    private static function gate(): void {
        if ( ! defined( 'WP_CLI' ) || ! WP_CLI || ! class_exists( 'WP_CLI' ) ) {
            throw new RuntimeException( 'R4a hanya boleh dilakukan melalui LocalWP Site Shell.' );
        }
        if ( ! ADE_Sources::preflight()['ready'] ) {
            throw new RuntimeException( 'R4a BLOCKED: jalankan wp ade sources preflight.' );
        }
    }

    private static function validate_text( string $raw, string $field, int $max ): string {
        $value = trim( $raw );
        if ( '' === $value || strlen( $value ) > $max || preg_match( '/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/', $value ) ) {
            throw new InvalidArgumentException( $field . ' wajib terisi (maks ' . $max . ' byte), tanpa kontrol karakter.' );
        }
        $clean = sanitize_textarea_field( $value );
        if ( '' === trim( $clean ) ) { throw new InvalidArgumentException( $field . ' tidak valid.' ); }
        return $clean;
    }

    public static function normalize( string $type, string $attribute, string $url, string $claim, string $title = '' ): array {
        if ( ! in_array( $type, self::TYPES, true ) || ! in_array( $attribute, self::HINTS, true ) ) {
            throw new InvalidArgumentException( 'evidence-type atau attribute tidak termasuk allowlist R4a.' );
        }
        $claim = self::validate_text( $claim, 'claim', 2048 );
        $title = trim( $title );
        if ( strlen( $title ) > 255 ) { throw new InvalidArgumentException( 'title maksimal 255 byte.' ); }
        $title = '' === $title ? '' : sanitize_text_field( $title );
        return array(
            'evidence_type' => $type,
            'attribute_hint' => $attribute,
            'evidence_url' => ADE_Evidence_URLs::canonicalize( $url ),
            'claim' => $claim,
            'title' => $title,
        );
    }

    private static function find_link( int $school_id, string $source_key ): array {
        global $wpdb;
        $sources = ADE_Schema::table_name( 'sources' );
        $links = ADE_Schema::table_name( 'school_sources' );
        $wpdb->last_error = '';
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT s.id AS source_id,l.id AS relation_id,l.identity_status,l.relationship_type,s.access_state FROM {$sources} s INNER JOIN {$links} l ON l.source_id=s.id WHERE l.school_id=%d AND s.canonical_key=%s LIMIT 2",
            $school_id, $source_key
        ), ARRAY_A );
        if ( ! is_array( $rows ) || '' !== $wpdb->last_error || count( $rows ) !== 1 ) {
            throw new RuntimeException( 'Relasi sumber-sekolah belum ada atau tidak unik; lakukan R3 observe yang benar dahulu.' );
        }
        if ( in_array( (string) $rows[0]['identity_status'], array( 'rejected', 'conflict' ), true ) ||
             in_array( (string) $rows[0]['relationship_type'], array( 'rejected' ), true ) ||
             'blocked' === (string) $rows[0]['access_state'] ) {
            throw new RuntimeException( 'Relasi/sumber diblokir atau konflik; hentikan R4a manual record.' );
        }
        return $rows[0];
    }

    public static function preview( string $npsn, string $source_url, string $evidence_url, string $type, string $attribute, string $claim, string $title = '' ): array {
        self::gate();
        $school = ADE_Identity::lookup( $npsn );
        $source = ADE_Source_URLs::canonicalize( $source_url );
        $link = self::find_link( (int) $school['id'], $source['canonical_key'] );
        $entry = self::normalize( $type, $attribute, $evidence_url, $claim, $title );
        $value_hash = hash( 'sha256', $entry['claim'] );
        $key = hash( 'sha256', implode( '|', array( 'r4a-evidence-v1', (string) $school['id'], (string) $link['source_id'], $entry['evidence_url'], $attribute, $type, $value_hash ) ) );
        return array(
            'school_id' => (int) $school['id'],
            'npsn' => $school['npsn'],
            'school_name' => $school['name'],
            'source_id' => (int) $link['source_id'],
            'relation_id' => (int) $link['relation_id'],
            'identity_status' => $link['identity_status'],
            'relationship_type' => $link['relationship_type'],
            'source_url' => $source['canonical_url'],
            'entry' => $entry,
            'evidence_key' => $key,
        );
    }

    /** Insert immutable evidence row, duplicate-safe, only on explicit CLI confirmation. */
    public static function record( string $npsn, string $source_url, string $evidence_url, string $type, string $attribute, string $claim, string $title = '' ): array {
        $data = self::preview( $npsn, $source_url, $evidence_url, $type, $attribute, $claim, $title );
        $table = ADE_Schema::table_name( 'evidence' );
        global $wpdb;
        if ( false === $wpdb->query( 'START TRANSACTION' ) ) { throw new RuntimeException( 'R4a transaksi gagal dimulai.' ); }
        try {
            $wpdb->last_error = '';
            $id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE evidence_key=%s LIMIT 1", $data['evidence_key'] ) );
            if ( '' !== $wpdb->last_error ) { throw new RuntimeException( 'Gagal membaca evidence yang ada.' ); }
            $created = false;
            if ( null === $id ) {
                $time = current_time( 'mysql', true );
                $entry = $data['entry'];
                $ok = $wpdb->insert( $table, array(
                    'school_id' => $data['school_id'],
                    'source_id' => $data['source_id'],
                    'evidence_type' => $entry['evidence_type'],
                    'attribute_hint' => $entry['attribute_hint'],
                    'evidence_url' => $entry['evidence_url'],
                    'evidence_key' => $data['evidence_key'],
                    'content_fingerprint' => null,
                    'title' => '' === $entry['title'] ? null : $entry['title'],
                    'snippet_text' => null,
                    'observed_value' => $entry['claim'],
                    'parse_status' => 'manual',
                    'http_code' => null,
                    'checked_at' => $time,
                    'created_at' => $time,
                ) );
                if ( false !== $ok ) {
                    $id = (int) $wpdb->insert_id;
                    $created = true;
                } else {
                    // Recover unique-key collision only; any other insert failure is an error.
                    $wpdb->last_error = '';
                    $id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE evidence_key=%s LIMIT 1", $data['evidence_key'] ) );
                    if ( null === $id || '' !== $wpdb->last_error ) { throw new RuntimeException( 'Gagal menyimpan evidence.' ); }
                }
            }
            if ( false === $wpdb->query( 'COMMIT' ) ) { throw new RuntimeException( 'R4a COMMIT gagal.' ); }
            return array( 'id' => (int) $id, 'created' => $created, 'source_id' => $data['source_id'], 'school_id' => $data['school_id'], 'evidence_key' => $data['evidence_key'] );
        } catch ( Throwable $e ) {
            $wpdb->query( 'ROLLBACK' );
            throw $e;
        }
    }

    public static function list_for_school( string $npsn, int $limit = 15 ): array {
        self::gate();
        $school = ADE_Identity::lookup( $npsn );
        $table = ADE_Schema::table_name( 'evidence' );
        global $wpdb;
        $wpdb->last_error = '';
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id,source_id,evidence_type,attribute_hint,evidence_url,evidence_key,parse_status,checked_at FROM {$table} WHERE school_id=%d ORDER BY id DESC LIMIT %d",
            (int) $school['id'], max( 1, min( 50, $limit ) )
        ), ARRAY_A );
        if ( ! is_array( $rows ) || '' !== $wpdb->last_error ) { throw new RuntimeException( 'Gagal membaca evidence R4a.' ); }
        return array( 'school' => $school, 'rows' => $rows );
    }
}
