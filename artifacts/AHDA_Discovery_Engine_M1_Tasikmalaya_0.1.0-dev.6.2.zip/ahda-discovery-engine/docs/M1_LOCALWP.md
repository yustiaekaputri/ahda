# M1 Tasikmalaya — panduan LocalWP dev.6.2

Build `0.1.0-dev.6.2` melanjutkan R4a, dengan skema database tetap versi 1,
tujuh tabel. Ini development build, belum production-ready. Jangan unggah ke
ahda.sch.id. Plugin induk Directory v0.8.9 tetap dipertahankan.

## Daftar beku yang dibundel

200 sekolah negeri Kabupaten/Kota Tasikmalaya: SMP159, MTS18, SMA21, SMK2;
Kabupaten164/Kota36. Daftar berasal dari Excel pengguna; semua SMP/MTS negeri
diikutkan, lalu 23 tambahan berdasarkan urutan NPSN. Tidak ada pemilihan ulang,
sekolah swasta atau provinsi lain. Tidak ada download sumber pada bootstrap.

- `data/pilots/tasikmalaya-200.txt`: 200 NPSN, satu per baris.
- `data/pilots/tasikmalaya-negeri-2026-200.json`: klasifikasi rujukan.

SHA-256 TXT: `42aaa7c51d5e0163c08146d1c46df70e260496639b9a3cc55e34f58781b1af20`.
Rujukan JSON dipatok checksum dalam kode. Mengubah file tanpa review build baru
akan memblokir proses. Rujukan tidak menyimpan school_id dari database; ID harus
dibaca dari indeks NPSN LocalWP. Referensi Excel bukan bukti independen resmi.

## Sebelum memasang — tindakan operator lokal

Penggantian/aktivasi plugin dapat menulis opsi dan capability WordPress. Codex
belum memasang plugin atau mengakses database LocalWP Anda. Instalasi perlu
persetujuan operator dan backup LocalWP yang benar-benar bisa dipulihkan.
Simpan ZIP R4a asli untuk rollback. Ganti hanya folder `ahda-discovery-engine`.
Jangan reaktivasi/ganti plugin Directory, jalankan schema install, reimport,
rebuild indeks, atau menghapus data. WinSCP bukan pengganti backup/pengujian.

## Tahap baca-saja setelah instalasi lokal yang disetujui

Dari LocalWP Site Shell untuk situs ahda.local, ganti ADMIN_LOGIN dengan akun
administrator lokal yang memiliki `ade_manage_jobs`. Jangan jalankan di produksi.

```sh
wp --user=ADMIN_LOGIN ade schema postflight
wp --user=ADMIN_LOGIN ade jobs preflight
wp --user=ADMIN_LOGIN help ade pilot
wp --user=ADMIN_LOGIN ade pilot preflight
wp --user=ADMIN_LOGIN ade pilot preview --batch-size=10 --dry-run
```

Preflight pilot memeriksa semua 200 NPSN terhadap database: identitas unik,
jenjang persis sesuai rujukan, ownership_status NEGERI, Kabupaten/Kota Tasikmalaya,
visibility `publish`. MTs/MTS dinormalisasi secara konservatif. Tidak menebak
status dari nama sekolah. Ketidaksesuaian menghentikan kelayakan, dengan kode
masalah per NPSN. `all_valid=true` hanya jika 200 benar-benar lolos; failed/unrun
dilaporkan terpisah, exit status gagal bila tidak lengkap.

Kode preflight/preview hanya SELECT, tanpa job baru, HTTP atau DNS. Ini bukan
audit seluruh efek bootstrap WordPress/plugin lain: Directory lama dapat
menjalankan installer tambahan bila opsi versinya tertinggal. Karena itu backup,
pemeriksaan instalasi dan persetujuan operator tetap berlaku sebelum penggunaan.
Laporan database_writes=0 mengacu pada operasi komponen preflight tersebut.

File NPSN tidak wajib diberikan karena daftar beku sudah dibundel. Jika
`--npsn-file=/path/file.txt` diberikan, preflight memerlukan tepat daftar 200 yang
sama; preview boleh memakai subset dari daftar beku. Tidak ada opsi melepas scope.
Preview mengembalikan cursor school_id; lanjutkan dengan `--after=ID` pada daftar
yang sama. Hasil source planning hanya `needs_source` atau
`operator_source_review_required`, bukan evidence sah, approval atau publikasi.

## Mutasi job — belum dijalankan; persetujuan eksplisit diperlukan

Dampak: membuat/memperbarui baris `ahda_discovery_jobs` dengan prefix aktual
WordPress, bukan tabel profil lama. Tidak fetch, mengubah sumber/evidence,
menerbitkan atau mengubah nilai profil. Sebelum menjalankan tahap ini, operator
harus menyetujui penulisan lokal tersebut dan memverifikasi backup.

```sh
wp --user=ADMIN_LOGIN ade pilot enqueue --confirm=ENQUEUE_M1_PLAN
wp --user=ADMIN_LOGIN ade pilot run-one-batch --job-id=JOB_ID --confirm=RUN_M1_PLAN
wp --user=ADMIN_LOGIN ade pilot status --job-id=JOB_ID
wp --user=ADMIN_LOGIN ade pilot integrity-check --job-id=JOB_ID
```

Maksimal 10 sekolah per langkah, satu worker per database. Status negeri,
jenjang, wilayah dan binding NPSN/school_id diperiksa ulang saat resume. Bila
berubah, tidak ada checkpoint maju. Stats/cursor commit bersama dengan fencing
lease token. Job baru wajib manifest scope v2; itu versi JSON payload, bukan
migrasi skema. Dedupe memasukkan scope dan checksum rujukan. Legacy job v1 tetap
dapat dibaca/diproses melalui API lama dan diberi label `legacy-v1-unscoped` pada
status; job v1 baru ditolak. CLI run-one-batch kini menolak job legacy unscoped
agar tidak mencampur pilihan provinsi lama; status/recovery/cancel tetap tersedia.
Pemrosesan legacy lewat API kompatibilitas membutuhkan review operator terpisah. Tidak ada penjadwalan otomatis.

```sh
wp --user=ADMIN_LOGIN ade pilot recover --confirm=RECOVER_M1_PLAN
wp --user=ADMIN_LOGIN ade pilot retry-failed --job-id=JOB_ID --confirm=RETRY_M1_PLAN
wp --user=ADMIN_LOGIN ade pilot cancel --job-id=JOB_ID --confirm=CANCEL_M1_PLAN
```

Retry menunggu 30 detik, maksimal tiga kegagalan berturut-turut per batch.
Retry eksplisit tidak menghapus hasil committed. Recovery hanya lease M1 yang
kedaluwarsa; cancel hanya job yang tidak leased. Pembatalan saat satu langkah
berjalan dilakukan setelah langkah terbatas itu berakhir. Tidak menghapus baris.
Semua perintah mutasi menolak `--dry-run`; gunakan preview untuk tanpa penulisan.

## Crawler dan fitur berikutnya

Adapter crawler tetap hard-disabled oleh ADE_Config dan tidak punya perintah
fetch. Tidak ada perubahan flag. Bounded DNS, throttle host lintas proses,
source/robots/terms policy dan native transport perlu diselesaikan/divalidasi
sebelum exposure. Generic proxy ditolak karena dapat melewati pin DNS lokal.
Ekstraksi kandidat, dashboard review, dan publisher lokal belum termasuk build.
Tidak ada sinkronisasi ke VPS produksi.

## Rollback

Hentikan perintah M1. Setelah backup/persetujuan lokal, kembalikan ZIP Discovery
R4a asli ke folder sama. Jangan drop tabel, hapus job atau reaktivasi Directory.
Baris M1 memakai tipe berbeda sehingga worker R2 tidak mengonsumsinya. Untuk
kembali ke dev.6.0, job scoped v2 baru tidak kompatibel dengan pembaca v1 lama;
jangan jalankan job scoped tersebut melalui dev.6.0. Pertahankan barisnya dan
pakai dev.6.2 untuk status/recovery. Periksa ulang perintah baseline setelah
rollback; tidak ada operasi pada profil lama yang perlu dipulihkan dari build ini.


## Langkah setelah preflight dev.6.1 yang sudah lulus: source-preview

Log LocalWP yang diberikan operator: schema INSTALLED7/7, pilot200/200 lolos,
preview10 berjalan, seluruh10 belum memiliki link Discovery (needs_source).
Ini hasil dari operator, bukan eksekusi cloud. Tidak perlu menjalankan ulang
seluruh preflight hanya untuk mengganti reader URL ini; skema tetap sama.

Setelah backup dan penggantian Discovery dengan dev.6.2 yang disetujui lokal,
jalankan dari Site Shell AHDA memakai akun admin yang sudah berhasil:

```sh
wp --user="admin" ade pilot source-preview --batch-size=10 --dry-run
```

Source-preview memeriksa field profile_website/profile_source_url pada meta,
official_website pada details, serta empat platform sosial yang didukung. Hanya
baris legacy verification_status=verified yang dibaca. Maksimal3 query berindeks
per sekolah, batch1–20. Tidak membaca kontak, data murid, password atau wp-config.
Tidak menyimpan source/evidence atau mengubah nilai lama.

Per hasil:
- discovery_link_count_capped_at_5: link yang sudah ada di Discovery.
- hint_count/url_hints: URL yang ditemukan di field lama; dedupe dengan provenance.
- review_existing_url_hints: perlu review URL; belum verifikasi identitas/izin.
- needs_source: belum ada link Discovery maupun petunjuk verified dari field ini.
- rejected: kode penolakan format/platform/query sensitif; nilai berbahaya disembunyikan.

Legacy verified tidak otomatis menjadi sumber resmi Discovery. Semua petunjuk
identity_status=pending, access_state=manual_only dan fetch_permission=NOT_GRANTED.
Tidak ada DNS atau HTTP. Ketika query gagal, perintah gagal, bukan melaporkan
sumber kosong. Situs sumber masih perlu pemeriksaan izin/robots/terms sebelum
ada permintaan jaringan dengan persetujuan operator.

Kirim hasil pertama. Cursor dari hasil dapat dipakai untuk melanjutkan:
`wp --user="admin" ade pilot source-preview --batch-size=10 --after=ID_CURSOR --dry-run`.
Ganti ID_CURSOR dengan cursor yang dikembalikan. Jangan langsung enqueue/crawl
untuk mengatasi needs_source, karena itu tidak menciptakan sumber yang sah.
