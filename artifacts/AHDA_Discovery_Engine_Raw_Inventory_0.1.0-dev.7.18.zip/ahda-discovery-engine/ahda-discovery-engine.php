<?php
/**
 * Plugin Name: AHDA Discovery Engine
 * Description: Companion development: bounded offline extraction and read-only candidate inspection; publication disabled.
 * Version: 0.1.0-dev.7.18
 * Requires PHP: 7.4
 * Author: AHDA Project
 * License: GPL-2.0-or-later
 * Text Domain: ahda-discovery-engine
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Do not load class files on unsupported PHP runtimes.
if ( PHP_VERSION_ID < 70400 ) {
    add_action( 'admin_notices', static function () {
        if ( current_user_can( 'manage_options' ) ) {
            echo '<div class="notice notice-error"><p>AHDA Discovery Engine R0 membutuhkan PHP 7.4 atau lebih baru. Tidak ada modul Discovery yang dijalankan.</p></div>';
        }
    } );
    return;
}

define( 'ADE_VERSION', '0.1.0-dev.7.18' );
define( 'ADE_R0_VERSION', ADE_VERSION ); // Compatibility with read-only R0 audit.
define( 'ADE_R0_PATH', plugin_dir_path( __FILE__ ) );

require_once ADE_R0_PATH . 'includes/class-ade-config.php';
require_once ADE_R0_PATH . 'includes/class-ade-capabilities.php';
require_once ADE_R0_PATH . 'includes/class-ade-dependencies.php';
require_once ADE_R0_PATH . 'includes/class-ade-schema.php';
require_once ADE_R0_PATH . 'includes/class-ade-jobs.php';
require_once ADE_R0_PATH . 'includes/class-ade-source-urls.php';
require_once ADE_R0_PATH . 'includes/class-ade-identity.php';
require_once ADE_R0_PATH . 'includes/class-ade-sources.php';
require_once ADE_R0_PATH . 'includes/class-ade-evidence-urls.php';
require_once ADE_R0_PATH . 'includes/class-ade-evidence.php';
require_once ADE_R0_PATH . 'includes/class-ade-crawl-policy.php';
require_once ADE_R0_PATH . 'includes/class-ade-crawler.php';
require_once ADE_R0_PATH . 'includes/class-ade-pilot-scope.php';
require_once ADE_R0_PATH . 'includes/class-ade-pilot.php';
require_once ADE_R0_PATH . 'includes/class-ade-pilot-jobs.php';
require_once ADE_R0_PATH . 'includes/class-ade-source-inventory.php';
require_once ADE_R0_PATH . 'includes/class-ade-enrichment-preview.php';
require_once ADE_R0_PATH . 'includes/class-ade-enrichment-store.php';
require_once ADE_R0_PATH . 'includes/class-ade-article-preview.php';
require_once ADE_R0_PATH . 'includes/class-ade-document-parser.php';
require_once ADE_R0_PATH . 'includes/class-ade-local-archive.php';
require_once ADE_R0_PATH . 'includes/class-ade-local-worker.php';
require_once ADE_R0_PATH . 'includes/class-ade-archive-review.php';
require_once ADE_R0_PATH . 'includes/class-ade-archive-vault.php';
require_once ADE_R0_PATH . 'includes/class-ade-archive-candidates.php';
require_once ADE_R0_PATH . 'includes/class-ade-archive-batch.php';
require_once ADE_R0_PATH . 'includes/class-ade-candidate-inspector.php';
require_once ADE_R0_PATH . 'includes/class-ade-archive-verifier.php';
require_once ADE_R0_PATH . 'includes/class-ade-source-attestation.php';
require_once ADE_R0_PATH . 'includes/class-ade-positive-review.php';
require_once ADE_R0_PATH . 'includes/class-ade-local-publication.php';
require_once ADE_R0_PATH . 'includes/class-ade-review-decisions.php';
require_once ADE_R0_PATH . 'includes/class-ade-bootstrap.php';

// Register lifecycle hooks at file-load time (never inside plugins_loaded).
register_activation_hook( __FILE__, array( 'ADE_Bootstrap', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'ADE_Bootstrap', 'deactivate' ) );

add_action( 'plugins_loaded', array( 'ADE_Bootstrap', 'init' ), 30 );
