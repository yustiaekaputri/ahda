<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
require_once __DIR__ . '/class-ade-strict-json.php';

/** M2 structured-document foundation. No fetch, model call, persistence or approval. */
final class ADE_Enrichment_Preview {
    private const TARGETS = array( 'profile_programs', 'profile_curriculum', 'profile_hours' );
    public const MAX_INPUT_BYTES = 65536;

    private static function exact_keys( array $value, array $keys ): void {
        if ( array_diff( array_keys( $value ), $keys ) || array_diff( $keys, array_keys( $value ) ) ) {
            throw new InvalidArgumentException( 'M2_SCHEMA_KEYS_INVALID' );
        }
    }

    private static function plain( $value, int $max ): string {
        if ( ! is_string( $value ) || '' === trim( $value ) || strlen( $value ) > $max || ! preg_match( '//u', $value ) ||
            preg_match( '/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f<>]/', $value ) ) {
            throw new InvalidArgumentException( 'M2_PLAIN_TEXT_REQUIRED' );
        }
        return trim( $value );
    }

    private static function digest( array $value ): string {
        return hash( 'sha256', json_encode( $value, JSON_THROW_ON_ERROR ) );
    }

    /** Pure validation/extraction of literal structured claims, never factual certification. */
    public static function normalize( string $raw, int $now ): array {
        if ( strlen( $raw ) > self::MAX_INPUT_BYTES ) { throw new InvalidArgumentException( 'M2_INPUT_TOO_LARGE' ); }
        $input_hash = hash( 'sha256', $raw );
        $data = ADE_Strict_JSON::decode( $raw, self::MAX_INPUT_BYTES );
        self::exact_keys( $data, array( 'schema_version', 'fixture_only', 'npsn', 'observed_npsn', 'source_url', 'checked_at', 'permission_reference', 'source_content', 'claims' ) );
        if ( $data['schema_version'] !== 1 || ! is_bool( $data['fixture_only'] ) || ! is_string( $data['npsn'] ) ||
            ! is_string( $data['observed_npsn'] ) || ADE_Identity::validate_npsn( $data['npsn'] ) !== $data['npsn'] ||
            ADE_Identity::validate_npsn( $data['observed_npsn'] ) !== $data['observed_npsn'] ) { throw new InvalidArgumentException( 'M2_IDENTITY_FORMAT_INVALID' ); }
        if ( $data['npsn'] !== $data['observed_npsn'] ) { throw new InvalidArgumentException( 'M2_HARD_NPSN_MISMATCH' ); }
        if ( ! ADE_Pilot_Scope::contains( $data['npsn'] ) ) { throw new InvalidArgumentException( 'M2_NPSN_OUTSIDE_PILOT' ); }
        if ( ! is_string( $data['permission_reference'] ) || ! preg_match( '/^[a-zA-Z0-9_-]{3,80}$/D', $data['permission_reference'] ) ) {
            throw new InvalidArgumentException( 'M2_OPERATOR_REFERENCE_REQUIRED' );
        }
        if ( ! is_string( $data['source_url'] ) ) { throw new InvalidArgumentException( 'M2_SOURCE_URL_INVALID' ); }
        $url = ADE_Evidence_URLs::canonicalize( $data['source_url'] );
        if ( parse_url( $url, PHP_URL_SCHEME ) !== 'https' ) { throw new InvalidArgumentException( 'M2_HTTPS_REQUIRED' ); }
        foreach ( explode( '&', (string) parse_url( $url, PHP_URL_QUERY ) ) as $pair ) {
            $key = strtolower( rawurldecode( explode( '=', $pair, 2 )[0] ) );
            if ( $key === 'key' || preg_match( '/token|secret|password|authorization|credential|signature|nonce|api[_-]?key/i', $key ) ) {
                throw new InvalidArgumentException( 'M2_SENSITIVE_SOURCE_URL' );
            }
        }
        if ( ! is_string( $data['checked_at'] ) ) { throw new InvalidArgumentException( 'M2_TIMESTAMP_INVALID' ); }
        $date = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i:s\Z', $data['checked_at'], new DateTimeZone( 'UTC' ) );
        if ( false === $date || $date->format( 'Y-m-d\TH:i:s\Z' ) !== $data['checked_at'] || $date->getTimestamp() > $now + 300 ) {
            throw new InvalidArgumentException( 'M2_TIMESTAMP_INVALID' );
        }
        $content = self::plain( $data['source_content'], 16384 );
        if ( ! preg_match( '/(?<![0-9])' . preg_quote( $data['npsn'], '/' ) . '(?![0-9])/', $content ) ) { throw new InvalidArgumentException( 'M2_SOURCE_NPSN_MISSING' ); }
        preg_match_all( '/\bNPSN\s*[:=-]?\s*([0-9]{8})(?![0-9])/i', $content, $named_npsns );
        foreach ( $named_npsns[1] as $code ) {
            if ( $code !== $data['npsn'] ) { throw new InvalidArgumentException( 'M2_HARD_NPSN_MISMATCH' ); }
        }
        if ( ! is_array( $data['claims'] ) || ! $data['claims'] || count( $data['claims'] ) > 20 ||
            array_keys( $data['claims'] ) !== array_keys( array_values( $data['claims'] ) ) ) { throw new InvalidArgumentException( 'M2_CLAIMS_INVALID' ); }
        $fingerprint = hash( 'sha256', $content ); $evidence = array(); $candidates = array();
        foreach ( $data['claims'] as $claim ) {
            if ( ! is_array( $claim ) ) { throw new InvalidArgumentException( 'M2_CLAIM_INVALID' ); }
            self::exact_keys( $claim, array( 'target_key', 'proposed_value', 'supporting_quote' ) );
            if ( ! is_string( $claim['target_key'] ) || ! in_array( $claim['target_key'], self::TARGETS, true ) ) {
                throw new InvalidArgumentException( 'M2_TARGET_BLOCKED' );
            }
            $target = $claim['target_key'];
            $value = self::plain( $claim['proposed_value'], 500 );
            $quote = self::plain( $claim['supporting_quote'], 2000 );
            if ( strpos( $content, $quote ) === false || strpos( $quote, $value ) === false ) { throw new InvalidArgumentException( 'M2_LITERAL_EVIDENCE_MISSING' ); }
            if ( isset( $candidates[$target] ) && $candidates[$target]['proposed_value'] !== $value ) { throw new InvalidArgumentException( 'M2_CONFLICTING_CLAIMS' ); }
            $evidence_key = self::digest( array( 'm2-preview-evidence-v1', $data['npsn'], $url, $fingerprint, $target, $value, $quote ) );
            $evidence[$evidence_key] = array( 'preview_key' => $evidence_key, 'persisted' => false,
                'source_url' => $url, 'checked_at' => $data['checked_at'], 'content_fingerprint' => $fingerprint,
                'target_key' => $target, 'observed_value' => $value, 'supporting_quote' => $quote,
                'provenance' => 'operator_supplied_document', 'operator_reference' => $data['permission_reference'],
                'permission_state' => 'NOT_INDEPENDENTLY_VERIFIED', 'identity_status' => 'pending' );
            if ( ! isset( $candidates[$target] ) ) {
                $candidates[$target] = array( 'preview_key' => self::digest( array( 'm2-preview-candidate-v1', $data['npsn'], $target, $value ) ),
                    'persisted' => false, 'target_type' => 'school_meta', 'target_key' => $target,
                    'proposed_value' => $value, 'evidence_preview_keys' => array(), 'review_status' => 'new',
                    'readiness' => 'needs_evidence', 'publish_status' => 'not_ready', 'approved_value' => null );
            }
            if ( ! in_array( $evidence_key, $candidates[$target]['evidence_preview_keys'], true ) ) { $candidates[$target]['evidence_preview_keys'][] = $evidence_key; }
        }
        ksort( $evidence ); ksort( $candidates );
        foreach ( $candidates as &$candidate ) { sort( $candidate['evidence_preview_keys'], SORT_STRING ); } unset( $candidate );
        return array( 'mode' => $data['fixture_only'] ? 'FIXTURE_ONLY_READ_ONLY' : 'UNVERIFIED_DOCUMENT_PREVIEW',
            'fixture_only' => $data['fixture_only'], 'npsn' => $data['npsn'], 'scope' => ADE_Pilot_Scope::NAME,
            'input_sha256' => $input_hash, 'source_content_sha256' => $fingerprint,
            'evidence' => array_values( $evidence ), 'candidates' => array_values( $candidates ),
            'blocking_reasons' => array_merge( array( 'SOURCE_IDENTITY_NOT_VERIFIED', 'SOURCE_PERMISSION_NOT_VERIFIED', 'ADMIN_REVIEW_REQUIRED' ),
                $data['fixture_only'] ? array( 'FIXTURE_NOT_SCHOOL_FACTS' ) : array(),
                $now - $date->getTimestamp() > 365 * 86400 ? array( 'STALE_EVIDENCE' ) : array() ),
            'network_requests' => 0, 'database_writes' => 0, 'publication_enabled' => false );
    }

    /** Local CLI only. Current snapshots come from SELECT, not input documents. */
    public static function preview( string $raw ): array {
        ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
        $result = self::normalize( $raw, time() );
        $school = ADE_Identity::lookup_pilot( $result['npsn'] );
        ADE_Pilot_Scope::assert_school( $school );
        if ( (string) $school['npsn'] !== $result['npsn'] ) { throw new RuntimeException( 'M2_IDENTITY_CONFLICT' ); }
        global $wpdb;
        $table = $wpdb->prefix . 'ahda_school_meta'; // Prefix validated by lookup_pilot.
        if ( strlen( $table ) > 64 ) { throw new RuntimeException( 'M2_TABLE_INVALID' ); }
        $wpdb->last_error = '';
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT meta_key,LEFT(meta_value,16385) AS meta_value,OCTET_LENGTH(meta_value) AS value_bytes FROM {$table} WHERE school_id=%d AND verification_status=%s AND meta_key IN (%s,%s,%s) ORDER BY meta_key LIMIT 4",
            (int) $school['id'], 'verified', self::TARGETS[0], self::TARGETS[1], self::TARGETS[2]
        ), ARRAY_A );
        if ( ! is_array( $rows ) || $wpdb->last_error || count( $rows ) > 3 ) { throw new RuntimeException( 'M2_SNAPSHOT_READ_FAILED' ); }
        $current = array();
        foreach ( $rows as $row ) {
            if ( ! in_array( $row['meta_key'] ?? null, self::TARGETS, true ) || ! is_string( $row['meta_value'] ?? null ) || ! isset( $row['value_bytes'] ) ||
                ! preg_match( '/^[0-9]+$/D', (string) $row['value_bytes'] ) || (int) $row['value_bytes'] > 16384 ||
                isset( $current[$row['meta_key']] ) ) { throw new RuntimeException( 'M2_SNAPSHOT_INVALID' ); }
            $current[$row['meta_key']] = $row['meta_value'];
        }
        foreach ( $result['candidates'] as &$candidate ) {
            $value = $current[$candidate['target_key']] ?? null;
            $candidate['school_id'] = (int) $school['id'];
            $candidate['current_value_snapshot'] = $value;
            $candidate['base_target_hash'] = self::digest( array( 'm2-meta-snapshot-v1', (int) $school['id'], $candidate['target_key'], $value ) );
            $candidate['change_required'] = $value !== $candidate['proposed_value'];
        } unset( $candidate );
        $result['school_id'] = (int) $school['id'];
        return $result;
    }
}
