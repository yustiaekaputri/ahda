# Positive review — dev.7.14

Historical service contract. For the dev.7.15 administrator form see ADMIN_APPROVAL.md.

Status: local-only service and explicit CLI, default OFF. One unedited, short
raw-backed claim for profile_programs/profile_curriculum/profile_hours only.
No web approval form yet. No publication, independent verification, source badge,
identity promotion, profile mutation, schema/options/role migration or fetching.
Approved is a recorded operator decision, not permission to publish forever.

## Preconditions

- Existing frozen pilot school, one same-school candidate/evidence link, and one
  exact candidate/evidence/source-bound operator attestation from dev.7.13.
- Fresh raw reparsed and compared to stored quote/value/source URL/hash/time.
  Current verified legacy target hash must still match; stale evidence blocks.
- Current source/relationship state matches the declaration, which is neither
  withdrawn nor expired/within five seconds of expiry. References and rights
  remain the operator's responsibility, not authenticated by software.
- Candidate new/deferred, not_ready, no approved value/actor/time/publication;
  no edit-and-approve and no bulk/automatic approvals.
- Local reviewer capability, actor-specific/version-bound preview token, nonce,
  backup acknowledgment and explicit APPROVE_ONE_CLAIM confirmation.

The feature gate is ADE_LOCAL_POSITIVE_REVIEW_ENABLED === true, undefined/OFF
by default. Do not enable it or change user wp-config during development.
CLI additionally requires the existing local manage-jobs/CLI guard; nonce is
created for that authenticated CLI operator after the guard. Future web entry
points must obtain and validate their own submitted nonce; none added here.

## Read-only preview

Only if legitimate stored records already exist, substitute their actual IDs:

```
wp --user="admin" ade pilot approve_stage --npsn=NPSN --candidate-id=CANDIDATE --evidence-id=EVIDENCE --attestation-id=GRANT --dry-run
```

This SELECT-only command does not approve, fetch, or write. It returns proposed
value (treat as untrusted text), before/after status, version and preview token.
It is a transient preview, not a persistent authorization. Bootstrap and admin
page loads do not parse raw, fetch references, or approve anything. The general
archive verifier's old POSITIVE_REVIEW_NOT_IMPLEMENTED blocker denotes its own
non-approval route; it is not an approval API and still always returns not-ready.
Historical declaration hashes are deliberately preserved.

## Explicit write contract (not instructions to run on user data now)

`approve_record --request-file=PATH --backup-confirmed=YES --confirm=APPROVE_ONE_CLAIM`
accepts max8KiB strict local JSON with exactly seven fields: npsn string,
candidate_id/evidence_id/attestation_id/row_version positive integers, note plain
UTF-8 10..500 bytes (no HTML/control/bidi), preview_token64hex. It cannot edit the
candidate or choose a replacement value. Writer checks OFF before file/database.
Service ADE_Positive_Review::record additionally requires nonce, confirm and
backup_confirmed; CLI injects those only after its explicit guards.

After shared per-school M2/M3/raw/attestation advisory mutex, a short transaction:

1. Reads and validates a historical receipt for exact retry, if any.
2. Locks grant and potential withdrawal by unique job key with CURRENT reads.
3. Rechecks current raw, candidate/evidence/link/source and verified target value
   under FOR UPDATE NOWAIT, from first read, not an older RR snapshot.
4. Rechecks declaration binding, expiry, mutable state, version and preview token.
5. CAS updates only Discovery candidate: approved_value=unchanged proposed value,
   review_status=approved, reviewer/time, row_version+1. publish_status remains
   not_ready, published_local_at NULL; identity/confidence fields unchanged.
6. Appends one reviews audit (value, actor, note, attestation binding/expiry,
   before/after versions, independent-verification=false) and one jobs receipt.
7. Commits all three or rolls them back and releases mutex.

Receipt plus exact bounded audit are checked on retry. An exact retry returns
historical=true and database_writes0, even if permission has since been withdrawn.
This does NOT report current permission. New differing decisions cannot silently
replace approved content. Review and attestation job types are not queue tasks.
Receipts/hashes are integrity checks, not signatures against a database admin.

## Withdrawal and rollback

Withdrawing a grant after approval keeps the decision/audit historical and makes
the grant unusable for any future publication check. It does not rewrite approved
status, revoke a whole domain, delete an audit or automatically unpublish anything.
There is no publisher in this version. A future publisher MUST lock and validate
latest grant/withdrawal/raw/target, not trust approved status or an old receipt.

On pre-commit failure candidate/audit/receipt roll back. A failed COMMIT response
can be ambiguous; retry exact request with fresh valid nonce to resolve receipt.
No manual deletion of events or resetting approved fields. File rollback to7.13
requires local backup, keeps all Discovery data. Previous versions do not have a
publisher either. Actual user operations/enablement require scoped permission.

## Evidence and remaining gates

See docs/qa/dev7.14 for final counts/logs. Actual WordPress7.1.4/Directory0.8.9/
wpdb/nonces and MySQL8.4 synthetic tests cover OFF, reviewer capability, nonce,
confirmation, schema/text input, IDOR, withdrawal after preview, every SQL write
failure + COMMIT failure, atomic rollback, exact replay, immutable approval and
postapproval withdrawal. Two-session tests create old RR snapshots, then change
candidate version or insert a synthetic revocation in the other session; approval
must reject. All25 legacy synthetic table hashes stay equal. Containers/sites/
servers are owned test resources and removed. Official CLI parser is tested
separately offline; full official runner and user LocalWP are not E2E-tested.

Still missing: positive admin form, edit workflow, durable extraction leaseworker,
controlled publisher/undo, raw retention/encryption/quota, real-source permissions
and evidence, frontend/SEO/load acceptance. Actual factual enrichment0/200.
