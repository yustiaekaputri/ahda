# AHDA development checkpoint

Date: 2026-11-09. Status: M1 PARTIAL — offline development increment complete;
real transport and LocalWP integration gates remain OPEN.

## Contracts and authorization

Read uploaded AHDA_AGENTS.md and AHDA_Codex_Master_Prompt_FastTrack.md in full;
copied them to repository root as AGENTS.md and master prompt. Continue actual
R4a, never rebuild the directory. User supplied both baseline ZIPs and approved
PHP tooling downloads. No live crawl, real DB write, production access, LocalWP
installation or publication has been executed. Production ahda.sch.id excluded.

## Source and changes

Original ZIPs preserved; extracted baseline under baseline/ with hashes in
qa/baseline-files.json. Directory unchanged. Development source is under
`development/ahda-discovery-engine`, version `0.1.0-dev.6.0`.

Added crawl policy, disabled pinned cURL adapter, frozen NPSN pilot validator,
read-only source-planning batches, separate m1_discovery_plan jobs with confirmed
local capability gate, leases/fencing, transaction checkpoint, resume, retry,
cancel, status and integrity-check. New ade pilot CLI registers only; no startup
network/cron/write. R2/R3/R4a code/schema remain unchanged except bootstrap/main
loads and version. New job type does not fetch, extract, verify or publish.

Changed/new file list and patch: docs/qa/development-diff.patch.
LocalWP guide and risks: development plugin docs/M1_LOCALWP.md and M1_QA.md.

## Tests

Logs: docs/qa/offline-tests.json and lint-php8.2.json / lint-php8.4.json.
PHP 8.2.32 and 8.4.24 run with -n. Six original Discovery suites pass (149 checks
per runtime), plus four new M1 suites; exact counts are in the logs. All ten
Directory standalone smoke suites pass under mocks. All PHP source files lint.
These are offline fixtures, not the user's schools, WordPress or MySQL proof.

## Known findings and unfinished work

- Actual Directory visibility is publish; some old fixtures use published.
- R1 legacy_hash is schema metadata only, not row data integrity.
- Old manual CLI lacks explicit capability checks in some paths; audit further.
- Native crawler remains hard-disabled and has no CLI fetch entrypoint.
  Need bounded DNS, durable per-host throttle across runs, real transport tests,
  and approved robots/terms/source policy before exposure. Generic proxy denied.
- Full manual parent-plugin security audit remains incomplete.
- Real LocalWP/MySQL integration: NOT TESTED. No real frozen pilot list supplied.
- M2 extraction/evidence/candidates, M3 admin review, M4 publication: NOT STARTED.
- Packaging is a development handoff only; production readiness NOT established.

## Next session

Do not repeat source inventory or passed offline suites unless code changes.
Read QA and handoff, review targeted diff and original hashes. Finish remaining
M1 transport/policy gates, extend CLI security review, and obtain the explicit
200-NPSN file. LocalWP is on user's machine, not cloud localhost. Before real DB,
network or install actions present exact impact and obtain scoped approval.
Never access wp-config.php/secrets, reimport, rebuild, or deploy production.
After an approved LocalWP planning test, record actual outputs and continue M2.
Rollback is restoring the original Discovery R4a ZIP on an approved backed-up
local installation; preserve M1 job rows and all legacy data, never drop tables.


## National NPSN input — follow-up 2026-11-09

User supplied nationwide text, not an explicitly frozen 200-school pilot.
Offline analysis/export DONE. 555,463 entries, 555,460 unique; duplicate codes
69931346, 70005045, 70005078 each occur twice. Unique partition: 530,732 eight-digit
numeric codes and 24,728 uppercase alphanumeric eight-character codes. Preserve
alphanumeric codes; existing numeric-only R3/M1 validation remains unchanged.
Matching counts alone do not establish matching database identities.

Outputs: data/npsn-national-2026-11-09/{master-unique.txt,
numeric8-pilot-compatible.txt,alphanumeric8-review.txt,report.json,README.md}.
New utility: tools/validate_npsn_master.py; tests/test_npsn_master.py.
Four Python unit tests PASS; national uniqueness/partition/hash checks PASS.
Evidence: docs/qa/npsn-master-tests.txt. No PHP plugin changes, so previous PHP
results stand without unrelated reruns. Existing development ZIP unchanged.
Original upload preserved; no network, real DB operations or pilot selection.
Next: explicit pilot selection and read-only matching against existing school
index (with school level and region); never treat numeric syntax as eligibility.
LocalWP database access is still unavailable in this cloud session.


## Regional pilot scope — follow-up 2026-11-09

User selected Jawa Barat and Jawa Tengah. Default documented allocation is 100
schools each, eligible forms SMA/SMK/MA/SMAK with visibility publish. Deterministic
ascending school_id within each province, intersecting the supplied national
master; never infer region from NPSN prefixes. No real schools selected yet.

Prepared data/pilot-jabar-jateng/scope.json, README.md and a read-only SQL export
template using the actual Directory schools schema and shipped regency map:
27 mapped Jabar regencies/cities (32), 35 Jateng (33). Query returns at most 1000
candidates per province, six school identity/classification columns only; actual
WP prefix must replace the placeholder. Query NOT EXECUTED; no DB connection.

Added tools/select_regional_pilot.py and tests/test_regional_pilot.py. Four unit
tests PASS: balanced stable selection, insufficient/master mismatch fails closed,
wrong region/level/visibility/formula/alpha rejection, duplicates and header checks.
QA log: docs/qa/regional-pilot-tests.txt. No PHP or ZIP changes.

Next external input: CSV from read-only LocalWP export containing school_id,
npsn,school_form,regency_raw,visibility,province_code. National NPSNs alone do not
contain these attributes. Do not invent or silently guess region/level. After
receipt run the selector, verify 100+100 and publish the frozen pilot file for
review; this does not authorize network/DB mutation/publication. Keep all existing
crawl and production gates. Rollback new tooling/docs/output only; no DB changes.


## Scope correction — latest user instruction 2026-11-09

SUPERSEDES the two-province 100+100 allocation and prior level restriction.
Select at most 200 STATE schools in JAWA BARAT ONLY. Prioritize SMP/MTs; only
if fewer than 200 exist, fill remaining slots with MA/SMA/SMK negeri in Jawa
Barat. Do not include Jateng, other provinces or private schools. Use explicit
ownership and province/regency evidence, never name/NPSN-prefix guesses. Stable
NPSN ordering per tier is a routine implementation default. If combined eligible
count is below 200, report shortage rather than relaxing constraints.

New uploaded ahda-nasional-2026.csv could NOT be transferred: download_file
returned "file exceeds the executor transfer limit of 32 MiB". Actual byte size,
CSV headers, contents and eligibility counts are UNKNOWN; no local CSV exists.
Tool discovery found no alternate upload/range-reading facility. No repeated
transfer attempts or invented results. Need ZIP <=32 MiB or smaller CSV parts
(with headers) / a Jabar-only export; keep original content and string NPSNs.

Saved current criteria in data/pilot-jabar-negeri/scope.json; prior regional scope
and README explicitly marked SUPERSEDED. No selection or output pilot yet.
No source/plugin/runtime/DB changes, network crawl or production action. No tests
run for this documentation-only scope correction. Existing M1 PHP eligibility
still excludes SMP/MTs: update + regression-test before feeding this new pilot to
M1. The old Python two-province selector must NOT be run for the new scope.


## Tasikmalaya workbook selection — 2026-11-09

Latest user supplied kab ko tasikmalaya.xlsx and instructed selection from it.
Input transferred successfully (464049 bytes), SHA-256:
fd02a73281cc85b9580b04a05c6e9f370421df8068cc3e615f4e1abfb81b4946.
One worksheet, 5763 data rows, 12 explicit classification columns. Only KAB.
TASIKMALAYA (4503) and KOTA TASIKMALAYA (1260); both map to Jabar code32.
Status explicitly NEGERI/SWASTA; no formulas or duplicate source NPSNs found.

235 eligible state candidates all match supplied national master: priority177
(SMP159/MTS18), fallback58 (MA10/SMA30/SMK18). Selected all priority177 plus
23 lowest-NPSN candidates from combined fallback: SMA21/SMK2, MA0. No quality
ranking implied. Final200: Kabupaten164, Kota36, all negeri, none outside Jabar.
Selection is now OFFLINE FROZEN; no random choice or live database validation.

Files: tools/select_tasikmalaya_pilot.py, tests/test_tasikmalaya_pilot.py;
outputs under data/pilot-jabar-negeri/tasikmalaya-200/ (TXT, CSV, JSON, XLSX,
report, README). scope.json updated. Six unit tests PASS plus actual source-row,
master membership, uniqueness, state/region/priority, hashes and generated XLSX
reopen/no-formula checks PASS. Log: docs/qa/tasikmalaya-selection-tests.txt.
Pilot TXT SHA-256: 42aaa7c51d5e0163c08146d1c46df70e260496639b9a3cc55e34f58781b1af20.

No PHP/ZIP changes or repeated unrelated PHP suites. No DB, network crawl,
publication or production operations. Important next work: M1 dev.6.0 currently
excludes SMP/MTS; update allowed forms under latest user scope, add regressions,
then validate frozen identities/ownership/region against read-only LocalWP data
before any approved write/run. Workbook validation is not proof of live DB or
independent official school verification. Rollback generated local files only;
original workbook and legacy records remain intact.


## Continued integration — dev.6.1 / 2026-11-09

User said "lanjutkan". Completed safe M1 integration for the selected 200:
- New pinned reference class and bundled 200-NPSN TXT/classification JSON.
- Scoped manifest JSON v2 binds NPSNs, current database IDs and reference SHA;
  database schema stays 1, no DDL and no parent/legacy record changes.
- Identity lookup_pilot adds ownership_status via SELECT; validates table prefix.
  Existing R3 lookup shape retained; original regressions unchanged.
- SMP/MTS support; scope requires frozen school form, NEGERI and exact Tasikmalaya
  regency. Checks at freeze and every batch, including resume after changes.
- Current CLI cannot enqueue unscoped jobs or run legacy unscoped jobs. Legacy
  reading/recovery/cancel and API compatibility remain; no data rewritten.
- CLI preflight defaults to bundled list, checks all200 with passed/failed/unrun
  and safe issue codes. Preview remains SELECT-only, defaults10, no fetch.
- All CLI mutations now reject --dry-run and require explicit matching confirm.

Canonical results in docs/qa/dev6.1: 12 suites on PHP8.2.32 and PHP8.4.24, 482
checks per runtime, all PASS; 39 development PHP files lint each PASS. Original
six R2/R3/R4a suite files byte-identical; all84 original baseline file hashes match.
New tests cover scope, reclassification/ownership/region, unknown/changed IDs,
SQL identifier/NPSN injection, preflight counts/errors, dry-run zero-query,
permissions, no legacy mixing, scoped enqueue/dedupe, failed scope checkpoint,
20 resumable fake batches and reference integrity. Actual NPSNs/classification
are fixture input only; database IDs and DB engine remain synthetic.
Independent temp-copy tamper test PASS; extracted ZIP offline runner PASS.

Artifact: artifacts/AHDA_Discovery_Engine_M1_Tasikmalaya_0.1.0-dev.6.1.zip.
Full changed-file list/diff/logs/checksums: docs/qa/dev6.1/. Previous dev.6.0 ZIP
preserved. New ZIP guides under plugin docs/M1_LOCALWP.md and M1_QA.md.
Frozen list unchanged, SHA 42aaa7c51d5e0163c08146d1c46df70e260496639b9a3cc55e34f58781b1af20.

Current-instance writes: code/local generated artifacts ONLY. No real DB,
network crawl, plugin installation/activation, production or publication.
Crawler remains hard-disabled; full DNS/transport/durable throttle gate OPEN.
LocalWP/MySQL8.4 integration NOT TESTED: user's ahda.local is not available in
this cloud executor. Full parent security audit and old manual CLI capability
hardening remain outstanding. M2 extraction/candidates, M3 review and M4 local
publisher still NOT IMPLEMENTED; do not call the MVP complete or production-ready.

Next action: user runs approved backed-up LocalWP installation and read-only
pilot preflight/preview according to handoff, then provides actual safe report.
Do not repeat passed offline audits without changes. Resolve classification or
identity mismatches without altering legacy data. Obtain scoped explicit approval
before any real job write, crawl or publish; no production scope. Continue M1
source permission/transport gates then M2 when prerequisites permit.
Rollback: restore original R4a ZIP locally after backup/approval; do not delete
M1 job rows or alter Directory. R4a ignores new job type. Dev.6.0 cannot process
new scoped v2 jobs; retain dev.6.1 for diagnosis rather than downgrading job data.


## GitHub artifact delivery — 2026-11-09

User explicitly approved uploading the prepared delivery branch and instructed
future package delivery via GitHub. Do not request the same upload authorization
again for routine future AHDA package delivery; preserve production/network/DB
approval gates. Avoid chat artifact links for this user.

Pushed ONLY ZIP + LocalWP delivery guide to GitHub yustiaekaputri/ahda,
branch delivery/tasikmalaya-dev6.1. Remote ref verified with git ls-remote:
62f2bd26cf42b2fd161b74bdfd7a31311f8868a3.
Files in uploaded commit:
- artifacts/AHDA_Discovery_Engine_M1_Tasikmalaya_0.1.0-dev.6.1.zip
- artifacts/LOCALWP-DELIVERY-dev6.1.md
ZIP SHA256 60a47eb5e6485b680ff152a04eb243a51bbcf7fe872e81098fe785d42d650f41.
No main-branch update/merge, production deployment or LocalWP operations.
The full workspace source/checkpoint remains local; this delivery commit contains
only the two listed files. The plugin source/tests/docs are included inside ZIP.


## LocalWP feedback + dev.6.2 source inventory — 2026-11-09

USER-REPORTED actual LocalWP output received, stored in
`docs/qa/localwp-dev6.1-user-report.json` (not cloud-executed).
- dev.6.1 schema postflight INSTALLED, complete,7 tables,0 missing, schema1.
- legacy METADATA SHA fbd684d9502cfe8cab5d91068f7c6829197837b3e2d29f67068f5c8076ada3b6.
- scope hash matches pinned reference; pilot200 checked/passed,0 failed/unrun.
- preview first10 successful, cursor27323, all10 Discovery links0/needs_source.
- DB-bound manifest hash c804d6044cbbf14f02178647a416c6f71118726517b3320b2dc96bcbe2d08dca.
This validates read-only scope/classification on user's installation, NOT actual
job writes, MySQL transactions, evidence record, native fetch, full200 sources or
absence of URLs from legacy metadata. Initial username placeholder failed;
operator then successfully used --user="admin". Use admin in future instructions.

Added dev.6.2 Source_Inventory and `wp ade pilot source-preview` command. SELECTs
only verified profile_website/profile_source_url metadata, official_website on
details, and four supported social platform URLs. Does not read contacts or pupil
data. Three bounded indexed reads per school, batch1–20; validates current frozen
scope via existing batch reader. Canonical dedupe retains origins; all new hints
remain pending/manual_only/fetch_permission NOT_GRANTED. Rejects unsafe formats,
platform mismatch, and sensitive query keys without echoing values. SQL/row
integrity errors fail closed rather than returning needs_source. No new writes.

13 suites PASS PHP8.2.32/8.4.24,512 checks per runtime;41 PHP files lint PASS.
New inventory suite30 checks, including CLI, dedupe, scope/permission, SQL failure,
query caps, sensitive tokens and cursor continuation. Full original regressions
and original84 baseline hashes unchanged. Logs/diff in docs/qa/dev6.2/.
One initial fixture error (invalid Facebook profile underscore) was corrected to
exercise valid-URL platform mismatch; final assertions unchanged/passing.

Packaged dev.6.2 for GitHub delivery per persistent user authorization; no main
merge, production, LocalWP install, real database write or live crawl by cloud.
Next external check: operator replaces ONLY Discovery on backed-up LocalWP, then
runs `wp --user="admin" ade pilot source-preview --batch-size=10 --dry-run` and
provides output. Avoid rerunning prior passed schema/pilot checks unnecessarily.
If hints exist, review source access/identity and obtain scoped approvals before
persistence or fetch. If no verified hints, source discovery still requires an
allowed source list/search adapter; do not enqueue empty planning work as a fix.
M2/extraction/candidates, M3/admin review and M4/publication remain unimplemented.
Crawl transport/DNS/durable-throttle gates remain open; no production readiness.
Rollback dev.6.2 to dev.6.1 after normal local backup/approval: no schema or data
migration, existing scoped v2 jobs remain compatible. Original R4a ZIP preserved.
