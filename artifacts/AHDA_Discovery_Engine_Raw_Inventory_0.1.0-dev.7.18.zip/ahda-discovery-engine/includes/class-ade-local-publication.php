<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Explicit single-school local publication; never a worker or production adapter. */
final class ADE_Local_Publication {
    public const APPLY = 'm4_local_publish';
    public const UNDO = 'm4_local_undo';
    public static function enabled(): bool { return defined( 'ADE_LOCAL_PUBLISH_ENABLED' ) && ADE_LOCAL_PUBLISH_ENABLED === true; }
    private static function guard( bool $write = false ): int {
        if ( $write && ! self::enabled() ) { throw new RuntimeException( 'PUB_WRITES_DISABLED' ); }
        ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
        if ( ! current_user_can( 'manage_options' ) || ! current_user_can( 'ade_review_candidates' ) || (int) get_current_user_id() < 1 || ! defined( 'AHDA_DIRECTORY_VERSION' ) || AHDA_DIRECTORY_VERSION !== '0.8.9' ) { throw new RuntimeException( 'PUB_ADMIN_COMPATIBILITY_GATE' ); }
        return (int) get_current_user_id();
    }
    private static function school_scope( string $npsn ): bool { return defined( 'ADE_LOCAL_PUBLISH_NPSN' ) && is_string( ADE_LOCAL_PUBLISH_NPSN ) && ADE_LOCAL_PUBLISH_NPSN === $npsn && ADE_Pilot_Scope::contains( $npsn ); }
    private static function consent( string $npsn, string $actual, string $expected, string $backup ): void {
        if ( ! self::school_scope( $npsn ) || $actual !== $expected || $backup !== 'YES' ) { throw new RuntimeException( 'PUB_EXPLICIT_SINGLE_SCHOOL_CONSENT_REQUIRED' ); }
    }
    private static function rows( string $sql, array $args = array() ): array {
        global $wpdb; $wpdb->last_error = ''; $r = $wpdb->get_results( $args ? $wpdb->prepare( $sql, $args ) : $sql, ARRAY_A );
        if ( ! is_array( $r ) || $wpdb->last_error ) { throw new RuntimeException( 'PUB_READ_FAILED' ); } return $r;
    }
    private static function one( string $sql, array $args = array() ): ?array { $r = self::rows( $sql, $args ); if ( count( $r ) > 1 ) { throw new RuntimeException( 'PUB_ROW_NOT_UNIQUE' ); } return $r[0] ?? null; }
    private static function query( string $sql, array $args = array() ): int {
        global $wpdb; $wpdb->last_error = ''; $r = $wpdb->query( $args ? $wpdb->prepare( $sql, $args ) : $sql ); if ( false === $r || $wpdb->last_error ) { throw new RuntimeException( 'PUB_WRITE_FAILED' ); } return (int) $r;
    }
    private static function insert( string $suffix, array $data ): int {
        if ( ! in_array( $suffix, array( 'reviews', 'jobs' ), true ) ) { throw new RuntimeException( 'PUB_TABLE_BLOCKED' ); } global $wpdb; $wpdb->last_error = '';
        if ( false === $wpdb->insert( ADE_Schema::table_name( $suffix ), $data ) || $wpdb->last_error || (int) $wpdb->insert_id < 1 ) { throw new RuntimeException( 'PUB_INSERT_FAILED' ); } return (int) $wpdb->insert_id;
    }
    private static function meta_table(): string { global $wpdb; $t = $wpdb->prefix . 'ahda_school_meta'; if ( ! preg_match( '/^[a-zA-Z0-9_]{1,64}$/D', $t ) ) { throw new RuntimeException( 'PUB_IDENTIFIER_INVALID' ); } return $t; }
    private static function schema(): string {
        global $wpdb; $t = self::meta_table(); $status = self::one( 'SHOW TABLE STATUS LIKE %s', array( $wpdb->esc_like( $t ) ) );
        if ( ! $status || strtolower( (string) ( $status['Engine'] ?? '' ) ) !== 'innodb' ) { throw new RuntimeException( 'PUB_NONTRANSACTIONAL_TARGET' ); }
        $cols = self::rows( "SHOW FULL COLUMNS FROM {$t}" ); $spec = array(); foreach ( $cols as $c ) { $spec[$c['Field']] = array( $c['Type'], $c['Null'], $c['Extra'], $c['Collation'] ); } ksort( $spec );
        $keys = array( 'id', 'school_id', 'meta_key', 'meta_value', 'verification_status', 'source_id', 'updated_at' ); sort( $keys );
        if ( array_keys( $spec ) !== $keys ) { throw new RuntimeException( 'PUB_SCHEMA_UNSUPPORTED' ); }
        if ( ! is_string( $spec['meta_value'][3] ) || strpos( $spec['meta_value'][3], 'utf8mb4_' ) !== 0 ) { throw new RuntimeException( 'PUB_CHARSET_UNSUPPORTED' ); }
        if ( self::rows( 'SELECT TRIGGER_NAME FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE() AND EVENT_OBJECT_TABLE=%s LIMIT 1', array( $t ) ) ) { throw new RuntimeException( 'PUB_TRIGGER_UNSUPPORTED' ); }
        $unique = array(); foreach ( self::rows( "SHOW INDEX FROM {$t}" ) as $index ) { if ( (int) $index['Non_unique'] === 0 ) { $unique[$index['Key_name']][(int) $index['Seq_in_index']] = $index['Column_name']; } }
        $found = false; foreach ( $unique as $parts ) { ksort( $parts ); if ( array_values( $parts ) === array( 'school_id', 'meta_key' ) ) { $found = true; } }
        if ( ! $found ) { throw new RuntimeException( 'PUB_UNIQUE_TARGET_REQUIRED' ); } return ADE_Local_Archive::digest( array( 'innodb', $spec, array( 'school_id', 'meta_key' ) ) );
    }
    private static function meta( int $school, string $key, bool $lock ): ?array {
        if ( ! in_array( $key, array( 'profile_programs', 'profile_curriculum', 'profile_hours', 'profile_source_url' ), true ) ) { throw new RuntimeException( 'PUB_TARGET_BLOCKED' ); }
        $t = self::meta_table(); $end = $lock ? ' FOR UPDATE NOWAIT' : '';
        $r = self::one( "SELECT id,school_id,meta_key,LEFT(meta_value,16385) AS meta_value,OCTET_LENGTH(meta_value) AS value_bytes,verification_status,source_id,updated_at FROM {$t} WHERE school_id=%d AND meta_key=%s LIMIT 2{$end}", array( $school, $key ) );
        if ( ! $r ) { return null; }
        if ( $r['meta_key'] !== $key || (int) $r['school_id'] !== $school ) { throw new RuntimeException( 'PUB_META_KEY_NONCANONICAL' ); }
        if ( (int) $r['value_bytes'] > 16384 || ( null !== $r['meta_value'] && ! is_string( $r['meta_value'] ) ) || ! is_string( $r['verification_status'] ) || ! is_string( $r['updated_at'] ) ) { throw new RuntimeException( 'PUB_META_INVALID' ); }
        $date = DateTimeImmutable::createFromFormat( '!Y-m-d H:i:s', $r['updated_at'], new DateTimeZone( 'UTC' ) );
        if ( ! $date || $date->format( 'Y-m-d H:i:s' ) !== $r['updated_at'] || (string) (int) $r['id'] !== (string) $r['id'] || (int) $r['id'] < 1 || ( null !== $r['source_id'] && ! preg_match( '/^[0-9]{1,20}$/D', (string) $r['source_id'] ) ) ) { throw new RuntimeException( 'PUB_META_INVALID' ); }
        unset( $r['value_bytes'] ); $r['id'] = (int) $r['id']; $r['school_id'] = (int) $r['school_id']; if ( null !== $r['source_id'] ) { $r['source_id'] = (string) $r['source_id']; } return $r;
    }
    private static function school( string $npsn, bool $lock, bool $undo ): array {
        global $wpdb; $table = $wpdb->prefix . 'ahda_schools';
        if ( ! preg_match( '/^[a-zA-Z0-9_]{1,64}$/D', $table ) ) { throw new RuntimeException( 'PUB_IDENTIFIER_INVALID' ); }
        $end = $lock ? ' FOR UPDATE NOWAIT' : '';
        $school = self::one( "SELECT id,npsn,name,school_form,education_level,ownership_status,regency_raw,district_raw,village_raw,visibility FROM {$table} WHERE npsn=%s LIMIT 2{$end}", array( $npsn ) );
        if ( ! $school || (int) $school['id'] < 1 || $school['npsn'] !== $npsn ) { throw new RuntimeException( 'PUB_SCHOOL_IDENTITY_CHANGED' ); }
        // Retraction may restore owned metadata while school remains hidden. Never unhide it.
        $check = $school; if ( $undo ) { $check['visibility'] = 'publish'; } ADE_Pilot_Scope::assert_school( $check ); return $school;
    }
    private static function candidate( string $npsn, int $id, bool $lock, bool $undo = false ): array {
        if ( ! ADE_Pilot_Scope::contains( $npsn ) || $id < 1 ) { throw new InvalidArgumentException( 'PUB_SCOPE_INVALID' ); } $school = self::school( $npsn, $lock, $undo );
        $t = ADE_Schema::table_name( 'candidates' ); $end = $lock ? ' FOR UPDATE NOWAIT' : '';
        $r = self::one( "SELECT id,school_id,target_key,LEFT(proposed_value,501) AS proposed_value,OCTET_LENGTH(proposed_value) AS proposed_bytes,LEFT(approved_value,501) AS approved_value,OCTET_LENGTH(approved_value) AS approved_bytes,base_target_hash,review_status,publish_status,row_version,approved_by_user_id,approved_at,published_local_at FROM {$t} WHERE id=%d AND school_id=%d AND candidate_type=%s AND target_type=%s LIMIT 2{$end}", array( $id, (int) $school['id'], 'm2_meta_text_v1', 'school_meta' ) );
        if ( ! $r || ! in_array( $r['target_key'], array( 'profile_programs', 'profile_curriculum', 'profile_hours' ), true ) || $r['review_status'] !== 'approved' || ! is_string( $r['approved_value'] ) || $r['approved_value'] !== $r['proposed_value'] || (int) $r['approved_bytes'] > 500 || (int) $r['proposed_bytes'] > 500 || (int) $r['approved_by_user_id'] < 1 || ! is_string( $r['approved_at'] ) || (int) $r['row_version'] < 2 ) { throw new RuntimeException( 'PUB_APPROVED_CANDIDATE_REQUIRED' ); }
        foreach ( array( 'id', 'school_id', 'row_version', 'approved_by_user_id' ) as $key ) { $r[$key] = (int) $r[$key]; } return $r;
    }
    private static function audit_row( int $id, bool $lock ): array {
        $t = ADE_Schema::table_name( 'reviews' ); $end = $lock ? ' FOR UPDATE NOWAIT' : '';
        $r = self::one( "SELECT id,candidate_id,school_id,review_action,before_status,after_status,candidate_version,LEFT(reviewed_value,501) AS reviewed_value,OCTET_LENGTH(reviewed_value) AS value_bytes,reason_code,LEFT(review_notes,8193) AS review_notes,OCTET_LENGTH(review_notes) AS notes_bytes,user_id,created_at FROM {$t} WHERE id=%d LIMIT 2{$end}", array( $id ) );
        if ( ! $r || (int) $r['value_bytes'] > 500 || (int) $r['notes_bytes'] > 8192 ) { throw new RuntimeException( 'PUB_AUDIT_INVALID' ); }
        unset( $r['value_bytes'], $r['notes_bytes'] ); foreach ( array( 'id', 'candidate_id', 'school_id', 'candidate_version', 'user_id' ) as $k ) { $r[$k] = (int) $r[$k]; } return $r;
    }
    private static function approval( string $npsn, array $c, bool $lock ): array {
        $rt = ADE_Schema::table_name( 'reviews' ); $jt = ADE_Schema::table_name( 'jobs' ); $end = $lock ? ' FOR UPDATE NOWAIT' : '';
        $ids = self::rows( "SELECT id FROM {$rt} WHERE candidate_id=%d AND school_id=%d AND review_action='approve' ORDER BY id DESC LIMIT 2{$end}", array( $c['id'], $c['school_id'] ) );
        if ( count( $ids ) !== 1 ) { throw new RuntimeException( 'PUB_POSITIVE_AUDIT_REQUIRED' ); } $a = self::audit_row( (int) $ids[0]['id'], $lock ); $n = ADE_Strict_JSON::decode( $a['review_notes'], 8192 );
        $op = $n['operation_key'] ?? ''; if ( ! is_string( $op ) || ! preg_match( '/^[a-f0-9]{64}$/D', $op ) ) { throw new RuntimeException( 'PUB_APPROVAL_PROOF_INVALID' ); }
        $job = self::one( "SELECT status,LEFT(scope_filter,8193) AS scope_filter,OCTET_LENGTH(scope_filter) AS scope_bytes,LEFT(stats_payload,4097) AS stats_payload,OCTET_LENGTH(stats_payload) AS stats_bytes FROM {$jt} WHERE job_key=%s AND job_type=%s LIMIT 1{$end}", array( $op, ADE_Positive_Review::TYPE ) );
        if ( ! $job || $job['status'] !== 'completed' || (int) $job['scope_bytes'] > 8192 || (int) $job['stats_bytes'] > 4096 ) { throw new RuntimeException( 'PUB_APPROVAL_PROOF_INVALID' ); }
        $m = ADE_Strict_JSON::decode( $job['scope_filter'], 8192 ); $s = ADE_Strict_JSON::decode( $job['stats_payload'], 4096 ); $audit = $a; unset( $audit['id'] );
        if ( ( $m['actor'] ?? null ) !== $c['approved_by_user_id'] || ( $m['request']['npsn'] ?? null ) !== $npsn || ( $m['request']['candidate_id'] ?? null ) !== $c['id'] || ( $m['request']['row_version'] ?? null ) !== $a['candidate_version'] || ( $m['audit'] ?? null ) !== $audit || ( $m['result_hash'] ?? null ) !== ADE_Local_Archive::digest( $s ) || ( $s['operation_key'] ?? null ) !== $op || ( $s['audit_id'] ?? null ) !== $a['id'] || ( $s['candidate_id'] ?? null ) !== $c['id'] || ( $s['after_status'] ?? null ) !== 'approved' || $a['reviewed_value'] !== $c['approved_value'] || $a['user_id'] !== $c['approved_by_user_id'] || $a['created_at'] !== $c['approved_at'] || ( $n['schema_version'] ?? null ) !== 1 || ( $n['after_version'] ?? null ) !== $a['candidate_version'] + 1 || $n['after_version'] > $c['row_version'] || ( $n['independently_verified'] ?? null ) !== false || $op !== ADE_Local_Archive::digest( array( ADE_Positive_Review::TYPE, ADE_Pilot_Scope::SHA256, $m['actor'], $c['school_id'], $m['request'] ) ) ) { throw new RuntimeException( 'PUB_APPROVAL_PROOF_INVALID' ); }
        return array( 'audit_id' => $a['id'], 'operation_key' => $op );
    }
    private static function context( string $npsn, int $candidate, int $evidence, int $grant, bool $lock ): array {
        if ( min( $candidate, $evidence, $grant ) < 1 ) { throw new InvalidArgumentException( 'PUB_SCOPE_INVALID' ); } $schema = self::schema(); $c = self::candidate( $npsn, $candidate, $lock );
        if ( ! in_array( $c['publish_status'], array( 'not_ready', 'rolled_back_local' ), true ) || null !== $c['published_local_at'] ) { throw new RuntimeException( 'PUB_STATE_LOCKED' ); }
        $approval = self::approval( $npsn, $c, $lock ); $att = ADE_Source_Attestation::approval_context( $grant, $npsn, $candidate, $evidence, $lock ); $et = ADE_Schema::table_name( 'evidence' ); $end = $lock ? ' FOR UPDATE NOWAIT' : '';
        $e = self::one( "SELECT evidence_url FROM {$et} WHERE id=%d AND school_id=%d LIMIT 2{$end}", array( $evidence, $c['school_id'] ) ); if ( ! $e || ! is_string( $e['evidence_url'] ) ) { throw new RuntimeException( 'PUB_CITATION_REQUIRED' ); }
        ADE_Local_Archive::document( 'citation', 'csv', $e['evidence_url'], '2026-01-01T00:00:00Z', 'local-publication-citation' );
        $before = array( $c['target_key'] => self::meta( $c['school_id'], $c['target_key'], $lock ), 'profile_source_url' => self::meta( $c['school_id'], 'profile_source_url', $lock ) ); $old = $before[$c['target_key']];
        $verified = $old && $old['verification_status'] === 'verified' ? $old['meta_value'] : null;
        if ( ! is_string( $c['base_target_hash'] ) || $c['base_target_hash'] !== ADE_Local_Archive::digest( array( 'm2-meta-snapshot-v1', $c['school_id'], $c['target_key'], $verified ) ) ) { throw new RuntimeException( 'PUB_BASE_HASH_CONFLICT' ); }
        if ( $old && $old['verification_status'] === 'verified' && $old['meta_value'] === $c['approved_value'] ) { throw new RuntimeException( 'PUB_NO_CHANGE' ); }
        $source = $before['profile_source_url']; if ( $source && null !== $source['meta_value'] && $source['meta_value'] !== '' && $source['meta_value'] !== $e['evidence_url'] ) { throw new RuntimeException( 'PUB_CITATION_CONFLICT' ); }
        return array( 'npsn' => $npsn, 'candidate' => $c, 'approval' => $approval, 'attestation' => $att, 'schema_sha256' => $schema, 'source_url' => $e['evidence_url'], 'before' => $before, 'citation_changes' => ! $source || $source['verification_status'] !== 'verified' || $source['meta_value'] !== $e['evidence_url'] );
    }
    private static function token( array $c, int $actor ): string { return ADE_Local_Archive::digest( array( 'local-publication-plan-v1', $actor, ADE_Pilot_Scope::SHA256, $c ) ); }
    public static function plan( string $npsn, int $candidate, int $evidence, int $grant ): array {
        $actor = self::guard(); $c = self::context( $npsn, $candidate, $evidence, $grant, false ); return array( 'mode' => 'READ_ONLY_LOCAL_PUBLICATION_PLAN', 'npsn' => $npsn, 'candidate_id' => $candidate, 'evidence_id' => $evidence, 'attestation_id' => $grant, 'row_version' => $c['candidate']['row_version'], 'target_key' => $c['candidate']['target_key'], 'old_target' => $c['before'][$c['candidate']['target_key']], 'approved_value' => $c['candidate']['approved_value'], 'old_source' => $c['before']['profile_source_url'], 'source_url' => $c['source_url'], 'source_will_change' => $c['citation_changes'], 'declaration' => ADE_Source_Attestation::declaration_for_review( $grant, $npsn, $candidate, $evidence ), 'preview_token' => self::token( $c, $actor ), 'write_enabled' => self::enabled(), 'configured_school_matches' => self::school_scope( $npsn ), 'database_writes' => 0, 'network_requests' => 0, 'production_enabled' => false, 'independently_verified' => false );
    }
    private static function request( array $r ): array {
        $keys = array( 'npsn', 'candidate_id', 'evidence_id', 'attestation_id', 'row_version', 'preview_token', 'note' ); ADE_Local_Archive::keys( $r, $keys );
        foreach ( array( 'candidate_id', 'evidence_id', 'attestation_id', 'row_version' ) as $k ) { if ( ! is_int( $r[$k] ) || $r[$k] < 1 ) { throw new InvalidArgumentException( 'PUB_REQUEST_INVALID' ); } }
        if ( ! is_string( $r['npsn'] ) || ! ADE_Pilot_Scope::contains( $r['npsn'] ) || ! is_string( $r['preview_token'] ) || ! preg_match( '/^[a-f0-9]{64}$/D', $r['preview_token'] ) || ! is_string( $r['note'] ) || strlen( trim( $r['note'] ) ) < 10 || strlen( $r['note'] ) > 500 || ! preg_match( '//u', $r['note'] ) || preg_match( '/[<>\x00-\x1f\x7f\x{200B}-\x{200F}\x{202A}-\x{202E}\x{2060}-\x{206F}\x{FEFF}]/u', $r['note'] ) ) { throw new InvalidArgumentException( 'PUB_REQUEST_INVALID' ); }
        $out = array(); foreach ( $keys as $k ) { $out[$k] = $r[$k]; } return $out;
    }
    private static function mutex( int $school ): string { $name = 'ade_m2_' . substr( ADE_Local_Archive::digest( array( ADE_Schema::table_name( 'candidates' ), $school ) ), 0, 48 ); $r = self::one( 'SELECT GET_LOCK(%s,0) AS acquired', array( $name ) ); if ( (int) ( $r['acquired'] ?? 0 ) !== 1 ) { throw new RuntimeException( 'PUB_WRITER_BUSY' ); } return $name; }
    private static function find( string $op, string $kind ): ?int { $t = ADE_Schema::table_name( 'jobs' ); $r = self::one( "SELECT id FROM {$t} WHERE job_key=%s AND job_type=%s LIMIT 1", array( $op, $kind ) ); return $r ? (int) $r['id'] : null; }
    private static function journal( int $id, string $kind, bool $lock = false ): array {
        if ( $id < 1 || ! in_array( $kind, array( self::APPLY, self::UNDO ), true ) ) { throw new InvalidArgumentException( 'PUB_RECEIPT_INVALID' ); } $t = ADE_Schema::table_name( 'jobs' ); $end = $lock ? ' FOR UPDATE NOWAIT' : '';
        $r = self::one( "SELECT id,job_key,status,LEFT(scope_filter,131073) AS scope_filter,OCTET_LENGTH(scope_filter) AS scope_bytes,LEFT(stats_payload,8193) AS stats_payload,OCTET_LENGTH(stats_payload) AS stats_bytes FROM {$t} WHERE id=%d AND job_type=%s LIMIT 1{$end}", array( $id, $kind ) );
        if ( ! $r || ! in_array( $r['status'], $kind === self::APPLY ? array( 'completed', 'rolled_back' ) : array( 'completed' ), true ) || (int) $r['scope_bytes'] > 131072 || (int) $r['stats_bytes'] > 8192 ) { throw new RuntimeException( 'PUB_RECEIPT_INVALID' ); }
        $m = ADE_Strict_JSON::decode( $r['scope_filter'], 131072 ); $s = ADE_Strict_JSON::decode( $r['stats_payload'], 8192 );
        $check = $m; $checksum = $check['metadata_sha256'] ?? null; unset( $check['metadata_sha256'] );
        if ( ! is_string( $checksum ) || ! hash_equals( ADE_Local_Archive::digest( $check ), $checksum ) ) { throw new RuntimeException( 'PUB_RECEIPT_INVALID' ); }
        if ( ( $m['schema_version'] ?? null ) !== 1 || ( $m['kind'] ?? null ) !== $kind || ( $m['result_sha256'] ?? null ) !== ADE_Local_Archive::digest( $s ) || ( $s['operation_key'] ?? null ) !== $r['job_key'] || ! is_int( $s['school_id'] ?? null ) || ! is_int( $s['candidate_id'] ?? null ) || ! is_string( $s['npsn'] ?? null ) || ! ADE_Pilot_Scope::contains( $s['npsn'] ) || ! is_int( $s['audit_id'] ?? null ) || ! is_array( $m['before'] ?? null ) || ! is_array( $m['after'] ?? null ) || ( $m['images_sha256'] ?? null ) !== ADE_Local_Archive::digest( array( $m['before'], $m['after'] ) ) || ! is_array( $m['audit'] ?? null ) ) { throw new RuntimeException( 'PUB_RECEIPT_INVALID' ); }
        $a = self::audit_row( $s['audit_id'], $lock ); unset( $a['id'] ); if ( $a !== $m['audit'] ) { throw new RuntimeException( 'PUB_RECEIPT_INVALID' ); }
        return array( 'id' => $id, 'status' => $r['status'], 'metadata' => $m, 'result' => $s );
    }
    private static function save( string $kind, string $op, array $request, array $c, array $before, array $after, array $changed, int $actor, string $action, int $before_version, int $after_version, ?int $original = null ): int {
        $now = current_time( 'mysql', true ); $audit = array( 'candidate_id' => $c['id'], 'school_id' => $c['school_id'], 'review_action' => $action, 'before_status' => 'approved', 'after_status' => 'approved', 'candidate_version' => $before_version, 'reviewed_value' => $kind === self::APPLY ? $c['approved_value'] : null, 'reason_code' => $kind === self::APPLY ? 'EXPLICIT_LOCAL_PUBLICATION' : 'EXPLICIT_LOCAL_ROLLBACK', 'review_notes' => json_encode( array( 'schema_version' => 1, 'operation_key' => $op, 'request' => $request, 'changed_keys' => array_keys( array_filter( $changed ) ), 'after_version' => $after_version, 'production_enabled' => false ), JSON_THROW_ON_ERROR ), 'user_id' => $actor, 'created_at' => $now );
        $audit_id = self::insert( 'reviews', $audit ); $result = array( 'operation_key' => $op, 'npsn' => $request['npsn'] ?? $c['npsn'], 'school_id' => $c['school_id'], 'candidate_id' => $c['id'], 'audit_id' => $audit_id, 'actor_user_id' => $actor, 'before_version' => $before_version, 'after_version' => $after_version, 'local_state' => $kind === self::APPLY ? 'published_local' : 'rolled_back_local', 'production_enabled' => false, 'independently_verified' => false );
        $meta = array( 'schema_version' => 1, 'kind' => $kind, 'actor_user_id' => $actor, 'request' => $request, 'before' => $before, 'after' => $after, 'changed' => $changed, 'images_sha256' => ADE_Local_Archive::digest( array( $before, $after ) ), 'audit' => $audit, 'result_sha256' => ADE_Local_Archive::digest( $result ), 'original_publication_id' => $original, 'preconditions' => $c['publication_proof'] ?? null );
        $meta['metadata_sha256'] = ADE_Local_Archive::digest( $meta );
        $encoded = json_encode( $meta, JSON_THROW_ON_ERROR ); if ( strlen( $encoded ) > 131072 ) { throw new RuntimeException( 'PUB_BACKUP_TOO_LARGE' ); }
        return self::insert( 'jobs', array( 'job_key' => $op, 'job_type' => $kind, 'scope_level' => 'LOCAL_' . $c['school_id'], 'scope_filter' => $encoded, 'stats_payload' => json_encode( $result, JSON_THROW_ON_ERROR ), 'status' => 'completed', 'attempt_count' => 1, 'max_attempts' => 1, 'cursor_school_id' => $c['school_id'], 'batch_size' => 1, 'created_at' => $now, 'updated_at' => $now, 'finished_at' => $now ) );
    }
    private static function write_meta( int $school, string $key, string $value, ?array $old ): void {
        $t = self::meta_table(); global $wpdb; $wpdb->last_error = ''; $fields = array( 'meta_value' => $value, 'verification_status' => 'verified', 'updated_at' => current_time( 'mysql', true ) );
        $ok = $old ? $wpdb->update( $t, $fields, array( 'id' => $old['id'], 'school_id' => $school, 'meta_key' => $key ) ) : $wpdb->insert( $t, array_merge( array( 'school_id' => $school, 'meta_key' => $key, 'source_id' => null ), $fields ) );
        if ( $ok !== 1 || $wpdb->last_error ) { throw new RuntimeException( 'PUB_META_WRITE_FAILED' ); }
    }
    public static function apply( array $input, string $confirm, string $backup ): array {
        $actor = self::guard( true ); $r = self::request( $input ); self::consent( $r['npsn'], $confirm, 'PUBLISH_LOCAL_CLAIM_WITH_SOURCE', $backup );
        $op = ADE_Local_Archive::digest( array( self::APPLY, ADE_Pilot_Scope::SHA256, $actor, $r ) ); $school = ADE_Identity::lookup_pilot( $r['npsn'] ); ADE_Pilot_Scope::assert_school( $school ); $name = self::mutex( (int) $school['id'] ); $tx = false;
        try {
            self::query( 'START TRANSACTION' ); $tx = true; $existing = self::find( $op, self::APPLY );
            if ( $existing ) { $j = self::journal( $existing, self::APPLY, true ); if ( $j['metadata']['request'] !== $r || $j['metadata']['actor_user_id'] !== $actor ) { throw new RuntimeException( 'PUB_RECEIPT_INVALID' ); } self::query( 'COMMIT' ); $tx = false; return array( 'receipt_id' => $existing, 'replayed' => true, 'historical_only' => true, 'current_receipt_state' => $j['status'], 'database_writes' => 0, 'production_enabled' => false ); }
            $x = self::context( $r['npsn'], $r['candidate_id'], $r['evidence_id'], $r['attestation_id'], true ); $c = $x['candidate'];
            if ( $c['row_version'] !== $r['row_version'] || ! hash_equals( self::token( $x, $actor ), $r['preview_token'] ) ) { throw new RuntimeException( 'PUB_PLAN_STALE' ); }
            $c['publication_proof'] = array( 'approval' => $x['approval'], 'attestation' => $x['attestation'], 'schema_sha256' => $x['schema_sha256'], 'source_url' => $x['source_url'] );
            $before = $x['before']; $changed = array( $c['target_key'] => true, 'profile_source_url' => $x['citation_changes'] );
            self::write_meta( $c['school_id'], $c['target_key'], $c['approved_value'], $before[$c['target_key']] ); if ( $x['citation_changes'] ) { self::write_meta( $c['school_id'], 'profile_source_url', $x['source_url'], $before['profile_source_url'] ); }
            $after = array(); foreach ( $before as $key => $row ) {
                $after[$key] = self::meta( $c['school_id'], $key, true ); $image = $after[$key];
                if ( $changed[$key] ) { $wanted = $key === 'profile_source_url' ? $x['source_url'] : $c['approved_value'];
                    if ( ! $image || $image['meta_value'] !== $wanted || $image['verification_status'] !== 'verified' || $image['source_id'] !== ( $row['source_id'] ?? null ) || ( $row && $image['id'] !== $row['id'] ) ) { throw new RuntimeException( 'PUB_META_READBACK_CONFLICT' ); }
                } elseif ( $image !== $row ) { throw new RuntimeException( 'PUB_META_READBACK_CONFLICT' ); }
            }
            $ct = ADE_Schema::table_name( 'candidates' ); if ( self::query( "UPDATE {$ct} SET publish_status='published_local',published_local_at=UTC_TIMESTAMP(),row_version=row_version+1,updated_at=UTC_TIMESTAMP() WHERE id=%d AND school_id=%d AND row_version=%d AND review_status='approved' AND publish_status=%s", array( $c['id'], $c['school_id'], $c['row_version'], $c['publish_status'] ) ) !== 1 ) { throw new RuntimeException( 'PUB_VERSION_CONFLICT' ); }
            $id = self::save( self::APPLY, $op, $r, $c, $before, $after, $changed, $actor, 'publish_local', $c['row_version'], $c['row_version'] + 1 );
            if ( ( new DateTimeImmutable( $x['attestation']['valid_until'] ) )->getTimestamp() <= time() + 5 ) { throw new RuntimeException( 'PUB_ATTESTATION_EXPIRED_OR_EXPIRING' ); }
            self::query( 'COMMIT' ); $tx = false;
            return array( 'receipt_id' => $id, 'replayed' => false, 'local_state' => 'published_local', 'changed_legacy_keys' => array_keys( array_filter( $changed ) ), 'production_enabled' => false );
        } finally { if ( $tx ) { self::query( 'ROLLBACK' ); } self::rows( 'SELECT RELEASE_LOCK(%s) AS released', array( $name ) ); }
    }
    private static function undo_context( int $id, bool $lock ): array {
        $j = self::journal( $id, self::APPLY, $lock ); if ( $j['status'] !== 'completed' ) { throw new RuntimeException( 'PUB_ALREADY_UNDONE' ); } $s = $j['result']; self::schema(); $c = self::candidate( $s['npsn'], $s['candidate_id'], $lock, true );
        if ( $c['publish_status'] !== 'published_local' || $c['row_version'] !== $s['after_version'] ) { throw new RuntimeException( 'PUB_UNDO_CANDIDATE_CONFLICT' ); }
        $jt = ADE_Schema::table_name( 'jobs' ); $end = $lock ? ' FOR UPDATE NOWAIT' : ''; $latest = self::one( "SELECT id FROM {$jt} WHERE job_type=%s AND scope_level=%s AND status='completed' ORDER BY id DESC LIMIT 1{$end}", array( self::APPLY, 'LOCAL_' . $c['school_id'] ) );
        if ( ! $latest || (int) $latest['id'] !== $id ) { throw new RuntimeException( 'PUB_UNDO_REVERSE_ORDER_REQUIRED' ); }
        $current = array(); foreach ( $j['metadata']['after'] as $key => $row ) { $current[$key] = self::meta( $c['school_id'], $key, $lock ); if ( ( $j['metadata']['changed'][$key] ?? null ) === true && $current[$key] !== $row ) { throw new RuntimeException( 'PUB_UNDO_VALUE_CONFLICT' ); } }
        return array( 'publication' => $j, 'candidate' => $c, 'current' => $current );
    }
    public static function undo_plan( int $id ): array {
        $actor = self::guard(); $x = self::undo_context( $id, false ); return array( 'mode' => 'READ_ONLY_LOCAL_UNDO_PLAN', 'publication_id' => $id, 'npsn' => $x['publication']['result']['npsn'], 'changed_keys' => array_keys( array_filter( $x['publication']['metadata']['changed'] ) ), 'restore' => $x['publication']['metadata']['before'], 'preview_token' => ADE_Local_Archive::digest( array( 'local-undo-plan-v1', $actor, $x ) ), 'database_writes' => 0, 'network_requests' => 0, 'write_enabled' => self::enabled(), 'production_enabled' => false );
    }
    public static function undo( int $id, string $token, string $confirm, string $backup ): array {
        $actor = self::guard( true ); if ( ! preg_match( '/^[a-f0-9]{64}$/D', $token ) ) { throw new InvalidArgumentException( 'PUB_UNDO_TOKEN_INVALID' ); }
        $j = self::journal( $id, self::APPLY ); $npsn = $j['result']['npsn']; self::consent( $npsn, $confirm, 'UNDO_ONE_LOCAL_PUBLICATION', $backup ); $op = ADE_Local_Archive::digest( array( self::UNDO, $j['result']['operation_key'] ) ); $name = self::mutex( $j['result']['school_id'] ); $tx = false;
        try {
            self::query( 'START TRANSACTION' ); $tx = true; $existing = self::find( $op, self::UNDO );
            if ( $existing ) { $old = self::journal( $existing, self::UNDO, true ); if ( $old['metadata']['actor_user_id'] !== $actor || ( $old['metadata']['request']['preview_token'] ?? null ) !== $token ) { throw new RuntimeException( 'PUB_ALREADY_UNDONE' ); } self::query( 'COMMIT' ); $tx = false; return array( 'receipt_id' => $existing, 'replayed' => true, 'historical_only' => true, 'database_writes' => 0, 'production_enabled' => false ); }
            $x = self::undo_context( $id, true ); if ( ! hash_equals( ADE_Local_Archive::digest( array( 'local-undo-plan-v1', $actor, $x ) ), $token ) ) { throw new RuntimeException( 'PUB_UNDO_PLAN_STALE' ); }
            $pub = $x['publication']; $c = $x['candidate']; $mt = self::meta_table(); global $wpdb;
            foreach ( $pub['metadata']['before'] as $key => $old ) {
                if ( $pub['metadata']['changed'][$key] !== true ) { continue; } $current = $x['current'][$key]; $wpdb->last_error = '';
                if ( null === $old ) { $changed = self::query( "DELETE FROM {$mt} WHERE id=%d AND school_id=%d AND meta_key=%s", array( $current['id'], $c['school_id'], $key ) ); }
                else { $changed = $wpdb->update( $mt, array( 'meta_value' => $old['meta_value'], 'verification_status' => $old['verification_status'], 'source_id' => $old['source_id'], 'updated_at' => $old['updated_at'] ), array( 'id' => $old['id'], 'school_id' => $c['school_id'], 'meta_key' => $key ) ); }
                if ( $changed !== 1 || $wpdb->last_error ) { throw new RuntimeException( 'PUB_UNDO_META_FAILED' ); }
            }
            $ct = ADE_Schema::table_name( 'candidates' ); if ( self::query( "UPDATE {$ct} SET publish_status='rolled_back_local',published_local_at=NULL,row_version=row_version+1,updated_at=UTC_TIMESTAMP() WHERE id=%d AND school_id=%d AND row_version=%d AND publish_status='published_local' AND review_status='approved'", array( $c['id'], $c['school_id'], $c['row_version'] ) ) !== 1 ) { throw new RuntimeException( 'PUB_UNDO_VERSION_CONFLICT' ); }
            $jt = ADE_Schema::table_name( 'jobs' ); if ( self::query( "UPDATE {$jt} SET status='rolled_back',updated_at=UTC_TIMESTAMP() WHERE id=%d AND job_type=%s AND status='completed'", array( $id, self::APPLY ) ) !== 1 ) { throw new RuntimeException( 'PUB_UNDO_RECEIPT_CONFLICT' ); }
            $after = array(); foreach ( $pub['metadata']['before'] as $key => $old ) { $after[$key] = self::meta( $c['school_id'], $key, true ); if ( $pub['metadata']['changed'][$key] === true && $after[$key] !== $old ) { throw new RuntimeException( 'PUB_UNDO_READBACK_CONFLICT' ); } }
            $c['npsn'] = $npsn; $undo_id = self::save( self::UNDO, $op, array( 'publication_id' => $id, 'preview_token' => $token ), $c, $x['current'], $after, $pub['metadata']['changed'], $actor, 'rollback_local', $c['row_version'], $c['row_version'] + 1, $id ); self::query( 'COMMIT' ); $tx = false;
            return array( 'receipt_id' => $undo_id, 'replayed' => false, 'local_state' => 'rolled_back_local', 'production_enabled' => false );
        } finally { if ( $tx ) { self::query( 'ROLLBACK' ); } self::rows( 'SELECT RELEASE_LOCK(%s) AS released', array( $name ) ); }
    }
    public static function receipt( int $id, bool $undo = false ): array {
        self::guard(); $j = self::journal( $id, $undo ? self::UNDO : self::APPLY ); return array( 'receipt_id' => $id, 'current_receipt_status' => $j['status'], 'historical_only' => true, 'result' => $j['result'], 'backup_images_sha256' => $j['metadata']['images_sha256'], 'database_writes' => 0, 'network_requests' => 0, 'production_enabled' => false );
    }
}
