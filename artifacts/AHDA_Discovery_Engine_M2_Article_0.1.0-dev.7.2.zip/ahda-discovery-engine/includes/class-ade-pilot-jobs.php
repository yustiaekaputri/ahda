<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** M1 read-only discovery planning; persistence ONLY in the existing jobs table. */
final class ADE_Pilot_Jobs {
    public const TYPE = 'm1_discovery_plan';

    public static function guard( string $confirmation, string $expected ): void {
        if ( ! defined( 'WP_CLI' ) || ! WP_CLI || ! class_exists( 'WP_CLI' ) ||
            ! ADE_Schema::is_allowed_local() || ! current_user_can( 'ade_manage_jobs' ) ||
            $confirmation !== $expected || ! ADE_Jobs::preflight()['ready'] ) {
            throw new RuntimeException( 'LOCAL_OPERATOR_GATE_BLOCKED' );
        }
    }

    private static function query( string $sql, array $args = array() ): int {
        global $wpdb;
        $wpdb->last_error = '';
        $r = $wpdb->query( $args ? $wpdb->prepare( $sql, $args ) : $sql );
        if ( false === $r || $wpdb->last_error ) { throw new RuntimeException( 'M1_DATABASE_ERROR' ); }
        return (int) $r;
    }

    private static function row( string $sql, array $args ): ?array {
        global $wpdb;
        $wpdb->last_error = '';
        $row = $wpdb->get_row( $wpdb->prepare( $sql, $args ), ARRAY_A );
        if ( $wpdb->last_error ) { throw new RuntimeException( 'M1_DATABASE_ERROR' ); }
        return $row ?: null;
    }

    /** Must receive the explicitly frozen 200-school manifest; no random selection. */
    public static function enqueue( array $manifest, string $confirmation ): array {
        self::guard( $confirmation, 'ENQUEUE_M1_PLAN' );
        ADE_Pilot::validate_manifest( $manifest );
        if ( $manifest['version'] !== 2 ) { throw new InvalidArgumentException( 'NEW_JOBS_REQUIRE_FROZEN_SCOPE' ); }
        if ( count( $manifest['schools'] ) !== 200 ) { throw new InvalidArgumentException( 'PILOT_REQUIRES_200' ); }
        $table = ADE_Schema::table_name( 'jobs' );
        $key = hash( 'sha256', self::TYPE . '|' . $manifest['hash'] );
        $find = static function () use ( $table, $key ) { return self::row( "SELECT id,status FROM {$table} WHERE job_key=%s AND job_type=%s LIMIT 1", array( $key, self::TYPE ) ); };
        $existing = $find();
        if ( $existing ) { return array( 'created' => false, 'job' => $existing ); }
        global $wpdb;
        $now = current_time( 'mysql', true );
        $ok = $wpdb->insert( $table, array( 'job_key' => $key, 'job_type' => self::TYPE,
            'scope_level' => 'TASIK_NEGERI_200', 'scope_filter' => json_encode( $manifest, JSON_THROW_ON_ERROR ),
            'status' => 'queued', 'batch_size' => 10, 'max_attempts' => 3,
            'created_at' => $now, 'updated_at' => $now ) );
        if ( false === $ok ) {
            $existing = $find();
            if ( $existing ) { return array( 'created' => false, 'job' => $existing ); }
            throw new RuntimeException( 'M1_ENQUEUE_FAILED' );
        }
        return array( 'created' => true, 'job' => array( 'id' => (int) $wpdb->insert_id, 'status' => 'queued' ) );
    }

    public static function status( int $id ): array {
        self::guard( 'READ_M1', 'READ_M1' );
        if ( $id < 1 ) { throw new InvalidArgumentException( 'JOB_ID_INVALID' ); }
        $table = ADE_Schema::table_name( 'jobs' );
        $job = self::row( "SELECT * FROM {$table} WHERE id=%d AND job_type=%s LIMIT 1", array( $id, self::TYPE ) );
        if ( ! $job ) { throw new RuntimeException( 'M1_JOB_NOT_FOUND' ); }
        return $job;
    }

    /** Read-only consistency of the frozen selection and committed prefix. */
    public static function integrity( int $id ): array {
        $job = self::status( $id );
        $manifest = json_decode( $job['scope_filter'], true, 16, JSON_THROW_ON_ERROR );
        ADE_Pilot::validate_manifest( $manifest );
        if ( count( $manifest['schools'] ) !== 200 || ! hash_equals( $job['job_key'], hash( 'sha256', self::TYPE . '|' . $manifest['hash'] ) ) ) {
            throw new RuntimeException( 'M1_MANIFEST_BINDING_INVALID' );
        }
        $stats = $job['stats_payload'] ? json_decode( $job['stats_payload'], true, 16, JSON_THROW_ON_ERROR ) : array();
        if ( ! is_array( $stats ) || count( $stats ) > 200 || array_keys( $stats ) !== array_keys( array_values( $stats ) ) ) { throw new RuntimeException( 'M1_STATS_INVALID' ); }
        foreach ( $stats as $index => $result ) {
            $expected = $manifest['schools'][$index];
            if ( ! is_array( $result ) || ( $result['school_id'] ?? null ) !== $expected['school_id'] ||
                ( $result['npsn'] ?? null ) !== $expected['npsn'] || ( $result['network_requests'] ?? null ) !== 0 ) {
                throw new RuntimeException( 'M1_STATS_PREFIX_INVALID' );
            }
        }
        $cursor = $stats ? $stats[count($stats)-1]['school_id'] : 0;
        if ( (int) ( $job['cursor_school_id'] ?? 0 ) !== $cursor || ( $job['status'] === 'completed' && count( $stats ) !== 200 ) ) {
            throw new RuntimeException( 'M1_CURSOR_INVALID' );
        }
        return array( 'valid' => true, 'manifest_hash' => $manifest['hash'], 'committed' => count( $stats ), 'cursor' => $cursor );
    }

    public static function retry_failed( int $id, string $confirmation ): bool {
        self::guard( $confirmation, 'RETRY_M1_PLAN' );
        self::integrity( $id );
        $table = ADE_Schema::table_name( 'jobs' );
        return self::query( "UPDATE {$table} SET status='retry_wait',attempt_count=0,finished_at=NULL,next_run_at=UTC_TIMESTAMP(),last_error_code=NULL,updated_at=UTC_TIMESTAMP() WHERE id=%d AND job_type=%s AND status='failed'", array( $id, self::TYPE ) ) === 1;
    }

    /** One worker per database, no WordPress options used for locks. */
    public static function step( int $id, string $confirmation ): array {
        self::guard( $confirmation, 'RUN_M1_PLAN' );
        if ( $id < 1 ) { throw new InvalidArgumentException( 'JOB_ID_INVALID' ); }
        $table = ADE_Schema::table_name( 'jobs' );
        global $wpdb;
        $lock = self::row( 'SELECT GET_LOCK(%s,0) AS acquired', array( 'ade_m1_' . substr( hash( 'sha256', $table ), 0, 40 ) ) );
        if ( (int) ( $lock['acquired'] ?? 0 ) !== 1 ) { throw new RuntimeException( 'M1_WORKER_BUSY' ); }
        $lock_name = 'ade_m1_' . substr( hash( 'sha256', $table ), 0, 40 );
        $token = bin2hex( random_bytes( 32 ) );
        try {
            $job = self::status( $id );
            self::integrity( $id );
            if ( $job['status'] === 'completed' || $job['status'] === 'cancelled' ) { return array( 'status' => $job['status'], 'processed' => 0 ); }
            $claimed = self::query( "UPDATE {$table} SET status='leased',lease_token=%s,leased_until=DATE_ADD(UTC_TIMESTAMP(),INTERVAL 60 SECOND),attempt_count=attempt_count+1,updated_at=UTC_TIMESTAMP(),started_at=COALESCE(started_at,UTC_TIMESTAMP()) WHERE id=%d AND job_type=%s AND status IN ('queued','retry_wait') AND attempt_count<max_attempts AND (next_run_at IS NULL OR next_run_at<=UTC_TIMESTAMP())", array( $token, $id, self::TYPE ) );
            if ( $claimed !== 1 ) { throw new RuntimeException( 'M1_JOB_NOT_READY' ); }
            try {
                $manifest = json_decode( $job['scope_filter'], true, 16, JSON_THROW_ON_ERROR );
                $result = ADE_Pilot::batch( $manifest, (int) ( $job['cursor_school_id'] ?? 0 ), 10 );
                if ( ! $result['results'] && ! $result['complete'] ) { throw new RuntimeException( 'M1_RESOURCE_LIMIT' ); }
                $previous = $job['stats_payload'] ? json_decode( $job['stats_payload'], true, 16, JSON_THROW_ON_ERROR ) : array();
                $stats = array_merge( $previous, $result['results'] );
                if ( count( $stats ) > 200 ) { throw new RuntimeException( 'M1_CHECKPOINT_INVALID' ); }
                self::query( 'START TRANSACTION' );
                try {
                    // Results and cursor commit together; expired/replaced leases cannot commit.
                    $changed = self::query( "UPDATE {$table} SET status=%s,cursor_school_id=%d,stats_payload=%s,lease_token=NULL,leased_until=NULL,next_run_at=NULL,attempt_count=0,last_error_code=NULL,finished_at=IF(%d=1,UTC_TIMESTAMP(),NULL),updated_at=UTC_TIMESTAMP() WHERE id=%d AND job_type=%s AND status='leased' AND lease_token=%s AND leased_until>UTC_TIMESTAMP()", array( $result['complete'] ? 'completed' : 'queued', $result['cursor'], json_encode( $stats, JSON_THROW_ON_ERROR ), $result['complete'] ? 1 : 0, $id, self::TYPE, $token ) );
                    if ( $changed !== 1 ) { throw new RuntimeException( 'M1_LEASE_LOST' ); }
                    self::query( 'COMMIT' );
                } catch ( Throwable $e ) { self::query( 'ROLLBACK' ); throw $e; }
                return array( 'status' => $result['complete'] ? 'completed' : 'queued', 'processed' => count( $result['results'] ), 'cursor' => $result['cursor'], 'network_requests' => 0 );
            } catch ( Throwable $e ) {
                // No cursor advance on any failure. Bounded retry, no raw exception/HTML stored.
                self::query( "UPDATE {$table} SET status=IF(attempt_count>=max_attempts,'failed','retry_wait'),finished_at=IF(attempt_count>=max_attempts,UTC_TIMESTAMP(),NULL),lease_token=NULL,leased_until=NULL,next_run_at=DATE_ADD(UTC_TIMESTAMP(),INTERVAL 30 SECOND),last_error_code='M1_BATCH_FAILED',updated_at=UTC_TIMESTAMP() WHERE id=%d AND job_type=%s AND status='leased' AND lease_token=%s AND leased_until>UTC_TIMESTAMP()", array( $id, self::TYPE, $token ) );
                throw $e;
            }
        } finally {
            self::row( 'SELECT RELEASE_LOCK(%s) AS released', array( $lock_name ) );
        }
    }

    public static function recover( string $confirmation ): int {
        self::guard( $confirmation, 'RECOVER_M1_PLAN' );
        $table = ADE_Schema::table_name( 'jobs' );
        return self::query( "UPDATE {$table} SET status=IF(attempt_count>=max_attempts,'failed','retry_wait'),finished_at=IF(attempt_count>=max_attempts,UTC_TIMESTAMP(),NULL),lease_token=NULL,leased_until=NULL,next_run_at=DATE_ADD(UTC_TIMESTAMP(),INTERVAL 30 SECOND),last_error_code='M1_LEASE_EXPIRED',updated_at=UTC_TIMESTAMP() WHERE job_type=%s AND status='leased' AND leased_until<UTC_TIMESTAMP()", array( self::TYPE ) );
    }

    public static function cancel( int $id, string $confirmation ): bool {
        self::guard( $confirmation, 'CANCEL_M1_PLAN' );
        if ( $id < 1 ) { throw new InvalidArgumentException( 'JOB_ID_INVALID' ); }
        $table = ADE_Schema::table_name( 'jobs' );
        return self::query( "UPDATE {$table} SET status='cancelled',next_run_at=NULL,finished_at=UTC_TIMESTAMP(),updated_at=UTC_TIMESTAMP() WHERE id=%d AND job_type=%s AND status IN ('queued','retry_wait','failed')", array( $id, self::TYPE ) ) === 1;
    }
}
