<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Bounded offline adapters. Extracts normalized literal records, never source trust. */
final class ADE_Document_Parser {
    private const TARGETS = array( 'profile_programs', 'profile_curriculum', 'profile_hours' );
    public const MAX_HTML_BYTES = 262144;
    public const MAX_CSV_BYTES = 65536;

    private static function text( string $value, int $max ): string {
        if ( strlen( $value ) > $max || ! preg_match( '//u', $value ) ||
            preg_match( '/[<>\x00-\x08\x0b\x0c\x0e-\x1f\x7f\x{200B}-\x{200F}\x{202A}-\x{202E}\x{2060}-\x{206F}\x{FEFF}]/u', $value ) || '' === trim( $value ) ) {
            throw new InvalidArgumentException( 'M2_DOCUMENT_TEXT_INVALID' );
        }
        return trim( $value );
    }

    /** Strict CSV grammar: no permissive recovery of broken/unclosed quotations. */
    private static function csv_records( string $raw ): array {
        $rows = array(); $row = array(); $cell = ''; $state = 'start'; $length = strlen( $raw );
        for ( $i = 0; $i < $length; ++$i ) {
            $char = $raw[$i];
            if ( 'quoted' === $state ) {
                if ( '"' === $char ) {
                    if ( $i + 1 < $length && '"' === $raw[$i + 1] ) { $cell .= '"'; ++$i; }
                    else { $state = 'closed'; }
                } else { $cell .= $char; }
                continue;
            }
            if ( 'closed' === $state && ! in_array( $char, array( ',', "\r", "\n" ), true ) ) { throw new InvalidArgumentException( 'M2_CSV_QUOTING_INVALID' ); }
            if ( '"' === $char ) {
                if ( 'start' !== $state ) { throw new InvalidArgumentException( 'M2_CSV_QUOTING_INVALID' ); }
                $state = 'quoted'; continue;
            }
            if ( ',' === $char || "\n" === $char || "\r" === $char ) {
                $row[] = $cell; $cell = ''; $state = 'start';
                if ( count( $row ) > 3 ) { throw new InvalidArgumentException( 'M2_CSV_COLUMNS_INVALID' ); }
                if ( ',' !== $char ) {
                    if ( "\r" === $char ) {
                        if ( ( $raw[$i + 1] ?? '' ) !== "\n" ) { throw new InvalidArgumentException( 'M2_CSV_LINE_ENDING_INVALID' ); }
                        ++$i;
                    }
                    $rows[] = $row; $row = array();
                    if ( count( $rows ) > 21 ) { throw new InvalidArgumentException( 'M2_DOCUMENT_CLAIM_LIMIT' ); }
                }
            } else { $cell .= $char; $state = 'plain'; }
        }
        if ( 'quoted' === $state ) { throw new InvalidArgumentException( 'M2_CSV_QUOTING_INVALID' ); }
        if ( $row || '' !== $cell || 'closed' === $state ) { $row[] = $cell; $rows[] = $row; }
        if ( count( $rows ) < 2 || count( $rows ) > 21 ) { throw new InvalidArgumentException( 'M2_DOCUMENT_CLAIM_LIMIT' ); }
        return $rows;
    }

    private static function csv( string $raw, string $npsn ): array {
        $rows = self::csv_records( $raw );
        if ( array_shift( $rows ) !== array( 'npsn', 'target_key', 'value' ) ) { throw new InvalidArgumentException( 'M2_CSV_HEADER_INVALID' ); }
        $claims = array(); $lines = array();
        foreach ( $rows as $row ) {
            if ( count( $row ) !== 3 ) { throw new InvalidArgumentException( 'M2_CSV_COLUMNS_INVALID' ); }
            if ( $row[0] !== $npsn ) { throw new InvalidArgumentException( 'M2_HARD_NPSN_MISMATCH' ); }
            if ( ! in_array( $row[1], self::TARGETS, true ) ) { throw new InvalidArgumentException( 'M2_TARGET_BLOCKED' ); }
            $value = self::text( $row[2], 500 );
            if ( preg_match( '/^\s*[=+@-]/u', $value ) ) { throw new InvalidArgumentException( 'M2_CSV_FORMULA_BLOCKED' ); }
            $quote = $row[1] . ': ' . $value;
            $lines[] = 'NPSN: ' . $row[0] . '. ' . $quote;
            $claims[] = array( 'target_key' => $row[1], 'proposed_value' => $value, 'supporting_quote' => $quote );
        }
        return array( $claims, implode( "\n", $lines ), count( $rows ), 0 );
    }

    private static function node_text( DOMNode $node, int $depth = 0 ): string {
        if ( $depth > 32 ) { throw new InvalidArgumentException( 'M2_HTML_DEPTH_LIMIT' ); }
        if ( $node instanceof DOMText ) { return $node->nodeValue; }
        $text = '';
        foreach ( $node->childNodes as $child ) { $text .= self::node_text( $child, $depth + 1 ); }
        return in_array( strtolower( $node->nodeName ), array( 'br', 'li', 'p', 'div', 'th', 'td', 'tr' ), true ) ? ' ' . $text . ' ' : $text;
    }

    private static function html( string $raw, string $npsn ): array {
        if ( ! class_exists( 'DOMDocument' ) ) { throw new RuntimeException( 'M2_HTML_DOM_EXTENSION_REQUIRED' ); }
        // Allow only the inert HTML5 doctype. Never load DTDs/entities or XML.
        $raw = preg_replace( '/<!doctype\s+html\s*>/i', '', $raw );
        if ( preg_match( '/<!\s*(?:doctype|entity)\b|<\?/i', $raw ) ) { throw new InvalidArgumentException( 'M2_HTML_EXTERNAL_DECLARATION_BLOCKED' ); }
        $dom = new DOMDocument( '1.0', 'UTF-8' );
        if ( ! $dom->loadHTML( '<meta charset="utf-8">' . $raw, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_COMPACT ) ) { throw new InvalidArgumentException( 'M2_HTML_INVALID' ); }
        $xpath = new DOMXPath( $dom );
        if ( $xpath->query( '//*' )->length > 10000 ) { throw new InvalidArgumentException( 'M2_HTML_NODE_LIMIT' ); }
        // DOM parsing never executes scripts or downloads assets. Ignore non-content.
        $remove = $xpath->query( '//script|//style|//noscript|//template|//iframe|//object|//embed|//svg|//math|//*[@hidden or translate(normalize-space(@aria-hidden),"TRUE","true")="true"]' );
        foreach ( iterator_to_array( $remove ) as $node ) { if ( $node->parentNode ) { $node->parentNode->removeChild( $node ); } }
        foreach ( iterator_to_array( $xpath->query( '//*[@style]' ) ) as $node ) {
            if ( preg_match( '/(?:display\s*:\s*none|visibility\s*:\s*(?:hidden|collapse))/i', $node->getAttribute( 'style' ) ) && $node->parentNode ) { $node->parentNode->removeChild( $node ); }
        }
        $body = $dom->getElementsByTagName( 'body' )->item( 0 );
        if ( ! $body ) { throw new InvalidArgumentException( 'M2_HTML_PROFILE_TABLE_REQUIRED' ); }
        $visible = self::node_text( $body );
        preg_match_all( '/\bNPSN\s*[:=-]?\s*([0-9]{8})(?![0-9])/i', $visible, $codes );
        foreach ( $codes[1] as $code ) { if ( $code !== $npsn ) { throw new InvalidArgumentException( 'M2_HARD_NPSN_MISMATCH' ); } }
        $tables = $xpath->query( '//table' );
        if ( $tables->length > 20 ) { throw new InvalidArgumentException( 'M2_HTML_TABLE_LIMIT' ); }
        $profiles = array();
        $labels = array( 'program' => 'profile_programs', 'program pendidikan' => 'profile_programs', 'program keahlian' => 'profile_programs',
            'kurikulum' => 'profile_curriculum', 'jam layanan' => 'profile_hours', 'jam operasional' => 'profile_hours' );
        foreach ( $tables as $table ) {
            if ( $xpath->query( './/table', $table )->length ) { throw new InvalidArgumentException( 'M2_HTML_NESTED_TABLE_BLOCKED' ); }
            $claims = array(); $lines = array(); $seen_identity = 0; $skipped = 0;
            $rows = $xpath->query( './tr|./thead/tr|./tbody/tr|./tfoot/tr', $table );
            if ( $rows->length > 64 ) { throw new InvalidArgumentException( 'M2_HTML_ROW_LIMIT' ); }
            foreach ( $rows as $row ) {
                $cells = $xpath->query( './th|./td', $row );
                if ( 0 === $cells->length ) { continue; }
                $label = trim( preg_replace( '/\s+/u', ' ', self::node_text( $cells->item( 0 ) ) ) );
                $key = strtolower( rtrim( $label, ' :') );
                if ( 'npsn' !== $key && ! isset( $labels[$key] ) ) { ++$skipped; continue; }
                if ( 2 !== $cells->length ) { throw new InvalidArgumentException( 'M2_HTML_COLUMNS_AMBIGUOUS' ); }
                foreach ( $cells as $cell ) {
                    foreach ( array( 'rowspan', 'colspan' ) as $attribute ) {
                        if ( $cell->hasAttribute( $attribute ) && $cell->getAttribute( $attribute ) !== '1' ) { throw new InvalidArgumentException( 'M2_HTML_COLUMNS_AMBIGUOUS' ); }
                    }
                }
                $label = self::text( $label, 100 );
                $value = self::text( trim( preg_replace( '/\s+/u', ' ', self::node_text( $cells->item( 1 ) ) ) ), 500 );
                $quote = $label . ': ' . $value;
                if ( 'npsn' === $key ) {
                    if ( $value !== $npsn ) { throw new InvalidArgumentException( 'M2_HARD_NPSN_MISMATCH' ); }
                    if ( ++$seen_identity > 1 ) { throw new InvalidArgumentException( 'M2_HTML_IDENTITY_AMBIGUOUS' ); }
                } else {
                    $claims[] = array( 'target_key' => $labels[$key], 'proposed_value' => $value, 'supporting_quote' => $quote );
                    if ( count( $claims ) > 20 ) { throw new InvalidArgumentException( 'M2_DOCUMENT_CLAIM_LIMIT' ); }
                }
                $lines[] = $quote;
            }
            if ( $seen_identity && $claims ) { $profiles[] = array( $claims, implode( "\n", $lines ), count( $claims ), $skipped ); }
        }
        if ( count( $profiles ) !== 1 ) { throw new InvalidArgumentException( count( $profiles ) > 1 ? 'M2_HTML_PROFILE_AMBIGUOUS' : 'M2_HTML_PROFILE_TABLE_REQUIRED' ); }
        return $profiles[0];
    }

    public static function parse( string $raw, string $format, string $npsn, array $metadata, int $now ): array {
        if ( ! in_array( $format, array( 'html', 'csv' ), true ) ) { throw new InvalidArgumentException( 'M2_DOCUMENT_FORMAT_UNSUPPORTED' ); }
        if ( strlen( $raw ) > ( 'html' === $format ? self::MAX_HTML_BYTES : self::MAX_CSV_BYTES ) ) { throw new InvalidArgumentException( 'M2_DOCUMENT_TOO_LARGE' ); }
        $raw_hash = hash( 'sha256', $raw );
        if ( substr( $raw, 0, 3 ) === "\xef\xbb\xbf" ) { $raw = substr( $raw, 3 ); }
        if ( '' === trim( $raw ) || ! preg_match( '//u', $raw ) || strpos( $raw, "\0" ) !== false ) { throw new InvalidArgumentException( 'M2_DOCUMENT_ENCODING_INVALID' ); }
        if ( ADE_Identity::validate_npsn( $npsn ) !== $npsn || ! ADE_Pilot_Scope::contains( $npsn ) ) { throw new InvalidArgumentException( 'M2_NPSN_OUTSIDE_PILOT' ); }
        $keys = array( 'fixture_only', 'source_url', 'checked_at', 'permission_reference' );
        if ( array_diff( array_keys( $metadata ), $keys ) || array_diff( $keys, array_keys( $metadata ) ) ) { throw new InvalidArgumentException( 'M2_DOCUMENT_METADATA_INVALID' ); }
        list( $claims, $content, $rows, $skipped ) = 'html' === $format ? self::html( $raw, $npsn ) : self::csv( $raw, $npsn );
        $document = array_merge( array( 'schema_version' => 1, 'npsn' => $npsn, 'observed_npsn' => $npsn ), $metadata,
            array( 'source_content' => $content, 'claims' => $claims ) );
        $preview = ADE_Enrichment_Preview::normalize( json_encode( $document, JSON_THROW_ON_ERROR ), $now );
        return array( 'mode' => 'LOCAL_DOCUMENT_PARSE_PREVIEW', 'format' => $format, 'raw_document_sha256' => $raw_hash,
            'normalization' => 'html' === $format ? 'html-table-text-v1' : 'csv-decoded-records-v1',
            'extracted_rows' => $rows, 'ignored_unmapped_rows' => $skipped, 'structured_document' => $document, 'preview' => $preview,
            'provenance_note' => 'Operator-supplied local document; quotes refer to normalized records, not raw file byte slices. Retain original file and its hash separately. Source authority/permission remain unverified.',
            'network_requests' => 0, 'database_writes' => 0, 'publication_enabled' => false );
    }

    public static function preview( string $raw, string $format, string $npsn, array $metadata ): array {
        ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
        $result = self::parse( $raw, $format, $npsn, $metadata, time() );
        $result['preview'] = ADE_Enrichment_Preview::preview( json_encode( $result['structured_document'], JSON_THROW_ON_ERROR ) );
        return $result;
    }
}
