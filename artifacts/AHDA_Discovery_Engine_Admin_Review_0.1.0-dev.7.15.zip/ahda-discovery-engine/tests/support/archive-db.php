<?php
if(PHP_SAPI!=='cli'){exit(2);}
final class ArchiveDB {
 public $prefix='custom_',$last_error='',$insert_id=0,$db,$relations=[],$lock_changed=false;
 public function __construct(){$this->db=new StoreDB;$this->db->inner->schools['20268071']=array_merge(ADE_Pilot_Scope::reference()['20268071'],['id'=>913,'name'=>'Synthetic archive candidate test','visibility'=>'publish']);foreach(['https://example.org/'=>7,'https://example.net/'=>9] as $url=>$id){$key=ADE_Source_URLs::canonicalize($url)['canonical_key'];$this->relations[$key]=['source_id'=>$id,'relation_id'=>$id+1,'source_type'=>'website','access_state'=>'manual_only','source_status'=>'discovered','identity_status'=>'pending','relationship_type'=>'pending'];}}
 public function prepare($sql,...$args){return $this->db->prepare($sql,...$args);}
 public function get_results($key,$kind){$this->db->last_error='';[$sql,$args]=$this->db->inner->prepared[$key]??[$key,[]];
  if(strpos($sql,'FROM custom_ahda_discovery_sources ')!==false){$key=strpos($sql,'AND l.id=%d')!==false?$args[3]:$args[1];$row=$this->relations[$key]??null;if($row&&$this->lock_changed&&strpos($sql,'FOR UPDATE')!==false){$row['access_state']='blocked';}return $row?[$row]:[];}
  $rows=$this->db->get_results($key,$kind);$this->last_error=$this->db->last_error;return $rows;
 }
 public function query($sql){$this->db->last_error='';$r=$this->db->query($sql);$this->last_error=$this->db->last_error;return $r;}
 public function insert($table,$values){$this->db->last_error='';$r=$this->db->insert($table,$values);$this->last_error=$this->db->last_error;$this->insert_id=$this->db->insert_id;return $r;}
}
