# Receipt arsip → evidence/kandidat pending — dev.7.10

Modul `ADE_Archive_Candidates` menghubungkan raw receipt7.9 ke tiga target M2 lama:
program, kurikulum, jam layanan. Default OFF. Tidak menyetujui fakta atau menerapkan
profil. Tidak ada sumber sekolah nyata yang diambil atau database pengguna yang
diubah sesi ini. Tidak perlu mengulang demo inspect yang sebelumnya sudah berhasil.

## Input dan pembuktian raw

Input hanya ID raw receipt yang sudah benar-benar ada dalam database lokal dan
NPSN sekolah yang sama. Bukan file/work report/checkpoint, bukan JSON klaim kiriman
caller. Vault memeriksa status/ukuran/hash/kontrak receipt, lalu mem-parse ulang raw
CSV/HTML/JSON terpilih. Salinan extraction saat capture hanya historis dan **tidak
dipercaya sebagai fakta**; tes memasukkan derived capture palsu yang hash-nya sah
untuk membuktikan pipeline tetap menggunakan raw dan menolak target tak didukung.

Identity/klasifikasi/ownership/visibility, current verified meta dan relasi source
terdaftar diperiksa ulang. Raw fixture, stale, salah NPSN, konflik/parseerror,
missing/blocked relation tidak diteruskan. Pending source/relationship bukan bukti
resmi, izin atau confidence. Operator penyimpan raw sebelumnya sudah menyatakan
privacy-reviewed; pernyataan tersebut bukan scanner PII/secret otomatis.

Evidence berisi kutipan literal teks normalisasi, URL/waktu, source_id spesifik,
raw_receipt_id, raw_payload_sha256, document_key/raw_document_sha256,
archive_evidence_key dan format. `parse_status=m2_archive_unverified` dan provenance
stored_raw_archive; identity pending/permission NOT_INDEPENDENTLY_VERIFIED. Tidak
mengubah sumber menjadi official/verified atau menganggap izin crawl = izin publikasi.

## Rencana dan penulisan

Nama command persis menggunakan underscore:

- `wp ade pilot archive_stage`: read-only, wajib raw-receipt-id, npsn, --dry-run. Menampilkan dampak konkret, source bindings, current/proposed, skip/reuse/insert, kenaikan versi dan preview token.
- `wp ade pilot archive_store`: pending-only write default OFF. Wajib token segar, backup-confirmed YES dan confirm STORE_ARCHIVE_CANDIDATES, selain ID/NPSN.
- `wp ade pilot archive_receipt --receipt-id=ID`: metadata hasil historis operasi, bukan approval/publication.

Flag `ADE_LOCAL_ARCHIVE_CANDIDATES_ENABLED` sengaja tidak didefinisikan pada paket.
Penyimpanan raw dan penyimpanan kandidat punya opt-in terpisah. Jangan mengaktifkan
flag, mengubah wp-config atau menjalankan write pada LocalWP pengguna sekarang:
belum ada rencana raw nyata/backup/persetujuan khusus. Harness hanya mengaktifkan
flag dalam proses uji sintetis disposable, bukan konfigurasi pengguna.

Command hanya SiteShell lokal dengan preflight/capability ade_manage_jobs dan
ade_review_candidates, actor WordPress positif. Tidak ada endpoint POST web baru;
nonce tetap diwajibkan handler admin lama untuk keputusan negatif, bukan proses CLI.
--dry-run tidak dipakai untuk mutasi; gunakan archive_stage. Inputstage kosong tanpa
rawreceipt yang sah memang ditolak; jangan memaksa demo jadi non-fixture.

## Lingkup database dan atomicity

Hanya empat tabel Discovery: candidates, evidence, candidate_evidence, jobs receipt,
memakai prefix aktual. Tidak mengubah schema1/seven tables, legacy25tabel/nama/NPSN/
profile_school_verified, source/relationship atau reviews keputusan. Candidate baru
m2_meta_text_v1, new/not_ready, approved_value NULL, score0, row_version1.

Contoh dua dokumen sejalan/3klaim:3candidate +6evidence +6link +1receipt =16row baru;
rawreceipt sudah ada dan tidak berubah. Source_id tiap dokumen tetap terpisah,
termasuk host yang berbeda. Kandidat pending manual lama memakai dedupe_key yang
sama, sehingga3candidate yang cocok dipakai ulang; menambah6evidence/6links/receipt
=13row, row_version3candidate naik. Tidak menimpa proposed/current snapshot diam-diam.
Snapshot pending yang tidak cocok ditolak, memerlukan review terpisah.

Kandidat yang sudah direview/approved/published atau punya approval marker tidak
berubah dan tidak mendapat evidence/link tambahan. Jika1dari3 ditolak, dua lainnya
pending:4evidence +4link +1receipt=9row, versi hanya2pending naik. Rencana lama
setelah review menjadi stale. Jika seluruhnya terkunci, hanya receipt skip dapat
dibuat; itu bukan status bahwa bukti telah disetujui atau ditempelkan.

Transaksi pendek tanpa network, mutex M2/M3/raw-vault yang sama perprefix+school,
GET_LOCK0; rawreceipt, source/relation dan kandidat/evidence/link/receipt diperiksa
ulang dengan row lock NOWAIT. Canonicalkey/URL/host/status source diperiksa sebelum
write; candidate version/status CAS untuk evidence tambahan.16posisi insert dan
CASfailure diuji rollback seluruh operasi: raw tetap utuh, tidak ada kandidat atau
link setengah jadi. Snapshot legacy hanya consistent read, bukan serialisasi editor
legacy; publisher masa depan harus recheck saat apply sebenarnya.

Metadata dan hasil receipt dibatasi16KiB setelah JSON encoding sebelum insert;
kasus URL Unicode panjang yang melewati cap membatalkan seluruh transaksi.
Operation key mengikat scope, school_id, rawreceiptID dan rawpayloadSHA. Replay oleh
actor sama memakai receipt historis tanpa duplikat; actor berbeda tidak boleh
memakai token receipt lama. Bukti ke rawrevision berbeda menghasilkan key berbeda;
pending candidate boleh ditambah dengan kenaikan versi, reviewed tetap beku.
Commit berhasil namun acknowledgment hilang dipulihkan dengan receipt. Raw hash
adalah konsistensi byte, bukan signature atau perlindungan dari DBadmin yang
menulis ulang payload dan hash. Izin operator tetap terpisah dari hash/token.

Penyimpanan manual structured lama tidak diubah runtime-nya; kelas DB fake untuk
tes dipindah ke support agar dua jalur dapat diuji bersama. Tidak memanggil store
lama berulang per dokumen (yang dapat menyisakan partial state bila dokumen kedua
 gagal). Semua dokumen satu operasi ada dalam satu transaksi.

## Panel admin

Inspector dapat membaca status m2_archive_unverified serta menampilkan nomor raw
receipt, format dan SHA dokumen secara escaped. Tidak menampilkan raw body atau
operator JSON sewenang-wenang. Struktur binding divalidasi sebelum ditampilkan;
hash/string berisi markup ditolak. Raw tidak dimuat ulang pada setiap evidence
halaman (menghindari sampai20pembacaan payload1MiB); readiness menandai jelas
RAW_ARCHIVE_BINDING_NOT_REVALIDATED_ON_THIS_PAGE. Referensi tersebut diperiksa pada
write, **belum diperiksa ulang saat halaman dibaca**, bukan status verified.
Review positif/publisher belum tersedia dan harus memverifikasi ulang binding.
Tidak ada form/approval baru; negative review defaultOFF tetap seperti sebelumnya.

## Bukti dan batas tes

- 24suite offline1504checks tiap PHP8.2.32/8.4.24 dengan DOM;1436tanpaDOM (HTML NOT RUN).
- 81filePHP lint,84hash baseline dan6file tes regresi asli utuh; runtime manual Store byte-identical terhadap7.9.
- Suitebridge77checks fakeDB, seluruh16posisi gagal/rollback, CAS, current/source/rawtamper, dedupe, IDOR, operator, two-host/source mapping, manual pending reuse, reviewed frozen, ignore forged derived extraction.
- 282checks actual MySQL8.4.13, WP/wpdb adapter **stubs**,195regresi+87bridge. Two-host CSV+HTML, source IDs7/9, complete16row/receipt, raw immutable, all16insert failures, realCOMMIT+simulated ackloss, stale/review append, two-session mutex/NOWAIT,5tabel terlindungi sintetis tetap sama.
- 26Chromium checks pada PHPview/WordPress+DB fixture, desktop/mobile, reference/hash wrapping, explicit revalidation notice, no newPOSTform/XSS/external request. Screenshot mobile diperiksa manual. Server sendiri dihentikan.

Dua container MySQL milik sesi (run awal dan final, tidak bersamaan) (1CPU/1GiB/512MiBtmpfs/loopback ephemeral) dihapus.
Bukti docs/qa/dev7.10; hasil native kode final di native-final. Ini bukan fullWordPress/wpdb/LocalWP pengguna/VPS performance
atau real-source acceptance. Bukti39actualWordPress dev7.6 dan laporan user7.8
inspect tetap scope historisnya; tidak diklaim ulang sebagai tes writer baru.

Rollback kode ke7.9 tidak menghapus raw/evidence/candidate/receipt yang kelak telah
sah disimpan.7.9inspector belum mengenal evidence archive baru sehingga mungkin
menahannya; jangan downgrade setelah write nyata tanpa rencana kompatibilitas.
Tidak ada perubahan DB pengguna sesi ini. Tidak ada deletion/import/migration.
Retensi raw/privacy/export/encryption/quota-total7.9 tetap belum dibuat. Writer
baru belum diizinkan dipakai pada data nyata; belum ada200artikel faktual lengkap.

Berikutnya: integrasi WordPress nyata untuk bridge dan inspector, verifikasi raw
binding penuh di workflow review, izin/identitas sumber dan approval positif,
worker durable lease/fencing/commitcheckpoint, publisher lokal/rollback terakhir.
Network katalog resmi tetap dibatasi cloud; sisa izin riset18/20request untuk10
sekolah awal, tidak ada probe/bypass baru. Tidak menjanjikan peringkat Google/AI.
