# WP-CLI dry-run hotfix dev.7.1.1

The previous extract/stage PHPDoc declared bare --dry-run. Official WP-CLI
rejects mandatory boolean flags as invalid synopsis and then unknown parameter.
Use [--dry-run] in synopsis; handler still requires explicit boolean true.
Stage valued options now have description paragraphs for synopsis extraction.
No DB schema, runtime dependency, writer, fetch, or publish changes.

The new suite reproduces the old rejection using unmodified WP-CLI v2.12.0
parser/validator and invokes fixed commands via its CommandFactory/Subcommand.
It checks all command synopses, exact demo flags, missing/negative dry-run,
CRLF comments, underscore names and explicit alias. Official source files are
SHA-256 pinned in tests/vendor/wp-cli-2.12.0/UPSTREAM.json with MIT LICENSE.
Only help rendering/global configuration and WordPress/DB are stubs. Tests do
not run a full WP-CLI binary, WordPress bootstrap, or native MySQL. The framework
files are test-only and never included by plugin runtime.

Retry after replacing Discovery plugin locally:
wp --user="admin" ade pilot extract --demo --dry-run
Expected: FIXTURE_ONLY_READ_ONLY, three synthetic candidates, zero network
requests/database writes. Native LocalWP retry remains pending user evidence.
Rollback files to previous package requires no database migration, but brings
back this flag error. Preserve all existing tables/data and Directory plugin.
