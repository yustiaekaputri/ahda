<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** M3 read-only inspection. Never approves, updates, fetches or publishes. */
final class ADE_Candidate_Inspector {
    private const TARGETS = array( 'profile_programs', 'profile_curriculum', 'profile_hours' );
    private const STATUSES = array( 'all', 'new', 'approved', 'rejected', 'deferred' );

    private static function guard(): void {
        if ( ! current_user_can( 'ade_review_candidates' ) || get_current_user_id() < 1 || ! ADE_Schema::is_allowed_local() ) {
            throw new RuntimeException( 'M3_LOCAL_REVIEW_CAP_REQUIRED' );
        }
        if ( ! ADE_Jobs::preflight()['ready'] ) { throw new RuntimeException( 'M3_PREFLIGHT_BLOCKED' ); }
    }

    private static function rows( string $sql, array $args ): array {
        global $wpdb;
        $wpdb->last_error = '';
        $rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
        if ( ! is_array( $rows ) || $wpdb->last_error ) { throw new RuntimeException( 'M3_INSPECTOR_READ_FAILED' ); }
        return $rows;
    }

    private static function school( string $npsn ): array {
        if ( ! ADE_Pilot_Scope::contains( $npsn ) ) { throw new RuntimeException( 'M3_OUTSIDE_PILOT' ); }
        $school = ADE_Identity::lookup_pilot( $npsn );
        ADE_Pilot_Scope::assert_school( $school );
        return $school;
    }

    private static function base(): array {
        return array( 'mode' => 'READ_ONLY_CANDIDATE_INSPECTOR', 'review_actions_enabled' => class_exists( 'ADE_Review_Decisions', false ) && ADE_Review_Decisions::enabled(), 'approval_enabled' => false,
            'network_requests' => 0, 'database_writes' => 0, 'publication_enabled' => false );
    }

    public static function listing( string $npsn, string $status = 'all', int $after = 0 ): array {
        self::guard();
        if ( ! in_array( $status, self::STATUSES, true ) || $after < 0 ) { throw new InvalidArgumentException( 'M3_FILTER_INVALID' ); }
        $school = self::school( $npsn ); $table = ADE_Schema::table_name( 'candidates' );
        $args = array( (int) $school['id'], 'm2_meta_text_v1', 'school_meta', $after );
        $where = '';
        if ( 'all' !== $status ) { $where = ' AND review_status=%s'; $args[] = $status; }
        $rows = self::rows( "SELECT id,target_key,LEFT(proposed_value,201) AS proposed_excerpt,review_status,publish_status,row_version,updated_at FROM {$table} WHERE school_id=%d AND candidate_type=%s AND target_type=%s AND id>%d{$where} ORDER BY id ASC LIMIT 21", $args );
        if ( count( $rows ) > 21 ) { throw new RuntimeException( 'M3_ROW_LIMIT_INVALID' ); }
        foreach ( $rows as &$row ) {
            if ( (int) ( $row['id'] ?? 0 ) <= $after || ! in_array( $row['target_key'] ?? null, self::TARGETS, true ) ) { throw new RuntimeException( 'M3_CANDIDATE_INVALID' ); }
            $row['id'] = (int) $row['id']; $row['row_version'] = (int) $row['row_version'];
        } unset( $row );
        $more = count( $rows ) > 20;
        if ( $more ) { array_pop( $rows ); }
        return array_merge( self::base(), array( 'school' => $school, 'status_filter' => $status, 'candidates' => $rows,
            'after' => $after, 'next_after' => $more ? end( $rows )['id'] : null ) );
    }

    /** Do not expose credentials/token-query URLs even as text in the inspector. */
    private static function safe_url( string $raw ): ?string {
        try {
            $url = ADE_Evidence_URLs::canonicalize( $raw );
            if ( 'https' !== parse_url( $url, PHP_URL_SCHEME ) ) { return null; }
            foreach ( explode( '&', (string) parse_url( $url, PHP_URL_QUERY ) ) as $pair ) {
                $key = rawurldecode( explode( '=', $pair, 2 )[0] );
                if ( strtolower( $key ) === 'key' || preg_match( '/token|secret|password|authorization|credential|signature|nonce|api[_-]?key/i', $key ) ) { return null; }
            }
            return $url;
        } catch ( Throwable $e ) { return null; }
    }

    public static function detail( string $npsn, int $id, int $evidence_after = 0 ): array {
        self::guard();
        if ( $id < 1 || $evidence_after < 0 ) { throw new InvalidArgumentException( 'M3_ID_INVALID' ); }
        $school = self::school( $npsn ); $school_id = (int) $school['id'];
        $candidates = ADE_Schema::table_name( 'candidates' );
        $rows = self::rows( "SELECT id,school_id,target_key,LEFT(proposed_value,501) AS proposed_value,OCTET_LENGTH(proposed_value) AS proposed_bytes,LEFT(current_value_snapshot,16385) AS current_value_snapshot,OCTET_LENGTH(current_value_snapshot) AS snapshot_bytes,base_target_hash,LEFT(approved_value,501) AS approved_value,OCTET_LENGTH(approved_value) AS approved_bytes,review_status,publish_status,row_version,updated_at FROM {$candidates} WHERE id=%d AND school_id=%d AND candidate_type=%s AND target_type=%s LIMIT 2", array( $id, $school_id, 'm2_meta_text_v1', 'school_meta' ) );
        if ( count( $rows ) !== 1 ) { throw new RuntimeException( 'M3_CANDIDATE_NOT_FOUND' ); }
        $row = $rows[0];
        if ( (int) $row['school_id'] !== $school_id || ! in_array( $row['target_key'], self::TARGETS, true ) ||
            (int) $row['proposed_bytes'] > 500 || (int) $row['snapshot_bytes'] > 16384 || (int) $row['approved_bytes'] > 500 ) { throw new RuntimeException( 'M3_CANDIDATE_INVALID' ); }
        global $wpdb;
        // Prefix validated by indexed school lookup. Only allowlisted verified meta.
        $meta_table = $wpdb->prefix . 'ahda_school_meta';
        if ( strlen( $meta_table ) > 64 ) { throw new RuntimeException( 'M3_TABLE_INVALID' ); }
        $meta = self::rows( "SELECT LEFT(meta_value,16385) AS meta_value,OCTET_LENGTH(meta_value) AS value_bytes FROM {$meta_table} WHERE school_id=%d AND meta_key=%s AND verification_status=%s LIMIT 2", array( $school_id, $row['target_key'], 'verified' ) );
        if ( count( $meta ) > 1 || ( $meta && (int) $meta[0]['value_bytes'] > 16384 ) ) { throw new RuntimeException( 'M3_CURRENT_VALUE_INVALID' ); }
        $current = $meta ? $meta[0]['meta_value'] : null;
        $hash = hash( 'sha256', json_encode( array( 'm2-meta-snapshot-v1', $school_id, $row['target_key'], $current ), JSON_THROW_ON_ERROR ) );
        $conflict = ! is_string( $row['base_target_hash'] ) || ! hash_equals( $hash, $row['base_target_hash'] );
        $evidence = ADE_Schema::table_name( 'evidence' ); $links = ADE_Schema::table_name( 'candidate_evidence' );
        $sources = ADE_Schema::table_name( 'sources' ); $relations = ADE_Schema::table_name( 'school_sources' );
        $entries = self::rows( "SELECT ce.id AS link_id,e.id,e.school_id,e.source_id,e.attribute_hint,e.evidence_type,e.evidence_url,LEFT(e.snippet_text,2001) AS snippet_text,OCTET_LENGTH(e.snippet_text) AS snippet_bytes,LEFT(e.observed_value,4097) AS observed_value,OCTET_LENGTH(e.observed_value) AS observed_bytes,e.parse_status,e.checked_at,s.access_state,s.source_status,l.identity_status,l.relationship_type FROM {$links} ce INNER JOIN {$evidence} e ON e.id=ce.evidence_id LEFT JOIN {$sources} s ON s.id=e.source_id LEFT JOIN {$relations} l ON l.source_id=e.source_id AND l.school_id=e.school_id WHERE ce.candidate_id=%d AND ce.id>%d ORDER BY ce.id ASC LIMIT 21", array( $id, $evidence_after ) );
        if ( count( $entries ) > 21 ) { throw new RuntimeException( 'M3_ROW_LIMIT_INVALID' ); }
        $reasons = array( class_exists( 'ADE_Review_Decisions', false ) && ADE_Review_Decisions::enabled() ? 'APPROVAL_NOT_IMPLEMENTED' : 'REVIEW_DECISIONS_DISABLED', 'PUBLISHER_DISABLED' );
        if ( $conflict ) { $reasons[] = 'CURRENT_VALUE_CHANGED_OR_BASE_HASH_INVALID'; }
        foreach ( $entries as &$entry ) {
            if ( (int) $entry['school_id'] !== $school_id || $entry['attribute_hint'] !== $row['target_key'] ||
                $entry['evidence_type'] !== 'document' || $entry['parse_status'] !== 'm2_manual_unverified' ||
                (int) $entry['snippet_bytes'] > 2000 || (int) $entry['observed_bytes'] > 4096 ) { throw new RuntimeException( 'M3_EVIDENCE_CONFLICT' ); }
            $observed = json_decode( $entry['observed_value'], true, 8, JSON_THROW_ON_ERROR );
            if ( ! is_array( $observed ) || ( $observed['value'] ?? null ) !== $row['proposed_value'] ||
                ( $observed['scope_hash'] ?? null ) !== ADE_Pilot_Scope::SHA256 ) { throw new RuntimeException( 'M3_EVIDENCE_CONFLICT' ); }
            unset( $entry['observed_value'] ); // Never echo arbitrary stored JSON or operator private notes.
            $entry['url'] = self::safe_url( (string) $entry['evidence_url'] ); unset( $entry['evidence_url'] );
            if ( null === $entry['url'] ) { $reasons[] = 'SOURCE_URL_BLOCKED'; }
            if ( $entry['identity_status'] !== 'verified' || $entry['relationship_type'] !== 'official' ) { $reasons[] = 'SOURCE_IDENTITY_NOT_VERIFIED'; }
            $reasons[] = 'SOURCE_PERMISSION_NOT_INDEPENDENTLY_VERIFIED';
            if ( $entry['access_state'] !== 'manual_only' || ! in_array( $entry['source_status'], array( 'discovered', 'verified', 'active' ), true ) ) { $reasons[] = 'SOURCE_STATE_REQUIRES_REVIEW'; }
            $time = DateTimeImmutable::createFromFormat( '!Y-m-d H:i:s', (string) $entry['checked_at'], new DateTimeZone( 'UTC' ) );
            if ( ! $time || $time->format( 'Y-m-d H:i:s' ) !== $entry['checked_at'] || $time->getTimestamp() > time() + 300 ) { $reasons[] = 'EVIDENCE_TIMESTAMP_INVALID'; }
            elseif ( time() - $time->getTimestamp() > 365 * 86400 ) { $reasons[] = 'STALE_EVIDENCE'; }
            $entry['id'] = (int) $entry['id']; $entry['link_id'] = (int) $entry['link_id'];
        } unset( $entry );
        if ( ! $entries ) { $reasons[] = $evidence_after ? 'NO_MORE_EVIDENCE_ON_THIS_PAGE' : 'EVIDENCE_MISSING'; }
        $more = count( $entries ) > 20;
        if ( $more ) { array_pop( $entries ); }
        $row['id'] = (int) $row['id']; $row['row_version'] = (int) $row['row_version'];
        return array_merge( self::base(), array( 'school' => $school, 'candidate' => $row, 'current_verified_value' => $current,
            'current_value_conflict' => $conflict, 'evidence' => $entries, 'evidence_after' => $evidence_after,
            'next_evidence_after' => $more ? end( $entries )['link_id'] : null,
            'readiness_reasons' => array_values( array_unique( $reasons ) ), 'readiness_is_page_scoped' => true ) );
    }
}
