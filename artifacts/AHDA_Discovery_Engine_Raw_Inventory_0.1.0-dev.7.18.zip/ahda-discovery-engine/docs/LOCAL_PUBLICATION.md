# Controlled local publication and owned rollback — dev.7.17

Implemented for ONE explicitly configured frozen-pilot NPSN. Local CLI only;
ADE_LOCAL_PUBLISH_ENABLED undefined/OFF and ADE_LOCAL_PUBLISH_NPSN undefined by
default. Never production, cron, worker, browser form or bulk publication. Requires
existing local manage-jobs/reviewer AND WordPress manage_options, actor, preflight,
Directory version exactly0.8.9, explicit backup and action confirmation.

## What may change

One already approved, unchanged raw-backed claim for profile_programs,
profile_curriculum or profile_hours. Also profile_source_url only when empty or
exactly the same selected safe evidence URL. Both field and conditional citation
appear in the preview and explicit PUBLISH_LOCAL_CLAIM_WITH_SOURCE consent.
Unrelated existing citation is a conflict, never silently overwritten. Exact-source
reuse does not rewrite its row/date. No HTML appended to approved_value, no badge,
NPSN/name/index/social/logo/student data change, no AHDA_Profile::save/admin handler.
Legacy source_id is NOT a Discovery source ID and is preserved; new rows useNULL.

This uses native Directory reader/template: meta verification_status=verified
means the field was manually approved. It does not certify independent source
verification or a school's official representative. profile_school_verified is
never set. Public native template displays source in #sumber. Multiple different
source URLs per profile are not supported by this conservative adapter; conflict
stays blocked until a separately reviewed citation design/data change exists.

## Read-only preview

Only if legitimate stored records already exist, substitute their actual IDs:

```
wp --user="admin" ade pilot publish_stage --npsn=NPSN --candidate-id=CANDIDATE --evidence-id=EVIDENCE --attestation-id=GRANT --dry-run
```

Returns old target/source rows, approved value, selected source URL, whether citation
changes, declaration actor/references/expiry, version and actor-bound preview token.
This is not permission to write. DefaultOFF and configured_school_matchesfalse are
normal. No record exists for unsaved demo; never convert fixture data into real data.

## Apply contract (not instructions to run on user data now)

`publish_apply --request-file=PATH --backup-confirmed=YES
--confirm=PUBLISH_LOCAL_CLAIM_WITH_SOURCE` requires gate + exact configured NPSN.
Strict JSON <=8KiB: npsn string, candidate_id/evidence_id/attestation_id/row_version
positive integers, preview_token64hex, note10..500UTF8bytes without HTML/control/bidi.
No client-selected value, target key or source URL. No new web mutation/nonce
surface: this is CLI only; existing positive browser review keeps its own nonce.

After shared school M2 mutex and one short transaction:

1. Exact prior request may resolve its checked historical receipt without new work.
   Historical replay is NOT current permission, especially after withdrawal/undo.
2. Confirm legacy meta InnoDB, known seven columns, utf8mb4 value field, school/key
   unique index and no visible target triggers. Complete metadata visibility is a
   deployment assumption. Refuse malformed legacy keys/case/spacing, dates or IDs.
3. CURRENT-lock school by NPSN (no old RR identity snapshot), enforce frozen class/
   negeri/Tasik/publish scope, then candidate, positive audit and matching operation
   receipt. Approved value equals proposed+reviewed value; approval actor/time/hash
   match. Candidate version still equals preview. No edits or implicit reapproval.
4. CURRENT-lock/revalidate grant, withdrawal, raw, evidence/link/source and legacy
   target. Source identity/rights remain explicit human statements, not authenticated
   legal proof. Grant must remain >5s from expiry at check and before COMMIT.
5. CURRENT-lock full target/source rows, recheck base hash and complete before-image
   token, including PENDING metadata that the verified-only basehash ignores.
6. Write only allowed target + conditional citation, preserve old PK/source_id.
   Read back exact intended values/status/source_id/PK; unchanged citation must be
   unchanged. Reject SQL-layer rewrites/truncation before candidate/audit commit.
7. Candidate remains review_statusapproved, publish_statuspublished_local,
   published_local_at set and row_version+1. Append reviews publish_local audit and
   jobs receipt with bounded complete before/after images, changed flags, approval/
   grant/schema provenance and checksums. All commit together or roll back.

No cache of authorization across requests. Frontend gains no Discovery query,
parser, source HTTP or new hook; native reader already queries its meta allowlist.
No production or VPS load acceptance is implied by synthetic tests.

## Undo safely

`publish_undo_stage --publication-id=ID --dry-run` reads owned restoration diff.
`publish_undo --publication-id=ID --preview-token=TOKEN --backup-confirmed=YES
--confirm=UNDO_ONE_LOCAL_PUBLICATION` uses same local/admin/flag/school guards.

- Validate full receipt-wide metadata checksum plus image/result/audit checksums.
  They detect corruption, not an administrator rewriting DB values and hashes.
- Reverse ACTIVE publication order per school protects shared source attribution.
- CURRENT-lock same NPSN identity and candidate. Hidden school may be undone and
  stays hidden; frozen identity/classification still required. Source/grant may be
  withdrawn, blocked or expired: undo does not need raw reparse or new source rights.
- Compare exact current after-images for every changed row. Other admin edit means
  conflict; never overwrite it. Existing rows restore original value/status/
  source_id/timestamp/PK; only proved newly inserted owned rows may be deleted.
  Unchanged citation is untouched. Verify exact restored images before COMMIT.
- Candidate stays approved, publish_statusrolled_back_local, published timeNULL,
  row_version+1. Mark apply receipt currentstatusrolled_back (metadata/result stay
  immutable), append rollback_local review audit and separate undo receipt.
- Exact undo retry is historical/write0 even if another publication later occurred.
  Reapply needs fresh plan/token/current grants and new version; never old receipt.

`publish_receipt --receipt-id=ID` (or --undo) reads historical summary + current
receipt state and backup checksum, without returning full backup plaintext.
COMMIT response can be ambiguous; read/EXACT-retry receipt before doing anything
else. Actual successful COMMIT + injected response error was tested for apply and
undo; genuine dropped TCP/OS crash not tested. Auto_increment gaps are retained,
not reset. Do not manually delete journals or reset approved/version fields.

## Limits before real rollout

This delivery does not enable flags, edit wp-config or operate on user DB. Gate
configuration and full site backup require scoped operator action. Native tests
use one SYNTHETIC school; operator's actual one-school LocalWP acceptance is still
required before any approved20-school expansion. Publisher UI/bulk/multiple citation
sources and other fields are not implemented. Changing parent version/schema blocks.

Permission expiry/withdrawal does not automatically erase published facts. No
scheduled publisher/retraction exists. Operator must review and explicitly undo/
renew as appropriate; declaration status/raw verifier may show old-basehash conflict
AFTER our own publication, which is not automatically a license revocation. Receipt
states/history are never current legal-rights proof. Raw storage retention,
encryption/totalquota and source-rights policy remain pre-rollout gates.

## Evidence

Final qa/dev7.17:205 earlier actualWP services +69 publication/undo services =274,
99 browser/HTTP HTML checks (89 existing admin flows +10 public template checks).
PHP8.2/8.4 offline27suites1643DOM/1575noDOM,96lint,84baselinehashes/6originaltests.
One-school existing-row and owned-insert restoration, public claim/source visible
then absent after undo, protected badge/name/NPSN unchanged, all25 legacy rowhashes
restored, source namespace preserved, MyISAM/unique/charset/triggers/canonical keys,
SQL rewrite/readback rollback, all write/COMMIT faults, revoked/blocked source,
actor/capability, pending-meta edits, two-session candidate and school RR races,
hidden-school undo, source reuse/reverse order, metadata tampering, idempotence and
postcommit response-loss tested. No PHP diagnostics in final run, all owned resources
removed. Public HTML from actual Directory template and owned minimal theme parsed
in DOM; frontend resource/layout/VPS benchmark and official CLI runner not E2E-tested.
No real sources or factual profiles enriched:0/200. No SEO/ranking/AI recommendation
promise. Rollback plugin files to7.16 from local backup preserves data/journals;
7.16 cannot perform M4 undo, so retain7.17 to undo an apply first when appropriate.
