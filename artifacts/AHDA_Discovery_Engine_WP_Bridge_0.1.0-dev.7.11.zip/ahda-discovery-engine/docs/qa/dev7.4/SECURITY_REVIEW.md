# M3 inspector security review

No write endpoint/POST/AJAX/REST/approval/nonce mutation surface. Existing flags
OFF; readonly diagnostic explicitly distinct. Server guard on service and view,
not menu only; current reviewer/site/preflight required. GET schema/IDs/status
validated, no query-dependent identifiers or dynamic ordering, all values prepared.
Frozen scope/current classification prevents cross-pilot access; detail ID bound
to school and M2type; cross-school evidence corrupt links block entirely.

Bounded keyset reads20+1, limited text bytes and exact current verified meta.
Current/base hash comparison is warning, not approval or atomic publication gate.
Raw DB JSON/private operator notes not output. Credential/IP/token URL hidden
rather than escaped then leaked. Text/attributes/URL via WordPress esc functions;
no untrusted HTML rendering, image/iframe/embed or asset fetch. Explicit source
links noreferrer/noopener and no automatic navigation. SQL errors mapped safe code.

Native queries tested actual MySQL with WP adapter stubs. Browser actual PHP view
under synthetic backend/WordPress stubs and minimal CSS, Chromium16checks including
XSS nonexecution and denied access403. Stubs do not establish real WP capability/
nonce/preflight/bootstrap/theme behavior. No complete security/SEO readiness claim.

Future review decisions must implement real nonce/cap, version fencing, evidence/
source/base hash recheck, transactions and append-only audit. Inspector page is
multi-read/non-atomic, not a decision token; readonly warnings page-scoped. No
source permission attestation exists yet. No production/local real-data write.
