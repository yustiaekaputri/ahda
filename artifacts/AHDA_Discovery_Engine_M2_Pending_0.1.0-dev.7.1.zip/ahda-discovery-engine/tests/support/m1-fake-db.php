<?php
if(PHP_SAPI!=='cli'){exit(2);}
define('ABSPATH',__DIR__.'/');define('WP_CLI',true);define('ARRAY_A','ARRAY_A');
class WP_CLI{public static $messages=[];public static function log($message){self::$messages[]=$message;}public static function error($message){throw new RuntimeException($message);}}
class ADE_Schema {public static $local=true;public static function is_allowed_local(){return self::$local;}public static function table_name($suffix){if(!in_array($suffix,['jobs','sources','school_sources','evidence','candidates','candidate_evidence','reviews'],true)){throw new RuntimeException('bad table');}return 'custom_ahda_discovery_'.$suffix;}}
class ADE_Jobs {public static function preflight(){return ['ready'=>true,'local'=>true,'schema'=>[],'unsafe_flags'=>[],'worker_lock'=>null];}}
$cap=true;$denied_caps=[];function current_user_can($capability){global $cap,$denied_caps;return $cap && !in_array($capability,$denied_caps,true) && in_array($capability,['ade_manage_jobs','ade_review_candidates'],true);}function get_current_user_id(){return 1;}function current_time($a,$b){return '2026-11-09 00:00:00';}
final class FakeDB {
 public $prefix='custom_',$last_error='',$insert_id=0,$jobs=[],$prepared=[],$sql=[],$held=false,$mode='',$snapshot=null,$identity_change=false,$read_failure=false,$schools=[];
 public function prepare($s,...$args){if(count($args)===1 && is_array($args[0])){$args=$args[0];}$key='prepared_'.count($this->prepared);$this->prepared[$key]=[$s,$args];return $key;}
 private function decode($key){$v=$this->prepared[$key]??[$key,[]];$this->sql[]=$v;return $v;}
 public function get_results($key,$kind){[$s,$a]=$this->decode($key);if(strpos($s,'FROM custom_ahda_schools')!==false){if($this->read_failure){$this->last_error='injected read failure';return null;}$n=$a[0];if(isset($this->schools[$n])){return [$this->schools[$n]];}if($n==='99999999'){return [];}return [['id'=>(int)$n-10000000+1+($this->identity_change?1:0),'npsn'=>$n,'name'=>'Fixture school','school_form'=>$n==='99999998'?'SD':'SMK','education_level'=>'secondary','regency_raw'=>'Fixture','district_raw'=>'Fixture','village_raw'=>'Fixture','visibility'=>$n==='99999997'?'published':'publish']];}if(strpos($s,'INNER JOIN')!==false){return (int)$a[0]%2?[['source_id'=>1,'access_state'=>'manual_only','identity_status'=>'pending','relationship_type'=>'pending']]:[];}throw new RuntimeException('Unexpected read: '.$s);}
 public function get_row($key,$kind){[$s,$a]=$this->decode($key);if(strpos($s,'GET_LOCK')!==false){if($this->held){return ['acquired'=>0];}$this->held=true;return ['acquired'=>1];}if(strpos($s,'RELEASE_LOCK')!==false){$this->held=false;return ['released'=>1];}foreach($this->jobs as $j){if(strpos($s,'job_key=%s')!==false ? $j['job_key']===$a[0] : $j['id']===$a[0]){return $j;}}return null;}
 public function insert($table,$f){if($table!=='custom_ahda_discovery_jobs'){throw new RuntimeException('Legacy write');}foreach($this->jobs as $j){if($j['job_key']===$f['job_key']){return false;}}$id=++$this->insert_id;$this->jobs[$id]=array_merge(['id'=>$id,'attempt_count'=>0,'cursor_school_id'=>null,'stats_payload'=>null,'lease_token'=>null,'leased_until'=>null,'next_run_at'=>null,'max_attempts'=>3],$f);return 1;}
 public function query($key){[$s,$a]=$this->decode($key);
  if($s==='START TRANSACTION'){if($this->mode==='lease-lost'){foreach($this->jobs as &$j){$j['lease_token']='replacement-token';}unset($j);}$this->snapshot=$this->jobs;return 0;}
  if($s==='COMMIT'){if($this->mode==='commit-fail'){return false;}$this->snapshot=null;return 0;}
  if($s==='ROLLBACK'){$this->jobs=$this->snapshot;$this->snapshot=null;return 0;}
  if(strpos($s,'UPDATE custom_ahda_discovery_jobs SET ')!==0){throw new RuntimeException('Non-allowlisted write '.$s);}
  if(strpos($s,"SET status='leased'")!==false){[$token,$id,$type]=$a;$j=&$this->jobs[$id];if(!in_array($j['status'],['queued','retry_wait'])||$j['attempt_count']>=3||$j['next_run_at']){return 0;}$j['status']='leased';$j['lease_token']=$token;$j['leased_until']=true;++$j['attempt_count'];return 1;}
  if(strpos($s,'SET status=%s,cursor_school_id=')!==false){[$status,$cursor,$stats,$done,$id,$type,$token]=$a;$j=&$this->jobs[$id];if($j['lease_token']!==$token||!$j['leased_until']||$j['status']!=='leased'){return 0;}$j=array_merge($j,['status'=>$status,'cursor_school_id'=>$cursor,'stats_payload'=>$stats,'lease_token'=>null,'leased_until'=>null,'attempt_count'=>0,'next_run_at'=>null]);return 1;}
  if(strpos($s,"last_error_code='M1_BATCH_FAILED'")!==false){[$id,$type,$token]=$a;$j=&$this->jobs[$id];if($j['lease_token']!==$token||!$j['leased_until']||$j['status']!=='leased'){return 0;}$j['status']=$j['attempt_count']>=3?'failed':'retry_wait';$j['lease_token']=null;$j['next_run_at']=true;return 1;}
  if(strpos($s,"last_error_code='M1_LEASE_EXPIRED'")!==false){$n=0;foreach($this->jobs as &$j){if($j['status']==='leased' && !$j['leased_until']){$j['status']=$j['attempt_count']>=3?'failed':'retry_wait';$j['lease_token']=null;$j['next_run_at']=true;++$n;}}unset($j);return $n;}
  if(strpos($s,"SET status='retry_wait',attempt_count=0")!==false){[$id,$type]=$a;$j=&$this->jobs[$id];if($j['status']!=='failed'){return 0;}$j['status']='retry_wait';$j['attempt_count']=0;$j['next_run_at']=null;return 1;}
  if(strpos($s,"SET status='cancelled'")!==false){[$id,$type]=$a;$j=&$this->jobs[$id];if(!in_array($j['status'],['queued','retry_wait','failed'])){return 0;}$j['status']='cancelled';return 1;}
  throw new RuntimeException('Unexpected query '.$s);
 }
}
