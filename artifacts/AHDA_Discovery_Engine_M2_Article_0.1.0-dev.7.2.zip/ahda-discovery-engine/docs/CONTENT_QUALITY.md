# Kualitas profil sekolah dan kesiapan pencarian

## Kontrak isi

Tujuan profil adalah membantu orang tua/siswa memahami pilihan sekolah. Tulisan
panjang, pengulangan kata kunci dan angka kelengkapan tidak membuktikan kualitas.
Jangan mengarang fasilitas, biaya, prestasi, akreditasi, reputasi, peluang masuk,
peringkat atau kanal resmi. Status negeri bukan bukti biaya gratis. Catatan lama
bukan bukti kondisi sekarang. Data yang belum tersedia berbeda dari tidak ada.

Setiap klaim pengayaan harus terhubung ke NPSN yang tepat, URL dokumen, kutipan
pendukung, fingerprint, waktu pemeriksaan dan keputusan reviewer. Nama/wilayah
pada indeks AHDA tetap mempunyai provenance sendiri; tidak boleh dianggap
verifikasi independen atas seluruh dokumen. Sumber yang menyebut NPSN lain diblokir.
Instruksi dalam dokumen diperlakukan sebagai data, tidak menjalankan tool/model.

## Checklist editor (bukan semua sudah didukung parser)

| Topik | Informasi yang membantu pembaca | Kebutuhan bukti |
| --- | --- | --- |
| Identitas/lokasi | Nama, NPSN, jenjang, status, alamat dan akses | Indeks AHDA + sumber institusi yang sesuai; jangan campur kabupaten/kota |
| Program | Pilihan pembelajaran yang tersedia | Dokumen sekolah dan periode berlakunya |
| Kurikulum | Kurikulum yang sedang digunakan | Dokumen resmi, tahun/periode |
| Jam layanan | Hari/jam dan pengecualian | Kanal institusi terkini |
| Penerimaan | Tahun ajaran, jadwal, syarat, alur dan tautan resmi | Dokumen penerimaan untuk tahun yang dimaksud |
| Biaya/bantuan | Komponen biaya dan bantuan | Sumber resmi, periode dan cakupan; tidak berasumsi gratis |
| Fasilitas | Fasilitas yang tersedia, bukan rencana | Bukti institusi yang relevan dan mutakhir |
| Ekstrakurikuler | Kegiatan yang masih aktif | Informasi kegiatan terkini |
| Akreditasi | Hasil, lembaga, tahun dan masa berlaku | Sumber otoritatif akreditasi |
| Sejarah | Tahun berdiri/riwayat penting | Dokumen sejarah yang bisa ditelusuri |
| Kontak | Website/kontak institusi | Hubungan resmi perlu verifikasi; hindari nomor pribadi |
| Aksesibilitas | Akses fisik/layanan yang dikonfirmasi | Keterangan institusi; tidak menyimpulkan dari foto |
| Prestasi | Kegiatan, hasil, tingkat, tanggal | Bukti spesifik; hindari data pribadi siswa |

Dua belas topik pengayaan pada output artikel tidak menghitung identitas sebagai
klaim baru. Saat ini hanya program, kurikulum dan jam layanan didukung adapter.
Sembilan topik lain ditandai not_assessed_by_this_adapter; ini tidak berarti
database lama kosong atau sekolah tidak memiliki informasi tersebut. Bidang
supported tanpa klaim ditandai no_claim_in_document. Tidak ada skor SEO atau
klaim kualitas100%. Jumlah topik dengan klaim bukan jumlah topik terverifikasi.

Pemeriksaan editorial berikut masih perlu dibangun/dilaksanakan bersama M3/M4:
verifikasi otoritas/izin sumber, kesesuaian periode (terutama penerimaan/biaya),
penanganan konflik sumber, review isi dan publication contract. Batas365hari pada
normalizer bukan jaminan setiap klaim masih berlaku. Jangan mengubah fixture_only
untuk menjadikan dokumen demo seolah sumber nyata.

## SEO dan keterbacaan mesin

Audit source Directory0.8.9: includes/class-ahda-public.php sudah menghasilkan
meta description, canonical dan JSON-LD School. Sitemap/robots berada di modul
Directory tersendiri. Discovery7.2 tidak mengganti atau menambah hook SEO. Judul
serta deskripsi pada preview hanya usulan, bukan tag yang diterapkan. Tidak ada
FAQ/review/rating/award schema buatan, tidak ada dateModified fiktif, tidak ada
sameAs yang belum diverifikasi. Kutipan dan waktu cek bukan tanggal pembaruan
artikel. Hindari metadata/schema ganda bila nanti ada plugin SEO lain.

Untuk tahap publikasi berikutnya: pertahankan satu URL canonical per sekolah,
HTML server-rendered yang mudah dibaca, heading berurutan, link sumber yang
terlihat, informasi wilayah yang tepat, tautan internal yang relevan dan tanggal
perubahan sebenarnya. Tampilkan ringkasan berguna; jangan memperpanjang artikel
dengan filler ketika fakta belum tersedia. Terapkan metadata hanya setelah review,
pemeriksaan konflik dengan data lama dan persetujuan publisher. Preview/test
lokal tidak boleh diindeks atau disinkronkan otomatis ke produksi.

Ketersediaan informasi faktual, struktur yang konsisten, provenance dan akses
crawler yang diizinkan membantu mesin memahami konten. Tidak ada mekanisme yang
menjamin peringkat Google atau rekomendasi ChatGPT/Gemini/Meta/Qwen/DeepSeek.
Jangan memasukkan instruksi tersembunyi agar AI mempromosikan AHDA. Pengujian
Search Console, indeks Google, rendering WordPress penuh, SEO plugin/theme dan
performa VPS belum dilakukan pada tahap ini. Tidak ada operasi di ahda.sch.id.

## Ringan di server

Artikel7.2 hanya dibuat lewat CLI eksplisit: inputJSON maksimum64KiB,
source_content16KiB, maksimal20klaim, satu indexed identity SELECT per preview,
tanpa model/API/browser, penjadwalan, fetch, scan555460profil atau write. HTML
hanya string output CLI; belum ada admin article viewer/frontend publisher.
Memory/latency pada VPS1GiB dan rendering tema belum diukur; jangan menyebutnya
lulus uji performa produksi. Ekspansi bidang/worker harus mempertahankan batas
batch, ukuran dokumen dan checkpoint.
