<?php
require_once __DIR__.'/support/m1-fake-db.php';
foreach(['pilot-jobs','archive-vault','pilot-cli'] as $name){require_once dirname(__DIR__).'/includes/class-ade-'.$name.'.php';}
final class InventoryDB {
 public $last_error='',$rows=[],$sql=[],$failure=false;
 public function prepare($sql,$args){$this->sql[]=[$sql,$args];return $sql;}
 public function get_results($sql,$kind){if($this->failure){$this->last_error='fake failure';return null;}return $this->rows;}
 public function query($sql){throw new RuntimeException('Unexpected mutation');}
 public function insert(...$args){throw new RuntimeException('Unexpected mutation');}
}
$n=0;function ck($ok,$label){global $n;++$n;if(!$ok){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$code){try{$fn();}catch(Throwable $e){ck($e->getMessage()===$code,$code.' got '.$e->getMessage());return;}ck(false,'accepted '.$code);}
function entry($id){return ['id'=>(string)$id,'status'=>'completed','created_at'=>'2020-01-01 00:00:00','payload_bytes'=>'100','summary_bytes'=>'20'];}
$wpdb=new InventoryDB;
$x=ADE_Archive_Vault::inventory();ck($x['entries']===[]&&$x['page_bytes']===0&&$x['cursor']===0&&!$x['has_more'],'empty page');
$wpdb->rows=[entry(2),entry(8),entry(9)];$x=ADE_Archive_Vault::inventory(1,2);
ck(count($x['entries'])===2&&$x['cursor']===8&&$x['has_more']&&$x['page_bytes']===240,'lookahead excluded from page bytes and next cursor');
ck($wpdb->sql[1][1]===[ADE_Archive_Vault::TYPE,1,3],'type/cursor/limit prepared');
[$sql]=$wpdb->sql[1];ck(strpos($sql,'SELECT id,status,created_at,OCTET_LENGTH(scope_filter) AS payload_bytes,OCTET_LENGTH(stats_payload) AS summary_bytes')===0&&strpos($sql,'ORDER BY id ASC LIMIT %d')!==false,'metadata projection and bounded keyset query');
ck(!preg_match('/COUNT|FOR UPDATE|GET_LOCK|OFFSET|LEFT\(/',$sql),'no global count, lock, offset or raw substring');
ck(!$x['raw_content_returned']&&!$x['raw_contents_checked']&&!$x['retention_policy_applied']&&!$x['quota_enforced']&&!$x['encryption_verified']&&!$x['deletion_eligibility_assessed']&&!$x['snapshot_consistent_across_pages']&&$x['database_writes']===0&&$x['network_requests']===0,'honest safety/coverage boundaries');
ck($x['entries'][0]['age_days']>1000&&!$x['entries'][0]['future_timestamp'],'UTC age advisory');
$wpdb->rows=[entry(20)];$wpdb->rows[0]['created_at']='2999-01-01 00:00:00';$wpdb->rows[0]['payload_bytes']='1048577';$x=ADE_Archive_Vault::inventory(8,2);ck(!$x['has_more']&&$x['entries'][0]['future_timestamp']&&$x['entries'][0]['age_days']===null&&$x['entries'][0]['exceeds_receipt_size_limit'],'future/oversize metadata flagged without decoding');
foreach([[-1,25],[0,0],[0,101]] as [$a,$l]){blocked(fn()=>ADE_Archive_Vault::inventory($a,$l),'VAULT_INVENTORY_RANGE_INVALID');}
foreach([['id'=>'0'],['id'=>'01'],['id'=>'1 OR 1=1'],['payload_bytes'=>'-1'],['payload_bytes'=>'1.5'],['payload_bytes'=>1.0],['payload_bytes'=>null],['payload_bytes'=>(string)PHP_INT_MAX.'0'],['summary_bytes'=>(string)PHP_INT_MAX],['created_at'=>'2026-02-30 00:00:00'],['created_at'=>'2020-01-01'],['status'=>'<script>']] as $bad){$wpdb->rows=[array_replace(entry(2),$bad)];blocked(fn()=>ADE_Archive_Vault::inventory(),'VAULT_INVENTORY_METADATA_INVALID');}
$wpdb->rows=[entry(2),entry(2)];blocked(fn()=>ADE_Archive_Vault::inventory(),'VAULT_INVENTORY_METADATA_INVALID');
$wpdb->rows=[entry(1),entry(2),entry(3)];blocked(fn()=>ADE_Archive_Vault::inventory(0,1),'VAULT_INVENTORY_METADATA_INVALID');
$wpdb->rows=[entry(1)];blocked(fn()=>ADE_Archive_Vault::inventory(1,1),'VAULT_INVENTORY_METADATA_INVALID');
$wpdb->failure=true;blocked(fn()=>ADE_Archive_Vault::inventory(),'VAULT_READ_FAILED');$wpdb->failure=false;
$count=count($wpdb->sql);$denied_caps=['ade_manage_jobs'];blocked(fn()=>ADE_Archive_Vault::inventory(),'LOCAL_OPERATOR_GATE_BLOCKED');$denied_caps=['ade_review_candidates'];blocked(fn()=>ADE_Archive_Vault::inventory(),'VAULT_OPERATOR_REQUIRED');$denied_caps=[];ADE_Schema::$local=false;blocked(fn()=>ADE_Archive_Vault::inventory(),'LOCAL_OPERATOR_GATE_BLOCKED');ADE_Schema::$local=true;$test_actor=0;blocked(fn()=>ADE_Archive_Vault::inventory(),'VAULT_OPERATOR_REQUIRED');$test_actor=1;
ck(count($wpdb->sql)===$count,'denied actors make no inventory query');
$cli=new ADE_Pilot_CLI;blocked(fn()=>$cli->raw_inventory([],[]),'VAULT_INVENTORY_REQUIRES_DRY_RUN');blocked(fn()=>$cli->raw_inventory([],['dry-run'=>false]),'VAULT_INVENTORY_REQUIRES_DRY_RUN');
echo "PASS: $n bounded metadata-only inventory checks (fake DB; no raw/document/network/write).\n";
