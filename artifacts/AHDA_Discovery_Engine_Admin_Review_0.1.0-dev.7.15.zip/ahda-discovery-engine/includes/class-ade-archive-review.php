<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Read-only bridge: raw documents -> current values/source bindings/editorial draft. */
final class ADE_Archive_Review {
    private const TARGETS = array( 'profile_programs', 'profile_curriculum', 'profile_hours' );
    private static function rows( string $sql, array $args ): array {
        global $wpdb; $wpdb->last_error = '';
        $rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
        if ( ! is_array( $rows ) || $wpdb->last_error ) { throw new RuntimeException( 'ARCHIVE_REVIEW_READ_FAILED' ); }
        return $rows;
    }
    private static function snapshot( int $school_id ): array {
        global $wpdb;
        // ADE_Identity::lookup_pilot validated this prefix before this method.
        $table = $wpdb->prefix . 'ahda_school_meta';
        if ( strlen( $table ) > 64 ) { throw new RuntimeException( 'M2_TABLE_INVALID' ); }
        $rows = self::rows( "SELECT meta_key,LEFT(meta_value,16385) AS meta_value,OCTET_LENGTH(meta_value) AS value_bytes FROM {$table} WHERE school_id=%d AND verification_status=%s AND meta_key IN (%s,%s,%s) ORDER BY meta_key LIMIT 4", array( $school_id, 'verified', self::TARGETS[0], self::TARGETS[1], self::TARGETS[2] ) );
        if ( count( $rows ) > 3 ) { throw new RuntimeException( 'ARCHIVE_REVIEW_SNAPSHOT_INVALID' ); }
        $values = array();
        foreach ( $rows as $row ) {
            if ( ! in_array( $row['meta_key'] ?? null, self::TARGETS, true ) || ! is_string( $row['meta_value'] ?? null ) || ! isset( $row['value_bytes'] ) || ! preg_match( '/^[0-9]+$/D', (string) $row['value_bytes'] ) || (int) $row['value_bytes'] > 16384 || isset( $values[$row['meta_key']] ) ) { throw new RuntimeException( 'ARCHIVE_REVIEW_SNAPSHOT_INVALID' ); }
            $values[$row['meta_key']] = $row['meta_value'];
        }
        return $values;
    }
    /** Binding map is document_key -> existing registered website URL; no new sources. */
    public static function plan( string $raw, string $npsn, array $bindings = array() ): array {
        ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
        if ( ! current_user_can( 'ade_review_candidates' ) || (int) get_current_user_id() < 1 ) { throw new RuntimeException( 'ARCHIVE_REVIEW_OPERATOR_REQUIRED' ); }
        $actor = (int) get_current_user_id(); $now = time();
        $school = ADE_Identity::lookup_pilot( $npsn ); $school['id'] = (int) $school['id'];
        $p = ADE_Local_Worker::inspect( $raw, $npsn, $now, static function( string $code ) use ( $school ): array {
            if ( $code !== (string) $school['npsn'] ) { throw new RuntimeException( 'WORKER_IDENTITY_CONFLICT' ); } return $school;
        } );
        $result = $p['result'];
        if ( count( $bindings ) > 3 || array_diff( array_keys( $bindings ), $result['document_keys'] ) ) { throw new InvalidArgumentException( 'ARCHIVE_REVIEW_BINDINGS_INVALID' ); }
        foreach ( $bindings as $binding ) { if ( ! is_string( $binding ) || '' === $binding ) { throw new InvalidArgumentException( 'ARCHIVE_REVIEW_BINDINGS_INVALID' ); } }
        $archive = ADE_Local_Archive::freeze( $raw )['bundle']; $documents = array();
        $blockers = array_merge( $result['blocking_reasons'], array( 'ARCHIVE_CANDIDATE_STORE_REQUIRES_SEPARATE_APPROVAL', 'POSITIVE_REVIEW_NOT_IMPLEMENTED', 'PUBLICATION_DISABLED' ) );
        $sources = ADE_Schema::table_name( 'sources' ); $relations = ADE_Schema::table_name( 'school_sources' );
        foreach ( $result['document_keys'] as $key ) {
            $doc = $archive['documents'][$key];
            $entry = array( 'document_key' => $key, 'raw_sha256' => $doc['raw_sha256'], 'format' => $doc['format'], 'bytes' => strlen( $doc['content'] ),
                'source_url' => $doc['source_url'], 'checked_at' => $doc['checked_at'], 'permission_reference' => $doc['permission_reference'],
                'binding_state' => 'missing_operator_binding', 'source_id' => null, 'relation_id' => null,
                'permission_attested' => false, 'identity_attested' => false, 'pending_source_policy_passed' => false );
            if ( isset( $bindings[$key] ) ) {
                if ( ! is_string( $bindings[$key] ) ) { throw new InvalidArgumentException( 'ARCHIVE_REVIEW_BINDINGS_INVALID' ); }
                // Reuse archive URL hygiene to avoid echoing a secret URL in a plan.
                ADE_Local_Archive::document( 'binding', 'csv', $bindings[$key], $doc['checked_at'], $doc['permission_reference'] );
                $registered = ADE_Source_URLs::canonicalize( $bindings[$key] );
                if ( $registered['source_type'] !== 'website' || parse_url( $doc['source_url'], PHP_URL_HOST ) !== $registered['normalized_host'] ) { throw new RuntimeException( 'ARCHIVE_REVIEW_SOURCE_HOST_CONFLICT' ); }
                $found = self::rows( "SELECT s.id AS source_id,l.id AS relation_id,s.source_type,s.access_state,s.source_status,l.identity_status,l.relationship_type FROM {$sources} s INNER JOIN {$relations} l ON l.source_id=s.id WHERE l.school_id=%d AND s.canonical_key=%s LIMIT 2", array( $school['id'], $registered['canonical_key'] ) );
                if ( count( $found ) > 1 ) { throw new RuntimeException( 'ARCHIVE_REVIEW_SOURCE_NOT_UNIQUE' ); }
                $entry['registered_url'] = $registered['canonical_url'];
                if ( $found ) {
                    $row = $found[0]; $valid = (int) ( $row['source_id'] ?? 0 ) > 0 && (int) ( $row['relation_id'] ?? 0 ) > 0;
                    foreach ( array( 'source_type', 'access_state', 'source_status', 'identity_status', 'relationship_type' ) as $field ) {
                        if ( ! is_string( $row[$field] ?? null ) ) { $valid = false; $row[$field] = ''; } else { $row[$field] = strtolower( trim( $row[$field] ) ); }
                        $entry[$field] = $row[$field];
                    }
                    $entry['source_id'] = (int) ( $row['source_id'] ?? 0 ); $entry['relation_id'] = (int) ( $row['relation_id'] ?? 0 );
                    $valid = $valid && $row['source_type'] === 'website' && $row['access_state'] === 'manual_only' && in_array( $row['source_status'], array( 'discovered', 'verified', 'active' ), true ) && in_array( $row['identity_status'], array( 'pending', 'verified' ), true ) && in_array( $row['relationship_type'], array( 'pending', 'official' ), true );
                    $entry['binding_state'] = $valid ? 'pending_only_policy_matched' : 'source_relation_blocked'; $entry['pending_source_policy_passed'] = $valid;
                } else { $entry['binding_state'] = 'registered_relation_not_found'; }
            }
            if ( ! $entry['pending_source_policy_passed'] ) { $blockers[] = 'SOURCE_BINDING_REQUIRED_OR_BLOCKED'; }
            $documents[] = $entry;
        }
        $current = self::snapshot( $school['id'] );
        foreach ( $result['candidates'] as &$candidate ) {
            $value = $current[$candidate['target_key']] ?? null;
            $candidate['school_id'] = $school['id']; $candidate['current_value_snapshot'] = $value;
            $candidate['base_target_hash'] = ADE_Local_Archive::digest( array( 'm2-meta-snapshot-v1', $school['id'], $candidate['target_key'], $value ) );
            $candidate['change_required'] = $value !== $candidate['proposed_value'];
        } unset( $candidate );
        $article = $result['outcome'] === 'preview_needs_review' ? ADE_Article_Preview::build_archive( $raw, $npsn, $school, $now ) : null;
        if ( $result['outcome'] !== 'preview_needs_review' ) { $blockers[] = 'ARCHIVE_DOCUMENTS_NOT_READY'; }
        $blockers = array_values( array_unique( $blockers ) ); sort( $blockers, SORT_STRING );
        $plan = array( 'mode' => 'READ_ONLY_ARCHIVE_REVIEW_PLAN', 'schema_version' => 1, 'actor_user_id' => $actor,
            'scope' => ADE_Pilot_Scope::NAME, 'scope_hash' => ADE_Pilot_Scope::SHA256, 'manifest_sha256' => $p['manifest_sha256'], 'archive_input_sha256' => $p['archive_input_sha256'],
            'npsn' => $npsn, 'school_id' => $school['id'], 'fixture_only' => $archive['fixture_only'], 'outcome' => $result['outcome'],
            'documents' => $documents, 'candidates' => $result['candidates'], 'evidence' => $result['evidence'], 'document_errors' => $result['errors'], 'conflicts' => $result['conflicts'] ?? array(),
            'article_draft' => $article, 'blocking_reasons' => $blockers,
            'storage_enabled' => false, 'approval_enabled' => false, 'publication_enabled' => false, 'persisted' => false,
            'filesystem_writes' => 0, 'database_writes' => 0, 'network_requests' => 0 );
        $plan['plan_sha256'] = ADE_Local_Archive::digest( $plan );
        $plan['plan_hash_is_authorization'] = false;
        return $plan;
    }
}
