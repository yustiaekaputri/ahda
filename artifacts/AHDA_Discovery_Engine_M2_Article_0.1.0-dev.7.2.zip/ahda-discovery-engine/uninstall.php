<?php
// Deliberately non-destructive. Deleting R0 files must not delete AHDA data or options.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) { exit; }
