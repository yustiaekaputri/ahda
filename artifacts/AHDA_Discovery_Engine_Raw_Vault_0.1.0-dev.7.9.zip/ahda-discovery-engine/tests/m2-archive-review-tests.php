<?php
/** Archive -> current/source review plan; fake SELECTs, no mutation/network. */
require_once __DIR__.'/support/m1-fake-db.php';
foreach(['identity','source-urls','evidence-urls','pilot-scope','pilot','pilot-jobs','enrichment-preview','document-parser','local-archive','local-worker','article-preview','archive-review'] as $name){require_once dirname(__DIR__).'/includes/class-ade-'.$name.'.php';}
final class ArchiveReviewDB {
 public $prefix='custom_',$last_error='',$inner,$meta=[],$rows=[],$queries=[],$fail=false;
 public function __construct(){$this->inner=new FakeDB;foreach(ADE_Pilot_Scope::reference() as $code=>$ref){$this->inner->schools[$code]=array_merge($ref,['id'=>100000+(int)$code,'name'=>'Sekolah Contoh & "Uji"','visibility'=>'publish']);}}
 public function prepare($sql,...$args){return $this->inner->prepare($sql,...$args);}
 public function get_results($key,$kind){[$sql,$args]=$this->inner->prepared[$key];$this->queries[]=[$sql,$args];if($this->fail){$this->last_error='Read failure';return null;}
  if(strpos($sql,'FROM custom_ahda_schools ')!==false){return $this->inner->get_results($key,$kind);}
  if(strpos($sql,'FROM custom_ahda_school_meta ')!==false){if(strpos($sql,'LEFT(meta_value,16385)')===false||$args[1]!=='verified'||array_slice($args,2)!==['profile_programs','profile_curriculum','profile_hours']){throw new RuntimeException('Unsafe snapshot query');}return $this->meta;}
  if(strpos($sql,'FROM custom_ahda_discovery_sources ')!==false){if(strpos($sql,'LIMIT 2')===false||strpos($sql,'l.school_id=%d AND s.canonical_key=%s')===false){throw new RuntimeException('Unsafe source query');}return $this->rows;}
  throw new RuntimeException('Unexpected query');
 }
 public function query(...$args){throw new RuntimeException('Mutation forbidden');}public function insert(...$args){throw new RuntimeException('Mutation forbidden');}
}
$n=0;function ck($ok,$label){global $n;++$n;if(!$ok){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$label,$expected=null){try{$fn();}catch(Throwable $e){ck($expected===null||$expected===$e->getMessage(),$label.' actual='.$e->getMessage());return;}ck(false,$label.' accepted');}
function enc($a){return json_encode($a,JSON_THROW_ON_ERROR);}
$now=time();$bundle=ADE_Local_Archive::freeze(ADE_Local_Archive::demo())['bundle'];$first=$bundle['schools'][0]['npsn'];$second=$bundle['schools'][1]['npsn'];$third=$bundle['schools'][2]['npsn'];
// Two agreeing independent raw CSV inputs, usable even with DOM disabled.
foreach($bundle['schools'][0]['document_keys'] as $key){unset($bundle['documents'][$key]);}$bundle['schools'][0]['document_keys']=[];
$csv=str_replace('20268071',$first,file_get_contents(dirname(__DIR__).'/data/examples/m2-profile-fixture.csv'));
foreach(['a','b'] as $path){$doc=ADE_Local_Archive::document($path==='a'?$csv:str_replace("\n","\r\n",$csv),'csv','https://example.org/doc-'.$path,gmdate('Y-m-d\TH:i:s\Z',$now-60),'synthetic-test-not-permission');$bundle['documents'][$doc['key']]=$doc['entry'];$bundle['schools'][0]['document_keys'][]=$doc['key'];}
$raw=enc($bundle);$keys=$bundle['schools'][0]['document_keys'];$bindings=array_fill_keys($keys,'https://example.org/');$wpdb=new ArchiveReviewDB;
$original=hash('sha256',serialize($wpdb->inner->schools));
$p=ADE_Archive_Review::plan($raw,$first);
ck($p['mode']==='READ_ONLY_ARCHIVE_REVIEW_PLAN'&&$p['outcome']==='preview_needs_review','one school reparsed and review planned');
ck($p['fixture_only']&&count($p['documents'])===2&&count($p['candidates'])===3&&count($p['evidence'])===6,'multisource candidates and raw evidence');
ck($p['storage_enabled']===false&&!$p['approval_enabled']&&!$p['publication_enabled']&&!$p['persisted']&&!$p['plan_hash_is_authorization'],'no authority from review plan');
ck($p['database_writes']===0&&$p['network_requests']===0&&$p['filesystem_writes']===0,'no operations');
foreach($p['documents'] as $d){ck($d['binding_state']==='missing_operator_binding'&&!$d['permission_attested']&&!$d['identity_attested'],'missing binding not inferred');ck(!isset($d['content']),'raw bytes not unnecessarily echoed');}
ck(in_array('SOURCE_BINDING_REQUIRED_OR_BLOCKED',$p['blocking_reasons'],true),'missing binding blocks');
foreach($p['candidates'] as $c){ck($c['current_value_snapshot']===null&&$c['change_required']&&strlen($c['base_target_hash'])===64&&$c['approved_value']===null,'fresh DB snapshot not input approval');}
$article=$p['article_draft'];ck(count($article['sections'])===3&&count($article['sources'])===6&&count($article['information_gaps'])===9,'multi-source article with gaps');
ck($article['coverage']['topics_approved']===0&&!$article['publication_enabled']&&!$article['search_metadata_draft']['apply_enabled'],'draft metadata never applies');
ck(strpos($article['article_html'],'&amp; &quot;Uji&quot;')!==false&&strpos($article['article_html'],'CONTOH SINTETIS')!==false,'escaped name and synthetic warning');
foreach($article['sources'] as $source){ck(isset($source['document_key'],$source['raw_document_sha256'],$source['format'])&&$source['identity_status']==='pending','raw provenance in article citations');}
$ids=array_column($article['sources'],'id');ck(count(array_unique($ids))===6,'distinct citations even normalized claims agree');
foreach($article['sections'] as $s){ck(count($s['source_ids'])===2&&!array_diff($s['source_ids'],$ids)&&!$s['approved'],'every section has two valid citations');}
$wpdb->meta=[['meta_key'=>'profile_programs','meta_value'=>'PROGRAM CONTOH UJI','value_bytes'=>18]];
$equal=ADE_Archive_Review::plan($raw,$first);$program=array_column($equal['candidates'],null,'target_key')['profile_programs'];ck(!$program['change_required']&&$program['current_value_snapshot']==='PROGRAM CONTOH UJI','equal current value no change');
ck($equal['plan_sha256']!==$p['plan_sha256'],'current snapshot changes plan checksum');
$wpdb->meta=[['meta_key'=>'profile_programs','meta_value'=>'Program lama','value_bytes'=>12]];$different=ADE_Archive_Review::plan($raw,$first);ck($different['plan_sha256']!==$equal['plan_sha256'],'different current snapshot binds plan');
$wpdb->rows=[['source_id'=>7,'relation_id'=>8,'source_type'=>'website','access_state'=>'manual_only','source_status'=>'discovered','identity_status'=>'pending','relationship_type'=>'pending']];
$bound=ADE_Archive_Review::plan($raw,$first,$bindings);foreach($bound['documents'] as $doc){ck($doc['pending_source_policy_passed']&&$doc['binding_state']==='pending_only_policy_matched'&&!$doc['permission_attested']&&!$doc['identity_attested'],'pending source not official attestation');}
ck(!in_array('SOURCE_BINDING_REQUIRED_OR_BLOCKED',$bound['blocking_reasons'],true)&&in_array('SOURCE_IDENTITY_NOT_VERIFIED',$bound['blocking_reasons'],true)&&in_array('ARCHIVE_EVIDENCE_CANDIDATE_STORE_NOT_IMPLEMENTED',$bound['blocking_reasons'],true),'binding does not authorize storage/approval');
foreach(['access_state'=>'blocked','source_status'=>'rejected','identity_status'=>'conflict','relationship_type'=>'alumni','source_type'=>'social','source_id'=>0,'relation_id'=>0] as $field=>$v){$saved=$wpdb->rows;$wpdb->rows[0][$field]=$v;$x=ADE_Archive_Review::plan($raw,$first,$bindings);ck(!$x['documents'][0]['pending_source_policy_passed'],'source policy '.$field);$wpdb->rows=$saved;}
$wpdb->rows[0]['identity_status']='verified';$wpdb->rows[0]['relationship_type']='official';$verified=ADE_Archive_Review::plan($raw,$first,$bindings);ck(!$verified['documents'][0]['identity_attested']&&!$verified['approval_enabled'],'database label not new independent verification');
$saved=$wpdb->rows;$wpdb->rows[]=$wpdb->rows[0];blocked(fn()=>ADE_Archive_Review::plan($raw,$first,$bindings),'ambiguous source relation','ARCHIVE_REVIEW_SOURCE_NOT_UNIQUE');$wpdb->rows=[];
$missing=ADE_Archive_Review::plan($raw,$first,$bindings);ck($missing['documents'][0]['binding_state']==='registered_relation_not_found','unregistered binding blocked');
foreach([array_fill_keys($keys,'https://different.example/'),array_fill_keys($keys,'https://example.org/?token=secret'),array_fill_keys($keys,'https://127.0.0.1/'),[$keys[0]=>false],[$keys[0]=>null],[str_repeat('0',64)=>'https://example.org/']] as $bad){blocked(fn()=>ADE_Archive_Review::plan($raw,$first,$bad),'invalid bindings');}
$wpdb->meta=[['meta_key'=>'profile_school_verified','meta_value'=>'1','value_bytes'=>1]];blocked(fn()=>ADE_Archive_Review::plan($raw,$first),'protected meta','ARCHIVE_REVIEW_SNAPSHOT_INVALID');
$wpdb->meta=[['meta_key'=>'profile_hours','meta_value'=>'x','value_bytes'=>16385]];blocked(fn()=>ADE_Archive_Review::plan($raw,$first),'oversized snapshot','ARCHIVE_REVIEW_SNAPSHOT_INVALID');
$wpdb->meta=[['meta_key'=>'profile_hours','meta_value'=>'x','value_bytes'=>1],['meta_key'=>'profile_hours','meta_value'=>'x','value_bytes'=>1]];blocked(fn()=>ADE_Archive_Review::plan($raw,$first),'duplicate snapshot','ARCHIVE_REVIEW_SNAPSHOT_INVALID');$wpdb->meta=[];
$bad=ADE_Archive_Review::plan($raw,$third);ck($bad['outcome']==='document_blocked'&&$bad['candidates']===[]&&$bad['article_draft']===null,'bad school gets no misleading article');
$no=ADE_Archive_Review::plan($raw,$bundle['schools'][3]['npsn']);ck($no['outcome']==='needs_source'&&$no['article_draft']===null,'no documents not expanded into empty article');
if(class_exists('DOMDocument')){$conflict=ADE_Archive_Review::plan($raw,$second);ck($conflict['outcome']==='conflicting_claims'&&$conflict['article_draft']===null&&isset($conflict['conflicts']['profile_programs']),'conflict blocks article');}
blocked(fn()=>ADE_Article_Preview::build_archive($raw,$third,$wpdb->inner->schools[$third],$now),'article directly reparses bad school','ARCHIVE_ARTICLE_BLOCKED_DOCUMENT_BLOCKED');
blocked(fn()=>ADE_Article_Preview::build_archive($raw,$first,$wpdb->inner->schools[$second],$now),'article school ID mismatch','M2_ARTICLE_IDENTITY_CONFLICT');
$fake=$p;$fake['storage_enabled']=true;blocked(fn()=>ADE_Archive_Review::plan(enc($fake),$first),'report cannot substitute archive');
$x=$bundle;$key=$keys[0];$x['documents'][$key]['content']='changed';blocked(fn()=>ADE_Archive_Review::plan(enc($x),$first),'raw tamper revalidated','ARCHIVE_DOCUMENT_HASH_MISMATCH');
$denied_caps=['ade_review_candidates'];blocked(fn()=>ADE_Archive_Review::plan($raw,$first),'review capability','ARCHIVE_REVIEW_OPERATOR_REQUIRED');$denied_caps=[];
ADE_Schema::$local=false;blocked(fn()=>ADE_Archive_Review::plan($raw,$first),'local gate','LOCAL_OPERATOR_GATE_BLOCKED');ADE_Schema::$local=true;
$test_actor=0;blocked(fn()=>ADE_Archive_Review::plan($raw,$first),'authenticated actor','ARCHIVE_REVIEW_OPERATOR_REQUIRED');$test_actor=1;
$wpdb->fail=true;blocked(fn()=>ADE_Archive_Review::plan($raw,$first),'DB read failure');$wpdb->fail=false;
ck(hash('sha256',serialize($wpdb->inner->schools))===$original,'legacy school fixture bytes unchanged');
foreach($wpdb->queries as [$sql,$args]){ck(strpos($sql,'SELECT ')===0,'all query paths SELECT only');}
echo "PASS: $n archive review/current-value/multisource editorial checks (fake DB, no HTTP or writes).\n";
