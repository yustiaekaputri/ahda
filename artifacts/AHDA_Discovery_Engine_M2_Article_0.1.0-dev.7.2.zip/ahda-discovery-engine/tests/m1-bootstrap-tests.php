<?php
if(PHP_SAPI!=='cli'){exit(2);}
define('ABSPATH',__DIR__.'/');define('WP_CLI',true);
class WP_CLI {public static $commands=[];public static function add_command($name,$class){self::$commands[$name]=$class;}}
$hooks=[];$activation=[];$deactivation=[];
function plugin_dir_path($file){return dirname($file).'/';}
function register_activation_hook($file,$callback){global $activation;$activation[]=$callback;}
function register_deactivation_hook($file,$callback){global $deactivation;$deactivation[]=$callback;}
function add_action($name,$callback,$priority=10){global $hooks;$hooks[$name][]=$callback;}
function is_admin(){return true;}
function add_option(...$args){throw new RuntimeException('Unexpected option write');}
function update_option(...$args){throw new RuntimeException('Unexpected option write');}
function wp_remote_get(...$args){throw new RuntimeException('Unexpected HTTP');}
function wp_schedule_event(...$args){throw new RuntimeException('Unexpected cron');}
require dirname(__DIR__).'/ahda-discovery-engine.php';
$n=0;function ck($v,$label){global $n;++$n;if(!$v){throw new RuntimeException('FAIL '.$label);}}
ck(array_keys($hooks)===['plugins_loaded'],'file-load registers only lifecycle/init');
ADE_Bootstrap::init();
ck(array_keys(WP_CLI::$commands)===['ade schema','ade jobs','ade sources','ade evidence','ade pilot','ade pilot source-preview','ade pilot run-one-batch','ade pilot integrity-check','ade pilot retry-failed'],'old CLI groups retained plus pilot');
foreach(['source-preview'=>'source_preview','run-one-batch'=>'run_one_batch','integrity-check'=>'integrity_check','retry-failed'=>'retry_failed'] as $alias=>$method){
    $callback=WP_CLI::$commands['ade pilot '.$alias];
    ck(is_callable($callback),'explicit hyphen command callable '.$alias);
    ck($callback[1]===$method && method_exists('ADE_Pilot_CLI',$method),'underscore method preserved '.$method);
}
ck(array_keys($hooks)===['plugins_loaded','admin_menu','admin_notices'],'no cron/network/write hooks added');
ck(count($activation)===1 && count($deactivation)===1,'lifecycle preserved');
ck(!ADE_Config::operational_feature_enabled('ade_enable_source_discovery'),'live crawler remains disabled');
ck(ADE_Schema::VERSION===1 && count(ADE_Schema::definitions())===7,'schema unchanged');
foreach(['preflight','seed','step','list_jobs','inspect','recover_expired','cancel'] as $method){ck(method_exists('ADE_Jobs',$method),'R2 method retained');}
foreach(['preview','observe','list_for_school'] as $method){ck(method_exists('ADE_Sources',$method),'R3 method retained');}
foreach(['preview','record','list_for_school'] as $method){ck(method_exists('ADE_Evidence',$method),'R4a method retained');}
echo "PASS: $n M1 bootstrap compatibility checks (offline, no WP/DB).\n";
