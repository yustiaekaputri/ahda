<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Resumable local preview only. Portable checkpoints are NOT approval/commit receipts. */
final class ADE_Local_Worker {
    public const PIPELINE = 'local-archive-preview-v1';
    private const OUTCOMES = array( 'preview_needs_review', 'needs_source', 'document_blocked', 'conflicting_claims', 'identity_blocked' );
    private static function checksum( array $state ): string { unset( $state['checksum'] ); return ADE_Local_Archive::digest( $state ); }
    private static function state( array $archive, ?string $raw, int $now ): array {
        $state = array( 'schema_version' => 1, 'pipeline' => self::PIPELINE, 'scope_hash' => ADE_Pilot_Scope::SHA256,
            'manifest_sha256' => $archive['manifest_sha256'], 'cursor' => 0, 'records' => array() );
        if ( null === $raw ) { return $state; }
        $given = ADE_Strict_JSON::decode( $raw, 524288 );
        if ( isset( $given['checkpoint'] ) ) {
            if ( ( $given['mode'] ?? null ) !== 'READ_ONLY_LOCAL_BATCH_PREVIEW' || ! is_array( $given['checkpoint'] ) ) { throw new InvalidArgumentException( 'WORKER_CHECKPOINT_INVALID' ); }
            $given = $given['checkpoint'];
        }
        ADE_Local_Archive::keys( $given, array( 'schema_version', 'pipeline', 'scope_hash', 'manifest_sha256', 'cursor', 'records', 'checksum' ) );
        foreach ( array( 'schema_version', 'pipeline', 'scope_hash', 'manifest_sha256' ) as $key ) { if ( $given[$key] !== $state[$key] ) { throw new InvalidArgumentException( 'WORKER_CHECKPOINT_BINDING_INVALID' ); } }
        if ( ! is_int( $given['cursor'] ) || $given['cursor'] < 0 || $given['cursor'] > 200 || ! is_array( $given['records'] ) || count( $given['records'] ) !== $given['cursor'] || array_values( $given['records'] ) !== $given['records'] || ! is_string( $given['checksum'] ) || ! hash_equals( self::checksum( $given ), $given['checksum'] ) ) { throw new InvalidArgumentException( 'WORKER_CHECKPOINT_INVALID' ); }
        foreach ( $given['records'] as $index => $record ) {
            if ( ! is_array( $record ) ) { throw new InvalidArgumentException( 'WORKER_CHECKPOINT_INVALID' ); }
            ADE_Local_Archive::keys( $record, array( 'npsn', 'outcome', 'attempts', 'document_keys', 'result_sha256', 'evaluated_at' ) );
            $school = $archive['bundle']['schools'][$index];
            if ( $record['npsn'] !== $school['npsn'] || $record['document_keys'] !== $school['document_keys'] || ! in_array( $record['outcome'], self::OUTCOMES, true ) ||
                ! is_int( $record['attempts'] ) || $record['attempts'] < 1 || $record['attempts'] > 3 || ! is_string( $record['result_sha256'] ) || ! preg_match( '/^[a-f0-9]{64}$/D', $record['result_sha256'] ) ||
                ! is_int( $record['evaluated_at'] ) || $record['evaluated_at'] < 1 || $record['evaluated_at'] > $now + 300 ) { throw new InvalidArgumentException( 'WORKER_CHECKPOINT_INVALID' ); }
        }
        unset( $given['checksum'] ); return $given;
    }
    private static function code( Throwable $e ): string {
        return preg_match( '/^[A-Z0-9_]{1,80}$/D', $e->getMessage() ) ? $e->getMessage() : 'LOCAL_DOCUMENT_REJECTED';
    }
    private static function school( array $archive, array $selection, int $now, ?callable $resolve ): array {
        $npsn = $selection['npsn'];
        $result = array( 'npsn' => $npsn, 'outcome' => 'needs_source', 'fixture_only' => $archive['fixture_only'], 'identity_checked' => false,
            'document_keys' => $selection['document_keys'], 'candidates' => array(), 'evidence' => array(), 'errors' => array(),
            'blocking_reasons' => array( 'ADMIN_REVIEW_REQUIRED', 'SOURCE_PERMISSION_NOT_VERIFIED' ), 'evaluated_at' => $now,
            'persisted' => false, 'network_requests' => 0, 'database_writes' => 0, 'publication_enabled' => false );
        if ( $resolve ) {
            try {
                $live = $resolve( $npsn );
                if ( ! is_array( $live ) || (string) ( $live['npsn'] ?? '' ) !== $npsn || (int) ( $live['id'] ?? 0 ) < 1 ) { throw new RuntimeException( 'WORKER_IDENTITY_CONFLICT' ); }
                ADE_Pilot_Scope::assert_school( $live ); $result['identity_checked'] = true; $result['school_id'] = (int) $live['id'];
            } catch ( Throwable $e ) { $result['outcome'] = 'identity_blocked'; $result['errors'][] = array( 'code' => self::code( $e ) ); return $result; }
        } else { $result['blocking_reasons'][] = 'LIVE_IDENTITY_NOT_CHECKED'; }
        if ( ! $selection['document_keys'] ) { return $result; }
        $candidates = array(); $evidence = array(); $values = array();
        foreach ( $selection['document_keys'] as $key ) {
            $doc = $archive['documents'][$key];
            try {
                if ( $doc['format'] === 'json' ) {
                    $p = ADE_Enrichment_Preview::normalize( $doc['content'], $now );
                    if ( $p['npsn'] !== $npsn || $p['fixture_only'] !== $archive['fixture_only'] || $p['evidence'][0]['source_url'] !== $doc['source_url'] || $p['evidence'][0]['checked_at'] !== $doc['checked_at'] || $p['evidence'][0]['operator_reference'] !== $doc['permission_reference'] ) { throw new InvalidArgumentException( 'ARCHIVE_JSON_METADATA_CONFLICT' ); }
                } else {
                    $parsed = ADE_Document_Parser::parse( $doc['content'], $doc['format'], $npsn, array( 'fixture_only' => $archive['fixture_only'], 'source_url' => $doc['source_url'], 'checked_at' => $doc['checked_at'], 'permission_reference' => $doc['permission_reference'] ), $now );
                    $p = $parsed['preview'];
                }
                $result['blocking_reasons'] = array_merge( $result['blocking_reasons'], $p['blocking_reasons'] );
                foreach ( $p['evidence'] as $entry ) {
                    $ref = ADE_Local_Archive::digest( array( 'archive-preview-evidence-v1', $key, $entry['preview_key'] ) );
                    $evidence[$ref] = array_merge( $entry, array( 'archive_evidence_key' => $ref, 'document_key' => $key, 'raw_document_sha256' => $doc['raw_sha256'], 'format' => $doc['format'] ) );
                }
                foreach ( $p['candidates'] as $candidate ) {
                    $target = $candidate['target_key']; $value = $candidate['proposed_value'];
                    if ( ! isset( $values[$target] ) ) { $values[$target] = array(); }
                    if ( ! in_array( $value, $values[$target], true ) ) { $values[$target][] = $value; }
                    $candidate_key = $candidate['preview_key'];
                    if ( ! isset( $candidates[$candidate_key] ) ) { unset( $candidate['evidence_preview_keys'] ); $candidate['archive_evidence_keys'] = array(); $candidates[$candidate_key] = $candidate; }
                    foreach ( $p['evidence'] as $entry ) {
                        if ( $entry['target_key'] === $target && $entry['observed_value'] === $value ) {
                            $ref = ADE_Local_Archive::digest( array( 'archive-preview-evidence-v1', $key, $entry['preview_key'] ) );
                            $candidates[$candidate_key]['archive_evidence_keys'][$ref] = $ref;
                        }
                    }
                }
            } catch ( Throwable $e ) { $result['errors'][] = array( 'document_key' => $key, 'code' => self::code( $e ) ); }
        }
        $result['blocking_reasons'] = array_values( array_unique( $result['blocking_reasons'] ) ); sort( $result['blocking_reasons'], SORT_STRING );
        if ( $result['errors'] ) { $result['outcome'] = 'document_blocked'; return $result; }
        $conflicts = array();
        foreach ( $values as $target => $options ) { if ( count( $options ) > 1 ) { sort( $options, SORT_STRING ); $conflicts[$target] = $options; } }
        if ( $conflicts ) { ksort( $conflicts ); $result['outcome'] = 'conflicting_claims'; $result['conflicts'] = $conflicts; $result['blocking_reasons'][] = 'MULTI_SOURCE_CONFLICT'; return $result; }
        ksort( $candidates, SORT_STRING ); ksort( $evidence, SORT_STRING );
        foreach ( $candidates as &$candidate ) { $candidate['archive_evidence_keys'] = array_values( $candidate['archive_evidence_keys'] ); sort( $candidate['archive_evidence_keys'], SORT_STRING ); } unset( $candidate );
        $result['outcome'] = 'preview_needs_review'; $result['candidates'] = array_values( $candidates ); $result['evidence'] = array_values( $evidence );
        return $result;
    }
    public static function run( string $raw_archive, ?string $raw_checkpoint, int $batch_size, int $now, ?callable $resolve = null, ?callable $clock = null, ?string $retry_npsn = null ): array {
        if ( $batch_size < 1 || $batch_size > 10 || $now < 1 ) { throw new InvalidArgumentException( 'WORKER_BATCH_INVALID' ); }
        $archive = ADE_Local_Archive::freeze( $raw_archive ); $state = self::state( $archive, $raw_checkpoint, $now );
        $clock = $clock ?? static function() { return microtime( true ); }; $deadline = $clock() + 5.0; $results = array(); $time_limited = false;
        if ( null !== $retry_npsn ) {
            $index = array_search( $retry_npsn, array_column( $state['records'], 'npsn' ), true );
            if ( false === $index || ! in_array( $state['records'][$index]['outcome'], array( 'document_blocked', 'identity_blocked', 'conflicting_claims' ), true ) || $state['records'][$index]['attempts'] >= 3 ) { throw new InvalidArgumentException( 'WORKER_RETRY_NOT_ELIGIBLE' ); }
            $indices = array( $index );
        } else { $indices = $state['cursor'] < 200 ? range( $state['cursor'], min( 199, $state['cursor'] + $batch_size - 1 ) ) : array(); }
        foreach ( $indices as $index ) {
            if ( $clock() >= $deadline ) { $time_limited = true; break; }
            $selection = $archive['bundle']['schools'][$index]; $result = self::school( $archive['bundle'], $selection, $now, $resolve );
            $attempt = null !== $retry_npsn ? $state['records'][$index]['attempts'] + 1 : 1;
            $state['records'][$index] = array( 'npsn' => $selection['npsn'], 'outcome' => $result['outcome'], 'attempts' => $attempt, 'document_keys' => $selection['document_keys'], 'result_sha256' => ADE_Local_Archive::digest( $result ), 'evaluated_at' => $now );
            if ( null === $retry_npsn ) { $state['cursor'] = $index + 1; }
            $results[] = $result;
        }
        $state['checksum'] = self::checksum( $state ); $summary = array_fill_keys( self::OUTCOMES, 0 );
        foreach ( $state['records'] as $record ) { ++$summary[$record['outcome']]; }
        return array( 'mode' => 'READ_ONLY_LOCAL_BATCH_PREVIEW', 'pipeline' => self::PIPELINE, 'scope' => ADE_Pilot_Scope::NAME,
            'manifest_sha256' => $archive['manifest_sha256'], 'archive_input_sha256' => $archive['input_sha256'], 'fixture_only' => $archive['bundle']['fixture_only'],
            'selection_count' => 200, 'processed_this_call' => count( $results ), 'cursor' => $state['cursor'], 'complete' => $state['cursor'] === 200,
            'summary' => $summary, 'time_limit_reached' => $time_limited, 'results' => $results, 'checkpoint' => $state,
            'checkpoint_is_operator_controlled' => true, 'checkpoint_is_commit_or_approval_receipt' => false,
            'filesystem_writes' => 0, 'database_writes' => 0, 'network_requests' => 0, 'publication_enabled' => false );
    }
}
