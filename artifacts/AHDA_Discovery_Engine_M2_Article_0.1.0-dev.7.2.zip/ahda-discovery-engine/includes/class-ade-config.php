<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Namespaced, safe-by-default R0 configuration. */
final class ADE_Config {
    private const DEFAULTS = array(
        'ade_enable_jobs'                 => '0',
        'ade_enable_source_discovery'     => '0',
        'ade_enable_candidate_generation' => '0',
        'ade_enable_review_ui'            => '0',
        'ade_enable_publication_local'    => '0',
        'ade_enable_sync_export'          => '0',
        'ade_dry_run_mode'                => '1',
    );

    /** Only called on explicit activation/deactivation; no frontend option writes. */
    public static function reset_safe_defaults(): void {
        foreach ( self::DEFAULTS as $name => $value ) {
            if ( ! add_option( $name, $value, '', false ) ) {
                update_option( $name, $value, false );
            }
        }
    }

    /** For R0 status and audits only. */
    public static function flags(): array {
        $values = array();
        foreach ( self::DEFAULTS as $name => $default ) {
            $raw = get_option( $name, null );
            $values[ $name ] = array(
                'stored'   => $raw === null ? null : (string) $raw,
                'expected' => $default,
                'valid'    => $raw !== null && (string) $raw === $default,
            );
        }
        return $values;
    }

    /** Fail-closed: no operational feature exists in the R0 binary. */
    public static function operational_feature_enabled( string $flag ): bool {
        return false;
    }
}
