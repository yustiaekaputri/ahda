<?php
if(PHP_SAPI!=='cli'||!in_array($argv[1]??'',array('valid','invalid_nonce','stale','array','get','approve'),true)){exit(2);}
putenv('AHDA_REVIEW_CONTROLLER_CHILD=1');
require dirname(__DIR__).'/m3-decisions-tests.php';
require dirname(__DIR__,2).'/admin/class-ade-admin-review.php';
function wp_unslash($v){return stripslashes($v);}
function esc_html($v){return htmlspecialchars((string)$v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
function admin_url($path){return 'http://ahda.local/wp-admin/'.$path;}
function add_query_arg($args,$url){return $url.'?'.http_build_query($args,'','&',PHP_QUERY_RFC3986);}
function wp_die($message,$title='',$args=[]){throw new RuntimeException(($args['response']??0).':'.$message);}
function wp_safe_redirect($url){global $wpdb;echo 'HANDLER_RESULT:'.json_encode(['redirect'=>$url,'audits'=>count($wpdb->reviews),'receipts'=>count($wpdb->jobs),'status'=>$wpdb->candidate['review_status'],'note'=>json_decode($wpdb->reviews[1]['review_notes'],true)['note']])."\n";return true;}
$db=fresh();$r=request();$_POST=[];foreach($r as $k=>$v){$_POST[$k]=addslashes((string)$v);}$_SERVER['REQUEST_METHOD']='POST';
$mode=$argv[1];if($mode==='invalid_nonce'){$_POST['nonce']='invalid';}if($mode==='stale'){$db->candidate['row_version']='2';}if($mode==='array'){$_POST['note']=['bad'];}if($mode==='get'){$_SERVER['REQUEST_METHOD']='GET';}if($mode==='approve'){$_POST['decision']='approve';}
try{ADE_Admin_Review::handle();}catch(Throwable $e){echo 'HANDLER_RESULT:'.json_encode(['error'=>$e->getMessage(),'audits'=>count($db->reviews),'status'=>$db->candidate['review_status']])."\n";}
