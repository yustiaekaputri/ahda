<?php
/** Fake transactional DB only. NEVER points at WordPress, MySQL or school data. */
require_once __DIR__.'/support/m1-fake-db.php';
foreach(['identity','source-urls','evidence-urls','pilot-scope','pilot','pilot-jobs','enrichment-preview','enrichment-store','pilot-cli'] as $name){require_once dirname(__DIR__).'/includes/class-ade-'.$name.'.php';}
require_once __DIR__.'/support/m2-store-db.php';
$n=0;function ck($ok,$label){global $n;++$n;if(!$ok){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$label,$expected=null){$caught=false;$message=null;try{$fn();}catch(Throwable $e){$caught=true;$message=$e->getMessage();}ck($caught,$label);if($expected!==null){ck($message===$expected,'reason '.$label);}}
$base=json_decode(file_get_contents(dirname(__DIR__).'/data/examples/m2-structured-fixture.json'),true,16,JSON_THROW_ON_ERROR);
$base['fixture_only']=false;$base['checked_at']=gmdate('Y-m-d\TH:i:s\Z',time()-60);$raw=json_encode($base,JSON_THROW_ON_ERROR);$url='https://example.org/';
function fresh_db(){global $wpdb,$base,$cap,$denied_caps;$cap=true;$denied_caps=[];ADE_Schema::$local=true;$wpdb=new StoreDB;$ref=ADE_Pilot_Scope::reference()[$base['npsn']];$wpdb->inner->schools[$base['npsn']]=array_merge($ref,['id'=>913,'name'=>'Synthetic test fixture','visibility'=>'publish','education_level'=>'fixture','district_raw'=>'fixture','village_raw'=>'fixture']);return $wpdb;}
function store($raw,$token){return ADE_Enrichment_Store::record($raw,'https://example.org/',$token,'STORE_M2_PENDING','YES');}
function sizes($db){return array_map('count',$db->tables);}
$db=fresh_db();$original=hash('sha256',serialize([$db->inner->schools,$db->meta,$db->relation]));
$stage=ADE_Enrichment_Store::stage($raw,$url);ck($stage['database_writes']===0&&count($stage['candidates'])===3&&$db->writes===0,'stage purely read-only');
ck($stage['estimated_rows_created_including_receipt']===10 && $stage['estimated_pending_versions_advanced']===0,'concrete stage write impact');
ck($stage['source_id']===7&&strlen($stage['preview_token'])===64,'stage bound source/token');
foreach($stage['candidates'] as $c){ck($c['action']==='insert_pending','explicit pending-only plan');}
blocked(fn()=>ADE_Enrichment_Store::record($raw,$url,$stage['preview_token'],'WRONG','YES'),'confirm required','M2_EXPLICIT_WRITE_APPROVAL_REQUIRED');
blocked(fn()=>ADE_Enrichment_Store::record($raw,$url,$stage['preview_token'],'STORE_M2_PENDING','NO'),'backup required','M2_EXPLICIT_WRITE_APPROVAL_REQUIRED');
$fixture=$base;$fixture['fixture_only']=true;blocked(fn()=>ADE_Enrichment_Store::stage(json_encode($fixture),$url),'fixture blocked','M2_FIXTURE_RECORD_BLOCKED');
$stale=$base;$stale['checked_at']='2020-01-01T00:00:00Z';blocked(fn()=>ADE_Enrichment_Store::stage(json_encode($stale),$url),'stale evidence blocked','M2_STALE_RECORD_BLOCKED');
blocked(fn()=>ADE_Enrichment_Store::stage($raw,'https://other.sch.id/'),'cross-host relation blocked','M2_SOURCE_HOST_MISMATCH');
$save=$db->relation;$db->relation=null;blocked(fn()=>ADE_Enrichment_Store::stage($raw,$url),'unregistered source blocked','M2_SOURCE_RELATION_REQUIRED_OR_BLOCKED');$db->relation=$save;
foreach(['identity_status'=>'REJECTED','access_state'=>'blocked','source_status'=>'UNKNOWN','relationship_type'=>'rejected'] as $field=>$value){$db->relation[$field]=$value;blocked(fn()=>ADE_Enrichment_Store::stage($raw,$url),'blocked/unknown source '.$field,'M2_SOURCE_RELATION_REQUIRED_OR_BLOCKED');$db->relation=$save;}
$denied_caps=['ade_review_candidates'];blocked(fn()=>ADE_Enrichment_Store::stage($raw,$url),'review capability required','M2_REVIEW_CAPABILITY_REQUIRED');$denied_caps=[];
$cap=false;blocked(fn()=>ADE_Enrichment_Store::stage($raw,$url),'manage capability required');$cap=true;ADE_Schema::$local=false;blocked(fn()=>ADE_Enrichment_Store::stage($raw,$url),'production blocked');ADE_Schema::$local=true;
$done=store($raw,$stage['preview_token']);ck(!$done['replayed']&&$done['result']['rows_created']===10,'atomic 3+3+3+1 insert result');
ck(sizes($db)===['evidence'=>3,'candidates'=>3,'candidate_evidence'=>3,'jobs'=>1],'exact Discovery rows');
ck(hash('sha256',serialize([$db->inner->schools,$db->meta,$db->relation]))===$original,'legacy/profile/source rows unchanged');
foreach($db->tables['candidates'] as $candidate){ck($candidate['review_status']==='new'&&$candidate['publish_status']==='not_ready'&&$candidate['approved_value']===null&&$candidate['overall_score']===0,'no fabricated approval/confidence/publication');}
$before=$db->tables;$writes=$db->writes;$again=store($raw,$stage['preview_token']);ck($again['replayed']&&$again['rows_created']===0&&$db->tables===$before&&$db->writes===$writes,'same operation exact idempotent replay');
$restage=ADE_Enrichment_Store::stage($raw,$url);ck($restage['already_recorded']&&$restage['preview_token']===$stage['preview_token'],'receipt restage stable');
$receipt=ADE_Enrichment_Store::receipt($done['receipt_id']);ck($receipt['historical']&&$receipt['database_writes']===0&&!$receipt['publication_enabled'],'receipt is history not approval');
blocked(fn()=>ADE_Enrichment_Store::record($raw,$url,str_repeat('0',64),'STORE_M2_PENDING','YES'),'wrong replay token blocked','M2_PREVIEW_STALE');
// Every insertion position, including final receipt, must roll back all rows.
for($position=1;$position<=10;++$position){$db=fresh_db();$plan=ADE_Enrichment_Store::stage($raw,$url);$db->fail_insert_at=$position;blocked(fn()=>store($raw,$plan['preview_token']),'injected insert failure '.$position,'M2_INSERT_FAILED');ck(array_sum(sizes($db))===0&&!$db->held&&$db->snapshot===null,'rollback all effects '.$position);}
$db=fresh_db();$plan=ADE_Enrichment_Store::stage($raw,$url);$db->commit_fail=true;blocked(fn()=>store($raw,$plan['preview_token']),'commit failure','M2_TRANSACTION_FAILED');ck(array_sum(sizes($db))===0,'failed commit rollback');
$db=fresh_db();$plan=ADE_Enrichment_Store::stage($raw,$url);$db->commit_ack_lost=true;blocked(fn()=>store($raw,$plan['preview_token']),'lost commit acknowledgment','M2_TRANSACTION_FAILED');ck(count($db->tables['jobs'])===1,'commit applied before acknowledgment failure');$db->commit_ack_lost=false;$replay=store($raw,$plan['preview_token']);ck($replay['replayed']&&count($db->tables['candidates'])===3,'unknown outcome retry reads receipt, no duplicates');
$db=fresh_db();$plan=ADE_Enrichment_Store::stage($raw,$url);$db->meta=[['meta_key'=>'profile_programs','meta_value'=>'Changed by external editor','value_bytes'=>26]];blocked(fn()=>store($raw,$plan['preview_token']),'stale current snapshot','M2_PREVIEW_STALE');ck(array_sum(sizes($db))===0,'stale plan zero inserted rows');
$db=fresh_db();$plan=ADE_Enrichment_Store::stage($raw,$url);$db->held=true;blocked(fn()=>store($raw,$plan['preview_token']),'concurrent writer blocked','M2_WRITER_BUSY');ck(array_sum(sizes($db))===0,'busy writer zero mutations');
// New evidence on a pending candidate advances version, protecting a review form.
$db=fresh_db();$plan=ADE_Enrichment_Store::stage($raw,$url);store($raw,$plan['preview_token']);$second=$base;$second['source_content'].=' New observation A.';$secondRaw=json_encode($second);$plan2=ADE_Enrichment_Store::stage($secondRaw,$url);ck($plan2['estimated_rows_created_including_receipt']===7 && $plan2['estimated_pending_versions_advanced']===3,'append plan shows evidence/versions impact');$more=store($secondRaw,$plan2['preview_token']);ck($more['result']['rows_created']===7&&$more['result']['candidate_versions_advanced']===3,'append evidence advances optimistic versions');
foreach($db->tables['candidates'] as $candidate){ck($candidate['row_version']===2,'candidate evidence update fenced by version');}
$third=$base;$third['source_content'].=' New observation B.';$thirdRaw=json_encode($third);$plan3=ADE_Enrichment_Store::stage($thirdRaw,$url);$db->version_conflict=true;blocked(fn()=>store($thirdRaw,$plan3['preview_token']),'candidate version race','M2_CANDIDATE_VERSION_CONFLICT');ck(count($db->tables['evidence'])===6&&count($db->tables['jobs'])===2,'version conflict rollback new evidence and receipt');$db->version_conflict=false;
// A review that happens after staging invalidates the operator's old plan.
$db->tables['candidates'][1]['review_status']='approved';$db->tables['candidates'][1]['approved_value']='Concurrent reviewed value';
blocked(fn()=>store($thirdRaw,$plan3['preview_token']),'review changed after stage','M2_PREVIEW_STALE');
ck(count($db->tables['evidence'])===6 && $db->tables['candidates'][1]['approved_value']==='Concurrent reviewed value','review race preserves external decision and zero inserts');
// Reviewed candidates: preserve complete row, no hidden evidence attachments.
$db->tables['candidates'][1]['review_status']='approved';$db->tables['candidates'][1]['approved_value']='Reviewed value';$db->tables['candidates'][1]['approved_by_user_id']=5;$db->tables['candidates'][1]['approved_at']='2026-11-09 00:00:00';$reviewed=$db->tables['candidates'][1];
$lockedPlan=ADE_Enrichment_Store::stage($thirdRaw,$url);ck($lockedPlan['candidates'][0]['action']==='skip_reviewed_no_mutation','stage warns reviewed candidate skip');$stored=store($thirdRaw,$lockedPlan['preview_token']);ck($db->tables['candidates'][1]===$reviewed,'approved row unchanged byte-for-byte');ck($stored['result']['candidates'][0]['action']==='skipped_reviewed','skip explicitly reported');
$linksToReviewed=array_filter($db->tables['candidate_evidence'],fn($row)=>$row['candidate_id']===1);ck(count($linksToReviewed)===2,'no evidence appended behind reviewer');
// New document same literal evidence creates only provenance receipt, no dup links.
$fourth=$base;$fourth['permission_reference']='new-observation-reference';$fourthRaw=json_encode($fourth);$plan4=ADE_Enrichment_Store::stage($fourthRaw,$url);$dedupe=store($fourthRaw,$plan4['preview_token']);ck($dedupe['result']['rows_created']===1&&$dedupe['result']['candidate_versions_advanced']===0,'cross-document evidence/link dedupe');
foreach($db->queries as [$sql,$args]){if(strpos($sql,'UPDATE ')===0){ck(strpos($sql,'UPDATE custom_ahda_discovery_candidates SET row_version=')===0&&strpos($sql,"approved_value IS NULL")!==false,'only guarded pending version DML');}}
$cli=new ADE_Pilot_CLI;blocked(fn()=>$cli->store([],['dry-run'=>true,'confirm'=>'STORE_M2_PENDING']),'CLI dry-run cannot write');blocked(fn()=>$cli->store([],['confirm'=>'STORE_M2_PENDING','backup-confirmed'=>'NO']),'CLI backup gate');
$cli->receipt([],['receipt-id'=>'1']);$out=json_decode(end(WP_CLI::$messages),true);ck($out['historical']&&$out['network_requests']===0,'CLI read-only receipt');
// Stored receipt/evidence corruption must not be reported as valid success.
$db=fresh_db();$plan=ADE_Enrichment_Store::stage($raw,$url);$saved=store($raw,$plan['preview_token']);
$originalStats=$db->tables['jobs'][1]['stats_payload'];$db->tables['jobs'][1]['stats_payload']=json_encode(['publication_enabled'=>true]);
blocked(fn()=>ADE_Enrichment_Store::receipt(1),'corrupt receipt blocked','M2_RECEIPT_INVALID');$db->tables['jobs'][1]['stats_payload']=$originalStats;
$db->tables['evidence'][1]['snippet_text']='Tampered quote';$different=$base;$different['permission_reference']='new-reference-after-tamper';
blocked(fn()=>ADE_Enrichment_Store::stage(json_encode($different),$url),'immutable evidence conflict','M2_EXISTING_EVIDENCE_CONFLICT');
// Exercise real CLI argument handlers without a real database/file mutation.
$db=fresh_db();$folder=sys_get_temp_dir().'/ahda-m2-cli-'.bin2hex(random_bytes(6));mkdir($folder);$path=$folder.'/document.json';file_put_contents($path,$raw);
try {
    $cli=new ADE_Pilot_CLI;$args=['evidence-file'=>$path,'source-url'=>$url,'dry-run'=>true];
    $cli->stage([],$args);$cliPlan=json_decode(end(WP_CLI::$messages),true);ck($cliPlan['mode']==='READ_ONLY_M2_STAGE'&&$db->writes===0,'CLI stages zero writes');
    $cli->store([],['evidence-file'=>$path,'source-url'=>$url,'preview-token'=>$cliPlan['preview_token'],'backup-confirmed'=>'YES','confirm'=>'STORE_M2_PENDING']);
    $cliResult=json_decode(end(WP_CLI::$messages),true);ck(!$cliResult['replayed']&&$cliResult['result']['rows_created']===10,'CLI explicit store path fake only');
} finally {unlink($path);rmdir($folder);}
echo "PASS: $n M2 pending-store transactional simulations (fake DB only; NO LocalWP/MySQL writes).\n";
