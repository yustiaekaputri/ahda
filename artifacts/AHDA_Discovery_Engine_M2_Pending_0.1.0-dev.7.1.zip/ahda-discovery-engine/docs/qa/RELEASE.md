# dev.7.1 — guarded manual pending-store backend

15 offline suites PASS on PHP8.2.32 and8.4.24,695 checks each;45 PHP files lint.
New store suite115 checks uses fake transactional DB only. All84 baseline files
and6 original R2/R3/R4a suites byte-identical. Native MySQL/LocalWP writes NOT TESTED.
Permission for a disposable MySQL8.4 cloud server is pending; managed local Docker
socket health check succeeded, but no image/database/container was started.

New stage/record/receipt APIs: scoped roles, real-document/fresh-source guard,
pre-existing school-source association required, source website/host/state checks,
prepared reads, four Discovery write tables only. Source/profile/review rows never
mutated. New proposals always score0/new/not_ready/approved NULL. Reviewed rows
and evidence immutable. Pending evidence additions advance row_version conditionally.

Stages report concrete estimated row/version impact and token binding. Record
requires exact confirmation, backup acknowledgment and matching stage token.
Per-school advisory mutex, short transaction, locked rows/NOWAIT, no HTTP. Up to
20 evidence/20 links/3 candidates/1 receipt. JSON provenance/receipt hashes stored.
Same operation reads completed receipt; no duplicate rows or invented current
approval. Cross-document matching evidence/link dedupe tested. Corruption blocks.

Tests cover each of10 insert failure positions, source/roles/scope/fixtures/stale,
commit failure, simulated acknowledgment loss after applied commit, retry receipt,
review change after stage, wrong token/snapshot, busy writer, version conflict,
reviewed-row preservation, immutable evidence conflict, receipt tamper, CLI stage/
store/receipt and row allowlist. These are simulations, NOT native engine proof.

No real database writes, source requests, production or publication. Catalog
allowlist unchanged,2/20 approved requests used previously;18 remain. User approval
for catalog research is retained; no repeat probes. M2 worker/HTML/CSV, admin review,
post-commit revoke and local publisher/apply rollback remain outstanding.
