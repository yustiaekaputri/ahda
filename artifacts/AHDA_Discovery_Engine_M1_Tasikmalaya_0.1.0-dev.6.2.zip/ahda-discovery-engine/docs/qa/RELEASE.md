# dev.6.2 source inventory

Based on dev.6.1. Adds operator-triggered source-preview, no schema/data migration.
13 offline suites PASS on PHP8.2.32 and PHP8.4.24: 512 checks per runtime; 41 PHP
files lint per runtime. Original six R2/R3/R4a test files and84 baseline files
unchanged. New reader/CLI integration tests use fake DB, never real LocalWP/HTTP.

LocalWP dev.6.1 user-reported schema/pilot preflight and preview PASSED. Native
source-preview dev.6.2 remains NOT TESTED on user's database. Real job writes,
evidence persistence, crawl/robots/transport, review and publisher are not proved.
No production or real DB operations performed by cloud. Crawler hard-disabled.

Reader uses verified legacy URL fields only, fixed prepared SELECTs, per-school
row caps, scope gate and safe error codes. Canonical dedupe preserves provenance;
legacy verified does not grant identity or network permission. Sensitive query
parameter URLs are rejected without values in reports. No contact/student data.

One fixture initially used an invalid underscore in a Facebook profile path,
which correctly failed format validation before platform mismatch. The fixture
was corrected to a valid Facebook profile to exercise the intended mismatch.
All final checks pass with no assertions removed.
