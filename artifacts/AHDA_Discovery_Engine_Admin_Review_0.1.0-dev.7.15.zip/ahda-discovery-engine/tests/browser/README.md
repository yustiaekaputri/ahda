# Standalone inspector rendering checks (not full WordPress)

Opt-in local synthetic fixture. fixture.php refuses unless PHP_SAPI=cli-server
AND AHDA_UI_FIXTURE_ONLY=SYNTHETIC_NO_WORDPRESS. It never bootstraps WordPress or
connects to a DB. In normal PHP-FPM/Apache requests it returns404. CLI generator
also requires explicit flag. Runtime plugin never includes these test files.

Install/use local PHP, Node+Playwright and an available Chromium via approved
workflow; don't disable TLS or source policies. Example from plugin root:

```
mkdir -p /tmp/ahda-inspector-ui
export AHDA_UI_FIXTURE_ONLY=SYNTHETIC_NO_WORDPRESS
export AHDA_UI_FIXTURE_DATA_FILE=/tmp/ahda-inspector-ui/fixtures.json
php -n tests/browser/generate-fixtures.php
php -n -S 127.0.0.1:18974 -t tests/browser tests/browser/fixture.php
```

In a second shell with fixture server still running:

```
AHDA_UI_FIXTURE_BASE_URL=http://127.0.0.1:18974 \
AHDA_UI_FIXTURE_OUTPUT=/tmp/ahda-inspector-ui \
AHDA_UI_BROWSER_PATH=/usr/bin/chromium \
node tests/browser/inspector.spec.cjs
```

Use your installed Chromium path or omit AHDA_UI_BROWSER_PATH if Playwright's
browser is available. Preserve inherited environment/proxy/trust. Stop only the
server you started after checks. All browser requests to nonloopback destinations
blocked by the harness. Tests actual view PHP/HTML, GET filtering/navigation,
comparison/citations, empty/conflict, XSS nonexecution, auth/site403, desktop/mobile
screenshots/no page overflow/no external requests. Backend data/service/context
are fixtures, CSS minimal; service SQL tested separately. Fixture data and UI are
prominently synthetic. Never point this harness at ahda.local/production.

Dev7.5 adds a test-only review_enabled case and21checks for conditional negative
forms/nonces/required confirmations. Browser does not submit POST; controller
roundtrips run separately via CLI fake WP/DB helper. GET case cannot enable real
plugin; actual gate is undefined/OFF by default. History note XSS also covered.
