<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** M1: pure fail-closed policy. Never resolves DNS or opens a connection. */
final class ADE_Crawl_Policy {
    public const MAX_BYTES = 262144;
    public const TIMEOUT_SECONDS = 10;
    public const HOST_INTERVAL_SECONDS = 5;

    public static function url( string $url, array $hosts ): string {
        $url = ADE_Evidence_URLs::canonicalize( $url );
        $host = (string) parse_url( $url, PHP_URL_HOST );
        if ( parse_url( $url, PHP_URL_SCHEME ) !== 'https' || ! in_array( $host, $hosts, true ) ) {
            throw new InvalidArgumentException( 'HOST_OR_SCHEME_BLOCKED' );
        }
        foreach ( array( 'instagram.com', 'facebook.com', 'youtube.com', 'tiktok.com' ) as $social ) {
            if ( $host === $social || substr( $host, -strlen( '.' . $social ) ) === '.' . $social ) {
                throw new InvalidArgumentException( 'MANUAL_ONLY_PLATFORM' );
            }
        }
        // Canonicalizer already rejects credentials, IP literals and custom ports.
        return $url;
    }

    private static function cidr( string $ip, string $network, int $bits ): bool {
        $a = inet_pton( $ip ); $b = inet_pton( $network );
        if ( false === $a || false === $b || strlen( $a ) !== strlen( $b ) ) { return false; }
        $bytes = intdiv( $bits, 8 ); $rest = $bits % 8;
        return substr( $a, 0, $bytes ) === substr( $b, 0, $bytes ) &&
            ( 0 === $rest || ( ord( $a[$bytes] ) & ( 255 << ( 8 - $rest ) ) ) === ( ord( $b[$bytes] ) & ( 255 << ( 8 - $rest ) ) ) );
    }

    public static function public_ip( string $ip ): bool {
        if ( ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) { return false; }
        if ( strpos( $ip, ':' ) !== false ) {
            // Conservative global-unicast only; exclude transition/protocol/docs ranges.
            if ( ! self::cidr( $ip, '2000::', 3 ) ) { return false; }
            foreach ( array( array('2001::',23), array('2001:db8::',32), array('2002::',16), array('3fff::',20) ) as $range ) {
                if ( self::cidr( $ip, $range[0], $range[1] ) ) { return false; }
            }
            return true;
        }
        foreach ( array( array('0.0.0.0',8), array('10.0.0.0',8), array('100.64.0.0',10), array('127.0.0.0',8), array('169.254.0.0',16), array('172.16.0.0',12), array('192.0.0.0',24), array('192.0.2.0',24), array('192.88.99.0',24), array('192.168.0.0',16), array('198.18.0.0',15), array('198.51.100.0',24), array('203.0.113.0',24), array('224.0.0.0',3) ) as $range ) {
            if ( self::cidr( $ip, $range[0], $range[1] ) ) { return false; }
        }
        return true;
    }

    /** Reject an entire mixed DNS answer, never select only its public member. */
    public static function addresses( array $addresses ): array {
        if ( ! $addresses || count( $addresses ) > 32 ) { throw new InvalidArgumentException( 'DNS_BLOCKED' ); }
        foreach ( $addresses as $ip ) {
            if ( ! is_string( $ip ) || ! self::public_ip( $ip ) ) { throw new InvalidArgumentException( 'DNS_BLOCKED' ); }
        }
        return array_values( array_unique( $addresses ) );
    }

    public static function response( int $status, string $content_type, string $body ): array {
        // Zero redirects is intentional: the next location is never requested.
        if ( $status >= 300 && $status < 400 ) { throw new InvalidArgumentException( 'REDIRECT_BLOCKED' ); }
        if ( 200 !== $status ) { throw new InvalidArgumentException( 'HTTP_STATUS_BLOCKED' ); }
        $type = strtolower( trim( explode( ';', $content_type )[0] ) );
        if ( ! in_array( $type, array( 'text/html', 'application/json', 'text/csv' ), true ) ) { throw new InvalidArgumentException( 'CONTENT_TYPE_BLOCKED' ); }
        if ( strlen( $body ) > self::MAX_BYTES ) { throw new InvalidArgumentException( 'RESPONSE_TOO_LARGE' ); }
        return array( 'content_type' => $type, 'body' => $body, 'sha256' => hash( 'sha256', $body ) );
    }
}
