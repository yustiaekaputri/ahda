> dev.7.6 adds real WordPress7.1.4 synthetic admin integration evidence for
> nonce/session/capability/wpdb/routing. See WORDPRESS_INTEGRATION.md. Earlier
> NOT TESTED statements below refer to prior versions; actual user LocalWP,
> third-party/theme/production operations still NOT TESTED. Writes remain OFF.

# M3 negative decisions — dev.7.5 (default OFF)

Implemented: reject/defer only, with scoped WordPress nonce, explicit per-action
backup+confirmation, actor-specific plan, optimistic version check, shared M2
application lock, row NOWAIT lock, atomic status/audit/receipt and idempotence.
Approve/edit+approve/publish/reopen do not exist and always fail. No fact/source/
permission/identity/legacy/profile updates. No network/model/cron/schema migration.

## Current delivered state

Standard package does NOT define ADE_LOCAL_NEGATIVE_REVIEW_ENABLED; writes and
admin_post handler remain OFF/unregistered. Inspector remains read-only, with
new read-only negative-decision history when available. No options/capabilities
are changed on load, all original feature flags remain at safe defaults. Do not
change wp-config.php, role/options, or deploy a helper to enable writing now.
No instructions to operate real LocalWP writes are authorized by this release.
Tests opt in solely inside isolated synthetic processes/containers. A future
LocalWP write trial needs a concrete candidate plan, verified backup, explicit
operator approval and real WordPress nonce/role/preflight integration testing.

## State rules and impact

new/deferred -> deferred or rejected. Rejected is terminal here. Reviewed,
approved, published, approved-value/actor/time present rows cannot be changed.
No editing proposal/snapshot/base hash/evidence/source/reviewed value. Row version
advances exactly1. Per decision:1candidate status UPDATE,1INSERT reviews,
1completed operation receipt INSERT jobs (job_type=m3_negative_review). Existing
schema1 supports this, no new tables/columns/indexes.

Review audit stores action, before/after status, candidate version BEFORE review,
reason, actorID, UTCtime and bounded note JSON with after_version/operation key.
Audit only appended by service; no review UPDATE/DELETE. This is application
append-only behavior, not cryptographic tamper protection from DB administrators.
Nonce never persisted. Reason is action-specific; note max500bytes UTF8 plain,
no markup/control/bidi and no private/student/credential data allowed. Raw actor
identifiers shown only in reviewer UI, no names/emails or public profile output.

Tunda does not automatically resume enrichment. Existing M2 writer treats both
deferred/rejected as reviewed and won't append evidence behind the reviewer.
A later explicit audited reopening/workflow is still needed; not implemented.
Do not manually rewrite status/row_version or delete audit rows to undo a decision.

## Safety contract

Service requires reviewer capability, actor>0, ahda.local, safe existing preflight,
strict request schema/typed IDs/scope/action/reason/note, explicit confirmation
SAVE_NEGATIVE_REVIEW and backup YES. Plan token binds actor/action/current candidate
values/version/base hash/snapshot digest and frozen scope. Nonce binds candidate,
version and decision using WordPress wp_verify_nonce; controller accepts POST only.
A valid nonce is not permission alone; capability/site/preflight/plan rechecked.
Default OFF remains an independent prerequisite. No GET parameter enables feature.

Shared lock exactly matches M2 per-school name; GET_LOCK timeout0. Transaction
freshly checks school classification and locked candidate. CAS status UPDATE
requires old version/status and absence of approval/publication fields. Changed
version/proposal/snapshot/actor plan blocks, no silent overwrite. Reject/defer may
be used for insufficient evidence; no claim of source verification required or
created by negative decision. No path to approve based only on literal quotes.

Operation key includes scope/actor/school/candidate/version/action/reason/note/plan,
not nonce or time. Exact resubmission returns historical receipt/no audit duplicate,
even after later negative decisions. Valid current scoped nonce still required.
Receipt hash/identity/action/versions and referenced audit integrity checked.
Failed UPDATE/audit/receipt/commit roll back all pending changes. If actual COMMIT
succeeds but acknowledgment is lost, receipt resolves retry. Internal controller
errors tell operator to inspect current status/history before retrying; a failed
response does not prove nothing committed. Nonces/session expiry still handled by
WordPress; don't bypass authentication to replay an old request.

Transaction rollback is not post-commit undo. Reopen/compensating decisions and
publisher rollback remain unimplemented. No audit deletion or auto revert.

## UI and history

Default inspector shows paginated20+1 negative audit history, escaped notes and
no decision forms. When intentionally opted in in a separately approved local
test, menu/banner clearly say negative review active. Two POST forms only: Tunda
and Tolak, each with scoped nonce, reason, note, backup/impact confirmations. No
approve/edit/publish. Safe fixed local redirect ignores arbitrary referer URLs;
view re-reads actual status/history, not a forgeable GET success flag.

## Verification and limits

Actual MySQL146checks (WP/wpdb/preflight/nonce stubs), including audit/receipt
rollback, replay, commit-ack simulation, CAS/version stale, shared M2/M3 application
lock/NOWAIT, immutable negative rows/links on later M2 extraction. Synthetic only,
container removed.111offline negative decision/controller checks include default
OFF, nonce actor/action/version, types/IDOR/state, rollback, corrupt receipts/audit,
GET405/stale409/invalid403 and slash-safe POST forwarding/redirect. Full offline
suites and baseline proof in qa/dev7.5.21Chromium fixture checks, including forms/
nonce/required confirmations and XSS nonexecution with synthetic CSS/backend/WP.

Not full WordPress: real nonce/session expiry/capability integration, preflight,
Core admin routing/headers/redirect/cookie behavior and actual LocalWP data writes
still NOT TESTED. No full admin source permission workflow, approved status,
complete profile contents, raw source archive, M2resumable worker or M4publisher.
No production, ranking or AI recommendation claims. Rollback files to7.4 without
migration; preserve audits/receipts/data and restore7.5 for historical diagnosis.
