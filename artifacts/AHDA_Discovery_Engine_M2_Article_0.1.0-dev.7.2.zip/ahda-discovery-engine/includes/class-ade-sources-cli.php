<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Explicit operator-led source inspection; no network access and no crawl. */
final class ADE_Sources_CLI {
    private function required( array $assoc, string $key ): string {
        if ( ! isset( $assoc[ $key ] ) || ! is_string( $assoc[ $key ] ) || '' === trim( $assoc[ $key ] ) ) {
            WP_CLI::error( 'source-url' === $key ? 'Parameter --source-url= wajib diisi. Jangan gunakan --url karena merupakan parameter global WP-CLI.' : 'Parameter --' . $key . '= wajib diisi.' );
        }
        return trim( $assoc[ $key ] );
    }
    private function fail( Throwable $e ): void { WP_CLI::error( $e->getMessage() ); }

    /** Read-only local/schema/flag check; no network calls. */
    public function preflight( $args, $assoc ): void {
        $r = ADE_Sources::preflight();
        WP_CLI::log( '=== AHDA DISCOVERY R3 SOURCE & IDENTITY PREFLIGHT — READ ONLY ===' );
        WP_CLI::log( 'Site: ' . home_url( '/' ) );
        WP_CLI::log( 'Plugin: ' . ADE_VERSION );
        WP_CLI::log( 'Local-only: ' . ( $r['local'] ? 'PASS' : 'BLOCKED' ) );
        WP_CLI::log( 'Schema: ' . $r['schema']['state'] . ' (' . count( $r['schema']['existing_discovery'] ) . '/7 tables)' );
        WP_CLI::log( 'Legacy metadata SHA-256: ' . $r['schema']['legacy_hash'] );
        WP_CLI::log( 'Safe flags: ' . ( $r['unsafe_flags'] ? implode( ', ', $r['unsafe_flags'] ) : 'PASS' ) );
        WP_CLI::log( 'R2 mutex: ' . ( is_array( $r['r2_worker_lock'] ) ? 'ACTIVE' : 'none' ) );
        WP_CLI::log( 'HTTP requests / crawler: DISABLED; manual sources only' );
        WP_CLI::log( 'Candidates / publication / production sync: DISABLED' );
        if ( ! $r['ready'] ) {
            foreach ( $r['schema']['issues'] as $issue ) { WP_CLI::warning( $issue ); }
            WP_CLI::error( 'R3 BLOCKED: jangan jalankan observe.' );
        }
        WP_CLI::success( 'R3 READY; pemeriksaan hanya-baca selesai.' );
    }

    /** Validate/canonicalize a URL without DB access or HTTP. */
    public function check( $args, $assoc ): void {
        try {
            if ( ! ADE_Sources::preflight()['ready'] ) { throw new RuntimeException( 'R3 BLOCKED.' ); }
            $r = ADE_Source_URLs::canonicalize( $this->required( $assoc, 'source-url' ) );
            WP_CLI::log( '=== SOURCE URL CHECK (NO HTTP) ===' );
            foreach ( $r as $k => $v ) { WP_CLI::log( $k . ': ' . ( null === $v ? '-' : $v ) ); }
            WP_CLI::success( 'Format URL lulus. Ini BUKAN verifikasi keaslian situs/akun.' );
        } catch ( Throwable $e ) { $this->fail( $e ); }
    }

    /** Read-only school selection by unique NPSN. */
    public function school( $args, $assoc ): void {
        try {
            if ( ! ADE_Sources::preflight()['ready'] ) { throw new RuntimeException( 'R3 BLOCKED.' ); }
            $r = ADE_Identity::lookup( $this->required( $assoc, 'npsn' ) );
            WP_CLI::log( '=== AHDA SCHOOL EXACT NPSN — READ ONLY ===' );
            foreach ( $r as $k => $v ) { WP_CLI::log( $k . ': ' . ( null === $v ? '-' : (string) $v ) ); }
            WP_CLI::success( 'Data sekolah ditemukan; tidak ada hubungan sumber yang diverifikasi.' );
        } catch ( Throwable $e ) { $this->fail( $e ); }
    }

    /** Read-only source-to-school plan; never upgrades official verification. */
    public function preview( $args, $assoc ): void {
        try {
            $r = ADE_Sources::preview(
                $this->required( $assoc, 'npsn' ),
                $this->required( $assoc, 'source-url' ),
                isset( $assoc['claimed-name'] ) ? (string) $assoc['claimed-name'] : ''
            );
            WP_CLI::log( '=== AHDA SOURCE LINK PREVIEW — READ ONLY ===' );
            WP_CLI::log( 'school_id: ' . $r['school']['id'] . ' / npsn: ' . $r['school']['npsn'] );
            WP_CLI::log( 'school_name: ' . $r['school']['name'] );
            WP_CLI::log( 'region: ' . $r['school']['regency_raw'] . ', ' . $r['school']['district_raw'] );
            WP_CLI::log( 'canonical_url: ' . $r['source']['canonical_url'] );
            WP_CLI::log( 'source_type: ' . $r['source']['source_type'] . '; platform: ' . ( $r['source']['platform'] ?: '(website)' ) );
            WP_CLI::log( 'claimed_name_comparison: ' . $r['claimed_name_comparison'] );
            WP_CLI::log( 'identity_status: pending; relationship_type: pending; HTTP: NOT_PERFORMED' );
            WP_CLI::success( 'Preview saja; tidak menyimpan atau mengakses URL.' );
        } catch ( Throwable $e ) { $this->fail( $e ); }
    }

    /**
     * Create/reuse one pending observation; no source fetching or promotion.
     *
     * ## OPTIONS
     * --npsn=<8-digits>
     * --source-url=<http(s)-url>
     * [--label=<display name>]
     * [--claimed-name=<school name>]
     * --confirm=STORE_R3_PENDING
     */
    public function observe( $args, $assoc ): void {
        if ( ( $assoc['confirm'] ?? '' ) !== 'STORE_R3_PENDING' ) {
            WP_CLI::error( 'Butuh --confirm=STORE_R3_PENDING. Tindakan menulis hanya ke dua tabel Discovery.' );
        }
        try {
            $r = ADE_Sources::observe(
                $this->required( $assoc, 'npsn' ),
                $this->required( $assoc, 'source-url' ),
                isset( $assoc['label'] ) ? (string) $assoc['label'] : '',
                isset( $assoc['claimed-name'] ) ? (string) $assoc['claimed-name'] : ''
            );
            WP_CLI::success( 'Observation saved/reused: source #' . $r['source_id'] . ( $r['source_created'] ? ' new' : ' existing' ) . '; relation #' . $r['school_source_id'] . ( $r['relation_created'] ? ' new' : ' existing' ) . '; school_id=' . $r['school_id'] . '; identity=pending; no network/profile writes.' );
        } catch ( Throwable $e ) { $this->fail( $e ); }
    }

    /** Read-only list of R3 school source associations (max 50). */
    public function list( $args, $assoc ): void {
        try {
            $limit = isset( $assoc['limit'] ) ? (int) $assoc['limit'] : 15;
            $r = ADE_Sources::list_for_school( $this->required( $assoc, 'npsn' ), $limit );
            WP_CLI::log( '=== AHDA R3 SCHOOL SOURCES — READ ONLY ===' );
            WP_CLI::log( $r['school']['name'] . ' (NPSN ' . $r['school']['npsn'] . ')' );
            if ( ! $r['rows'] ) { WP_CLI::log( 'Belum ada sumber untuk sekolah ini.' ); }
            foreach ( $r['rows'] as $row ) {
                WP_CLI::log( 'relation #' . $row['relation_id'] . ' source #' . $row['source_id'] . ' type=' . $row['source_type'] . ' platform=' . $row['platform'] . ' identity=' . $row['identity_status'] . ' role=' . $row['relationship_type'] . ' access=' . $row['access_state'] . ' url=' . $row['canonical_url'] );
            }
            WP_CLI::success( 'Listed ' . count( $r['rows'] ) . ' link(s); no writes.' );
        } catch ( Throwable $e ) { $this->fail( $e ); }
    }

    /** Pure offline tests. No WordPress schema writes or HTTP. */
    public function selftest( $args, $assoc ): void {
        try {
            if ( ! ADE_Schema::is_allowed_local() ) { throw new RuntimeException( 'Selftest khusus LocalWP ahda.local.' ); }
            $positive = array(
                'https://www.sman1.sch.id/' => 'website',
                'https://www.instagram.com/osis_satu/?utm_source=demo' => 'social_profile',
                'https://www.youtube.com/@sma-contoh' => 'social_profile',
                'https://www.tiktok.com/@sma.contoh' => 'social_profile',
                'https://www.facebook.com/sekolah.contoh' => 'social_profile',
            );
            $negative = array(
                'http://127.0.0.1/admin', 'http://localhost/', 'http://192.168.1.1/',
                'http://foo.local/', 'ftp://sekolah.sch.id/', 'http://user:secret@sekolah.sch.id/',
                'https://www.instagram.com/reel/abc', 'https://www.youtube.com/watch?v=xyz',
                'http://sekolah.sch.id:8080/', 'http://foo.example/',
            );
            $checks = 0;
            foreach ( $positive as $url => $type ) {
                $r = ADE_Source_URLs::canonicalize( $url );
                if ( $r['source_type'] !== $type ) { throw new RuntimeException( 'Positive selftest failed.' ); }
                $checks++;
            }
            foreach ( $negative as $url ) {
                $threw = false;
                try { ADE_Source_URLs::canonicalize( $url ); } catch ( InvalidArgumentException $e ) { $threw = true; }
                if ( ! $threw ) { throw new RuntimeException( 'Negative selftest failed: ' . $url ); }
                $checks++;
            }
            if ( ADE_Identity::compare_name( 'SMA Negeri 01 Bandung', 'SMA   NEGERI 01 Bandung' ) !== 'exact_normalized' ) {
                throw new RuntimeException( 'Name normalization selftest failed.' );
            }
            $checks++;
            WP_CLI::success( 'R3 offline selftest PASS: ' . $checks . ' checks; no network, DB writes, or WordPress option changes.' );
        } catch ( Throwable $e ) { $this->fail( $e ); }
    }
}
