<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Frozen operator-selected reference. No live school IDs, network or DB writes. */
final class ADE_Pilot_Scope {
    public const NAME = 'tasikmalaya-negeri-2026-200';
    public const SHA256 = 'be4c291f4013bd14143f305fb107183a7a8c067985fbd90019f65753343803b1';

    public static function reference(): array {
        static $reference = null;
        if ( null !== $reference ) { return $reference; }
        $path = dirname( __DIR__ ) . '/data/pilots/tasikmalaya-negeri-2026-200.json';
        if ( ! is_file( $path ) || filesize( $path ) > 65536 ) { throw new RuntimeException( 'PILOT_REFERENCE_MISSING' ); }
        $raw = file_get_contents( $path, false, null, 0, 65537 );
        if ( false === $raw || ! hash_equals( self::SHA256, hash( 'sha256', $raw ) ) ) { throw new RuntimeException( 'PILOT_REFERENCE_CHANGED' ); }
        $data = json_decode( $raw, true, 8, JSON_THROW_ON_ERROR );
        if ( $data['schema_version'] !== 1 || $data['scope'] !== self::NAME || count( $data['schools'] ) !== 200 ) {
            throw new RuntimeException( 'PILOT_REFERENCE_INVALID' );
        }
        $map = array();
        foreach ( $data['schools'] as $school ) {
            $npsn = ADE_Identity::validate_npsn( $school['npsn'] );
            if ( isset( $map[$npsn] ) || $school['province_code'] !== '32' || $school['ownership_status'] !== 'NEGERI' ||
                ! in_array( $school['regency_raw'], array( 'KAB. TASIKMALAYA', 'KOTA TASIKMALAYA' ), true ) ||
                ! in_array( $school['school_form'], array( 'SMP', 'MTS', 'MA', 'SMA', 'SMK' ), true ) ) {
                throw new RuntimeException( 'PILOT_REFERENCE_INVALID' );
            }
            $map[$npsn] = $school;
        }
        $reference = $map;
        return $reference;
    }

    public static function contains( string $npsn ): bool {
        return isset( self::reference()[$npsn] );
    }

    /** Recheck live classification on each batch, never infer ownership from name. */
    public static function assert_school( array $school ): void {
        $reference = self::reference();
        $npsn = (string) ( $school['npsn'] ?? '' );
        if ( ! isset( $reference[$npsn] ) ) { throw new RuntimeException( 'PILOT_NPSN_OUTSIDE_FROZEN_SELECTION' ); }
        $expected = $reference[$npsn];
        foreach ( array( 'school_form', 'ownership_status', 'regency_raw' ) as $key ) {
            if ( ! isset( $school[$key] ) || ! is_string( $school[$key] ) || strtoupper( trim( $school[$key] ) ) !== $expected[$key] ) {
                throw new RuntimeException( 'PILOT_CLASSIFICATION_CONFLICT_' . strtoupper( $key ) );
            }
        }
        if ( ( $school['visibility'] ?? null ) !== 'publish' ) { throw new RuntimeException( 'PILOT_NOT_PUBLISHED' ); }
    }
}
