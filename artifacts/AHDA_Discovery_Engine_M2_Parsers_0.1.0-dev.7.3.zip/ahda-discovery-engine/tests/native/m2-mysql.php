<?php
/** Opt-in disposable MySQL only. NEVER run against an existing WordPress DB. */
if ( PHP_SAPI !== 'cli' || getenv('AHDA_NATIVE_TEST_APPROVED') !== 'DISPOSABLE_SYNTHETIC_ONLY' || !extension_loaded('mysqli') || !extension_loaded('dom') ) { exit(2); }
$port=getenv('AHDA_NATIVE_TEST_PORT');$password=getenv('AHDA_NATIVE_TEST_PASSWORD');
if(!is_string($port)||!preg_match('/^[0-9]{5}$/D',$port)||(int)$port<20000||!is_string($password)||strlen($password)<32){exit(2);}
define('ABSPATH',__DIR__.'/');define('WP_CLI',true);define('ARRAY_A','ARRAY_A');
class WP_CLI {public static function error($message){throw new RuntimeException($message);}}
function current_user_can($cap){return in_array($cap,['ade_manage_jobs','ade_review_candidates'],true);}
function get_current_user_id(){return 1;}
function current_time($type,$utc){return gmdate('Y-m-d H:i:s');}
function wp_parse_url($url,$part){return parse_url($url,$part);}
function home_url($path){return 'http://ahda.local/';} // Context stub, never contacted.
function is_multisite(){return false;}
class ADE_Jobs {public static function preflight(){return ['ready'=>true];}} // WP/preflight stub, actual schema tested below.
mysqli_report(MYSQLI_REPORT_ERROR|MYSQLI_REPORT_STRICT);
final class NativeDB {
 public $prefix='ade_native_',$last_error='',$insert_id=0,$db,$inserts=0,$fail_insert_at=0,$lose_commit_ack=false,$executed=[];
 public function __construct(){global $port,$password;$this->db=new mysqli('127.0.0.1','root',$password,'ahda_m2_disposable',(int)$port);$this->db->set_charset('utf8mb4');$this->db->query('SET SESSION innodb_lock_wait_timeout=1');}
 public function get_charset_collate(){return 'DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';}
 public function prepare($sql,...$args){if(count($args)===1&&is_array($args[0])){$args=$args[0];}$i=0;$out=preg_replace_callback('/%[sdf%]/',function($m)use(&$i,$args){if($m[0]==='%%'){return '%';}if(!array_key_exists($i,$args)){throw new RuntimeException('Native adapter missing placeholder');}$v=$args[$i++];return $m[0]==='%d'?(string)(int)$v:($m[0]==='%f'?(string)(float)$v:"'".$this->db->real_escape_string((string)$v)."'");},$sql);if($i!==count($args)){throw new RuntimeException('Native adapter extra args');}return $out;}
 public function get_results($sql,$kind){$this->executed[]=$sql;try{$result=$this->db->query($sql);return $result->fetch_all(MYSQLI_ASSOC);}catch(mysqli_sql_exception $e){$this->last_error=(string)$e->getCode();return null;}}
 public function query($sql){$this->executed[]=$sql;try{$this->db->query($sql);if($sql==='COMMIT'&&$this->lose_commit_ack){$this->last_error='simulated acknowledgment loss after native COMMIT';return false;}return $this->db->affected_rows;}catch(mysqli_sql_exception $e){$this->last_error=(string)$e->getCode();return false;}}
 public function insert($table,$values){++$this->inserts;if($this->inserts===$this->fail_insert_at){$this->last_error='injected insert failure';return false;}if(!preg_match('/^ade_native_ahda_discovery_(evidence|candidates|candidate_evidence|jobs)$/D',$table)){throw new RuntimeException('Native adapter write scope violation');}$cols=implode(',',array_keys($values));$args=[];foreach($values as $v){$args[]=$v===null?'NULL':"'".$this->db->real_escape_string((string)$v)."'";}$sql="INSERT INTO $table ($cols) VALUES (".implode(',',$args).')';$result=$this->query($sql);$this->insert_id=$this->db->insert_id;return $result;}
}
$wpdb=new NativeDB;
foreach(['schema','identity','source-urls','evidence-urls','pilot-scope','pilot','pilot-jobs','enrichment-preview','enrichment-store','article-preview','document-parser'] as $name){require_once dirname(__DIR__,2).'/includes/class-ade-'.$name.'.php';}
$n=0;function ck($v,$label){global $n;++$n;if(!$v){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$label,$expected=null){$message=null;try{$fn();}catch(Throwable $e){$message=$e->getMessage();}ck($message!==null,$label);if($expected!==null){ck($message===$expected,'reason '.$label);}}
function sql($s){global $wpdb;return $wpdb->db->query($s);}
function counts(){ $out=[];foreach(['evidence','candidates','candidate_evidence','jobs'] as $s){$out[$s]=(int)sql('SELECT COUNT(*) AS n FROM '.ADE_Schema::table_name($s))->fetch_assoc()['n'];}return $out; }
function state_hash($suffix){return hash('sha256',json_encode(sql('SELECT * FROM ade_native_ahda_'.$suffix.' ORDER BY id')->fetch_all(MYSQLI_ASSOC),JSON_THROW_ON_ERROR));}
function fresh(){global $wpdb;foreach(['evidence','candidates','candidate_evidence','jobs'] as $s){sql('DELETE FROM '.ADE_Schema::table_name($s));}$wpdb->inserts=0;$wpdb->fail_insert_at=0;$wpdb->lose_commit_ack=false;}
function store($raw,$token){return ADE_Enrichment_Store::record($raw,'https://example.org/',$token,'STORE_M2_PENDING','YES');}
$server=sql('SELECT VERSION() AS version')->fetch_assoc()['version'];ck(strpos($server,'8.4.')===0,'native MySQL8.4');
ck(sql('SELECT DATABASE() AS name')->fetch_assoc()['name']==='ahda_m2_disposable','fixed isolated database');
foreach(array_keys(ADE_Schema::definitions()) as $suffix){sql(ADE_Schema::create_sql($suffix));}
ck(count(sql("SHOW TABLES LIKE 'ade_native_ahda_discovery_%'")->fetch_all())===7,'all seven actual schema definitions valid InnoDB');
sql('CREATE TABLE ade_native_ahda_schools (id BIGINT UNSIGNED PRIMARY KEY,npsn CHAR(8) UNIQUE NOT NULL,name VARCHAR(255),school_form VARCHAR(20),education_level VARCHAR(20),regency_raw VARCHAR(100),district_raw VARCHAR(100),village_raw VARCHAR(100),ownership_status VARCHAR(20),visibility VARCHAR(20)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
sql('CREATE TABLE ade_native_ahda_school_meta (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,school_id BIGINT UNSIGNED,meta_key VARCHAR(100),meta_value LONGTEXT,verification_status VARCHAR(24),UNIQUE KEY school_meta(school_id,meta_key)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
$base=json_decode(file_get_contents(dirname(__DIR__,2).'/data/examples/m2-structured-fixture.json'),true,16,JSON_THROW_ON_ERROR);
$base['fixture_only']=false; // Synthetic native test input only; never delivered as a real source document.
$base['checked_at']=gmdate('Y-m-d\TH:i:s\Z',time()-60);$base['permission_reference']='disposable-synthetic-test';$raw=json_encode($base,JSON_THROW_ON_ERROR);$url='https://example.org/';
$ref=ADE_Pilot_Scope::reference()[$base['npsn']];
sql($wpdb->prepare('INSERT INTO ade_native_ahda_schools VALUES (913,%s,%s,%s,%s,%s,%s,%s,%s,%s)',$base['npsn'],'Native synthetic school',$ref['school_form'],'fixture',$ref['regency_raw'],'fixture','fixture','NEGERI','publish'));
$source=ADE_Source_URLs::canonicalize($url);$date=gmdate('Y-m-d H:i:s');
sql($wpdb->prepare('INSERT INTO ade_native_ahda_discovery_sources (id,source_type,canonical_url,canonical_key,normalized_host,created_at,updated_at) VALUES (7,%s,%s,%s,%s,%s,%s)','website',$url,$source['canonical_key'],$source['normalized_host'],$date,$date));
sql($wpdb->prepare('INSERT INTO ade_native_ahda_discovery_school_sources (id,school_id,source_id,created_at,updated_at) VALUES (8,913,7,%s,%s)',$date,$date));
$baseline=[];foreach(['schools','school_meta','discovery_sources','discovery_school_sources','discovery_reviews'] as $s){$baseline[$s]=state_hash($s);}
$plan=ADE_Enrichment_Store::stage($raw,$url);ck($plan['estimated_rows_created_including_receipt']===10&&array_sum(counts())===0,'native stage zero writes concrete ten-row plan');
$result=store($raw,$plan['preview_token']);ck($result['result']['rows_created']===10&&counts()===['evidence'=>3,'candidates'=>3,'candidate_evidence'=>3,'jobs'=>1],'native pending atomic insert');
ck((int)sql("SELECT COUNT(*) AS n FROM ade_native_ahda_discovery_candidates WHERE review_status='new' AND publish_status='not_ready' AND approved_value IS NULL AND overall_score=0")->fetch_assoc()['n']===3,'native pending/score/approval defaults');
$again=store($raw,$plan['preview_token']);ck($again['replayed']&&array_sum(counts())===10,'native idempotent receipt replay');
ck(ADE_Enrichment_Store::receipt($result['receipt_id'])['historical']===true,'native receipt read');
$draft=ADE_Article_Preview::preview($raw);ck(count($draft['sections'])===3&&!$draft['publication_enabled'],'article native indexed read with WP stubs');
foreach($baseline as $s=>$h){ck(state_hash($s)===$h,'initial legacy/source/review preservation '.$s);}
for($position=1;$position<=10;++$position){fresh();$p=ADE_Enrichment_Store::stage($raw,$url);$wpdb->fail_insert_at=$position;blocked(fn()=>store($raw,$p['preview_token']),'native rollback insert position '.$position,'M2_INSERT_FAILED');ck(array_sum(counts())===0,'native transaction atomic rollback '.$position);}
fresh();$p=ADE_Enrichment_Store::stage($raw,$url);$wpdb->lose_commit_ack=true;blocked(fn()=>store($raw,$p['preview_token']),'native committed but simulated ack lost','M2_TRANSACTION_FAILED');$wpdb->lose_commit_ack=false;ck(array_sum(counts())===10,'actual native commit remained durable');ck(store($raw,$p['preview_token'])['replayed']&&array_sum(counts())===10,'native receipt recovers unknown outcome');
$second=$base;$second['source_content'].=' Additional synthetic evidence A.';$raw2=json_encode($second);$p2=ADE_Enrichment_Store::stage($raw2,$url);$done=store($raw2,$p2['preview_token']);ck($done['result']['rows_created']===7&&$done['result']['candidate_versions_advanced']===3,'native append evidence and row version increments');
ck((int)sql('SELECT MIN(row_version) AS n FROM ade_native_ahda_discovery_candidates')->fetch_assoc()['n']===2,'native candidate versions advanced');
// A separate actual SQL session holds the same application lock.
$other=new NativeDB;$lock='ade_m2_'.substr(hash('sha256',json_encode([ADE_Schema::table_name('candidates'),913],JSON_THROW_ON_ERROR)),0,48);
$other->db->query($other->prepare('SELECT GET_LOCK(%s,0)',$lock));
$third=$base;$third['source_content'].=' Additional synthetic evidence B.';$raw3=json_encode($third);$p3=ADE_Enrichment_Store::stage($raw3,$url);$before=counts();
blocked(fn()=>store($raw3,$p3['preview_token']),'native two-session writer lock','M2_WRITER_BUSY');ck(counts()===$before,'busy writer no changes');$other->db->query($other->prepare('SELECT RELEASE_LOCK(%s)',$lock));
// Lock an actual source row in second connection; production SELECT FOR UPDATE NOWAIT must fail fast.
$other->db->begin_transaction();$other->db->query('SELECT id FROM ade_native_ahda_discovery_sources WHERE id=7 FOR UPDATE');$start=microtime(true);
blocked(fn()=>store($raw3,$p3['preview_token']),'native NOWAIT row contention','M2_READ_FAILED');ck(microtime(true)-$start<2&&counts()===$before,'NOWAIT bounded latency and rollback');$other->db->rollback();
$reviewed=sql('SELECT id FROM ade_native_ahda_discovery_candidates ORDER BY id LIMIT 1')->fetch_assoc()['id'];
sql("UPDATE ade_native_ahda_discovery_candidates SET review_status='approved',approved_value='Synthetic reviewed value',approved_by_user_id=2,approved_at=UTC_TIMESTAMP() WHERE id=".(int)$reviewed);
blocked(fn()=>store($raw3,$p3['preview_token']),'native review changed after stage','M2_PREVIEW_STALE');
$beforeReview=state_hash('discovery_candidates');$newPlan=ADE_Enrichment_Store::stage($raw3,$url);$reviewRow=sql('SELECT * FROM ade_native_ahda_discovery_candidates WHERE id='.(int)$reviewed)->fetch_assoc();$linkCount=(int)sql('SELECT COUNT(*) AS n FROM ade_native_ahda_discovery_candidate_evidence WHERE candidate_id='.(int)$reviewed)->fetch_assoc()['n'];
store($raw3,$newPlan['preview_token']);ck(sql('SELECT * FROM ade_native_ahda_discovery_candidates WHERE id='.(int)$reviewed)->fetch_assoc()===$reviewRow,'native reviewed candidate immutable');
ck((int)sql('SELECT COUNT(*) AS n FROM ade_native_ahda_discovery_candidate_evidence WHERE candidate_id='.(int)$reviewed)->fetch_assoc()['n']===$linkCount,'native reviewed evidence links unchanged');
// Existing verified meta changes after stage must invalidate fresh plan.
fresh();$p=ADE_Enrichment_Store::stage($raw,$url);sql("INSERT INTO ade_native_ahda_school_meta (school_id,meta_key,meta_value,verification_status) VALUES (913,'profile_hours','Synthetic concurrent editor value','verified')");blocked(fn()=>store($raw,$p['preview_token']),'native current-value hash stale','M2_PREVIEW_STALE');ck(array_sum(counts())===0,'stale snapshot zero inserts');sql('DELETE FROM ade_native_ahda_school_meta');
// Strict SQL escaping must preserve literal punctuation and block turning data into DML.
$quote="O'Reilly & sekolah; DROP TABLE schools; --";$quoted=$base;$quoted['source_content'].=' '.$quote;$quoted['claims'][0]=['target_key'=>'profile_programs','proposed_value'=>$quote,'supporting_quote'=>$quote];$quotedRaw=json_encode($quoted);$p=ADE_Enrichment_Store::stage($quotedRaw,$url);store($quotedRaw,$p['preview_token']);
ck(sql("SELECT proposed_value FROM ade_native_ahda_discovery_candidates WHERE target_key='profile_programs'")->fetch_assoc()['proposed_value']===$quote,'native SQL literal roundtrip');
ck((int)sql('SELECT COUNT(*) AS n FROM ade_native_ahda_schools')->fetch_assoc()['n']===1,'native identity table preserved');
foreach($baseline as $s=>$h){ck(state_hash($s)===$h,'final legacy/source/review preservation '.$s);}
// Parser-generated normalized records through actual pending writer SQL.
foreach(['csv','html'] as $format){
 fresh();$input=file_get_contents(dirname(__DIR__,2).'/data/examples/m2-profile-fixture.'.$format);
 $metadata=['fixture_only'=>false,'source_url'=>'https://example.org/ahda-fixture-only','checked_at'=>gmdate('Y-m-d\TH:i:s\Z',time()-60),'permission_reference'=>'disposable-parser-test'];
 $parsed=ADE_Document_Parser::preview($input,$format,'20268071',$metadata);
 ck(count($parsed['preview']['candidates'])===3&&$parsed['preview']['school_id']===913,'native parser preview '.$format);
 ck($parsed['raw_document_sha256']===hash('sha256',$input)&&array_sum(counts())===0,'native parser raw hash/read-only '.$format);
 $doc=json_encode($parsed['structured_document'],JSON_THROW_ON_ERROR);$stage=ADE_Enrichment_Store::stage($doc,$url);$stored=store($doc,$stage['preview_token']);
 ck($stored['result']['rows_created']===10&&array_sum(counts())===10,'native parser-to-pending transaction '.$format);
 ck(store($doc,$stage['preview_token'])['replayed']&&array_sum(counts())===10,'native parser receipt replay '.$format);
 foreach($baseline as $suffix=>$hash){ck(state_hash($suffix)===$hash,'native parser legacy/source/review preservation '.$format.' '.$suffix);}
}
$other->db->close();$wpdb->db->close();
echo "PASS: $n native MySQL $server checks (actual schema/SQL/InnoDB/locks, WordPress and wpdb adapter stubs; disposable synthetic data only).\n";
