<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Explicit POST preview then POST approval; normal GET never reparses raw. */
final class ADE_Admin_Approval {
    public static function register(): void {
        if ( ADE_Positive_Review::enabled() ) {
            add_action( 'admin_post_ade_positive_preview', array( __CLASS__, 'preview' ) );
            add_action( 'admin_post_ade_positive_review', array( __CLASS__, 'record' ) );
        }
    }
    private static function guard(): void {
        if ( ! ADE_Positive_Review::enabled() || ! ADE_Schema::is_allowed_local() || ! current_user_can( 'ade_review_candidates' ) || (int) get_current_user_id() < 1 ) { throw new RuntimeException( 'APPROVE_WEB_GATE_BLOCKED' ); }
        if ( ( $_SERVER['REQUEST_METHOD'] ?? '' ) !== 'POST' ) { throw new RuntimeException( 'APPROVE_POST_REQUIRED' ); }
    }
    private static function fields( array $keys ): array {
        if ( ! isset( $_POST['action'] ) || ! is_string( $_POST['action'] ) || ! in_array( $_POST['action'], array( 'ade_positive_preview', 'ade_positive_review' ), true ) ) { throw new InvalidArgumentException( 'APPROVE_WEB_REQUEST_INVALID' ); }
        ADE_Local_Archive::keys( $_POST, array_merge( array( 'action' ), $keys ) ); $r = array();
        foreach ( $keys as $key ) {
            if ( ! isset( $_POST[$key] ) || ! is_string( $_POST[$key] ) || strlen( $_POST[$key] ) > 2048 ) { throw new InvalidArgumentException( 'APPROVE_WEB_REQUEST_INVALID' ); }
            $r[$key] = wp_unslash( $_POST[$key] );
            if ( in_array( $key, array( 'candidate_id', 'evidence_id', 'attestation_id', 'row_version' ), true ) ) {
                if ( ! preg_match( '/^[1-9][0-9]{0,17}$/D', $r[$key] ) ) { throw new InvalidArgumentException( 'APPROVE_WEB_REQUEST_INVALID' ); } $r[$key] = (int) $r[$key];
            }
        }
        return $r;
    }
    private static function url( string $npsn, int $candidate ): string { return add_query_arg( array( 'page' => 'ahda-discovery-candidates', 'npsn' => $npsn, 'candidate' => $candidate ), admin_url( 'admin.php' ) ); }
    private static function hidden( array $values ): void { foreach ( $values as $key => $value ) { echo '<input type="hidden" name="' . esc_attr( $key ) . '" value="' . esc_attr( (string) $value ) . '">'; } }
    private static function failure( Throwable $e ): void {
        nocache_headers();
        $code = preg_match( '/^[A-Z0-9_]{1,80}$/D', $e->getMessage() ) ? $e->getMessage() : 'APPROVE_UNAVAILABLE';
        $status = $code === 'APPROVE_POST_REQUIRED' ? 405 : 403;
        if ( in_array( $code, array( 'APPROVE_PLAN_STALE', 'APPROVE_STATE_LOCKED', 'APPROVE_WRITER_BUSY', 'APPROVE_VERSION_CONFLICT', 'ATTEST_REVOKED', 'ATTEST_BINDING_CHANGED', 'ATTEST_EXPIRED_OR_EXPIRING', 'ATTEST_RAW_NOT_CURRENT' ), true ) ) { $status = 409; }
        $message = esc_html( $code );
        if ( preg_match( '/(?:READ_FAILED|TRANSACTION_FAILED|INSERT_FAILED|UNAVAILABLE|RECEIPT_INVALID)$/D', $code ) ) { $status = 503; $message .= '<p>Periksa status dan audit sebelum mencoba kembali; hasil transaksi mungkin sudah tersimpan.</p>'; }
        wp_die( $message, '', array( 'response' => $status ) );
    }
    public static function section( array $report ): void {
        $row = $report['candidate'];
        if ( ! ADE_Positive_Review::enabled() ) { return; }
        $after = $_GET['approval_after'] ?? '0'; if ( ! is_string( $after ) || ! preg_match( '/^[0-9]{1,18}$/D', $after ) ) { throw new InvalidArgumentException( 'APPROVE_SCOPE_INVALID' ); }
        $history = ADE_Positive_Review::history( $report['school']['npsn'], (int) $row['id'], (int) $after );
        echo '<h2>Riwayat persetujuan</h2><p>Riwayat keputusan bukan pemeriksaan izin terkini.</p>';
        foreach ( $history['rows'] as $entry ) { echo '<p>' . esc_html( $entry['created_at'] . ' UTC · Reviewer #' . $entry['user_id'] . ' · Versi ' . $entry['candidate_version'] . ' → ' . $entry['after_version'] . ' · Deklarasi #' . $entry['attestation_id'] ) . '</p><blockquote>' . esc_html( $entry['note'] ) . '</blockquote>'; }
        if ( null !== $history['next_after'] ) { echo '<p><a href="' . esc_url( add_query_arg( array( 'approval_after' => $history['next_after'] ), self::url( $report['school']['npsn'], (int) $row['id'] ) ) ) . '">Riwayat persetujuan berikutnya</a></p>'; }
        echo '<h2>Persetujuan satu klaim</h2><p>Persetujuan tidak menerbitkan profil. Deklarasi operator bukan verifikasi independen atau pengesahan hukum izin.</p>';
        if ( $row['review_status'] === 'approved' ) { echo '<p>Kandidat ini sudah disetujui. Nilai disimpan pada tabel perbandingan; penerbitan tetap nonaktif. Izin sumber wajib diperiksa ulang sebelum penerbitan.</p>'; return; }
        if ( ! in_array( $row['review_status'], array( 'new', 'deferred' ), true ) || $row['publish_status'] !== 'not_ready' || null !== $row['approved_value'] || ! $report['evidence'] ) { echo '<p>Kandidat ini tidak menerima persetujuan baru.</p>'; return; }
        $archive_evidence = array_filter( $report['evidence'], static function( array $entry ): bool { return isset( $entry['archive_binding'] ); } );
        if ( ! $archive_evidence ) { echo '<p>Persetujuan memerlukan bukti raw tersimpan; evidence halaman ini belum memenuhi syarat tersebut.</p>'; return; }
        echo '<p>Pilih satu evidence dan isi ID deklarasi sumber yang sudah dicatat untuk kandidat dan bukti yang sama. Pemeriksaan raw hanya berjalan setelah tombol di bawah ditekan.</p>';
        echo '<form id="ade-positive-select" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        self::hidden( array( 'action' => 'ade_positive_preview', 'npsn' => $report['school']['npsn'], 'candidate_id' => $row['id'] ) );
        wp_nonce_field( 'ade_positive_preview_' . $report['school']['npsn'] . '_' . $row['id'], 'nonce', false );
        echo '<p><label for="ade-positive-evidence">Bukti tersimpan </label><select id="ade-positive-evidence" name="evidence_id">';
        foreach ( $report['evidence'] as $entry ) { if ( isset( $entry['archive_binding'] ) ) { echo '<option value="' . esc_attr( (string) $entry['id'] ) . '">Evidence #' . esc_html( (string) $entry['id'] ) . '</option>'; } }
        echo '</select></p><p><label for="ade-positive-grant">ID deklarasi sumber </label><input id="ade-positive-grant" name="attestation_id" type="number" min="1" step="1" required></p><button class="button" type="submit">Periksa kelayakan persetujuan</button></form>';
    }
    public static function preview(): void {
        try {
            self::guard(); $r = self::fields( array( 'npsn', 'candidate_id', 'evidence_id', 'attestation_id', 'nonce' ) );
            if ( strlen( $r['npsn'] ) !== 8 || strlen( $r['nonce'] ) > 128 || ! wp_verify_nonce( $r['nonce'], 'ade_positive_preview_' . $r['npsn'] . '_' . $r['candidate_id'] ) ) { throw new RuntimeException( 'APPROVE_PREVIEW_NONCE_INVALID' ); }
            $plan = ADE_Positive_Review::plan( $r['npsn'], $r['candidate_id'], $r['evidence_id'], $r['attestation_id'] );
            $report = ADE_Candidate_Inspector::detail( $r['npsn'], $r['candidate_id'] );
            $declaration = ADE_Source_Attestation::declaration_for_review( $r['attestation_id'], $r['npsn'], $r['candidate_id'], $r['evidence_id'] );
            nocache_headers(); header( 'Content-Type: text/html; charset=UTF-8' );
            echo '<!doctype html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Konfirmasi persetujuan AHDA</title><style>body{font:16px/1.6 system-ui,sans-serif;max-width:800px;margin:24px auto;padding:0 16px;color:#172033;background:#fff}dd,pre{margin:0 0 12px;white-space:pre-wrap;overflow-wrap:anywhere}dt{font-weight:700}textarea{box-sizing:border-box;width:100%}button{padding:12px;font:inherit}label{display:block;margin:12px 0}</style></head><body><main><h1>Konfirmasi persetujuan satu klaim</h1><p>Preview baca-saja: belum ada keputusan disimpan. Tidak menerbitkan profil.</p><dl>';
            foreach ( array( 'NPSN' => $r['npsn'], 'Kandidat / evidence / deklarasi' => $r['candidate_id'] . ' / ' . $r['evidence_id'] . ' / ' . $r['attestation_id'], 'Bidang' => array( 'profile_programs' => 'Program pendidikan', 'profile_curriculum' => 'Kurikulum', 'profile_hours' => 'Jam layanan' )[$plan['target_key']], 'Nilai terverifikasi saat preview' => $report['current_verified_value'] ?? '(belum tersedia)', 'Nilai saat kandidat dibuat' => $report['candidate']['current_value_snapshot'] ?? '(belum tersedia)', 'Nilai yang akan disetujui' => $plan['proposed_value'], 'Versi diperiksa' => $plan['row_version'], 'Berlaku sampai (UTC)' => $declaration['valid_until'], 'Reviewer deklarasi' => '#' . $declaration['actor_user_id'], 'Dasar identitas' => $declaration['identity_basis'], 'Referensi identitas' => $declaration['identity_reference'], 'Catatan identitas' => $declaration['identity_note'], 'Dasar izin' => $declaration['permission_basis'], 'Referensi izin' => $declaration['permission_reference'], 'Catatan izin' => $declaration['permission_note'] ) as $label => $value ) { echo '<dt>' . esc_html( $label ) . '</dt><dd>' . esc_html( (string) $value ) . '</dd>'; }
            echo '</dl><p>Raw dan ikatan sumber cocok saat diperiksa. Referensi deklarasi dicatat oleh operator, tidak diakses atau disahkan sistem. Jika izin, bukti atau kandidat berubah, penyimpanan ditolak. Cakupan izin hanya satu klaim faktual singkat dengan atribusi.</p><form id="ade-positive-confirm" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
            self::hidden( array( 'action' => 'ade_positive_review', 'npsn' => $r['npsn'], 'candidate_id' => $r['candidate_id'], 'evidence_id' => $r['evidence_id'], 'attestation_id' => $r['attestation_id'], 'row_version' => $plan['row_version'], 'preview_token' => $plan['preview_token'] ) );
            wp_nonce_field( ADE_Positive_Review::nonce_action( $r['candidate_id'], $plan['row_version'], $r['attestation_id'] ), 'nonce', false );
            echo '<label for="ade-positive-note">Catatan review (10–500 byte, tanpa data pribadi)</label><textarea id="ade-positive-note" name="note" minlength="10" maxlength="500" rows="4" required></textarea><label><input type="checkbox" name="backup_confirmed" value="YES" required> Backup lokal sudah diperiksa.</label><label><input type="checkbox" name="confirm" value="APPROVE_ONE_CLAIM" required> Saya menyetujui satu klaim dan pencatatan audit, tanpa penerbitan.</label><button type="submit">Setujui satu klaim tanpa menerbitkan</button></form><p><a href="' . esc_url( self::url( $r['npsn'], $r['candidate_id'] ) ) . '">Batal dan kembali ke kandidat</a></p></main></body></html>';
        } catch ( Throwable $e ) { self::failure( $e ); }
        exit;
    }
    public static function record(): void {
        try {
            self::guard(); $r = self::fields( array( 'npsn', 'candidate_id', 'evidence_id', 'attestation_id', 'row_version', 'note', 'preview_token', 'nonce', 'confirm', 'backup_confirmed' ) );
            // Reject forged forms before expensive schema reads; the service repeats nonce
            // and all local/capability/preflight/transactional checks before mutation.
            if ( strlen( $r['nonce'] ) > 128 || ! wp_verify_nonce( $r['nonce'], ADE_Positive_Review::nonce_action( $r['candidate_id'], $r['row_version'], $r['attestation_id'] ) ) ) { throw new RuntimeException( 'APPROVE_NONCE_INVALID' ); }
            ADE_Positive_Review::record( $r ); nocache_headers(); wp_safe_redirect( self::url( $r['npsn'], $r['candidate_id'] ) ); exit;
        } catch ( Throwable $e ) { self::failure( $e ); }
    }
}
