<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Custom primitives reserved for future releases; only admins receive them in R0. */
final class ADE_Capabilities {
    private const CAPS = array(
        'ade_view_discovery',
        'ade_review_sources',
        'ade_review_candidates',
        'ade_manage_jobs',
        'ade_publish_local',
        'ade_export_sync',
        'ade_manage_settings',
    );

    public static function all(): array { return self::CAPS; }

    public static function grant_admin(): void {
        $role = get_role( 'administrator' );
        if ( ! $role ) { return; }
        foreach ( self::CAPS as $cap ) {
            if ( ! $role->has_cap( $cap ) ) {
                $role->add_cap( $cap, true );
            }
        }
    }

    public static function revoke_admin(): void {
        $role = get_role( 'administrator' );
        if ( ! $role ) { return; }
        foreach ( self::CAPS as $cap ) {
            if ( $role->has_cap( $cap ) ) {
                $role->remove_cap( $cap );
            }
        }
    }
}
