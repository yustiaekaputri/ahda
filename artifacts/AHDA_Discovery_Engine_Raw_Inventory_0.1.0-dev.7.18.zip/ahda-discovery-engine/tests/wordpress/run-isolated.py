#!/usr/bin/env python3
"""Real WordPress/nonce/wpdb on owned disposable DB. No real wp-config or live site."""
from pathlib import Path
import argparse,os,subprocess,tempfile,shutil,secrets,json,time,socket,re
parser=argparse.ArgumentParser();parser.add_argument('--approved-disposable-mysql',required=True,action='store_true');parser.add_argument('--wordpress-source',required=True);parser.add_argument('--directory-source',required=True);parser.add_argument('--php-bin',required=True);parser.add_argument('--extension-dir',required=True);parser.add_argument('--output-dir',required=True);args=parser.parse_args()
p=Path(__file__).resolve().parents[2];q=Path(args.output_dir).resolve();q.mkdir(parents=True,exist_ok=True)
source=Path(args.wordpress_source).resolve();directory=Path(args.directory_source).resolve()
assert (directory/'ahda-school-directory.php').is_file()
sha=subprocess.run(['git','rev-parse','HEAD'],cwd=source,text=True,capture_output=True,check=True).stdout.strip();assert sha=='db96f5eaa77a8d3e8eec8923a518fa2326f0d46a','Use pinned official WordPress7.1.4 source'
assert subprocess.run(['git','diff','--quiet'],cwd=source).returncode==0
for mod in ['ctype','iconv','fileinfo','dom','mysqlnd','mysqli'] : assert (Path(args.extension_dir)/(mod+'.so')).is_file()
env=dict(os.environ)
for key in ['DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH']:env.pop(key,None)
docker=['docker','--host=unix:///var/run/docker.sock'];image='mysql@sha256:a81d043930e51745522bd5c430961cf8286f0a23f0a9a2a6e0108f7ea71b0902'
def d(cmd,check=True):return subprocess.run(docker+cmd,env=env,text=True,capture_output=True,check=check)
password=secrets.token_hex(32);admin_password=secrets.token_hex(24);editor_password=secrets.token_hex(24);seed=secrets.token_hex(48)
def redact(s):
 for secret in [password,admin_password,editor_password,seed]:s=s.replace(secret,'[REDACTED]')
 return s
owned=None;server=None;server_log=None;tmp=None;record={'status':'NOT_COMPLETED','wordpress':'7.1.4','wordpress_commit':sha,'database_removed':False,'site_removed':False,'server_stopped':False,'scope':'Actual WP/roles/cookies/nonces/wpdb/admin routing with test-only wp-load bootstrap shim and home alias. Not user LocalWP.'}
(q/'wordpress-e2e-result.json').write_text(json.dumps(record,indent=2))
try:
 d(['info','--format','{{.ServerVersion}}']);env['MYSQL_ROOT_PASSWORD']=password
 c=d(['run','-d','--name','ahda-wp-e2e-'+secrets.token_hex(6),'--label','ahda.disposable-test=true','--cpus=1','--memory=1g','--memory-swap=1g','--tmpfs','/var/lib/mysql:rw,size=512m','-p','127.0.0.1::3306','-e','MYSQL_ROOT_PASSWORD','-e','MYSQL_ROOT_HOST=%','-e','MYSQL_DATABASE=ahda_m2_disposable',image,'--innodb-buffer-pool-size=67108864','--performance-schema=OFF','--mysqlx=OFF','--max-connections=12','--innodb-redo-log-capacity=16777216']);owned=c.stdout.strip();assert len(owned)==64
 binding=d(['port',owned,'3306/tcp']).stdout.strip();assert binding.startswith('127.0.0.1:');db_port=int(binding.split(':')[-1]);assert db_port>=20000
 print('Owned disposable MySQL started; preparing pinned WordPress copy.',flush=True)
 for _ in range(90):
  if d(['exec',owned,'mysqladmin','ping','-h127.0.0.1','--silent'],False).returncode==0:break
  time.sleep(1)
 else:raise RuntimeError('MySQL readiness timeout')
 tmp=tempfile.TemporaryDirectory(prefix='ahda-wp-e2e-',dir='/tmp');root=Path(tmp.name);site=root/'site';state=root/'state';state.mkdir();(state/'owned-test-root').write_text('synthetic-only')
 shutil.copytree(source,site,ignore=shutil.ignore_patterns('.git'));assert not (site/'wp-config.php').exists()
 # Only test COPY of wp-load changed; official source cache/core apart from shim intact.
 (site/'wp-load.php').write_text("<?php require_once getenv('AHDA_WP_E2E_BOOTSTRAP');\n")
 # Minimal test-only theme for actual Directory public template/reader checks.
 theme=site/'wp-content/themes/ahda-synthetic-test';theme.mkdir(parents=True,exist_ok=True)
 (theme/'style.css').write_text('/* Theme Name: AHDA owned synthetic test */\n')
 (theme/'index.php').write_text('<?php get_header(); get_footer();')
 (theme/'header.php').write_text('<!doctype html><html><head><meta charset="UTF-8"><?php wp_head(); ?></head><body>')
 (theme/'footer.php').write_text('<?php wp_footer(); ?></body></html>')
 plugins=site/'wp-content/plugins';shutil.copytree(directory,plugins/'ahda-school-directory');shutil.copytree(p,plugins/'ahda-discovery-engine',ignore=shutil.ignore_patterns('__pycache__'))
 with socket.socket() as sock:sock.bind(('127.0.0.1',0));http_port=sock.getsockname()[1]
 base='http://127.0.0.1:'+str(http_port)
 runenv=dict(os.environ,AHDA_WP_E2E_ONLY='SYNTHETIC_ISOLATED',AHDA_WP_E2E_ROOT=str(site),AHDA_WP_E2E_STATE=str(state),AHDA_WP_E2E_URL=base,AHDA_WP_E2E_DB_PORT=str(db_port),AHDA_WP_E2E_DB_PASSWORD=password,AHDA_WP_E2E_ADMIN_PASSWORD=admin_password,AHDA_WP_E2E_EDITOR_PASSWORD=editor_password,AHDA_WP_E2E_AUTH_SEED=seed,AHDA_WP_E2E_BOOTSTRAP=str(p/'tests/wordpress/bootstrap.php'),AHDA_WP_E2E_OUTPUT=str(q),AHDA_WP_E2E_PHP=args.php_bin,AHDA_WP_E2E_EXTENSION_DIR=args.extension_dir,AHDA_WP_E2E_CONTROL=str(p/'tests/wordpress/control.php'))
 php=[args.php_bin,'-n']
 for mod in ['ctype','iconv','fileinfo','dom','mysqlnd','mysqli']:php+=['-d','extension='+str(Path(args.extension_dir)/(mod+'.so'))]
 install=subprocess.run(php+[str(p/'tests/wordpress/control.php'),'install'],env=runenv,text=True,capture_output=True,timeout=120)
 (q/'wordpress-install-log.txt').write_text(redact(install.stdout+install.stderr));assert install.returncode==0,redact(install.stdout+install.stderr)
 setup=json.loads(install.stdout);assert setup['wordpress']=='7.1.4' and setup['preflight']['ready'] and setup['database_adapter']=='wpdb' and setup['nonce_provider']=='wp-includes/pluggable.php',setup
 (q/'wordpress-setup.json').write_text(json.dumps(setup,indent=2));print('Actual WordPress and both plugins installed; preflight PASS.',flush=True)
 server_log=open(state/'http-server.log','w');server=subprocess.Popen(php+['-S','127.0.0.1:'+str(http_port),'-t',str(site)],env=runenv,stdout=server_log,stderr=subprocess.STDOUT)
 for _ in range(50):
  try:
   with socket.create_connection(('127.0.0.1',http_port),timeout=.2):break
  except OSError:time.sleep(.1)
 else:raise RuntimeError('Owned PHP server not ready')
 tests=subprocess.run(['node',str(p/'tests/wordpress/e2e.spec.cjs')],env=runenv,text=True,capture_output=True,timeout=180)
 (q/'wordpress-browser-log.txt').write_text(redact(tests.stdout+tests.stderr));print(redact(tests.stdout+tests.stderr),flush=True)
 assert tests.returncode==0,'WordPress browser tests failed; see safe logs'
 assert not (site/'wp-config.php').exists(),'Unexpected configuration file in owned test copy'
 assert subprocess.run(['git','diff','--quiet'],cwd=source).returncode==0,'Official source cache modified'
 debug=(state/'php-debug.log').read_text() if (state/'php-debug.log').exists() else ''
 assert not re.search(r'PHP (?:Warning|Notice|Deprecated|Fatal error)|Fatal error:',debug),'Unexpected PHP diagnostic; see retained safe debug log'
 record.update(php_diagnostics_clean=True,bridge_checks=json.loads((q/'wordpress-bridge-result.json').read_text())['checks'],cli_scope='Direct service API with WP_CLI class-presence marker; official dispatcher covered separately offline')
 record.update(no_wp_config_file=True,official_source_cache_unchanged=True,real_wpdb=setup['database_adapter'],nonce_provider=setup['nonce_provider'])
 pubproof=json.loads((q/'wordpress-publication-result.json').read_text());assert pubproof['status']=='PASS'
 record.update(publication_checks=pubproof['checks'],public_frontend_scope='Actual Directory template/reader HTTP HTML parsed in DOM; no frontend resources/maps/source fetched')
 record.update(status='PASS',checks=json.loads((q/'wordpress-browser-result.json').read_text())['checks'],image_digest=image)
except Exception as e:
 record.update(status='FAIL',error=redact(str(e)));print(redact(str(e)),flush=True)
finally:
 if server:
  server.terminate()
  try:server.wait(timeout=10)
  except subprocess.TimeoutExpired:server.kill();server.wait()
  record['server_stopped']=True
 if server_log:server_log.close()
 if tmp:
  state=Path(tmp.name)/'state'
  if (state/'http-server.log').exists():(q/'wordpress-http-log.txt').write_text(redact((state/'http-server.log').read_text()))
  if (state/'php-debug.log').exists():(q/'wordpress-debug-log.txt').write_text(redact((state/'php-debug.log').read_text()))
  tmp.cleanup();record['site_removed']=True
 if owned:record['database_removed']=d(['rm','-f','-v',owned],False).returncode==0
 (q/'wordpress-e2e-result.json').write_text(json.dumps(record,indent=2));print('Cleanup: '+json.dumps({k:record[k] for k in ['database_removed','site_removed','server_stopped']}),flush=True)
raise SystemExit(0 if record['status']=='PASS' else 1)
