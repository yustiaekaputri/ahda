<?php
require_once __DIR__.'/support/m1-fake-db.php';
foreach(['identity','pilot-scope','review-decisions'] as $name){require_once dirname(__DIR__).'/includes/class-ade-'.$name.'.php';}
function wp_verify_nonce($nonce,$action){return hash_equals(hash('sha256','synthetic|'.get_current_user_id().'|'.$action),$nonce);}
function test_nonce($id,$version,$decision){return hash('sha256','synthetic|'.get_current_user_id().'|'.ADE_Review_Decisions::nonce_action($id,$version,$decision));}
final class ReviewDB {
 public $prefix='custom_',$last_error='',$insert_id=0,$inner,$candidate,$jobs=[],$reviews=[],$held=false,$snapshot=null,$fail_insert_at=0,$inserts=0,$version_conflict=false,$lose_ack=false,$fail_commit=false,$queries=[];
 public function __construct(){
  $this->inner=new FakeDB;$ref=ADE_Pilot_Scope::reference()['20268071'];$this->inner->schools['20268071']=array_merge($ref,['id'=>913,'name'=>'Synthetic negative review test','visibility'=>'publish']);
  $this->candidate=['id'=>'42','school_id'=>'913','target_key'=>'profile_programs','proposed_value'=>'Program test','proposed_bytes'=>'12','snapshot_null'=>'1','snapshot_digest'=>hash('sha256',''),'base_target_hash'=>str_repeat('a',64),'review_status'=>'new','publish_status'=>'not_ready','row_version'=>'1','approval_null'=>'1','approved_by_user_id'=>null,'approved_at'=>null,'published_local_at'=>null];
 }
 public function prepare($sql,...$args){return $this->inner->prepare($sql,...$args);}
 public function get_results($key,$kind){[$sql,$args]=$this->inner->prepared[$key]??[$key,[]];$this->queries[]=[$sql,$args];
  if(strpos($sql,'GET_LOCK(')!==false){if($this->held){return [['acquired'=>0]];}$this->held=true;return [['acquired'=>1]];}
  if(strpos($sql,'RELEASE_LOCK(')!==false){$this->held=false;return [['released'=>1]];}
  if(strpos($sql,'FROM custom_ahda_schools ')!==false){return $this->inner->get_results($key,$kind);}
  if(strpos($sql,'FROM custom_ahda_discovery_candidates ')!==false){return $args[0]===42&&$args[1]===913?[$this->candidate]:[];}
  if(strpos($sql,'FROM custom_ahda_discovery_jobs ')!==false){foreach($this->jobs as $row){if($row['job_key']===$args[0]&&$row['job_type']===$args[1]){$row['scope_bytes']=strlen($row['scope_filter']);$row['stats_bytes']=strlen($row['stats_payload']);return [$row];}}return [];}
  if(strpos($sql,'FROM custom_ahda_discovery_reviews ')!==false){$out=[];foreach($this->reviews as $row){$ok=strpos($sql,'WHERE id=%d')!==false?(int)$row['id']===$args[0]:($row['candidate_id']===$args[0]&&(int)$row['id']>$args[1]);if($ok){$row['notes_bytes']=strlen($row['review_notes']);$out[]=$row;}}return $out;}
  throw new RuntimeException('Unexpected review read');
 }
 public function query($key){[$sql,$args]=$this->inner->prepared[$key]??[$key,[]];$this->queries[]=[$sql,$args];
  if($sql==='START TRANSACTION'){$this->snapshot=[$this->candidate,$this->jobs,$this->reviews];return 0;}
  if($sql==='ROLLBACK'){if($this->snapshot!==null){[$this->candidate,$this->jobs,$this->reviews]=$this->snapshot;}$this->snapshot=null;return 0;}
  if($sql==='COMMIT'){if($this->lose_ack){$this->snapshot=null;$this->last_error='ack lost';return false;}if($this->fail_commit){$this->last_error='commit fail';return false;}$this->snapshot=null;return 0;}
  if(strpos($sql,'UPDATE custom_ahda_discovery_candidates SET review_status=')===0){[$status,$now,$id,$school,$version,$before]=$args;if($this->version_conflict||(int)$this->candidate['row_version']!==$version||$this->candidate['review_status']!==$before){return 0;}$this->candidate['review_status']=$status;$this->candidate['row_version']=(string)($version+1);$this->candidate['updated_at']=$now;return 1;}
  throw new RuntimeException('Unexpected review mutation');
 }
 public function insert($table,$values){++$this->inserts;if($this->fail_insert_at===$this->inserts){$this->last_error='injected insert';return false;}
  if($table==='custom_ahda_discovery_reviews'){$id=count($this->reviews)+1;$values['id']=$id;$this->reviews[$id]=$values;}
  elseif($table==='custom_ahda_discovery_jobs'){$id=count($this->jobs)+1;$values['id']=$id;$this->jobs[$id]=$values;}
  else{throw new RuntimeException('Review table outside allowlist');}$this->insert_id=$id;return 1;
 }
}
$n=0;function ck($v,$name){global $n;++$n;if(!$v){throw new RuntimeException('FAIL '.$name);}}
function blocked($fn,$name,$expected=null){$error=null;try{$fn();}catch(Throwable $e){$error=$e->getMessage();}ck($error!==null,$name);if($expected!==null){ck($error===$expected,'reason '.$name.' actual='.($error??'none'));}}
function fresh(){global $wpdb,$test_actor,$cap;$test_actor=1;$cap=true;ADE_Schema::$local=true;ADE_Jobs::$ready=true;$wpdb=new ReviewDB;return $wpdb;}
function request($decision='defer'){ $p=ADE_Review_Decisions::plan('20268071',42,$decision);return ['npsn'=>'20268071','candidate_id'=>42,'row_version'=>$p['row_version'],'decision'=>$decision,'reason'=>$decision==='reject'?'WRONG_INFORMATION':'WAITING_SOURCE','note'=>"O'Reilly: perlu dokumen institusi",'preview_token'=>$p['preview_token'],'nonce'=>test_nonce(42,$p['row_version'],$decision),'confirm'=>'SAVE_NEGATIVE_REVIEW','backup_confirmed'=>'YES']; }
$db=fresh();$p=ADE_Review_Decisions::plan('20268071',42,'defer');ck(!$p['write_enabled']&&$p['database_writes']===0&&$db->reviews===[],'default off and plan read-only');blocked(fn()=>ADE_Review_Decisions::record(request()),'record off','M3_REVIEW_WRITES_DISABLED');
define('ADE_LOCAL_NEGATIVE_REVIEW_ENABLED',true);
$r=request();$before=$db->candidate;$result=ADE_Review_Decisions::record($r);ck($result['database_writes']===3&&!$result['replayed']&&!$result['publication_enabled'],'one status/audit/receipt');
ck($db->candidate['review_status']==='deferred'&&$db->candidate['row_version']==='2'&&count($db->reviews)===1&&count($db->jobs)===1,'atomic defer');
foreach(['proposed_value','base_target_hash','approval_null','approved_at','published_local_at','publish_status'] as $field){ck($db->candidate[$field]===$before[$field],'preserve '.$field);}
$rows=[$db->candidate,$db->reviews,$db->jobs];$again=ADE_Review_Decisions::record($r);ck($again['replayed']&&$again['database_writes']===0&&[$db->candidate,$db->reviews,$db->jobs]===$rows,'duplicate exact replay no audit duplicate');
$history=ADE_Review_Decisions::history('20268071',42);ck(count($history['rows'])===1&&$history['rows'][0]['note']===$r['note']&&!isset($history['rows'][0]['review_notes']),'history plain note only');
$reject=request('reject');ADE_Review_Decisions::record($reject);ck($db->candidate['review_status']==='rejected'&&count($db->reviews)===2,'deferred->rejected');
blocked(fn()=>ADE_Review_Decisions::plan('20268071',42,'defer'),'rejected terminal','M3_REVIEW_STATE_LOCKED');ck(ADE_Review_Decisions::record($r)['result_is_historical'],'old receipt remains historical after later reject');
foreach(['approve','edit_approve','publish','reopen'] as $decision){blocked(fn()=>ADE_Review_Decisions::plan('20268071',42,$decision),'forbidden action '.$decision,'M3_APPROVAL_NOT_AVAILABLE');}
$db=fresh();$r=request();foreach(['nonce'=>'bad','confirm'=>'NO','backup_confirmed'=>'NO','reason'=>'anything','note'=>'<script>bad</script>','row_version'=>'1'] as $key=>$value){$bad=$r;$bad[$key]=$value;blocked(fn()=>ADE_Review_Decisions::record($bad),'invalid field '.$key);ck($db->candidate['review_status']==='new'&&$db->reviews===[],'no write invalid '.$key);}
$bad=$r;$bad['extra']='unexpected';blocked(fn()=>ADE_Review_Decisions::record($bad),'extra field');
$bad=$r;$bad['nonce']=test_nonce(42,1,'reject');blocked(fn()=>ADE_Review_Decisions::record($bad),'nonce decision bound','M3_REVIEW_NONCE_INVALID');
$test_actor=2;blocked(fn()=>ADE_Review_Decisions::record($r),'nonce actor bound','M3_REVIEW_NONCE_INVALID');$actorRequest=$r;$actorRequest['nonce']=test_nonce(42,1,'defer');blocked(fn()=>ADE_Review_Decisions::record($actorRequest),'plan bound to actor','M3_REVIEW_STALE');$test_actor=0;blocked(fn()=>ADE_Review_Decisions::record($r),'anonymous actor','M3_REVIEW_LOCAL_CAP_REQUIRED');$test_actor=1;
$cap=false;blocked(fn()=>ADE_Review_Decisions::record($r),'review cap');$cap=true;ADE_Schema::$local=false;blocked(fn()=>ADE_Review_Decisions::record($r),'production');ADE_Schema::$local=true;ADE_Jobs::$ready=false;blocked(fn()=>ADE_Review_Decisions::record($r),'preflight');ADE_Jobs::$ready=true;
$db->held=true;blocked(fn()=>ADE_Review_Decisions::record($r),'same school M2 lock','M3_REVIEW_WRITER_BUSY');$db->held=false;
$db->candidate['row_version']='2';blocked(fn()=>ADE_Review_Decisions::record($r),'stale worker evidence version','M3_REVIEW_STALE');ck($db->candidate['row_version']==='2'&&$db->reviews===[],'stale leaves external version intact');
foreach(['review_status'=>'approved','publish_status'=>'published_local','approval_null'=>'0','approved_by_user_id'=>2] as $key=>$value){$db=fresh();$db->candidate[$key]=$value;blocked(fn()=>ADE_Review_Decisions::plan('20268071',42,'reject'),'protected state '.$key,'M3_REVIEW_STATE_LOCKED');}
$db=fresh();$r=request();$db->candidate['proposed_value']='Changed without version';blocked(fn()=>ADE_Review_Decisions::record($r),'content/token stale','M3_REVIEW_STALE');
for($position=1;$position<=2;$position++){$db=fresh();$r=request();$original=$db->candidate;$db->fail_insert_at=$position;blocked(fn()=>ADE_Review_Decisions::record($r),'insert failure '.$position,'M3_REVIEW_INSERT_FAILED');ck($db->candidate===$original&&$db->reviews===[]&&$db->jobs===[]&&!$db->held&&$db->snapshot===null,'all rollback '.$position);}
$db=fresh();$r=request();$db->version_conflict=true;blocked(fn()=>ADE_Review_Decisions::record($r),'CAS failure','M3_REVIEW_VERSION_CONFLICT');ck($db->reviews===[]&&$db->candidate['review_status']==='new','CAS rollback');
$db=fresh();$r=request();$db->fail_commit=true;blocked(fn()=>ADE_Review_Decisions::record($r),'failed commit','M3_REVIEW_TRANSACTION_FAILED');ck($db->reviews===[]&&$db->candidate['review_status']==='new','failed commit all rollback');
$db=fresh();$r=request();$db->lose_ack=true;blocked(fn()=>ADE_Review_Decisions::record($r),'committed ack lost','M3_REVIEW_TRANSACTION_FAILED');$db->lose_ack=false;ck(ADE_Review_Decisions::record($r)['replayed']&&count($db->reviews)===1,'unknown outcome receipt recovery');
$db->reviews[1]['reason_code']='TAMPERED';blocked(fn()=>ADE_Review_Decisions::record($r),'receipt audit tampered','M3_REVIEW_RECEIPT_INVALID');
$db=fresh();$r=request();ADE_Review_Decisions::record($r);$db->jobs[1]['stats_payload']=json_encode(['publication_enabled'=>true]);blocked(fn()=>ADE_Review_Decisions::record($r),'receipt result tampered','M3_REVIEW_RECEIPT_INVALID');
$db=fresh();blocked(fn()=>ADE_Review_Decisions::plan('12345678',42,'defer'),'outside scope');blocked(fn()=>ADE_Review_Decisions::plan('20268071',99,'defer'),'IDOR','M3_REVIEW_CANDIDATE_NOT_FOUND');
foreach($db->queries as [$sql,$args]){ck(strpos($sql,'DELETE ')!==0&&strpos($sql,'UPDATE custom_ahda_schools')!==0,'no audit delete or legacy update');}
if(!getenv('AHDA_REVIEW_CONTROLLER_CHILD')){
 foreach(['valid','invalid_nonce','stale','array','get','approve'] as $case){
  $pipes=[];$process=proc_open([PHP_BINARY,'-n',__DIR__.'/support/m3-handler-child.php',$case],[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);
  fclose($pipes[0]);$stdout=stream_get_contents($pipes[1]);$stderr=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$exit=proc_close($process);
  ck($exit===0&&$stderr==='','handler child exit '.$case);$at=strrpos($stdout,'HANDLER_RESULT:');ck($at!==false,'handler response '.$case);$out=json_decode(substr($stdout,$at+strlen('HANDLER_RESULT:')),true,16,JSON_THROW_ON_ERROR);
  if($case==='valid'){ck($out['audits']===1&&$out['receipts']===1&&$out['status']==='deferred'&&strpos($out['redirect'],'http://ahda.local/wp-admin/admin.php?')===0&&$out['note']==="O'Reilly: perlu dokumen institusi",'controller typed IDs/unslash/nonce/safe redirect');}
  else{ck($out['audits']===0&&$out['status']==='new','controller invalid request no write '.$case);ck(strpos($out['error'],$case==='stale'?'409:':($case==='get'?'405:':'403:'))===0,'controller error status '.$case);}
 }
}
echo "PASS: $n M3 negative-review atomicity/nonce/permission checks (fake WP/DB; default OFF).\n";
