# M1 QA dev.6.2 — scope Tasikmalaya

## Bukti LocalWP yang diterima

Operator mengirim output dev.6.1: schema INSTALLED7/7, preflight200/200 PASS,
preview10 berjalan dan membutuhkan sumber. Bukti ini tidak mencakup source-preview
dev.6.2, penulisan job/evidence, transaksi MySQL, transport/crawl atau publisher.
Log terstruktur disimpan di repo docs/qa/localwp-dev6.1-user-report.json.

## Perubahan

- Source-preview SELECT-only pada field URL verified legacy; query dibatasi,
  dedupe/provenance, pending/manual-only, penolakan query-token tanpa echo nilai.
  SQL error/row tidak valid memblokir hasil; tidak disamarkan menjadi needs_source.
- Membundel daftar operator 200 sekolah dan JSON klasifikasi dengan checksum.
- lookup_pilot SELECT ownership_status tanpa mengubah kontrak lookup R3.
- Validator identifier prefix ditambahkan pada lookup identitas.
- Manifest scoped v2 mengikat daftar NPSN, ID LocalWP dan checksum rujukan.
- CLI default memakai daftar beku; job baru tidak boleh unscoped.
- Preflight read-only seluruh 200, structured issues, failed/unrun terpisah.
- Scope diperiksa ulang setiap batch: negeri, region, jenjang dan NPSN/ID.
- Dry-run ditolak pada semua mutasi CLI, bukan hanya enqueue/run-one-batch.
- Legacy manifest v1 tetap dibaca untuk job lama; tidak ada DDL/schema change.

## Tes dan bukti

Jalankan `sh bin/test-offline.sh` dengan PHP CLI 8.2. `PHP_BIN=/path/php8.2`
dapat dipakai bila perlu. Runner memakai `-n`; setiap suite berjalan terpisah.
Fake cURL suite menolak native extension agar tidak membuka socket sungguhan.
Regresi enam suite R2/R3/R4a tetap dipertahankan. Tambahan scope/CLI memakai
NPSN dan klasifikasi yang dipilih, tetapi school_id SINTETIS dan database palsu.
Kelulusan fixture bukan bukti bahwa NPSN tersebut sudah cocok ke LocalWP aktual.

Bukti run, exit status, jumlah pemeriksaan dan lint tersimpan dalam
`docs/qa` paket dan `docs/qa/dev6.2` repositori. Perubahan kode hanya pada
salinan development, bukan baseline atau plugin Directory. PHP 8.2.32 / 8.4.24
CLI tersedia dari paket Debian bertanda tangan; bukan PHP LocalWP 8.2.29 pengguna.

Cakupan: original regressions, scope checksum, 200 identifiers, reclassification,
state/private, regency/province mismatch, changed ID, form mismatch, SQL prefix/
NPSN injection, permission/confirmation/local gate, dry-run zero-query rejection,
reference membership, complete 200-row audit, batch resume, conflict checkpoint,
dedupe, stale lease, commit rollback, retry/cancel, bootstrap no side effects.

## NOT TESTED / outstanding

- Native source-preview dev.6.2 and MySQL write/transaction integration.
  Schema/pilot preflight and preview dev.6.1 PASS dari log operator sebagaimana di atas.
- Native HTTP/cURL, robots/terms policy, OS DNS bound and durable host throttle.
- Full parent plugin security review; some original manual CLI methods still
  lack explicit capability checks. New pilot entrypoints have capability gates.
- Real VPS resource usage, search-engine indexing and AI recommendations.
- Extraction/candidate generation, admin review and publication adapters.

Cloud did not execute network crawl, DB write, installation, activation, production
or publish. Operator demonstrated the LocalWP dev.6.1 read-only checks above. All operational flags remain off; global dry-run stays on.
Read M1_LOCALWP.md before any operator-approved LocalWP operations.


## Hotfix nama CLI dev.6.2.1

LocalWP membuktikan bahwa dev.6.2 mendaftarkan `source_preview`, bukan
`source-preview`. Ini cacat pada panduan/registrasi, bukan kegagalan query URL.
Perintah underscore berhasil membaca10 sekolah, semuanya hint_count0 dan
Discovery links0. Tidak menyimpulkan bahwa seluruh200 tidak punya website.

Dev.6.2.1 mendaftarkan alias eksplisit berikut sambil mempertahankan underscore:
- source-preview / source_preview
- run-one-batch / run_one_batch
- integrity-check / integrity_check
- retry-failed / retry_failed

Pengguna dev.6.2 bisa melanjutkan memakai underscore tanpa instalasi ulang.
Hotfix tidak mengubah parser, pemilihan sekolah, query, tabel, flags atau crawler.
Jika memasang hotfix lokal setelah backup/persetujuan, `wp help ade pilot` dapat
memeriksa nama perintah. Penamaan alias telah diuji pada registrasi stub offline;
dispatch native alias di LocalWP belum diuji oleh operator. Tes lama sebelumnya
memanggil method langsung sehingga tidak menangkap perbedaan nama ini.
Pencarian URL di luar database masih membutuhkan persetujuan jaringan operator.
