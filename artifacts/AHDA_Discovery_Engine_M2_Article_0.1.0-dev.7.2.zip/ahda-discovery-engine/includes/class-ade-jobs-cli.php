<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** R2 manual test job commands; nothing is scheduled or executed on registration. */
final class ADE_Jobs_CLI {
    private function require_confirm( array $assoc_args, string $expected ): void {
        if ( ! isset( $assoc_args['confirm'] ) || $assoc_args['confirm'] !== $expected ) {
            WP_CLI::error( 'Tindakan ini memerlukan --confirm=' . $expected );
        }
    }

    /**
     * Read-only R2 safety and schema preflight.
     *
     * ## EXAMPLES
     *
     *     wp ade jobs preflight
     */
    public function preflight( $args, $assoc_args ): void {
        $report = ADE_Jobs::preflight();
        WP_CLI::log( '=== AHDA DISCOVERY R2 JOB ENGINE PREFLIGHT — READ ONLY ===' );
        WP_CLI::log( 'Site: ' . home_url( '/' ) );
        WP_CLI::log( 'Plugin: ' . ADE_VERSION );
        WP_CLI::log( 'Local-only: ' . ( $report['local'] ? 'PASS' : 'BLOCKED' ) );
        WP_CLI::log( 'Schema: ' . $report['schema']['state'] );
        WP_CLI::log( 'Schema version: ' . (string) $report['schema']['schema_version'] );
        WP_CLI::log( 'Legacy metadata SHA-256: ' . (string) $report['schema']['legacy_hash'] );
        WP_CLI::log( 'Discovery tables: ' . count( $report['schema']['existing_discovery'] ) . '/7' );
        WP_CLI::log( 'Safe flags: ' . ( $report['unsafe_flags'] ? implode( ', ', $report['unsafe_flags'] ) : 'PASS' ) );
        WP_CLI::log( 'Manual mutex: ' . ( is_array( $report['worker_lock'] ) ? 'ACTIVE' : 'none' ) );
        WP_CLI::log( 'Real discovery / crawler / publication: DISABLED' );
        foreach ( $report['schema']['issues'] as $issue ) { WP_CLI::warning( $issue ); }
        if ( ! $report['ready'] ) { WP_CLI::error( 'R2 BLOCKED: jangan membuat atau memproses job uji.' ); }
        WP_CLI::success( 'R2 READY; pemeriksaan tidak mengubah data.' );
    }

    /**
     * Read-only bounded listing of synthetic jobs.
     *
     * ## OPTIONS
     *
     * [--limit=<n>]
     * : Rows from 1 to 50, default 15.
     */
    public function status( $args, $assoc_args ): void {
        try {
            $limit = isset( $assoc_args['limit'] ) ? (int) $assoc_args['limit'] : 15;
            $rows = ADE_Jobs::list_jobs( $limit );
            WP_CLI::log( '=== R2 SYNTHETIC JOBS — READ ONLY ===' );
            WP_CLI::log( 'No background processing. Job types other than r2_smoke_test are not listed.' );
            if ( ! $rows ) { WP_CLI::log( 'Tidak ada job uji.' ); }
            foreach ( $rows as $r ) {
                WP_CLI::log( '#' . $r['id'] . ' status=' . $r['status'] . ' attempts=' . $r['attempt_count'] . '/' . $r['max_attempts'] . ' cursor=' . ( $r['cursor_school_id'] ?? '-' ) . ' retry_at=' . ( $r['next_run_at'] ?? '-' ) . ' error=' . ( $r['last_error_code'] ?? '-' ) );
            }
            WP_CLI::success( 'Listed ' . count( $rows ) . ' synthetic job(s) without writes.' );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Create an explicitly named synthetic job, never a crawler.
     *
     * ## OPTIONS
     *
     * --test-key=<slug>
     * : 3–40 chars a-z, 0-9, underscore, hyphen.
     *
     * --confirm=<value>
     * : Must equal SEED_R2_TEST.
     *
     * ## EXAMPLES
     *
     *     wp ade jobs seed --test-key=smoke-a --confirm=SEED_R2_TEST
     */
    public function seed( $args, $assoc_args ): void {
        $this->require_confirm( $assoc_args, 'SEED_R2_TEST' );
        try {
            if ( ! isset( $assoc_args['test-key'] ) || ! is_string( $assoc_args['test-key'] ) ) { WP_CLI::error( 'Butuh --test-key=<slug>' ); }
            $result = ADE_Jobs::seed( $assoc_args['test-key'] );
            if ( $result['created'] ) { WP_CLI::success( 'Created synthetic job #' . $result['id'] . ' (queued); no source/network/school writes.' ); }
            else { WP_CLI::success( 'Idempotent: existing job #' . $result['id'] . ' status=' . $result['status'] . '; no duplicate.' ); }
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Run exactly one synthetic test step (no crawler/network/legacy table writes).
     *
     * ## OPTIONS
     *
     * --confirm=<value>
     * : Must equal STEP_R2_TEST.
     *
     * [--simulate-fail=<value>]
     * : YES only; test retry behavior, does not throw PHP fatal errors.
     *
     * ## EXAMPLES
     *
     *     wp ade jobs step --confirm=STEP_R2_TEST
     *     wp ade jobs step --confirm=STEP_R2_TEST --simulate-fail=YES
     */
    public function step( $args, $assoc_args ): void {
        $this->require_confirm( $assoc_args, 'STEP_R2_TEST' );
        $simulate = isset( $assoc_args['simulate-fail'] ) && $assoc_args['simulate-fail'] === 'YES';
        if ( isset( $assoc_args['simulate-fail'] ) && ! $simulate ) { WP_CLI::error( 'simulate-fail hanya menerima YES.' ); }
        try {
            $result = ADE_Jobs::step( $simulate );
            if ( ! $result['processed'] ) { WP_CLI::log( $result['message'] ); return; }
            WP_CLI::success( 'Job #' . $result['id'] . ' attempt=' . $result['attempt'] . ' status=' . $result['status'] . ( isset( $result['checkpoint'] ) ? ' cursor=' . $result['checkpoint'] : '' ) . ( isset( $result['next_delay_seconds'] ) && $result['next_delay_seconds'] ? ' retry_delay=' . $result['next_delay_seconds'] . 's' : '' ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /** Read-only inspection of one synthetic job. */
    public function inspect( $args, $assoc_args ): void {
        if ( count( $args ) !== 1 || ! ctype_digit( (string) $args[0] ) || (int) $args[0] < 1 ) { WP_CLI::error( 'Gunakan wp ade jobs inspect <numeric-id>.' ); }
        try {
            $row = ADE_Jobs::inspect( (int) $args[0] );
            if ( ! $row ) { WP_CLI::error( 'Job tidak ditemukan atau bukan synthetic.' ); }
            WP_CLI::log( '=== R2 SYNTHETIC JOB DETAIL — READ ONLY ===' );
            foreach ( $row as $key => $value ) { WP_CLI::log( $key . ': ' . ( null === $value ? '(null)' : (string) $value ) ); }
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Recover synthetic jobs whose lease has expired (manual only).
     *
     * ## OPTIONS
     *
     * --confirm=<value>
     * : Must equal RECOVER_R2_TEST.
     */
    public function recover( $args, $assoc_args ): void {
        $this->require_confirm( $assoc_args, 'RECOVER_R2_TEST' );
        try {
            $r = ADE_Jobs::recover_expired();
            WP_CLI::success( 'Expired leases: requeued=' . $r['retried'] . ', failed=' . $r['failed'] );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Cancel queued/retry_wait synthetic test job; no deletion.
     *
     * ## OPTIONS
     *
     * --confirm=<value>
     * : Must equal CANCEL_R2_TEST.
     */
    public function cancel( $args, $assoc_args ): void {
        $this->require_confirm( $assoc_args, 'CANCEL_R2_TEST' );
        if ( count( $args ) !== 1 || ! ctype_digit( (string) $args[0] ) || (int) $args[0] < 1 ) { WP_CLI::error( 'Gunakan wp ade jobs cancel <numeric-id> --confirm=CANCEL_R2_TEST.' ); }
        try {
            if ( ! ADE_Jobs::cancel( (int) $args[0] ) ) { WP_CLI::error( 'Job tidak ditemukan, sudah selesai, atau sedang leased.' ); }
            WP_CLI::success( 'Cancelled synthetic job #' . (int) $args[0] );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Manual recovery for mutex older than ten minutes after process stop confirmed.
     *
     * ## OPTIONS
     *
     * --confirm=<value>
     * : Must equal UNLOCK_R2_STOPPED.
     */
    public function unlock( $args, $assoc_args ): void {
        $this->require_confirm( $assoc_args, 'UNLOCK_R2_STOPPED' );
        try {
            $result = ADE_Jobs::unlock_stale();
            WP_CLI::success( $result ? 'Old mutex cleared; inspect expired leases next.' : 'No old mutex to clear.' );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }
}
