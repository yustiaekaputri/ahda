<?php
/** Pure portable archive/checkpoint tests: no WordPress bootstrap, SQL or sockets. */
require_once __DIR__.'/support/m1-fake-db.php';
foreach(['identity','evidence-urls','pilot-scope','enrichment-preview','document-parser','local-archive','local-worker'] as $name){require_once dirname(__DIR__).'/includes/class-ade-'.$name.'.php';}
$n=0;function ck($ok,$label){global $n;++$n;if(!$ok){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$label,$expected=null){try{$fn();}catch(Throwable $e){ck($expected===null||$e->getMessage()===$expected,$label.' error='.$e->getMessage());return;}ck(false,$label.' accepted');}
function enc($v){return json_encode($v,JSON_THROW_ON_ERROR);}
function rehash($s){unset($s['checksum']);$s['checksum']=ADE_Local_Archive::digest($s);return $s;}
$now=strtotime('2026-11-10T12:00:00Z');$raw=ADE_Local_Archive::demo();$a=ADE_Local_Archive::freeze($raw);$bundle=$a['bundle'];$schools=$bundle['schools'];$first=$schools[0]['npsn'];$second=$schools[1]['npsn'];$third=$schools[2]['npsn'];
ck(count($schools)===200&&count($bundle['documents'])===5,'frozen full200 with5 synthetic documents');
ck($bundle['fixture_only']===true,'demo explicitly fixture');
$reverse=$bundle;$reverse['schools']=array_reverse($reverse['schools']);$reverse['documents']=array_reverse($reverse['documents'],true);
$b=ADE_Local_Archive::freeze(json_encode($reverse,JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR));ck($b['manifest_sha256']===$a['manifest_sha256']&&$b['input_sha256']!==$a['input_sha256'],'canonical hash independent order/format, raw distinct');
foreach(['root'=>'{"x":1,"x":2}','escaped'=>'{"x":1,"\\u0078":2}','nested'=>'{"x":[{"k":1,"k":2}]}'] as $label=>$json){blocked(fn()=>ADE_Strict_JSON::decode($json),$label.' duplicate','M2_DUPLICATE_JSON_KEY');}
$strings=['quotes'=>'a"b\\c','braces'=>'{[,]}:','unicode'=>'é sekolah','empty'=>''];ck(ADE_Strict_JSON::decode(enc($strings))===$strings,'escaped quoted/Unicode/structural strings');
ck(ADE_Strict_JSON::decode("\xef\xbb\xbf".enc($strings))===$strings,'BOM input');
blocked(fn()=>ADE_Strict_JSON::decode('null'),'scalar');blocked(fn()=>ADE_Strict_JSON::decode('{bad}'),'invalid syntax');blocked(fn()=>ADE_Strict_JSON::decode(str_repeat('[',20).'0'.str_repeat(']',20)),'depth limit');
blocked(fn()=>ADE_Strict_JSON::decode('['.str_repeat('0,',50001).'0]',4194304),'allocation token budget','M2_JSON_TOKEN_LIMIT');
$large=enc(['content'=>str_repeat('a',4000000)]);ck(strlen(ADE_Strict_JSON::decode($large,4194304)['content'])===4000000,'4MiB decoder without PCRE token limit');
blocked(fn()=>ADE_Strict_JSON::decode($large),'small default limit','M2_INPUT_TOO_LARGE');blocked(fn()=>ADE_Local_Archive::freeze(str_repeat(' ',4194305)),'archive byte cap','M2_INPUT_TOO_LARGE');unset($large);
foreach(['scope_hash'=>'bad','fixture_only'=>'true','schema_version'=>2] as $key=>$v){$x=$bundle;$x[$key]=$v;blocked(fn()=>ADE_Local_Archive::freeze(enc($x)),'scope/type '.$key);}
$x=$bundle;array_pop($x['schools']);blocked(fn()=>ADE_Local_Archive::freeze(enc($x)),'not200');
$x=$bundle;$x['schools'][1]=$x['schools'][0];blocked(fn()=>ADE_Local_Archive::freeze(enc($x)),'duplicate school');
$x=$bundle;$x['schools'][0]['npsn']='00000000';blocked(fn()=>ADE_Local_Archive::freeze(enc($x)),'outside selected scope');
$x=$bundle;$x['approved']=true;blocked(fn()=>ADE_Local_Archive::freeze(enc($x)),'unknown approval flag');
$docKey=array_key_first($bundle['documents']);
foreach(['content'=>'changed','raw_sha256'=>str_repeat('0',64),'source_url'=>'https://example.org/changed'] as $key=>$value){$x=$bundle;$x['documents'][$docKey][$key]=$value;blocked(fn()=>ADE_Local_Archive::freeze(enc($x)),'tampered document '.$key,'ARCHIVE_DOCUMENT_HASH_MISMATCH');}
$x=$bundle;$x['schools'][3]['document_keys']=[$schools[0]['document_keys'][0]];blocked(fn()=>ADE_Local_Archive::freeze(enc($x)),'cross-school document reuse');
$x=$bundle;$x['schools'][0]['document_keys'][]=$x['schools'][0]['document_keys'][0];blocked(fn()=>ADE_Local_Archive::freeze(enc($x)),'duplicate reference');
$x=$bundle;$x['schools'][3]['document_keys']=[str_repeat('0',64)];blocked(fn()=>ADE_Local_Archive::freeze(enc($x)),'missing doc');
$x=$bundle;$x['schools'][0]['document_keys']=[];blocked(fn()=>ADE_Local_Archive::freeze(enc($x)),'unreferenced doc');
foreach(['http://example.org/','https://127.0.0.1/','https://example.org/?token=secret','https://example.org/?api_key=secret','https://example.org/?key=secret'] as $url){blocked(fn()=>ADE_Local_Archive::document('x','csv',$url,'2020-01-01T00:00:00Z','test-ref'),'unsafe/noncanonical URL');}
foreach([['x','pdf'],[str_repeat('x',65537),'csv'],[str_repeat('x',262145),'html'],["\xff",'csv'],['','csv']] as $spec){blocked(fn()=>ADE_Local_Archive::document($spec[0],$spec[1],'https://example.org/','2020-01-01T00:00:00Z','test-ref'),'format/size/UTF8');}
blocked(fn()=>ADE_Local_Archive::document('x','csv','https://example.org/','2026-02-31T00:00:00Z','test-ref'),'invalid date');
blocked(fn()=>ADE_Local_Archive::document('x','csv','https://example.org/','2020-01-01T00:00:00Z','bad ref'),'reference whitespace');
$r=ADE_Local_Worker::run($raw,null,10,$now);ck($r['cursor']===10&&$r['processed_this_call']===10&&!$r['complete'],'bounded first batch');
$expected=class_exists('DOMDocument')?['preview_needs_review','conflicting_claims','document_blocked']:['document_blocked','document_blocked','document_blocked'];
foreach($expected as $i=>$value){ck($r['results'][$i]['outcome']===$value,'document outcome '.$i);}
ck($r['summary']['needs_source']===7,'7 schools missing sources');
ck($r['network_requests']===0&&$r['database_writes']===0&&$r['filesystem_writes']===0&&!$r['publication_enabled'],'no operations');
ck($r['checkpoint_is_operator_controlled']&&!$r['checkpoint_is_commit_or_approval_receipt'],'checkpoint grants no authority');
foreach($r['results'] as $result){ck(!$result['persisted']&&!$result['identity_checked']&&in_array('LIVE_IDENTITY_NOT_CHECKED',$result['blocking_reasons'],true),'pure mode no live identity or persistence');}
if(class_exists('DOMDocument')){
 $good=$r['results'][0];ck(count($good['candidates'])===3&&count($good['evidence'])===6,'agreeing documents merge3claims with6provenance entries');
 foreach($good['candidates'] as $c){ck(count($c['archive_evidence_keys'])===2&&$c['approved_value']===null,'two refs each; never approved');}
 foreach($good['evidence'] as $e){ck(isset($bundle['documents'][$e['document_key']])&&$e['raw_document_sha256']===$bundle['documents'][$e['document_key']]['raw_sha256'],'raw provenance retained');}
 ck($r['results'][1]['candidates']===[]&&$r['results'][1]['evidence']===[]&&isset($r['results'][1]['conflicts']['profile_programs']),'conflicting sources not chosen');
}
ck($r['results'][2]['candidates']===[]&&$r['results'][2]['errors'][0]['code']==='M2_HARD_NPSN_MISMATCH','wrong NPSN blocked without stopping batch');
$cp=$r['checkpoint'];$next=ADE_Local_Worker::run($raw,enc($r),10,$now+1);ck($next['cursor']===20&&array_slice($next['checkpoint']['records'],0,10)===$cp['records'],'report resumes and retains prefix');
for($i=2;$i<20;++$i){$next=ADE_Local_Worker::run($raw,enc($next['checkpoint']),10,$now+$i);}
ck($next['complete']&&$next['cursor']===200&&array_sum($next['summary'])===200&&$next['summary']['needs_source']===197,'200processed does not mean200enriched');
$done=ADE_Local_Worker::run($raw,enc($next['checkpoint']),10,$now+21);ck($done['processed_this_call']===0&&$done['checkpoint']===$next['checkpoint'],'complete replay processes none');
foreach([0,11,-1] as $batch){blocked(fn()=>ADE_Local_Worker::run($raw,null,$batch,$now),'batch cap');}
$x=$bundle;$x['fixture_only']=false;blocked(fn()=>ADE_Local_Worker::run(enc($x),enc($cp),10,$now),'changed archive bound','WORKER_CHECKPOINT_BINDING_INVALID');
$x=$cp;$x['cursor']=11;blocked(fn()=>ADE_Local_Worker::run($raw,enc($x),10,$now),'tampered checksum');
$x=$cp;$x['records'][0]['npsn']=$second;$x=rehash($x);blocked(fn()=>ADE_Local_Worker::run($raw,enc($x),10,$now),'rehashed swapped identity');
$x=$cp;$x['records'][0]['evaluated_at']=$now+301;$x=rehash($x);blocked(fn()=>ADE_Local_Worker::run($raw,enc($x),10,$now),'future record');
$x=$cp;$x['records'][0]['approved']=true;$x=rehash($x);blocked(fn()=>ADE_Local_Worker::run($raw,enc($x),10,$now),'approval in checkpoint');
$retry=ADE_Local_Worker::run($raw,enc($cp),10,$now+1,null,null,$third);ck($retry['cursor']===10&&$retry['processed_this_call']===1&&$retry['checkpoint']['records'][2]['attempts']===2,'retry single failure leaves cursor');
ck($retry['checkpoint']['records'][0]===$cp['records'][0]&&$retry['checkpoint']['records'][3]===$cp['records'][3],'retry retains other results');
$retry=ADE_Local_Worker::run($raw,enc($retry['checkpoint']),10,$now+2,null,null,$third);ck($retry['checkpoint']['records'][2]['attempts']===3,'third attempt');
blocked(fn()=>ADE_Local_Worker::run($raw,enc($retry['checkpoint']),10,$now+3,null,null,$third),'retry cap','WORKER_RETRY_NOT_ELIGIBLE');
blocked(fn()=>ADE_Local_Worker::run($raw,enc($cp),10,$now,null,null,$schools[3]['npsn']),'no retry needs_source');
blocked(fn()=>ADE_Local_Worker::run($raw,enc($cp),10,$now,null,null,$schools[20]['npsn']),'no retry unprocessed');
$resolve=static function($code){return array_merge(ADE_Pilot_Scope::reference()[$code],['id'=>123,'visibility'=>'publish']);};
$live=ADE_Local_Worker::run($raw,null,10,$now,$resolve);ck($live['results'][0]['identity_checked']&&$live['results'][0]['school_id']===123,'read-only live resolver binding');
$bad=ADE_Local_Worker::run($raw,null,10,$now,fn($code)=>['npsn'=>'00000000','id'=>123]);ck($bad['summary']['identity_blocked']===10,'resolver identity conflict per school');
$bad=ADE_Local_Worker::run($raw,null,1,$now,static function($code)use($resolve){$s=$resolve($code);$s['ownership_status']='SWASTA';return $s;});ck($bad['results'][0]['outcome']==='identity_blocked','changed ownership blocked');
$tick=0;$limited=ADE_Local_Worker::run($raw,null,10,$now,null,static function()use(&$tick){return $tick++*3.0;});ck($limited['time_limit_reached']&&$limited['cursor']===1&&$limited['processed_this_call']===1,'deadline checked between schools; no skipped cursor');
$blockedTime=ADE_Local_Worker::run($raw,null,10,$now,null,static function()use(&$tick){return $tick++*6.0;});ck($blockedTime['cursor']===0&&$blockedTime['time_limit_reached'],'deadline before first school');
// Metadata and NPSN of structured JSON must match the archive, not just its hash.
$j=json_decode(str_replace('20268071',$first,file_get_contents(dirname(__DIR__).'/data/examples/m2-structured-fixture.json')),true);
$d=ADE_Local_Archive::document(enc($j),'json','https://example.org/mismatched-metadata','2020-01-01T00:00:00Z','fixture-only-not-a-permission');
$x=$bundle;foreach($schools[0]['document_keys'] as $key){unset($x['documents'][$key]);}$x['documents'][$d['key']]=$d['entry'];$x['schools'][0]['document_keys']=[$d['key']];
$bad=ADE_Local_Worker::run(enc($x),null,1,$now);ck($bad['results'][0]['outcome']==='document_blocked'&&$bad['results'][0]['errors'][0]['code']==='ARCHIVE_JSON_METADATA_CONFLICT','structured JSON metadata bound');
$d=ADE_Local_Archive::document(enc($j),'json',$j['source_url'],$j['checked_at'],$j['permission_reference']);
$x['documents']=[$d['key']=>$d['entry']];foreach($x['schools'] as &$school){$school['document_keys']=[];}unset($school);$x['schools'][0]['document_keys']=[$d['key']];
$validJson=ADE_Local_Worker::run(enc($x),null,1,$now);ck($validJson['results'][0]['outcome']==='preview_needs_review'&&count($validJson['results'][0]['candidates'])===3,'valid structured JSON preview with raw binding');
$j['observed_npsn']='00000000';$d=ADE_Local_Archive::document(enc($j),'json',$j['source_url'],$j['checked_at'],$j['permission_reference']);$x['documents']=[$d['key']=>$d['entry']];$x['schools'][0]['document_keys']=[$d['key']];
$bad=ADE_Local_Worker::run(enc($x),null,1,$now);ck($bad['results'][0]['errors'][0]['code']==='M2_HARD_NPSN_MISMATCH','JSON observed identity cannot bypass archive binding');
echo "PASS: $n local archive/resume/conflict/security checks (pure synthetic; no DB/HTTP; HTML ".(class_exists('DOMDocument')?'actual DOM':'NOT RUN, fail-closed guard').").\n";
