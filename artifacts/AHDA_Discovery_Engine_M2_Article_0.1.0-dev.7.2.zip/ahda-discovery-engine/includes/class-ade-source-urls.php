<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** R3 offline-only URL canonicalizer: does not resolve DNS or issue HTTP. */
final class ADE_Source_URLs {
    private const SOCIAL_HOSTS = array(
        'instagram' => 'instagram.com',
        'facebook' => 'facebook.com',
        'youtube' => 'youtube.com',
        'tiktok' => 'tiktok.com',
    );
    private const BLOCKED_TLDS = array( 'local', 'localhost', 'internal', 'test', 'example', 'invalid', 'lan', 'home', 'onion', 'arpa' );

    public static function canonicalize( string $raw ): array {
        $raw = trim( $raw );
        if ( '' === $raw || strlen( $raw ) > 1000 || preg_match( '/[\x00-\x20\x7F\\\\]/', $raw ) ) {
            throw new InvalidArgumentException( 'URL kosong, terlalu panjang, atau mengandung karakter tidak aman.' );
        }
        if ( preg_match( '/%(?:0[0-9a-f]|1[0-9a-f]|7f|5c)/i', $raw ) ) {
            throw new InvalidArgumentException( 'URL mengandung escape kontrol/tidak aman.' );
        }
        $parts = parse_url( $raw );
        if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
            throw new InvalidArgumentException( 'URL harus berformat http(s)://domain/path.' );
        }
        if ( isset( $parts['user'] ) || isset( $parts['pass'] ) ) {
            throw new InvalidArgumentException( 'URL dengan kredensial tidak diizinkan.' );
        }
        $scheme = strtolower( (string) $parts['scheme'] );
        if ( ! in_array( $scheme, array( 'https', 'http' ), true ) ) {
            throw new InvalidArgumentException( 'Hanya skema http/https yang diizinkan.' );
        }
        $host = strtolower( rtrim( (string) $parts['host'], '.' ) );
        if ( strlen( $host ) > 190 || ! preg_match( '/^[a-z0-9.-]+$/D', $host ) ) {
            throw new InvalidArgumentException( 'Nama host tidak valid atau bukan ASCII/Punycode.' );
        }
        if ( filter_var( $host, FILTER_VALIDATE_IP ) || preg_match( '/^(?:0x[0-9a-f]+|[0-9]+)(?:\.(?:0x[0-9a-f]+|[0-9]+))*$/iD', $host ) ) {
            throw new InvalidArgumentException( 'URL menggunakan alamat IP/numerik; hanya host domain publik.' );
        }
        $labels = explode( '.', $host );
        if ( count( $labels ) < 2 ) { throw new InvalidArgumentException( 'Host harus berupa nama domain publik.' ); }
        foreach ( $labels as $label ) {
            if ( strlen( $label ) < 1 || strlen( $label ) > 63 || ! preg_match( '/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/D', $label ) ) {
                throw new InvalidArgumentException( 'Label domain tidak valid.' );
            }
        }
        $tld = end( $labels );
        if ( in_array( $tld, self::BLOCKED_TLDS, true ) || ! preg_match( '/^(?:[a-z]{2,63}|xn--[a-z0-9-]{2,59})$/D', $tld ) ) {
            throw new InvalidArgumentException( 'Domain privat/reserved/tidak didukung.' );
        }
        if ( isset( $parts['port'] ) && (int) $parts['port'] !== ( 'https' === $scheme ? 443 : 80 ) ) {
            throw new InvalidArgumentException( 'Port khusus tidak diizinkan pada R3.' );
        }
        $path = isset( $parts['path'] ) ? (string) $parts['path'] : '/';
        if ( '' === $path ) { $path = '/'; }
        if ( '/' !== $path && substr( $path, -1 ) === '/' ) { $path = rtrim( $path, '/' ); }
        if ( preg_match( '~(?:^|/)(?:\.{1,2}|%2e(?:%2e)?)(?:/|$)~i', $path ) ) {
            throw new InvalidArgumentException( 'Path relatif/dot-segment tidak diizinkan.' );
        }
        $platform = '';
        foreach ( self::SOCIAL_HOSTS as $name => $domain ) {
            if ( $host === $domain || $host === 'www.' . $domain || $host === 'm.' . $domain ) {
                $platform = $name;
                $host = $domain; // Stable canonical identity across www/m/root social host variants.
                break;
            }
        }
        // Social profile URLs are identifiers, not individual posts. Strip
        // referral/language parameters, except numeric Facebook profile.php?id=.
        if ( $platform ) {
            self::assert_profile_path( $platform, $path );
            $query = '';
            if ( 'facebook' === $platform && trim( $path, '/' ) === 'profile.php' ) {
                $raw_query = (string) ( $parts['query'] ?? '' );
                if ( ! preg_match( '/(?:^|&)id=([0-9]{1,30})(?:&|$)/D', $raw_query, $m ) ) {
                    throw new InvalidArgumentException( 'Facebook profile.php memerlukan parameter id numerik.' );
                }
                $query = 'id=' . $m[1];
            }
        } else {
            $query = self::clean_query( (string) ( $parts['query'] ?? '' ) );
        }
        $url = $scheme . '://' . $host . $path . ( '' !== $query ? '?' . $query : '' );
        if ( strlen( $url ) > 1000 ) { throw new InvalidArgumentException( 'URL normalisasi terlalu panjang.' ); }

        return array(
            'canonical_url' => $url,
            'canonical_key' => hash( 'sha256', 'r3-source-url-v1|' . $url ),
            'normalized_host' => $host,
            'source_type' => $platform ? 'social_profile' : 'website',
            'platform' => $platform,
            'handle_or_slug' => self::handle( $platform, $path ),
        );
    }

    private static function clean_query( string $query ): string {
        if ( '' === $query ) { return ''; }
        $kept = array();
        foreach ( explode( '&', $query ) as $kv ) {
            if ( '' === $kv ) { continue; }
            $key = strtolower( rawurldecode( explode( '=', $kv, 2 )[0] ) );
            if ( strpos( $key, 'utm_' ) === 0 || in_array( $key, array( 'fbclid', 'gclid', 'igshid', 'mc_cid', 'mc_eid' ), true ) ) { continue; }
            $kept[] = $kv;
        }
        // Keep parameter order; query parameter order can be meaningful.
        return implode( '&', $kept );
    }

    private static function assert_profile_path( string $platform, string $path ): void {
        $trim = trim( $path, '/' );
        if ( '' === $trim ) { throw new InvalidArgumentException( 'URL sosial harus menunjuk akun, bukan beranda platform.' ); }
        if ( 'instagram' === $platform && ! preg_match( '~^[a-zA-Z0-9._]{1,30}$~D', $trim ) ) {
            throw new InvalidArgumentException( 'URL Instagram bukan halaman akun langsung.' );
        }
        if ( 'tiktok' === $platform && ! preg_match( '~^@[a-zA-Z0-9._]{2,24}$~D', $trim ) ) {
            throw new InvalidArgumentException( 'URL TikTok harus berupa profil @handle.' );
        }
        if ( 'youtube' === $platform && ! preg_match( '~^(?:@[a-zA-Z0-9._-]{2,50}|(?:channel|user|c)/[a-zA-Z0-9_-]{2,100})$~D', $trim ) ) {
            throw new InvalidArgumentException( 'URL YouTube harus berupa channel, user, atau @handle.' );
        }
        if ( 'facebook' === $platform && ! preg_match( '~^(?:[a-zA-Z0-9.\-]{2,100}|profile\.php)$~D', $trim ) ) {
            throw new InvalidArgumentException( 'URL Facebook harus berupa profil/halaman, bukan post/video.' );
        }
        $blocked = array( 'p', 'reel', 'reels', 'stories', 'explore', 'accounts', 'direct', 'watch', 'videos', 'posts', 'share', 'login', 'signup' );
        if ( in_array( strtolower( explode( '/', $trim )[0] ), $blocked, true ) ) {
            throw new InvalidArgumentException( 'URL sosial adalah konten, bukan akun.' );
        }
    }

    private static function handle( string $platform, string $path ): ?string {
        if ( '' === $platform ) { return null; }
        $parts = explode( '/', trim( $path, '/' ) );
        $handle = 'youtube' === $platform && count( $parts ) > 1 ? $parts[1] : $parts[0];
        return substr( $handle, 0, 190 );
    }
}
