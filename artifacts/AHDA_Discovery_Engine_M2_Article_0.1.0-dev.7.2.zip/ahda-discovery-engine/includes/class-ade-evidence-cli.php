<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** R4a manual evidence operator commands. No HTTP and no verification decisions. */
final class ADE_Evidence_CLI {
    private function param( array $assoc, string $key ): string {
        if ( ! isset( $assoc[ $key ] ) || ! is_string( $assoc[ $key ] ) || '' === trim( $assoc[ $key ] ) ) {
            WP_CLI::error( 'Parameter --' . $key . '= wajib diisi.' );
        }
        return trim( $assoc[ $key ] );
    }
    /**
     * Preview one manually supplied evidence claim; read only.
     *
     * ## OPTIONS
     * --npsn=<8-digits>
     * --source-url=<canonical-school-source-url>
     * --evidence-url=<public-document-or-post-url>
     * --evidence-type=<profile_page|post|video|news_article|document|manual_review>
     * --attribute=<source_identity|school_relationship>
     * --claim=<short-factual-observation>
     * [--title=<short-title>]
     */
    public function preview( $args, $assoc ): void {
        try {
            $r = ADE_Evidence::preview(
                $this->param( $assoc, 'npsn' ), $this->param( $assoc, 'source-url' ),
                $this->param( $assoc, 'evidence-url' ), $this->param( $assoc, 'evidence-type' ),
                $this->param( $assoc, 'attribute' ), $this->param( $assoc, 'claim' ),
                isset( $assoc['title'] ) ? (string) $assoc['title'] : ''
            );
            WP_CLI::log( '=== AHDA R4a EVIDENCE PREVIEW — READ ONLY ===' );
            WP_CLI::log( 'school: ' . $r['school_name'] . ' npsn=' . $r['npsn'] . ' school_id=' . $r['school_id'] );
            WP_CLI::log( 'source #' . $r['source_id'] . ' relation #' . $r['relation_id'] . ' identity=' . $r['identity_status'] . ' role=' . $r['relationship_type'] );
            WP_CLI::log( 'source_url: ' . $r['source_url'] );
            WP_CLI::log( 'evidence_url: ' . $r['entry']['evidence_url'] );
            WP_CLI::log( 'type=' . $r['entry']['evidence_type'] . ' attribute=' . $r['entry']['attribute_hint'] );
            WP_CLI::log( 'evidence_key: ' . $r['evidence_key'] );
            WP_CLI::success( 'R4a preview saja; belum memverifikasi kepemilikan atau menulis data.' );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }
    /**
     * Store/reuse a manual evidence claim; never verifies the source or publishes.
     *
     * ## OPTIONS
     * --npsn=<8-digits>
     * --source-url=<canonical-school-source-url>
     * --evidence-url=<public-document-or-post-url>
     * --evidence-type=<profile_page|post|video|news_article|document|manual_review>
     * --attribute=<source_identity|school_relationship>
     * --claim=<short-factual-observation>
     * [--title=<short-title>]
     * --confirm=STORE_R4_EVIDENCE
     */
    public function record( $args, $assoc ): void {
        if ( ( $assoc['confirm'] ?? '' ) !== 'STORE_R4_EVIDENCE' ) {
            WP_CLI::error( 'Perintah write memerlukan --confirm=STORE_R4_EVIDENCE.' );
        }
        try {
            $r = ADE_Evidence::record(
                $this->param( $assoc, 'npsn' ), $this->param( $assoc, 'source-url' ),
                $this->param( $assoc, 'evidence-url' ), $this->param( $assoc, 'evidence-type' ),
                $this->param( $assoc, 'attribute' ), $this->param( $assoc, 'claim' ),
                isset( $assoc['title'] ) ? (string) $assoc['title'] : ''
            );
            WP_CLI::success( 'R4a evidence #' . $r['id'] . ( $r['created'] ? ' new' : ' existing' ) . ', source #' . $r['source_id'] . '; no network/identity/profile writes.' );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }
    /**
     * List manual evidence for one school (read only, maximum 50).
     *
     * ## OPTIONS
     * --npsn=<8-digits>
     * [--limit=<1-50>]
     */
    public function list( $args, $assoc ): void {
        try {
            $r = ADE_Evidence::list_for_school( $this->param( $assoc, 'npsn' ), isset( $assoc['limit'] ) ? (int) $assoc['limit'] : 15 );
            WP_CLI::log( '=== AHDA R4a EVIDENCE LIST — READ ONLY ===' );
            WP_CLI::log( $r['school']['name'] . ' (NPSN ' . $r['school']['npsn'] . ')' );
            foreach ( $r['rows'] as $row ) {
                WP_CLI::log( 'evidence #' . $row['id'] . ' source #' . $row['source_id'] . ' type=' . $row['evidence_type'] . ' attribute=' . $row['attribute_hint'] . ' parse=' . $row['parse_status'] . ' url=' . $row['evidence_url'] );
            }
            WP_CLI::success( 'Listed ' . count( $r['rows'] ) . ' evidence rows; no writes.' );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }
}
