<?php
/** Official WP-CLI v2.12 parser/dispatcher, WordPress/DB facade stubs, no network. */
require_once __DIR__.'/support/m1-fake-db.php';
require_once __DIR__.'/support/wpcli-help-stub.php';
$vendor=__DIR__.'/vendor/wp-cli-2.12.0/';
$upstream=json_decode(file_get_contents($vendor.'UPSTREAM.json'),true,16,JSON_THROW_ON_ERROR);
foreach($upstream['files'] as $name=>$meta){if(hash_file('sha256',$vendor.$name)!==$meta['sha256']){throw new RuntimeException('Changed upstream WP-CLI fixture: '.$name);}}
foreach(['SynopsisParser','SynopsisValidator','DocParser','CompositeCommand','Subcommand','CommandNamespace','CommandFactory','dispatcher'] as $name){require_once $vendor.$name.'.php';}
foreach(['identity','source-urls','evidence-urls','pilot-scope','pilot','pilot-jobs','enrichment-preview','enrichment-store','article-preview','document-parser','pilot-cli','jobs-cli','sources-cli','evidence-cli','schema-cli'] as $name){require_once dirname(__DIR__).'/includes/class-ade-'.$name.'.php';}
final class DispatcherRoot {public function get_hook(){return '';}public function get_name(){return 'ade';}public function get_parent(){return null;}}
final class DispatcherDB {
 public $prefix='custom_',$last_error='',$inner,$snapshots=0;
 public function __construct(){$this->inner=new FakeDB;$ref=ADE_Pilot_Scope::reference()['20268071'];$this->inner->schools['20268071']=array_merge($ref,['id'=>913,'name'=>'Synthetic fixture','visibility'=>'publish','education_level'=>'fixture','district_raw'=>'fixture','village_raw'=>'fixture']);}
 public function prepare($sql,...$args){return $this->inner->prepare($sql,...$args);}
 public function get_results($key,$kind){[$sql,$args]=$this->inner->prepared[$key];if(strpos($sql,'FROM custom_ahda_school_meta ')!==false){++$this->snapshots;return [];}$out=$this->inner->get_results($key,$kind);$this->last_error=$this->inner->last_error;return $out;}
 public function query($sql){throw new RuntimeException('Unexpected real-dispatch write');}
 public function insert(...$args){throw new RuntimeException('Unexpected real-dispatch write');}
}
$n=0;function ck($ok,$label){global $n;++$n;if(!$ok){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$label,$expected){$message=null;try{$fn();}catch(Throwable $e){$message=$e->getMessage();}ck($message===$expected,$label);}
$parent=new DispatcherRoot;
$group=WP_CLI\Dispatcher\CommandFactory::create('pilot','ADE_Pilot_CLI',$parent);
$extract=$group->get_subcommands()['extract'];
$validator=new WP_CLI\SynopsisValidator($extract->get_synopsis());
ck($validator->get_unknown()===[],'official parser: no invalid extract synopsis');
ck($validator->unknown_assoc(['demo'=>true,'dry-run'=>true])===[],'official parser accepts exact user flags');
$oldDoc=str_replace('[--dry-run]','--dry-run',(new ReflectionMethod('ADE_Pilot_CLI','extract'))->getDocComment());
$before=new WP_CLI\Dispatcher\Subcommand($group,'extract',new WP_CLI\DocParser($oldDoc),function(){});
$bad=new WP_CLI\SynopsisValidator($before->get_synopsis());
ck(in_array('--dry-run',$bad->get_unknown(),true),'reproduce previous mandatory-boolean synopsis defect');
ck(in_array('dry-run',$bad->unknown_assoc(['demo'=>true,'dry-run'=>true]),true),'reproduce previous unknown --dry-run');
foreach(['ADE_Pilot_CLI','ADE_Jobs_CLI','ADE_Sources_CLI','ADE_Evidence_CLI','ADE_Schema_CLI'] as $class){
 $commands=WP_CLI\Dispatcher\CommandFactory::create('test',$class,$parent);
 foreach($commands->get_subcommands() as $name=>$command){$v=new WP_CLI\SynopsisValidator($command->get_synopsis());ck($v->get_unknown()===[],'official synopsis valid '.$class.' '.$name);}
}
$wpdb=new DispatcherDB;WP_CLI::$messages=[];WP_CLI::$warnings=[];
$extract->invoke([],['demo'=>true,'dry-run'=>true],[]);
$out=json_decode(end(WP_CLI::$messages),true,16,JSON_THROW_ON_ERROR);
ck($out['mode']==='FIXTURE_ONLY_READ_ONLY'&&count($out['candidates'])===3,'official dispatcher reaches handler and returns three demo previews');
ck($wpdb->snapshots===1&&$out['database_writes']===0&&$out['network_requests']===0,'dispatch uses fake SELECT only, no DB/HTTP');
ck(WP_CLI::$warnings===[],'no invalid synopsis or parameter warning');
blocked(fn()=>$extract->invoke([],['demo'=>true],[]),'handler still requires explicit dry-run','M2_PREVIEW_REQUIRES_DRY_RUN');
blocked(fn()=>$extract->invoke([],['demo'=>true,'dry-run'=>false],[]),'negative dry-run cannot satisfy safety flag','M2_PREVIEW_REQUIRES_DRY_RUN');
$stage=$group->get_subcommands()['stage'];$stageValidator=new WP_CLI\SynopsisValidator($stage->get_synopsis());
ck($stageValidator->get_unknown()===[]&&$stageValidator->unknown_assoc(['evidence-file'=>'test.json','source-url'=>'https://example.org/','dry-run'=>true])===[],'stage flag and valued args supported by official parser');
$path=dirname(__DIR__).'/data/examples/m2-structured-fixture.json';
blocked(fn()=>$stage->invoke([],['evidence-file'=>$path,'source-url'=>'https://example.org/','dry-run'=>true],[]),'official stage dispatcher reaches fixture safety gate','M2_FIXTURE_RECORD_BLOCKED');
$article=$group->get_subcommands()['article'];
$article->invoke([],['demo'=>true,'dry-run'=>true],[]);
$draft=json_decode(end(WP_CLI::$messages),true,16,JSON_THROW_ON_ERROR);
ck($draft['mode']==='EDITORIAL_DRAFT_READ_ONLY'&&count($draft['sections'])===3,'official article dispatcher exact flags');
ck($draft['database_writes']===0&&$draft['network_requests']===0&&$draft['publication_enabled']===false,'article dispatch never writes/fetches/publishes');
ck(WP_CLI::$warnings===[],'new article synopsis no warning');
blocked(fn()=>$article->invoke([],['demo'=>true],[]),'article still requires dry-run','M2_ARTICLE_REQUIRES_DRY_RUN');
$parse=$group->get_subcommands()['parse'];
foreach(class_exists('DOMDocument')?['csv','html']:['csv'] as $format){
 $parse->invoke([],['demo'=>true,'format'=>$format,'dry-run'=>true],[]);
 $parsed=json_decode(end(WP_CLI::$messages),true,16,JSON_THROW_ON_ERROR);
 ck($parsed['mode']==='LOCAL_DOCUMENT_PARSE_PREVIEW'&&count($parsed['preview']['candidates'])===3,'official parse dispatcher exact flags '.$format);
 ck($parsed['network_requests']===0&&$parsed['database_writes']===0&&!$parsed['publication_enabled'],'official parse no operations '.$format);
}
ck(WP_CLI::$warnings===[],'parse synopsis no warnings');
blocked(fn()=>$parse->invoke([],['demo'=>true,'format'=>'csv'],[]),'parse handler requires dry-run','M2_PARSE_REQUIRES_DRY_RUN');
$crlf=new WP_CLI\Dispatcher\Subcommand($group,'extract',new WP_CLI\DocParser(str_replace("\n","\r\n",(new ReflectionMethod('ADE_Pilot_CLI','extract'))->getDocComment())),function(){});
ck($crlf->get_synopsis()===$extract->get_synopsis(),'Windows CRLF doc comments parsed identically');
ck(isset($group->get_subcommands()['source_preview']),'official factory preserves underscore command');
$alias=WP_CLI\Dispatcher\CommandFactory::create('source-preview',[new ADE_Pilot_CLI,'source_preview'],$group);
ck($alias->get_name()==='source-preview','official factory supports explicit hyphen alias');
echo "PASS: $n official WP-CLI parser/dispatcher checks (v2.12.0; WP facade/fake DB, no MySQL writes).\n";
