# Real WordPress on an owned synthetic site only

Requires explicit disposable MySQL test permission, local managed Docker and pinned
cached image, PHP8.2 ctype/iconv/fileinfo/dom/mysqlnd/mysqli, Node Playwright/system
Chromium. Dependency installation must use approved official sources with proxy/
TLS/signatures preserved. No browser/WordPress needed for production runtime.

Obtain official WordPress dependency cache (outside project) at tag7.1.4 SHA
`db96f5eaa77a8d3e8eec8923a518fa2326f0d46a`. Runner requires exact unchanged Git HEAD.
Never point at user WordPress data/configuration. From plugin root:

```
python3 tests/wordpress/run-isolated.py --approved-disposable-mysql \
  --wordpress-source=/path/to/official-wordpress-7.1.4 \
  --directory-source=/path/to/original-ahda-directory-0.8.9 \
  --php-bin=/path/to/php8.2 --extension-dir=/path/to/php/modules \
  --output-dir=/path/to/safe-test-results
```

Runner creates its own new container/database/temp site, no arbitrary DB/host/
credentials accepted. Copies Core/plugins, uses bootstrap shim (never wp-config),
actual WP install/roles/plugin activation/R1 install, controlled fixture data,
then real browser login/admin-post/nonces/wpdb assertions. Mail/background HTTP/
cron/updaters suppressed. Browser/API addresses fixed to owned loopback. All own
resources removed in finally; random credentials never written to repo/logs.
No plugin feature gate enabled on user's site. Test flag only in owned bootstrap.

bootstrap.php refuses normal web/FPM and missing synthetic marker/env; control.php
CLI only. Do not use helpers on ahda.local/production. Review bootstrap/home/REST
alias distinctions and remaining limitations in docs/WORDPRESS_INTEGRATION.md.
