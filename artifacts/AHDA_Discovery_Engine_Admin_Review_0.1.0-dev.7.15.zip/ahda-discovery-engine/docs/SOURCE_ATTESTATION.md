# Pernyataan operator tentang identitas dan izin sumber — dev.7.13

Modul ini mencatat **pernyataan pemeriksaan manusia** untuk satu klaim kandidat
beserta sumber/raw yang terikat. `operator_attested` bukan verifikasi independen,
keputusan hukum hak konten, source official/verified, approval kandidat, atau
publikasi. Tidak ada perubahan field sources/relations/candidates/evidence/reviews/
legacy. Hanya satu row append-only di Discovery jobs per grant atau pencabutan.
Default OFF; tidak ada write pada LocalWP/data pengguna dari sesi ini.

## Kontrak masukan

`attest_stage --request-file=<local.json> --dry-run` menerima JSON<=16KiB dengan
**tepat** field berikut, tanpa flag approved/published tambahan:

| Field | Aturan |
| --- | --- |
| npsn | Anggota200pilot yang sama |
| candidate_id, evidence_id | Integer positif, linked dan sekolah sama |
| identity_basis | registry_crosscheck atau school_confirmation |
| identity_reference | URLHTTPS kanonik tanpa credential/token, atau kode arsip operator3..80ASCII; registry_crosscheck wajib URL salah satu2host referensi pemerintah yang sudah ditentukan |
| identity_note | Penjelasan operator40..500byte, memuat NPSN dan host sumber yang diperiksa |
| permission_basis | explicit_permission atau open_license; publicly_available tidak diterima sebagai dasar izin |
| permission_reference | URLHTTPS bersih atau kode arsip persetujuan/lisensi operator |
| permission_note | Penjelasan40..500byte tentang dasar, kondisi dan atribusi yang benar-benar diperiksa |
| valid_until | UTC Y-m-dTH:i:sZ, >60detik dan <=90hari ke depan saat pencatatan |
| identity_checked, permission_checked, privacy_checked | Ketiganya boolean true, pernyataan tanggung jawab operator |

Catatan harus UTF8, tanpa HTML/control/bidi. Referensi hanya metadata: kode tidak
mengambil URL, membaca surat, menilai keaslian dokumen, atau memutuskan lisensi
secara otomatis. Registry URL yang valid bentuknya belum membuktikan isi halaman.
Operator harus memeriksa sumber secara sah dan menyimpan rujukan nyata yang bisa
diaudit. Jangan masukkan surat privat/data siswa/nomor pribadi/password ke note.
Checkbox privacy adalah pernyataan manusia, bukan pemindai data sensitif.

Scope tetap **one_short_factual_claim_with_attribution**, bukan foto/logo/seluruh
artikel/raw redistribution/crawl permission. Izin crawl, penyimpanan raw dan reuse
klaim adalah hal berbeda. Tidak ada asumsi semua konten internet bebas dipakai.

## Alur yang diimplementasikan

- `attest_stage` membaca request, raw verifier segar, current meta dan source-state, lalu menampilkan token/dampak1row. Tidak menulis.
- `attest_record` memerlukan flag kode ADE_LOCAL_SOURCE_ATTESTATION_ENABLED=true (default tidak didefinisikan), localCLI/preflight/managejobs/reviewcap/actor, backupYES, token segar dan confirm RECORD_SOURCE_ATTESTATION.
- `attest_status --attestation-id=<id>` membaca grant+withdrawal, memeriksa kedaluwarsa dan binding/source/raw/current secara segar. Mengeluarkan operator_statement_current, tetap independently_verified=false/candidate_approved=false/publication=false.
- `attest_revoke_stage` menerima attestation-id, reason dan note10..500byte, --dry-run. Reason WITHDRAWN_PERMISSION/IDENTITY_DOUBT/OPERATOR_CORRECTION.
- `attest_revoke` menambah satu row pencabutan dengan token, backupYES dan confirm REVOKE_SOURCE_ATTESTATION, flag yang sama. Grant lama tidak dihapus atau ditimpa.

Tidak ada endpoint/form web baru sehingga tidak ada surface CSRF web baru.
Nonce tetap diwajibkan untuk keputusan admin HTTP yang sudah ada; writer baru
CLI-only. Status reader internal hanya reviewcap/local/preflight untuk workflow
berikutnya. Jangan mengaktifkan flag atau menjalankan write nyata sekarang:
belum ada rencana sumber sah/backup/persetujuan operator khusus pada data Anda.
Demo/fixtures sintetis tidak boleh diubah menjadi fakta untuk melewati gate.

## Integritas, concurrency, expiry dan pencabutan

Fresh raw verifier harus cocok, tidak stale/current conflict. Deklarasi mengikat
NPSN/school/candidate/evidence/source, rawreceipt/payload/doc hashes dan source-state.
Candidate version mengikat previewtoken tetapi tidak membuat pernyataan semantik
kedaluwarsa hanya karena ada tambahan bukti; perubahan binding/source-state
membutuhkan pernyataan baru. Operator harus melihat status dinamis, bukan hanya
result historis operator_attested pada receipt lama.

Mutasi memakai mutex M2/M3/raw yang sama, transaksi pendek, NOWAIT locks pada
candidate/evidence/link/raw/source serta receipt, bounded JSON16KiB dan satu INSERT.
Mode internal verifier locked memakai **current reads sejak SELECT pertama**,
bukan mengandalkan snapshot lama REPEATABLE READ. Test dua sesi sengaja membuat
snapshot lama lalu sesi lain menaikkan versi; token lama harus ditolak.

Insert/COMMIT gagal -> rollback; exact retry grant/revoke tanpa duplikat. Simulasi
commit berhasil namun ack hilang diuji fakeDB. Pencabutan tidak perlu fresh raw
berhasil, sehingga operator masih bisa menarik deklarasi setelah source blocked,
raw tak layak, atau grant expired. ID grant+operation mengikat withdrawal, reason/
note/actor replay berbeda tidak menimpa audit lama. Regrant adalah deklarasi baru
berizin/review ulang, tidak menghapus revocation historis.

Pencabutan ini spesifik grant/klaim, bukan larangan seluruh domain. Ia menahan
pemakaian grant tersebut untuk review/apply berikutnya; tidak otomatis menghapus
profil yang sudah terbit. Belum ada publisher/undo. Global source blocked harus
mengikuti kebijakan source terpisah. Tidak ada source official/verified/ownership
promotion, kandidat rejected tidak dibuka kembali, nilai/score/approved tetap.

`attest_status` adalah pembacaan snapshot, bukan token approval/locking guarantee.
Approval positif masa depan wajib mengambil grant+revocation/raw/source locks dan
fresh checks dalam transaksi/mutex yang sama; **jangan memakai report current() lama
sebagai otorisasi**. API locked current untuk transaksi approval belum dibuat.
Legacy verified-meta masih consistent read; publisher nanti harus mengunci/recheck
target sebelum apply. Hash bukan signature dan tidak melindungi DBadmin yang
mengubah payload+hash bersama. Declaration tidak menjadi bukti independen kebenaran
identitas, lisensi, catatan hak atau isi sekolah.

## Bukti dan batas

26suite/1588checks per PHP8.2.32/8.4.24 dengan DOM;1520tanpaDOM (HTML NOT RUN).
88PHP lint,84hash baseline/6tes asli utuh.35checks fakeDB baru: scope/type/reference/
expiry/consent, defaultOFF, grant+revoke append-only/replay, corruption, insertrollback,
lostack recovery, blockedsource invalidation, revocation after blockedsource,
staleversion, mutex/capability, historicalexpiry. Shared VerifyDB fake dipindahkan
ke support, adapter SQL diganti hanya pada tes, runtime writer lama tetap.

118checks layanan actualWordPress7.1.4/wpdb/MySQL8.4.13 plus47browser/admin checks.
Termasuk actualqueryfilter faults untuk insert/COMMIT, role, immutable grants,
current status/replay, blocked source dan withdrawal,6nonjobsDiscovery hashes
serta25legacy synthetic tables utuh, dan dua actualwpdb sessions RR race.
Tidak ada adapter SQL/core function stub; directservice API memakai marker kelas
WP_CLI untuk guard, bukan full officialCLIrunner. FinalPHP diagnostics bersih.
Dua run owned DB/site/server (116awal sebelum hardening,118final), tidak bersamaan,
1CPU/1GiB/512MiBtmpfs/loopback, semuanya dihapus. Initial proof dipertahankan sesuai
scope awal, final docs/qa/dev7.13/wordpress. Tidak ada source request atau produksi.

Masih belum: approval/edit positif, pemeriksaan otoritas sumber independen,
validity check locked untuk approval, durableworker/lease/fencing, publisher/undo,
raw privacy/retention/encryption/quota, fullWPCLI/userLocalWP/thirdparty/VPS load.
Pengayaan faktual nyata masih0/200. Rollback kode7.12 tanpa migrasi/delete/import;
row grant/revoke yang kelak dibuat sah tetap dipertahankan, tidak dihapus otomatis.
