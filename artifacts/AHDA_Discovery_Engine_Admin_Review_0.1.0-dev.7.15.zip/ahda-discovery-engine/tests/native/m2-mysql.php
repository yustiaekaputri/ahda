<?php
/** Opt-in disposable MySQL only. NEVER run against an existing WordPress DB. */
if ( PHP_SAPI !== 'cli' || getenv('AHDA_NATIVE_TEST_APPROVED') !== 'DISPOSABLE_SYNTHETIC_ONLY' || !extension_loaded('mysqli') || !extension_loaded('dom') ) { exit(2); }
$port=getenv('AHDA_NATIVE_TEST_PORT');$password=getenv('AHDA_NATIVE_TEST_PASSWORD');
if(!is_string($port)||!preg_match('/^[0-9]{5}$/D',$port)||(int)$port<20000||!is_string($password)||strlen($password)<32){exit(2);}
define('ABSPATH',__DIR__.'/');define('WP_CLI',true);define('ARRAY_A','ARRAY_A');
class WP_CLI {public static function error($message){throw new RuntimeException($message);}}
function current_user_can($cap){return in_array($cap,['ade_manage_jobs','ade_review_candidates'],true);}
function get_current_user_id(){return 1;}
function current_time($type,$utc){return gmdate('Y-m-d H:i:s');}
function wp_parse_url($url,$part){return parse_url($url,$part);}
function home_url($path){return 'http://ahda.local/';} // Context stub, never contacted.
function is_multisite(){return false;}
function wp_verify_nonce($nonce,$action){return hash_equals(hash('sha256','synthetic|1|'.$action),$nonce);}
class ADE_Jobs {public static function preflight(){return ['ready'=>true];}} // WP/preflight stub, actual schema tested below.
mysqli_report(MYSQLI_REPORT_ERROR|MYSQLI_REPORT_STRICT);
final class NativeDB {
 public $prefix='ade_native_',$last_error='',$insert_id=0,$db,$inserts=0,$fail_insert_at=0,$lose_commit_ack=false,$executed=[];
 public function __construct(){global $port,$password;$this->db=new mysqli('127.0.0.1','root',$password,'ahda_m2_disposable',(int)$port);$this->db->set_charset('utf8mb4');$this->db->query('SET SESSION innodb_lock_wait_timeout=1');}
 public function get_charset_collate(){return 'DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';}
 public function prepare($sql,...$args){if(count($args)===1&&is_array($args[0])){$args=$args[0];}$i=0;$out=preg_replace_callback('/%[sdf%]/',function($m)use(&$i,$args){if($m[0]==='%%'){return '%';}if(!array_key_exists($i,$args)){throw new RuntimeException('Native adapter missing placeholder');}$v=$args[$i++];return $m[0]==='%d'?(string)(int)$v:($m[0]==='%f'?(string)(float)$v:"'".$this->db->real_escape_string((string)$v)."'");},$sql);if($i!==count($args)){throw new RuntimeException('Native adapter extra args');}return $out;}
 public function get_results($sql,$kind){$this->executed[]=$sql;try{$result=$this->db->query($sql);return $result->fetch_all(MYSQLI_ASSOC);}catch(mysqli_sql_exception $e){$this->last_error=(string)$e->getCode();return null;}}
 public function query($sql){$this->executed[]=$sql;try{$this->db->query($sql);if($sql==='COMMIT'&&$this->lose_commit_ack){$this->last_error='simulated acknowledgment loss after native COMMIT';return false;}return $this->db->affected_rows;}catch(mysqli_sql_exception $e){$this->last_error=(string)$e->getCode();return false;}}
 public function insert($table,$values){++$this->inserts;if($this->inserts===$this->fail_insert_at){$this->last_error='injected insert failure';return false;}if(!preg_match('/^ade_native_ahda_discovery_(evidence|candidates|candidate_evidence|jobs|reviews)$/D',$table)){throw new RuntimeException('Native adapter write scope violation');}$cols=implode(',',array_keys($values));$args=[];foreach($values as $v){$args[]=$v===null?'NULL':"'".$this->db->real_escape_string((string)$v)."'";}$sql="INSERT INTO $table ($cols) VALUES (".implode(',',$args).')';$result=$this->query($sql);$this->insert_id=$this->db->insert_id;return $result;}
}
$wpdb=new NativeDB;
foreach(['schema','identity','source-urls','evidence-urls','pilot-scope','pilot','pilot-jobs','enrichment-preview','enrichment-store','article-preview','document-parser','local-archive','local-worker','archive-review','archive-vault','archive-candidates','candidate-inspector','review-decisions'] as $name){require_once dirname(__DIR__,2).'/includes/class-ade-'.$name.'.php';}
$n=0;function ck($v,$label){global $n;++$n;if(!$v){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$label,$expected=null){$message=null;try{$fn();}catch(Throwable $e){$message=$e->getMessage();}ck($message!==null,$label);if($expected!==null){ck($message===$expected,'reason '.$label);}}
function sql($s){global $wpdb;return $wpdb->db->query($s);}
function counts(){ $out=[];foreach(['evidence','candidates','candidate_evidence','jobs'] as $s){$out[$s]=(int)sql('SELECT COUNT(*) AS n FROM '.ADE_Schema::table_name($s))->fetch_assoc()['n'];}return $out; }
function state_hash($suffix){return hash('sha256',json_encode(sql('SELECT * FROM ade_native_ahda_'.$suffix.' ORDER BY id')->fetch_all(MYSQLI_ASSOC),JSON_THROW_ON_ERROR));}
function fresh(){global $wpdb;foreach(['evidence','candidates','candidate_evidence','jobs'] as $s){sql('DELETE FROM '.ADE_Schema::table_name($s));}$wpdb->inserts=0;$wpdb->fail_insert_at=0;$wpdb->lose_commit_ack=false;}
function store($raw,$token){return ADE_Enrichment_Store::record($raw,'https://example.org/',$token,'STORE_M2_PENDING','YES');}
$server=sql('SELECT VERSION() AS version')->fetch_assoc()['version'];ck(strpos($server,'8.4.')===0,'native MySQL8.4');
ck(sql('SELECT DATABASE() AS name')->fetch_assoc()['name']==='ahda_m2_disposable','fixed isolated database');
foreach(array_keys(ADE_Schema::definitions()) as $suffix){sql(ADE_Schema::create_sql($suffix));}
ck(count(sql("SHOW TABLES LIKE 'ade_native_ahda_discovery_%'")->fetch_all())===7,'all seven actual schema definitions valid InnoDB');
sql('CREATE TABLE ade_native_ahda_schools (id BIGINT UNSIGNED PRIMARY KEY,npsn CHAR(8) UNIQUE NOT NULL,name VARCHAR(255),school_form VARCHAR(20),education_level VARCHAR(20),regency_raw VARCHAR(100),district_raw VARCHAR(100),village_raw VARCHAR(100),ownership_status VARCHAR(20),visibility VARCHAR(20)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
sql('CREATE TABLE ade_native_ahda_school_meta (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,school_id BIGINT UNSIGNED,meta_key VARCHAR(100),meta_value LONGTEXT,verification_status VARCHAR(24),UNIQUE KEY school_meta(school_id,meta_key)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
$base=json_decode(file_get_contents(dirname(__DIR__,2).'/data/examples/m2-structured-fixture.json'),true,16,JSON_THROW_ON_ERROR);
$base['fixture_only']=false; // Synthetic native test input only; never delivered as a real source document.
$base['checked_at']=gmdate('Y-m-d\TH:i:s\Z',time()-60);$base['permission_reference']='disposable-synthetic-test';$raw=json_encode($base,JSON_THROW_ON_ERROR);$url='https://example.org/';
$ref=ADE_Pilot_Scope::reference()[$base['npsn']];
sql($wpdb->prepare('INSERT INTO ade_native_ahda_schools VALUES (913,%s,%s,%s,%s,%s,%s,%s,%s,%s)',$base['npsn'],'Native synthetic school',$ref['school_form'],'fixture',$ref['regency_raw'],'fixture','fixture','NEGERI','publish'));
$source=ADE_Source_URLs::canonicalize($url);$date=gmdate('Y-m-d H:i:s');
sql($wpdb->prepare('INSERT INTO ade_native_ahda_discovery_sources (id,source_type,canonical_url,canonical_key,normalized_host,created_at,updated_at) VALUES (7,%s,%s,%s,%s,%s,%s)','website',$url,$source['canonical_key'],$source['normalized_host'],$date,$date));
sql($wpdb->prepare('INSERT INTO ade_native_ahda_discovery_school_sources (id,school_id,source_id,created_at,updated_at) VALUES (8,913,7,%s,%s)',$date,$date));
$baseline=[];foreach(['schools','school_meta','discovery_sources','discovery_school_sources','discovery_reviews'] as $s){$baseline[$s]=state_hash($s);}
$plan=ADE_Enrichment_Store::stage($raw,$url);ck($plan['estimated_rows_created_including_receipt']===10&&array_sum(counts())===0,'native stage zero writes concrete ten-row plan');
$result=store($raw,$plan['preview_token']);ck($result['result']['rows_created']===10&&counts()===['evidence'=>3,'candidates'=>3,'candidate_evidence'=>3,'jobs'=>1],'native pending atomic insert');
ck((int)sql("SELECT COUNT(*) AS n FROM ade_native_ahda_discovery_candidates WHERE review_status='new' AND publish_status='not_ready' AND approved_value IS NULL AND overall_score=0")->fetch_assoc()['n']===3,'native pending/score/approval defaults');
$again=store($raw,$plan['preview_token']);ck($again['replayed']&&array_sum(counts())===10,'native idempotent receipt replay');
ck(ADE_Enrichment_Store::receipt($result['receipt_id'])['historical']===true,'native receipt read');
$draft=ADE_Article_Preview::preview($raw);ck(count($draft['sections'])===3&&!$draft['publication_enabled'],'article native indexed read with WP stubs');
foreach($baseline as $s=>$h){ck(state_hash($s)===$h,'initial legacy/source/review preservation '.$s);}
for($position=1;$position<=10;++$position){fresh();$p=ADE_Enrichment_Store::stage($raw,$url);$wpdb->fail_insert_at=$position;blocked(fn()=>store($raw,$p['preview_token']),'native rollback insert position '.$position,'M2_INSERT_FAILED');ck(array_sum(counts())===0,'native transaction atomic rollback '.$position);}
fresh();$p=ADE_Enrichment_Store::stage($raw,$url);$wpdb->lose_commit_ack=true;blocked(fn()=>store($raw,$p['preview_token']),'native committed but simulated ack lost','M2_TRANSACTION_FAILED');$wpdb->lose_commit_ack=false;ck(array_sum(counts())===10,'actual native commit remained durable');ck(store($raw,$p['preview_token'])['replayed']&&array_sum(counts())===10,'native receipt recovers unknown outcome');
$second=$base;$second['source_content'].=' Additional synthetic evidence A.';$raw2=json_encode($second);$p2=ADE_Enrichment_Store::stage($raw2,$url);$done=store($raw2,$p2['preview_token']);ck($done['result']['rows_created']===7&&$done['result']['candidate_versions_advanced']===3,'native append evidence and row version increments');
ck((int)sql('SELECT MIN(row_version) AS n FROM ade_native_ahda_discovery_candidates')->fetch_assoc()['n']===2,'native candidate versions advanced');
// A separate actual SQL session holds the same application lock.
$other=new NativeDB;$lock='ade_m2_'.substr(hash('sha256',json_encode([ADE_Schema::table_name('candidates'),913],JSON_THROW_ON_ERROR)),0,48);
$other->db->query($other->prepare('SELECT GET_LOCK(%s,0)',$lock));
$third=$base;$third['source_content'].=' Additional synthetic evidence B.';$raw3=json_encode($third);$p3=ADE_Enrichment_Store::stage($raw3,$url);$before=counts();
blocked(fn()=>store($raw3,$p3['preview_token']),'native two-session writer lock','M2_WRITER_BUSY');ck(counts()===$before,'busy writer no changes');$other->db->query($other->prepare('SELECT RELEASE_LOCK(%s)',$lock));
// Lock an actual source row in second connection; production SELECT FOR UPDATE NOWAIT must fail fast.
$other->db->begin_transaction();$other->db->query('SELECT id FROM ade_native_ahda_discovery_sources WHERE id=7 FOR UPDATE');$start=microtime(true);
blocked(fn()=>store($raw3,$p3['preview_token']),'native NOWAIT row contention','M2_READ_FAILED');ck(microtime(true)-$start<2&&counts()===$before,'NOWAIT bounded latency and rollback');$other->db->rollback();
$reviewed=sql('SELECT id FROM ade_native_ahda_discovery_candidates ORDER BY id LIMIT 1')->fetch_assoc()['id'];
sql("UPDATE ade_native_ahda_discovery_candidates SET review_status='approved',approved_value='Synthetic reviewed value',approved_by_user_id=2,approved_at=UTC_TIMESTAMP() WHERE id=".(int)$reviewed);
blocked(fn()=>store($raw3,$p3['preview_token']),'native review changed after stage','M2_PREVIEW_STALE');
$beforeReview=state_hash('discovery_candidates');$newPlan=ADE_Enrichment_Store::stage($raw3,$url);$reviewRow=sql('SELECT * FROM ade_native_ahda_discovery_candidates WHERE id='.(int)$reviewed)->fetch_assoc();$linkCount=(int)sql('SELECT COUNT(*) AS n FROM ade_native_ahda_discovery_candidate_evidence WHERE candidate_id='.(int)$reviewed)->fetch_assoc()['n'];
store($raw3,$newPlan['preview_token']);ck(sql('SELECT * FROM ade_native_ahda_discovery_candidates WHERE id='.(int)$reviewed)->fetch_assoc()===$reviewRow,'native reviewed candidate immutable');
ck((int)sql('SELECT COUNT(*) AS n FROM ade_native_ahda_discovery_candidate_evidence WHERE candidate_id='.(int)$reviewed)->fetch_assoc()['n']===$linkCount,'native reviewed evidence links unchanged');
// Existing verified meta changes after stage must invalidate fresh plan.
fresh();$p=ADE_Enrichment_Store::stage($raw,$url);sql("INSERT INTO ade_native_ahda_school_meta (school_id,meta_key,meta_value,verification_status) VALUES (913,'profile_hours','Synthetic concurrent editor value','verified')");blocked(fn()=>store($raw,$p['preview_token']),'native current-value hash stale','M2_PREVIEW_STALE');ck(array_sum(counts())===0,'stale snapshot zero inserts');sql('DELETE FROM ade_native_ahda_school_meta');
// Strict SQL escaping must preserve literal punctuation and block turning data into DML.
$quote="O'Reilly & sekolah; DROP TABLE schools; --";$quoted=$base;$quoted['source_content'].=' '.$quote;$quoted['claims'][0]=['target_key'=>'profile_programs','proposed_value'=>$quote,'supporting_quote'=>$quote];$quotedRaw=json_encode($quoted);$p=ADE_Enrichment_Store::stage($quotedRaw,$url);store($quotedRaw,$p['preview_token']);
ck(sql("SELECT proposed_value FROM ade_native_ahda_discovery_candidates WHERE target_key='profile_programs'")->fetch_assoc()['proposed_value']===$quote,'native SQL literal roundtrip');
ck((int)sql('SELECT COUNT(*) AS n FROM ade_native_ahda_schools')->fetch_assoc()['n']===1,'native identity table preserved');
foreach($baseline as $s=>$h){ck(state_hash($s)===$h,'final legacy/source/review preservation '.$s);}
// Parser-generated normalized records through actual pending writer SQL.
foreach(['csv','html'] as $format){
 fresh();$input=file_get_contents(dirname(__DIR__,2).'/data/examples/m2-profile-fixture.'.$format);
 $metadata=['fixture_only'=>false,'source_url'=>'https://example.org/ahda-fixture-only','checked_at'=>gmdate('Y-m-d\TH:i:s\Z',time()-60),'permission_reference'=>'disposable-parser-test'];
 $parsed=ADE_Document_Parser::preview($input,$format,'20268071',$metadata);
 ck(count($parsed['preview']['candidates'])===3&&$parsed['preview']['school_id']===913,'native parser preview '.$format);
 ck($parsed['raw_document_sha256']===hash('sha256',$input)&&array_sum(counts())===0,'native parser raw hash/read-only '.$format);
 $doc=json_encode($parsed['structured_document'],JSON_THROW_ON_ERROR);$stage=ADE_Enrichment_Store::stage($doc,$url);$stored=store($doc,$stage['preview_token']);
 ck($stored['result']['rows_created']===10&&array_sum(counts())===10,'native parser-to-pending transaction '.$format);
 ck(store($doc,$stage['preview_token'])['replayed']&&array_sum(counts())===10,'native parser receipt replay '.$format);
 foreach($baseline as $suffix=>$hash){ck(state_hash($suffix)===$hash,'native parser legacy/source/review preservation '.$format.' '.$suffix);}
}
// M3 read-only inspector uses actual SQL under the same WordPress context stubs.
$allSuffixes=['schools','school_meta','discovery_sources','discovery_school_sources','discovery_reviews','discovery_candidates','discovery_evidence','discovery_candidate_evidence','discovery_jobs'];
$beforeInspector=[];foreach($allSuffixes as $suffix){$beforeInspector[$suffix]=state_hash($suffix);}
$list=ADE_Candidate_Inspector::listing('20268071');ck(count($list['candidates'])===3,'native inspector candidate list');
ck(count(ADE_Candidate_Inspector::listing('20268071','new')['candidates'])===3&&count(ADE_Candidate_Inspector::listing('20268071','approved')['candidates'])===0,'native status filter');
$inspectID=$list['candidates'][0]['id'];$detail=ADE_Candidate_Inspector::detail('20268071',$inspectID);
ck(!$detail['current_value_conflict']&&count($detail['evidence'])===1,'native detail current hash and citation');
ck(!$detail['review_actions_enabled']&&$detail['database_writes']===0&&!$detail['publication_enabled'],'native inspector cannot decide or publish');
$lastID=end($list['candidates'])['id'];ck(ADE_Candidate_Inspector::listing('20268071','all',$lastID)['candidates']===[],'native keyset after cursor');
blocked(fn()=>ADE_Candidate_Inspector::detail('20268071',99999999),'native missing/cross-candidate ID','M3_CANDIDATE_NOT_FOUND');
$otherRef=ADE_Pilot_Scope::reference()['20268073'];
sql($wpdb->prepare('INSERT INTO ade_native_ahda_schools VALUES (914,%s,%s,%s,%s,%s,%s,%s,%s,%s)','20268073','Second synthetic school',$otherRef['school_form'],'fixture',$otherRef['regency_raw'],'fixture','fixture','NEGERI','publish'));
blocked(fn()=>ADE_Candidate_Inspector::detail('20268073',$inspectID),'native cross-school IDOR','M3_CANDIDATE_NOT_FOUND');sql('DELETE FROM ade_native_ahda_schools WHERE id=914');
$key=$detail['candidate']['target_key'];sql($wpdb->prepare('INSERT INTO ade_native_ahda_school_meta (school_id,meta_key,meta_value,verification_status) VALUES (913,%s,%s,%s)',$key,'Changed synthetic value','verified'));
ck(ADE_Candidate_Inspector::detail('20268071',$inspectID)['current_value_conflict'],'native inspector current/base mismatch');sql('DELETE FROM ade_native_ahda_school_meta');
$evidenceID=$detail['evidence'][0]['id'];sql('UPDATE ade_native_ahda_discovery_evidence SET school_id=999 WHERE id='.(int)$evidenceID);
blocked(fn()=>ADE_Candidate_Inspector::detail('20268071',$inspectID),'native cross-school evidence leak blocked','M3_EVIDENCE_CONFLICT');sql('UPDATE ade_native_ahda_discovery_evidence SET school_id=913 WHERE id='.(int)$evidenceID);
$oldURL=sql('SELECT evidence_url FROM ade_native_ahda_discovery_evidence WHERE id='.(int)$evidenceID)->fetch_assoc()['evidence_url'];
sql($wpdb->prepare('UPDATE ade_native_ahda_discovery_evidence SET evidence_url=%s WHERE id=%d','https://example.org/?token=HIDDEN_SECRET',$evidenceID));$blockedURL=ADE_Candidate_Inspector::detail('20268071',$inspectID);
ck($blockedURL['evidence'][0]['url']===null&&strpos(json_encode($blockedURL),'HIDDEN_SECRET')===false,'native sensitive URL masked');sql($wpdb->prepare('UPDATE ade_native_ahda_discovery_evidence SET evidence_url=%s WHERE id=%d',$oldURL,$evidenceID));
foreach($beforeInspector as $suffix=>$hash){ck(state_hash($suffix)===$hash,'native all-table inspector preservation '.$suffix);}
// Negative review is opt-in; actual WordPress nonce still represented by scoped stub.
$planOff=ADE_Review_Decisions::plan('20268071',$inspectID,'defer');ck(!$planOff['write_enabled'],'native negative-review default disabled');
define('ADE_LOCAL_NEGATIVE_REVIEW_ENABLED',true);
function negative_request($id,$decision='defer'){$p=ADE_Review_Decisions::plan('20268071',$id,$decision);return ['npsn'=>'20268071','candidate_id'=>$id,'row_version'=>$p['row_version'],'decision'=>$decision,'reason'=>$decision==='reject'?'WRONG_INFORMATION':'WAITING_SOURCE','note'=>"Synthetic O'Reilly review note",'preview_token'=>$p['preview_token'],'nonce'=>hash('sha256','synthetic|1|'.ADE_Review_Decisions::nonce_action($id,$p['row_version'],$decision)),'confirm'=>'SAVE_NEGATIVE_REVIEW','backup_confirmed'=>'YES'];}
$reviewPreserve=[];foreach(['schools','school_meta','discovery_sources','discovery_school_sources','discovery_evidence','discovery_candidate_evidence'] as $suffix){$reviewPreserve[$suffix]=state_hash($suffix);}
$r=negative_request($inspectID);$jobCount=(int)sql('SELECT COUNT(*) AS n FROM ade_native_ahda_discovery_jobs')->fetch_assoc()['n'];$auditCount=(int)sql('SELECT COUNT(*) AS n FROM ade_native_ahda_discovery_reviews')->fetch_assoc()['n'];
$done=ADE_Review_Decisions::record($r);ck($done['database_writes']===3&&$done['result']['after_status']==='deferred','native atomic negative decision');
ck((int)sql('SELECT COUNT(*) AS n FROM ade_native_ahda_discovery_reviews')->fetch_assoc()['n']===$auditCount+1,'native one append-only audit');
ck(ADE_Review_Decisions::record($r)['replayed']&&(int)sql('SELECT COUNT(*) AS n FROM ade_native_ahda_discovery_reviews')->fetch_assoc()['n']===$auditCount+1,'native exact decision idempotent');
ck(ADE_Review_Decisions::history('20268071',$inspectID)['rows'][0]['note']===$r['note'],'native audit note roundtrip');
$reject=negative_request($inspectID,'reject');ADE_Review_Decisions::record($reject);ck(ADE_Review_Decisions::record($r)['result_is_historical'],'native older receipt historical after reject');
blocked(fn()=>ADE_Review_Decisions::plan('20268071',$inspectID,'defer'),'native reject terminal','M3_REVIEW_STATE_LOCKED');
blocked(fn()=>ADE_Review_Decisions::plan('20268071',$inspectID,'approve'),'native approve impossible','M3_APPROVAL_NOT_AVAILABLE');
// Other candidates remain new. Fail audit or receipt insertion, including after status UPDATE.
$nextID=$list['candidates'][1]['id'];
for($position=1;$position<=2;$position++){
 $req=negative_request($nextID);$beforeCand=state_hash('discovery_candidates');$beforeAudit=state_hash('discovery_reviews');$beforeJobs=state_hash('discovery_jobs');$wpdb->fail_insert_at=$wpdb->inserts+$position;
 blocked(fn()=>ADE_Review_Decisions::record($req),'native negative insert failure '.$position,'M3_REVIEW_INSERT_FAILED');
 ck(state_hash('discovery_candidates')===$beforeCand&&state_hash('discovery_reviews')===$beforeAudit&&state_hash('discovery_jobs')===$beforeJobs,'native negative all rollback '.$position);$wpdb->fail_insert_at=0;
}
$req=negative_request($nextID);sql('UPDATE ade_native_ahda_discovery_candidates SET row_version=row_version+1 WHERE id='.(int)$nextID);
blocked(fn()=>ADE_Review_Decisions::record($req),'native stale review after worker version','M3_REVIEW_STALE');
$req=negative_request($nextID);$other->db->query($other->prepare('SELECT GET_LOCK(%s,0)',$lock));
blocked(fn()=>ADE_Review_Decisions::record($req),'native M2/M3 shared application lock','M3_REVIEW_WRITER_BUSY');$other->db->query($other->prepare('SELECT RELEASE_LOCK(%s)',$lock));
$other->db->begin_transaction();$other->db->query('SELECT id FROM ade_native_ahda_discovery_candidates WHERE id='.(int)$nextID.' FOR UPDATE');
blocked(fn()=>ADE_Review_Decisions::record($req),'native review NOWAIT conflict','M3_REVIEW_READ_FAILED');$other->db->rollback();
$wpdb->lose_commit_ack=true;blocked(fn()=>ADE_Review_Decisions::record($req),'native negative ack lost','M3_REVIEW_TRANSACTION_FAILED');$wpdb->lose_commit_ack=false;
ck(ADE_Review_Decisions::record($req)['replayed'],'native negative receipt resolves unknown commit');
$bad=$req;$bad['nonce']='bad';blocked(fn()=>ADE_Review_Decisions::record($bad),'native CSRF stub invalid','M3_REVIEW_NONCE_INVALID');
foreach($reviewPreserve as $suffix=>$hash){ck(state_hash($suffix)===$hash,'native negative preserves '.$suffix);}
// M2 must not append evidence behind deferred/rejected review decisions.
$negativeRows=sql("SELECT * FROM ade_native_ahda_discovery_candidates WHERE review_status IN ('deferred','rejected') ORDER BY id")->fetch_all(MYSQLI_ASSOC);
$negativeLinks=sql("SELECT ce.* FROM ade_native_ahda_discovery_candidate_evidence ce JOIN ade_native_ahda_discovery_candidates c ON c.id=ce.candidate_id WHERE c.review_status IN ('deferred','rejected') ORDER BY ce.id")->fetch_all(MYSQLI_ASSOC);
$afterReviewDoc=$base;$afterReviewDoc['source_content'].=' Additional synthetic observation after negative review.';$afterReviewRaw=json_encode($afterReviewDoc);
$afterReviewPlan=ADE_Enrichment_Store::stage($afterReviewRaw,$url);$afterReviewResult=store($afterReviewRaw,$afterReviewPlan['preview_token']);
ck($afterReviewResult['result']['candidate_versions_advanced']===1,'native M2 updates only remaining new candidate');
ck(sql("SELECT * FROM ade_native_ahda_discovery_candidates WHERE review_status IN ('deferred','rejected') ORDER BY id")->fetch_all(MYSQLI_ASSOC)===$negativeRows,'native M2 negative decision rows immutable');
ck(sql("SELECT ce.* FROM ade_native_ahda_discovery_candidate_evidence ce JOIN ade_native_ahda_discovery_candidates c ON c.id=ce.candidate_id WHERE c.review_status IN ('deferred','rejected') ORDER BY ce.id")->fetch_all(MYSQLI_ASSOC)===$negativeLinks,'native M2 no hidden evidence behind negative review');
// New archive/current/source/editorial bridge uses actual MySQL SELECTs only.
$archive=ADE_Local_Archive::freeze(ADE_Local_Archive::demo())['bundle'];$archive['documents']=[];
foreach($archive['schools'] as &$school){$school['document_keys']=[];}unset($school);
foreach(['csv','html'] as $format){
 $doc=ADE_Local_Archive::document(file_get_contents(dirname(__DIR__,2).'/data/examples/m2-profile-fixture.'.$format),$format,'https://example.org/synthetic-archive-'.$format,gmdate('Y-m-d\TH:i:s\Z',time()-60),'synthetic-native-archive-test');
 $archive['documents'][$doc['key']]=$doc['entry'];foreach($archive['schools'] as &$school){if($school['npsn']==='20268071'){$school['document_keys'][]=$doc['key'];}}unset($school);
}
$archiveRaw=json_encode($archive,JSON_THROW_ON_ERROR);$bindings=array_fill_keys(array_keys($archive['documents']),'https://example.org/');
$bridgeBefore=[];foreach($allSuffixes as $suffix){$bridgeBefore[$suffix]=state_hash($suffix);}
$insertBefore=$wpdb->inserts;$executedBefore=count($wpdb->executed);
$bridge=ADE_Archive_Review::plan($archiveRaw,'20268071',$bindings);
ck($bridge['school_id']===913&&$bridge['outcome']==='preview_needs_review','native archive identity and parse');
ck(count($bridge['candidates'])===3&&count($bridge['evidence'])===6,'native archive combines both raw documents');
ck(count($bridge['article_draft']['sources'])===6&&count($bridge['article_draft']['information_gaps'])===9,'native multisource article citations and gaps');
foreach($bridge['documents'] as $entry){ck($entry['source_id']===7&&$entry['relation_id']===8&&$entry['pending_source_policy_passed']&&!$entry['permission_attested'],'native bound pending relation not attestation');}
ck(!$bridge['storage_enabled']&&!$bridge['publication_enabled']&&$wpdb->inserts===$insertBefore,'native bridge no mutator');
$runtimeSQL=array_slice($wpdb->executed,$executedBefore);ck(count($runtimeSQL)===4&&count(array_filter($runtimeSQL,static function($sql){return strpos($sql,'SELECT ')===0;}))===4,'native exactly identity two bindings one snapshot SELECTs');
sql("INSERT INTO ade_native_ahda_school_meta (school_id,meta_key,meta_value,verification_status) VALUES (913,'profile_hours','JAM CONTOH UJI','verified')");
$equalBridge=ADE_Archive_Review::plan($archiveRaw,'20268071',$bindings);$hours=array_column($equalBridge['candidates'],null,'target_key')['profile_hours'];
ck(!$hours['change_required']&&$hours['current_value_snapshot']==='JAM CONTOH UJI'&&$equalBridge['plan_sha256']!==$bridge['plan_sha256'],'native current value comparison and changed plan');sql('DELETE FROM ade_native_ahda_school_meta');
sql("UPDATE ade_native_ahda_discovery_sources SET access_state='blocked' WHERE id=7");$blockedBridge=ADE_Archive_Review::plan($archiveRaw,'20268071',$bindings);
ck(!$blockedBridge['documents'][0]['pending_source_policy_passed']&&in_array('SOURCE_BINDING_REQUIRED_OR_BLOCKED',$blockedBridge['blocking_reasons'],true),'native blocked source cannot pass plan');sql("UPDATE ade_native_ahda_discovery_sources SET access_state='manual_only' WHERE id=7");
foreach($bridgeBefore as $suffix=>$hash){ck(state_hash($suffix)===$hash,'native archive preserves all tables '.$suffix);}
// Explicit synthetic-only raw archive storage. No user-site configuration.
ck(!ADE_Archive_Vault::enabled(),'native raw vault default OFF');
blocked(fn()=>ADE_Archive_Vault::record($archiveRaw,'20268071',$bindings,str_repeat('0',64),'STORE_RAW_PENDING','YES','YES'),'native raw default guard','VAULT_STORAGE_DISABLED');
$archive['fixture_only']=false; // Only inside approved disposable synthetic database tests.
$vaultRaw=json_encode($archive,JSON_THROW_ON_ERROR);$vaultPlan=ADE_Archive_Vault::stage($vaultRaw,'20268071',$bindings);
ck($vaultPlan['estimated_jobs_rows_created']===1&&!$vaultPlan['storage_module_enabled'],'native raw stage one-row impact no write');
define('ADE_LOCAL_ARCHIVE_STORAGE_ENABLED',true);
function vault_store($raw,$bindings,$token){return ADE_Archive_Vault::record($raw,'20268071',$bindings,$token,'STORE_RAW_PENDING','YES','YES');}
$vaultPreserve=[];foreach(array_diff($allSuffixes,['discovery_jobs']) as $suffix){$vaultPreserve[$suffix]=state_hash($suffix);}
$jobBefore=(int)sql('SELECT COUNT(*) AS n FROM ade_native_ahda_discovery_jobs')->fetch_assoc()['n'];
$storedVault=vault_store($vaultRaw,$bindings,$vaultPlan['preview_token']);
ck($storedVault['rows_created']===1&&!$storedVault['replayed']&&(int)sql('SELECT COUNT(*) AS n FROM ade_native_ahda_discovery_jobs')->fetch_assoc()['n']===$jobBefore+1,'native raw one atomic archive row');
$vaultReceipt=ADE_Archive_Vault::receipt($storedVault['receipt_id']);ck(!$vaultReceipt['raw_content_returned']&&count($vaultReceipt['summary']['documents'])===2,'native raw receipt metadata only');
ck($vaultReceipt['summary']['evidence_rows_created']===0&&$vaultReceipt['summary']['candidate_rows_created']===0&&!$vaultReceipt['summary']['publication_enabled'],'native raw no fact/approval promotion');
ck(vault_store($vaultRaw,$bindings,$vaultPlan['preview_token'])['replayed']&&(int)sql('SELECT COUNT(*) AS n FROM ade_native_ahda_discovery_jobs')->fetch_assoc()['n']===$jobBefore+1,'native raw dedupe/retry');
// Different operator reference creates a new archive revision for failure tests.
$revision=$archive;$revision['documents']=[];foreach($revision['schools'] as &$school){$school['document_keys']=[];}unset($school);
$revDoc=ADE_Local_Archive::document(file_get_contents(dirname(__DIR__,2).'/data/examples/m2-profile-fixture.csv'),'csv','https://example.org/synthetic-vault-revision',gmdate('Y-m-d\TH:i:s\Z',time()-60),'synthetic-native-revision');
$revision['documents'][$revDoc['key']]=$revDoc['entry'];foreach($revision['schools'] as &$school){if($school['npsn']==='20268071'){$school['document_keys']=[$revDoc['key']];}}unset($school);
$revisionRaw=json_encode($revision,JSON_THROW_ON_ERROR);$revisionBindings=[$revDoc['key']=>'https://example.org/'];$revisionPlan=ADE_Archive_Vault::stage($revisionRaw,'20268071',$revisionBindings);
$jobsBeforeFailure=state_hash('discovery_jobs');$wpdb->fail_insert_at=$wpdb->inserts+1;
blocked(fn()=>vault_store($revisionRaw,$revisionBindings,$revisionPlan['preview_token']),'native raw insert failure','VAULT_INSERT_FAILED');$wpdb->fail_insert_at=0;ck(state_hash('discovery_jobs')===$jobsBeforeFailure,'native raw insert failure rollback');
$other->db->query($other->prepare('SELECT GET_LOCK(%s,0)',$lock));blocked(fn()=>vault_store($revisionRaw,$revisionBindings,$revisionPlan['preview_token']),'native raw shared M2 contention','VAULT_WRITER_BUSY');$other->db->query($other->prepare('SELECT RELEASE_LOCK(%s)',$lock));
$other->db->begin_transaction();$other->db->query('SELECT id FROM ade_native_ahda_discovery_sources WHERE id=7 FOR UPDATE');$timeStart=microtime(true);
blocked(fn()=>vault_store($revisionRaw,$revisionBindings,$revisionPlan['preview_token']),'native raw NOWAIT source lock','VAULT_READ_FAILED');ck(microtime(true)-$timeStart<2&&state_hash('discovery_jobs')===$jobsBeforeFailure,'native raw row lock bounded no insert');$other->db->rollback();
sql("INSERT INTO ade_native_ahda_school_meta (school_id,meta_key,meta_value,verification_status) VALUES (913,'profile_hours','Changed before raw store','verified')");blocked(fn()=>vault_store($revisionRaw,$revisionBindings,$revisionPlan['preview_token']),'native raw snapshot stale','VAULT_PREVIEW_STALE');sql('DELETE FROM ade_native_ahda_school_meta');
$wpdb->lose_commit_ack=true;blocked(fn()=>vault_store($revisionRaw,$revisionBindings,$revisionPlan['preview_token']),'native raw committed acknowledgment lost','VAULT_TRANSACTION_FAILED');$wpdb->lose_commit_ack=false;
ck(vault_store($revisionRaw,$revisionBindings,$revisionPlan['preview_token'])['replayed'],'native raw unknown outcome recovered by receipt');
$vaultId=(int)$storedVault['receipt_id'];$vaultRow=sql('SELECT scope_filter FROM ade_native_ahda_discovery_jobs WHERE id='.$vaultId)->fetch_assoc()['scope_filter'];
sql($wpdb->prepare('UPDATE ade_native_ahda_discovery_jobs SET scope_filter=%s WHERE id=%d',str_replace('PROGRAM CONTOH UJI','CORRUPTED CLAIM',$vaultRow),$vaultId));blocked(fn()=>ADE_Archive_Vault::receipt($vaultId),'native raw corruption detected');sql($wpdb->prepare('UPDATE ade_native_ahda_discovery_jobs SET scope_filter=%s WHERE id=%d',$vaultRow,$vaultId));
ck(ADE_Archive_Vault::receipt($vaultId)['summary']['raw_payload_sha256']===$vaultReceipt['summary']['raw_payload_sha256'],'native raw restore exact byte hash');
foreach($vaultPreserve as $suffix=>$hash){ck(state_hash($suffix)===$hash,'native raw preserves all non-job tables '.$suffix);}
// Raw receipt -> pending candidates: new guarded module, native SQL, two hosts.
ck(!ADE_Archive_Candidates::enabled(),'native archive candidate default OFF');
blocked(fn()=>ADE_Archive_Candidates::record($vaultId,'20268071',str_repeat('0',64),'STORE_ARCHIVE_CANDIDATES','YES'),'native candidate default guard','AC_STORAGE_DISABLED');
$secondSource=ADE_Source_URLs::canonicalize('https://example.net/');
sql($wpdb->prepare('INSERT INTO ade_native_ahda_discovery_sources (id,source_type,canonical_url,canonical_key,normalized_host,created_at,updated_at) VALUES (9,%s,%s,%s,%s,%s,%s)','website','https://example.net/',$secondSource['canonical_key'],$secondSource['normalized_host'],$date,$date));
sql($wpdb->prepare('INSERT INTO ade_native_ahda_discovery_school_sources (id,school_id,source_id,created_at,updated_at) VALUES (10,913,9,%s,%s)',$date,$date));
$bridgeArchive=$archive;$bridgeArchive['documents']=[];foreach($bridgeArchive['schools'] as &$school){$school['document_keys']=[];}unset($school);$bridgeBindings=[];
foreach(['csv'=>'https://example.org/','html'=>'https://example.net/'] as $format=>$host){
 $doc=ADE_Local_Archive::document(file_get_contents(dirname(__DIR__,2).'/data/examples/m2-profile-fixture.'.$format),$format,$host.'synthetic-native-bridge',gmdate('Y-m-d\TH:i:s\Z',time()-60),'synthetic-native-bridge');$bridgeArchive['documents'][$doc['key']]=$doc['entry'];$bridgeBindings[$doc['key']]=$host;
 foreach($bridgeArchive['schools'] as &$school){if($school['npsn']==='20268071'){$school['document_keys'][]=$doc['key'];}}unset($school);
}
$bridgeRaw=json_encode($bridgeArchive,JSON_THROW_ON_ERROR);
function bridge_fresh($raw,$bindings){fresh();$p=ADE_Archive_Vault::stage($raw,'20268071',$bindings);return ADE_Archive_Vault::record($raw,'20268071',$bindings,$p['preview_token'],'STORE_RAW_PENDING','YES','YES')['receipt_id'];}
function bridge_stage($id){return ADE_Archive_Candidates::stage($id,'20268071');}
function bridge_store($id,$token){return ADE_Archive_Candidates::record($id,'20268071',$token,'STORE_ARCHIVE_CANDIDATES','YES');}
$rawID=bridge_fresh($bridgeRaw,$bridgeBindings);$p=bridge_stage($rawID);ck($p['estimated_rows_created_including_receipt']===16&&count($p['source_links'])===2,'native two-host stage16rows');
define('ADE_LOCAL_ARCHIVE_CANDIDATES_ENABLED',true);
$rawRowBefore=sql('SELECT * FROM ade_native_ahda_discovery_jobs WHERE id='.(int)$rawID)->fetch_assoc();
$protectedTables=[];foreach(['schools','school_meta','discovery_sources','discovery_school_sources','discovery_reviews'] as $suffix){$protectedTables[$suffix]=state_hash($suffix);}
$bridgeDone=bridge_store($rawID,$p['preview_token']);ck($bridgeDone['result']['rows_created']===16&&counts()===['evidence'=>6,'candidates'=>3,'candidate_evidence'=>6,'jobs'=>2],'native atomic two-source evidence/candidates');
ck(sql('SELECT * FROM ade_native_ahda_discovery_jobs WHERE id='.(int)$rawID)->fetch_assoc()===$rawRowBefore,'native raw archive row unchanged');
$proofRows=sql('SELECT source_id,parse_status,observed_value FROM ade_native_ahda_discovery_evidence ORDER BY id')->fetch_all(MYSQLI_ASSOC);$sourceSet=[];
foreach($proofRows as $entry){$o=json_decode($entry['observed_value'],true);$sourceSet[(int)$entry['source_id']]=true;ck($o['raw_receipt_id']===$rawID&&$entry['parse_status']==='m2_archive_unverified'&&isset($bridgeArchive['documents'][$o['document_key']])&&$o['raw_document_sha256']===$bridgeArchive['documents'][$o['document_key']]['raw_sha256'],'native evidence anchored in stored raw');}
ck(count($sourceSet)===2&&isset($sourceSet[7],$sourceSet[9]),'native both source IDs preserved');
$sampleID=(int)sql('SELECT id FROM ade_native_ahda_discovery_candidates ORDER BY id LIMIT 1')->fetch_assoc()['id'];$ins=ADE_Candidate_Inspector::detail('20268071',$sampleID);
ck(count($ins['evidence'])===2&&$ins['evidence'][0]['archive_binding']['raw_receipt_id']===$rawID&&!$ins['evidence'][0]['archive_binding']['revalidated_on_this_page'],'native inspector raw references visible; no false revalidation');
ck(in_array('RAW_ARCHIVE_BINDING_NOT_REVALIDATED_ON_THIS_PAGE',$ins['readiness_reasons'],true),'native inspector raw limitation explicit');
ck(bridge_store($rawID,$p['preview_token'])['replayed']&&counts()['jobs']===2,'native candidate replay idempotent');ck(ADE_Archive_Candidates::receipt($bridgeDone['receipt_id'])['historical'],'native archive operation receipt');
blocked(fn()=>ADE_Archive_Candidates::stage($rawID,'20268073'),'native raw cross-school IDOR','VAULT_SCHOOL_BINDING_CONFLICT');
// Fail every candidate/evidence/link/receipt insertion: raw row survives unchanged.
for($position=1;$position<=16;$position++){
 $rawID=bridge_fresh($bridgeRaw,$bridgeBindings);$p=bridge_stage($rawID);$before=counts();$rawHash=state_hash('discovery_jobs');$wpdb->fail_insert_at=$wpdb->inserts+$position;
 blocked(fn()=>bridge_store($rawID,$p['preview_token']),'native archive rollback insert '.$position,'AC_INSERT_FAILED');$wpdb->fail_insert_at=0;
 ck(counts()===$before&&state_hash('discovery_jobs')===$rawHash,'native archive all-or-nothing '.$position);
}
$rawID=bridge_fresh($bridgeRaw,$bridgeBindings);$p=bridge_stage($rawID);$wpdb->lose_commit_ack=true;
blocked(fn()=>bridge_store($rawID,$p['preview_token']),'native archive COMMIT acknowledgment lost','AC_TRANSACTION_FAILED');$wpdb->lose_commit_ack=false;ck(bridge_store($rawID,$p['preview_token'])['replayed']&&counts()['evidence']===6,'native archive unknown outcome recovered');
// New raw revision binds new evidence to existing pending keys; reviewed remain frozen.
$rev=$bridgeArchive;$rev['documents']=[];foreach($rev['schools'] as &$school){$school['document_keys']=[];}unset($school);$revBindings=[];
foreach($bridgeArchive['documents'] as $doc){$new=ADE_Local_Archive::document($doc['content'],$doc['format'],$doc['source_url'],$doc['checked_at'],'synthetic-native-revision-bridge');$rev['documents'][$new['key']]=$new['entry'];$revBindings[$new['key']]=$doc['format']==='csv'?'https://example.org/':'https://example.net/';foreach($rev['schools'] as &$school){if($school['npsn']==='20268071'){$school['document_keys'][]=$new['key'];}}unset($school);}
$revRaw=json_encode($rev,JSON_THROW_ON_ERROR);$vp=ADE_Archive_Vault::stage($revRaw,'20268071',$revBindings);$revisionID=ADE_Archive_Vault::record($revRaw,'20268071',$revBindings,$vp['preview_token'],'STORE_RAW_PENDING','YES','YES')['receipt_id'];
$p=bridge_stage($revisionID);ck($p['estimated_rows_created_including_receipt']===13&&$p['estimated_pending_versions_advanced']===3,'native append evidence to existing3pending');
$protectedID=(int)sql('SELECT id FROM ade_native_ahda_discovery_candidates ORDER BY id LIMIT 1')->fetch_assoc()['id'];sql("UPDATE ade_native_ahda_discovery_candidates SET review_status='rejected',row_version=row_version+1 WHERE id=".$protectedID);
$protectedRow=sql('SELECT * FROM ade_native_ahda_discovery_candidates WHERE id='.$protectedID)->fetch_assoc();$protectedLinks=sql('SELECT * FROM ade_native_ahda_discovery_candidate_evidence WHERE candidate_id='.$protectedID.' ORDER BY id')->fetch_all(MYSQLI_ASSOC);
blocked(fn()=>bridge_store($revisionID,$p['preview_token']),'native review changed after stage','AC_PREVIEW_STALE');
$p=bridge_stage($revisionID);$appended=bridge_store($revisionID,$p['preview_token']);ck($appended['result']['rows_created']===9&&$appended['result']['candidate_versions_advanced']===2,'native skip reviewed and version only2pending');
ck(sql('SELECT * FROM ade_native_ahda_discovery_candidates WHERE id='.$protectedID)->fetch_assoc()===$protectedRow&&sql('SELECT * FROM ade_native_ahda_discovery_candidate_evidence WHERE candidate_id='.$protectedID.' ORDER BY id')->fetch_all(MYSQLI_ASSOC)===$protectedLinks,'native reviewed row and evidence links immutable');
$rawID=bridge_fresh($bridgeRaw,$bridgeBindings);$p=bridge_stage($rawID);$other->db->query($other->prepare('SELECT GET_LOCK(%s,0)',$lock));blocked(fn()=>bridge_store($rawID,$p['preview_token']),'native archive M2 shared mutex','AC_WRITER_BUSY');$other->db->query($other->prepare('SELECT RELEASE_LOCK(%s)',$lock));
$other->db->begin_transaction();$other->db->query('SELECT id FROM ade_native_ahda_discovery_sources WHERE id=9 FOR UPDATE');$start=microtime(true);blocked(fn()=>bridge_store($rawID,$p['preview_token']),'native archive second-source NOWAIT','VAULT_READ_FAILED');ck(microtime(true)-$start<2&&counts()['evidence']===0,'native NOWAIT bounded and no partial rows');$other->db->rollback();
sql("INSERT INTO ade_native_ahda_school_meta (school_id,meta_key,meta_value,verification_status) VALUES (913,'profile_hours','Concurrent change before candidate store','verified')");blocked(fn()=>bridge_store($rawID,$p['preview_token']),'native archive snapshot stale','AC_PREVIEW_STALE');sql('DELETE FROM ade_native_ahda_school_meta');
foreach($protectedTables as $suffix=>$hash){ck(state_hash($suffix)===$hash,'native archive preserves protected table '.$suffix);}
$other->db->close();$wpdb->db->close();
echo "PASS: $n native MySQL $server checks (actual schema/SQL/InnoDB/locks, WordPress and wpdb adapter stubs; disposable synthetic data only).\n";
