<?php
require_once __DIR__.'/support/m1-fake-db.php';
$wpdb=new FakeDB;
require_once dirname(__DIR__).'/includes/class-ade-identity.php';
require_once dirname(__DIR__).'/includes/class-ade-source-urls.php';
require_once dirname(__DIR__).'/includes/class-ade-sources.php';
require_once dirname(__DIR__).'/includes/class-ade-pilot.php';
require_once dirname(__DIR__).'/includes/class-ade-pilot-jobs.php';
$n=0;function ck($v,$label){global $n;++$n;if(!$v){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$label){$caught=false;try{$fn();}catch(RuntimeException|InvalidArgumentException $e){$caught=true;}ck($caught,$label);}
foreach(['','npsn','12345678,12345679','12345678\n12345678',"=SUM(1)","12345678\n",str_repeat('1',4097)] as $input){if($input==="12345678\n"){continue;}blocked(fn()=>ADE_Pilot::parse($input),'invalid pilot text');}
ck(ADE_Pilot::parse("01234567\r\n12345678")===['01234567','12345678'],'leading zero preserved');
$npsns=[];for($i=0;$i<200;++$i){$npsns[]=strval(10000000+$i);}
$m=ADE_Pilot::freeze(array_reverse($npsns));ck($m===ADE_Pilot::freeze($npsns),'frozen manifest stable across input order');
blocked(fn()=>ADE_Pilot::freeze(['99999999']),'unknown NPSN');blocked(fn()=>ADE_Pilot::freeze(['99999998']),'ineligible level');blocked(fn()=>ADE_Pilot::freeze(['99999997']),'noncanonical publication state rejected');
$extra=$m;$extra['extra']='unexpected';blocked(fn()=>ADE_Pilot::batch($extra),'strict manifest keys');
$bad=$m;$bad['schools'][0]['npsn']='12345678';blocked(fn()=>ADE_Pilot::batch($bad),'manifest tamper');
blocked(fn()=>ADE_Pilot::batch($m,9999),'cursor outside pilot');blocked(fn()=>ADE_Pilot::batch($m,0,21),'size cap');
$r=ADE_Pilot::batch($m);ck(count($r['results'])===10 && $r['cursor']===10 && !$r['complete'],'first ten schools');ck($r['results'][0]['outcome']==='operator_source_review_required' && $r['results'][1]['outcome']==='needs_source','structured blocked/no source outcomes');ck($wpdb->jobs===[],'preview zero writes');
blocked(fn()=>ADE_Pilot_Jobs::enqueue($m,''),'no write without approval');$cap=false;blocked(fn()=>ADE_Pilot_Jobs::enqueue($m,'ENQUEUE_M1_PLAN'),'capability denied');$cap=true;ADE_Schema::$local=false;blocked(fn()=>ADE_Pilot_Jobs::enqueue($m,'ENQUEUE_M1_PLAN'),'production denied');ADE_Schema::$local=true;
$small=ADE_Pilot::freeze(array_slice($npsns,0,2));blocked(fn()=>ADE_Pilot_Jobs::enqueue($small,'ENQUEUE_M1_PLAN'),'requires explicit 200');
blocked(fn()=>ADE_Pilot_Jobs::enqueue($m,'ENQUEUE_M1_PLAN'),'new unscoped jobs rejected');
// Seed pre-upgrade v1 rows DIRECTLY into the fake DB, not through current API.
function legacy_seed($manifest){global $wpdb;$key=hash('sha256',ADE_Pilot_Jobs::TYPE.'|'.$manifest['hash']);foreach($wpdb->jobs as $job){if($job['job_key']===$key){return ['created'=>false,'job'=>$job];}}$wpdb->insert('custom_ahda_discovery_jobs',['job_key'=>$key,'job_type'=>ADE_Pilot_Jobs::TYPE,'scope_filter'=>json_encode($manifest),'status'=>'queued']);return ['created'=>true,'job'=>$wpdb->jobs[$wpdb->insert_id]];}
$a=legacy_seed($m);$b=legacy_seed($m);ck($a['created'] && !$b['created'] && count($wpdb->jobs)===1,'enqueue idempotency');
$id=$a['job']['id'];$wpdb->held=true;blocked(fn()=>ADE_Pilot_Jobs::step($id,'RUN_M1_PLAN'),'concurrent worker rejected');$wpdb->held=false;
$r=ADE_Pilot_Jobs::step($id,'RUN_M1_PLAN');ck($r['cursor']===10 && $r['network_requests']===0,'checkpoint first batch');
$r=ADE_Pilot_Jobs::step($id,'RUN_M1_PLAN');ck($r['cursor']===20 && count(json_decode($wpdb->jobs[$id]['stats_payload'],true))===20,'resume without duplicates');
$wpdb->read_failure=true;blocked(fn()=>ADE_Pilot_Jobs::step($id,'RUN_M1_PLAN'),'SQL read failure');ck($wpdb->jobs[$id]['cursor_school_id']===20 && $wpdb->jobs[$id]['status']==='retry_wait','failure retains cursor');$wpdb->read_failure=false;$wpdb->jobs[$id]['next_run_at']=null;
$wpdb->mode='commit-fail';blocked(fn()=>ADE_Pilot_Jobs::step($id,'RUN_M1_PLAN'),'commit failure');ck($wpdb->jobs[$id]['cursor_school_id']===20 && count(json_decode($wpdb->jobs[$id]['stats_payload'],true))===20,'atomic rollback results and cursor');$wpdb->mode='';$wpdb->jobs[$id]['next_run_at']=null;
$wpdb->mode='lease-lost';blocked(fn()=>ADE_Pilot_Jobs::step($id,'RUN_M1_PLAN'),'stale worker fenced');ck($wpdb->jobs[$id]['cursor_school_id']===20,'stale token cannot advance');$wpdb->mode='';$wpdb->jobs[$id]['leased_until']=false;
ck(ADE_Pilot_Jobs::recover('RECOVER_M1_PLAN')===1,'expired lease recovered');ck($wpdb->jobs[$id]['status']==='failed','attempt limit reached');
ck(ADE_Pilot_Jobs::retry_failed($id,'RETRY_M1_PLAN'),'explicit retry preserves committed results');
for($i=0;$i<18;++$i){$r=ADE_Pilot_Jobs::step($id,'RUN_M1_PLAN');}
ck($r['status']==='completed' && $r['cursor']===200,'200 fixture schools completed');
$results=json_decode($wpdb->jobs[$id]['stats_payload'],true);ck(count($results)===200 && count(array_unique(array_column($results,'school_id')))===200,'exact 200 unique committed outcomes');
ck(ADE_Pilot_Jobs::step($id,'RUN_M1_PLAN')['processed']===0,'completed repeat is no-op');
ck(!ADE_Pilot_Jobs::cancel($id,'CANCEL_M1_PLAN'),'completed cannot cancel');
ck(ADE_Pilot_Jobs::integrity($id)['committed']===200,'integrity complete');
$saved=$wpdb->jobs[$id]['cursor_school_id'];$wpdb->jobs[$id]['cursor_school_id']=199;blocked(fn()=>ADE_Pilot_Jobs::integrity($id),'cursor tamper detected');$wpdb->jobs[$id]['cursor_school_id']=$saved;
$m2=ADE_Pilot::freeze(array_map(fn($v)=>strval((int)$v+200),$npsns));$new=legacy_seed($m2);$id2=$new['job']['id'];ck(ADE_Pilot_Jobs::cancel($id2,'CANCEL_M1_PLAN'),'queued cancellation');ck(ADE_Pilot_Jobs::step($id2,'RUN_M1_PLAN')['processed']===0,'cancelled no-op');
foreach($wpdb->sql as [$sql,$args]){if(strpos($sql,'UPDATE ')===0){ck(strpos($sql,'UPDATE custom_ahda_discovery_jobs ')===0,'write table allowlist');}}
echo "PASS: $n M1 pilot/queue simulation checks (fake DB; no real writes/network).\n";
