<?php
/** Isolated test bootstrap only; no wp-config.php is read, generated or changed. */
if(!in_array(PHP_SAPI,['cli','cli-server'],true)||getenv('AHDA_WP_E2E_ONLY')!=='SYNTHETIC_ISOLATED'){http_response_code(404);exit;}
$root=getenv('AHDA_WP_E2E_ROOT');$state=getenv('AHDA_WP_E2E_STATE');$port=getenv('AHDA_WP_E2E_DB_PORT');
if(!$root||!$state||!is_file($state.'/owned-test-root')||!preg_match('/^[0-9]{5}$/D',(string)$port)||(int)$port<20000){exit(2);}
if(!defined('ABSPATH')){define('ABSPATH',rtrim($root,'/').'/');}
define('DB_NAME','ahda_m2_disposable');define('DB_USER','root');define('DB_PASSWORD',getenv('AHDA_WP_E2E_DB_PASSWORD'));define('DB_HOST','127.0.0.1:'.$port);
define('DB_CHARSET','utf8mb4');define('DB_COLLATE','');$table_prefix='ahda_e2e_';
define('WP_SITEURL',getenv('AHDA_WP_E2E_URL'));define('WP_HOME','http://ahda.local');
define('WP_DEBUG',true);define('WP_DEBUG_DISPLAY',false);define('WP_DEBUG_LOG',$state.'/php-debug.log');
define('DISABLE_WP_CRON',true);define('AUTOMATIC_UPDATER_DISABLED',true);define('WP_AUTO_UPDATE_CORE',false);
define('WP_HTTP_BLOCK_EXTERNAL',true);define('DISALLOW_FILE_EDIT',true);define('DISALLOW_FILE_MODS',true);
foreach(['AUTH_KEY','SECURE_AUTH_KEY','LOGGED_IN_KEY','NONCE_KEY','AUTH_SALT','SECURE_AUTH_SALT','LOGGED_IN_SALT','NONCE_SALT'] as $key){define($key,hash_hmac('sha256',$key,getenv('AHDA_WP_E2E_AUTH_SEED')));}
if(is_file($state.'/negative-enabled')){define('ADE_LOCAL_NEGATIVE_REVIEW_ENABLED',true);}
if(is_file($state.'/positive-enabled')){define('ADE_LOCAL_POSITIVE_REVIEW_ENABLED',true);}
// Real WordPress hook API, preloaded only to suppress all mail/HTTP before install.
require_once ABSPATH.'wp-includes/plugin.php';
add_filter('pre_wp_mail',function(){return false;},PHP_INT_MAX);
add_filter('pre_http_request',function(){return new WP_Error('ahda_e2e_network_blocked','External and background HTTP disabled for isolated test.');},PHP_INT_MAX);
// Admin origin is loopback; home alias exists solely for the plugin's local guard.
add_filter('rest_url',function($url){return preg_replace('~^http://ahda\.local~',WP_SITEURL,$url);});
add_filter('allowed_redirect_hosts',function($hosts){$hosts[]='127.0.0.1';return array_unique($hosts);});
add_action('admin_notices',function(){echo '<div class="notice notice-warning"><p>UJI WORDPRESS SINTETIS DI CLOUD — BUKAN DATA SEKOLAH ATAU SITUS LOCALWP PENGGUNA</p></div>';});
// Test-only removal of Core update checks: never send update metadata or emit
// blocked-network warnings. Actual plugin/user-site update behavior is untouched.
add_action('plugins_loaded',function(){
 foreach(['_maybe_update_core','_maybe_update_plugins','_maybe_update_themes'] as $callback){remove_action('admin_init',$callback);}
 remove_action('init','wp_schedule_update_checks');
},PHP_INT_MAX);
require_once ABSPATH.'wp-settings.php';

// Owned test instrumentation only: numeric counts, no SQL/URL/query/notes/secrets retained.
if(PHP_SAPI==='cli-server' && in_array(parse_url($_SERVER['REQUEST_URI']??'',PHP_URL_PATH),['/wp-admin/admin.php','/wp-admin/admin-post.php'],true)){
 $httpMetrics=['queries'=>0,'raw_reads'=>0,'discovery_writes'=>0];$httpStart=microtime(true);
 add_filter('query',function($sql)use(&$httpMetrics){$httpMetrics['queries']++;if(strpos($sql,"job_type='m2_raw_archive_pending'")!==false&&strpos($sql,'LEFT(scope_filter,')!==false){$httpMetrics['raw_reads']++;}if(preg_match('/^(INSERT|UPDATE|DELETE)\b/i',$sql)&&strpos($sql,'ahda_discovery_')!==false){$httpMetrics['discovery_writes']++;}return $sql;},PHP_INT_MAX);
 register_shutdown_function(function()use(&$httpMetrics,$httpStart,$state){$httpMetrics['elapsed_ms']=round((microtime(true)-$httpStart)*1000,2);$httpMetrics['peak_php_bytes']=memory_get_peak_usage(true);file_put_contents($state.'/http-metrics.json',json_encode($httpMetrics));file_put_contents($state.'/http-metrics-'.strtolower($_SERVER['REQUEST_METHOD']).'.json',json_encode($httpMetrics));});
}
