<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Approve one unchanged raw-backed claim locally. No publishing or independent verification. */
final class ADE_Positive_Review {
    public const TYPE = 'm3_positive_review';
    public static function enabled(): bool { return defined( 'ADE_LOCAL_POSITIVE_REVIEW_ENABLED' ) && ADE_LOCAL_POSITIVE_REVIEW_ENABLED === true; }
    private static function guard(): int {
        if ( ! ADE_Schema::is_allowed_local() || ! current_user_can( 'ade_review_candidates' ) || (int) get_current_user_id() < 1 || ! ADE_Jobs::preflight()['ready'] ) { throw new RuntimeException( 'APPROVE_LOCAL_REVIEW_GATE_BLOCKED' ); }
        return (int) get_current_user_id();
    }
    public static function nonce_action( int $id, int $version, int $attestation ): string { return 'ade_positive_review_' . $id . '_' . $version . '_' . $attestation; }
    private static function rows( string $sql, array $args = array() ): array {
        global $wpdb; $wpdb->last_error = ''; $rows = $wpdb->get_results( $args ? $wpdb->prepare( $sql, $args ) : $sql, ARRAY_A );
        if ( ! is_array( $rows ) || $wpdb->last_error ) { throw new RuntimeException( 'APPROVE_READ_FAILED' ); } return $rows;
    }
    private static function transaction( string $sql ): void {
        global $wpdb; $wpdb->last_error = '';
        if ( ! in_array( $sql, array( 'START TRANSACTION', 'COMMIT', 'ROLLBACK' ), true ) || false === $wpdb->query( $sql ) || $wpdb->last_error ) { throw new RuntimeException( 'APPROVE_TRANSACTION_FAILED' ); }
    }
    private static function insert( string $suffix, array $values ): int {
        global $wpdb; $wpdb->last_error = '';
        if ( ! in_array( $suffix, array( 'reviews', 'jobs' ), true ) || false === $wpdb->insert( ADE_Schema::table_name( $suffix ), $values ) || $wpdb->last_error || (int) $wpdb->insert_id < 1 ) { throw new RuntimeException( 'APPROVE_INSERT_FAILED' ); } return (int) $wpdb->insert_id;
    }
    private static function ids( string $npsn, int $candidate, int $evidence, int $attestation ): void {
        if ( ! ADE_Pilot_Scope::contains( $npsn ) || min( $candidate, $evidence, $attestation ) < 1 ) { throw new InvalidArgumentException( 'APPROVE_SCOPE_INVALID' ); }
    }
    private static function context( string $npsn, int $candidate, int $evidence, int $attestation, bool $lock ): array {
        self::ids( $npsn, $candidate, $evidence, $attestation );
        $a = ADE_Source_Attestation::approval_context( $attestation, $npsn, $candidate, $evidence, $lock );
        $table = ADE_Schema::table_name( 'candidates' ); $end = $lock ? ' FOR UPDATE NOWAIT' : '';
        $rows = self::rows( "SELECT id,school_id,target_key,LEFT(proposed_value,501) AS proposed_value,OCTET_LENGTH(proposed_value) AS proposed_bytes,current_value_snapshot IS NULL AS snapshot_null,SHA2(COALESCE(current_value_snapshot,''),256) AS snapshot_digest,base_target_hash,review_status,publish_status,row_version,approved_value IS NULL AS approval_null,approved_by_user_id,approved_at,published_local_at FROM {$table} WHERE id=%d AND school_id=%d AND candidate_type=%s AND target_type=%s LIMIT 2{$end}", array( $candidate, $a['school_id'], 'm2_meta_text_v1', 'school_meta' ) );
        if ( count( $rows ) !== 1 ) { throw new RuntimeException( 'APPROVE_CANDIDATE_NOT_FOUND' ); } $r = $rows[0];
        if ( ! is_string( $r['proposed_value'] ) || (int) $r['proposed_bytes'] > 500 || $r['target_key'] !== $a['target_key'] || (int) $r['row_version'] !== $a['candidate_version'] || ! in_array( $r['review_status'], array( 'new', 'deferred' ), true ) || $r['publish_status'] !== 'not_ready' || (int) $r['approval_null'] !== 1 || null !== $r['approved_by_user_id'] || null !== $r['approved_at'] || null !== $r['published_local_at'] ) { throw new RuntimeException( 'APPROVE_STATE_LOCKED' ); }
        return array( 'npsn' => $npsn, 'candidate' => $r, 'attestation' => $a );
    }
    private static function token( array $c, int $actor ): string { return ADE_Local_Archive::digest( array( 'positive-review-plan-v1', ADE_Pilot_Scope::SHA256, $actor, $c ) ); }
    public static function plan( string $npsn, int $candidate, int $evidence, int $attestation ): array {
        $actor = self::guard(); $c = self::context( $npsn, $candidate, $evidence, $attestation, false );
        return array( 'mode' => 'READ_ONLY_POSITIVE_REVIEW_PLAN', 'npsn' => $npsn, 'candidate_id' => $candidate, 'evidence_id' => $evidence, 'attestation_id' => $attestation, 'school_id' => $c['attestation']['school_id'], 'row_version' => (int) $c['candidate']['row_version'], 'target_key' => $c['candidate']['target_key'], 'proposed_value' => $c['candidate']['proposed_value'], 'before_status' => $c['candidate']['review_status'], 'after_status' => 'approved', 'publish_status' => 'not_ready', 'preview_token' => self::token( $c, $actor ), 'write_enabled' => self::enabled(), 'database_writes' => 0, 'network_requests' => 0, 'independently_verified' => false, 'snapshot_only' => true, 'publication_enabled' => false );
    }
    private static function request( array $r ): array {
        $keys = array( 'npsn', 'candidate_id', 'evidence_id', 'attestation_id', 'row_version', 'note', 'preview_token', 'nonce', 'confirm', 'backup_confirmed' );
        ADE_Local_Archive::keys( $r, $keys );
        foreach ( array( 'candidate_id', 'evidence_id', 'attestation_id', 'row_version' ) as $k ) { if ( ! is_int( $r[$k] ) || $r[$k] < 1 ) { throw new InvalidArgumentException( 'APPROVE_REQUEST_INVALID' ); } }
        foreach ( array_diff( $keys, array( 'candidate_id', 'evidence_id', 'attestation_id', 'row_version' ) ) as $k ) { if ( ! is_string( $r[$k] ) ) { throw new InvalidArgumentException( 'APPROVE_REQUEST_INVALID' ); } }
        self::ids( $r['npsn'], $r['candidate_id'], $r['evidence_id'], $r['attestation_id'] );
        if ( strlen( trim( $r['note'] ) ) < 10 || strlen( $r['note'] ) > 500 || ! preg_match( '//u', $r['note'] ) || preg_match( '/[<>\x00-\x1f\x7f\x{200B}-\x{200F}\x{202A}-\x{202E}\x{2060}-\x{206F}\x{FEFF}]/u', $r['note'] ) || ! preg_match( '/^[a-f0-9]{64}$/D', $r['preview_token'] ) || strlen( $r['nonce'] ) > 128 ) { throw new InvalidArgumentException( 'APPROVE_REQUEST_INVALID' ); }
        if ( $r['confirm'] !== 'APPROVE_ONE_CLAIM' || $r['backup_confirmed'] !== 'YES' ) { throw new RuntimeException( 'APPROVE_EXPLICIT_CONFIRMATION_REQUIRED' ); }
        if ( ! wp_verify_nonce( $r['nonce'], self::nonce_action( $r['candidate_id'], $r['row_version'], $r['attestation_id'] ) ) ) { throw new RuntimeException( 'APPROVE_NONCE_INVALID' ); }
        $ordered = array(); foreach ( $keys as $key ) { $ordered[$key] = $r[$key]; } return $ordered;
    }
    /** Receipt is historical; retry never grants permission to publish from old result. */
    private static function replay( string $op, array $request, int $actor, int $school ): ?array {
        $table = ADE_Schema::table_name( 'jobs' );
        $rows = self::rows( "SELECT id,status,LEFT(scope_filter,8193) AS scope_filter,OCTET_LENGTH(scope_filter) AS scope_bytes,LEFT(stats_payload,4097) AS stats_payload,OCTET_LENGTH(stats_payload) AS stats_bytes FROM {$table} WHERE job_key=%s AND job_type=%s LIMIT 2 FOR UPDATE NOWAIT", array( $op, self::TYPE ) );
        if ( ! $rows ) { return null; } $row = $rows[0];
        if ( count( $rows ) !== 1 || $row['status'] !== 'completed' || (int) $row['scope_bytes'] > 8192 || (int) $row['stats_bytes'] > 4096 ) { throw new RuntimeException( 'APPROVE_RECEIPT_INVALID' ); }
        $m = ADE_Strict_JSON::decode( $row['scope_filter'], 8192 ); $s = ADE_Strict_JSON::decode( $row['stats_payload'], 4096 );
        if ( ( $m['request'] ?? null ) !== $request || ( $m['actor'] ?? null ) !== $actor || ( $m['result_hash'] ?? null ) !== ADE_Local_Archive::digest( $s ) || ( $s['operation_key'] ?? null ) !== $op || ( $s['school_id'] ?? null ) !== $school || ( $s['candidate_id'] ?? null ) !== $request['candidate_id'] || ( $s['before_version'] ?? null ) !== $request['row_version'] || ( $s['after_version'] ?? null ) !== $request['row_version'] + 1 || ( $s['publication_enabled'] ?? null ) !== false || ! is_int( $s['audit_id'] ?? null ) || $s['audit_id'] < 1 || ! is_array( $m['audit'] ?? null ) ) { throw new RuntimeException( 'APPROVE_RECEIPT_INVALID' ); }
        $reviews = ADE_Schema::table_name( 'reviews' );
        $audits = self::rows( "SELECT candidate_id,school_id,review_action,before_status,after_status,candidate_version,LEFT(reviewed_value,501) AS reviewed_value,OCTET_LENGTH(reviewed_value) AS value_bytes,reason_code,LEFT(review_notes,4097) AS review_notes,OCTET_LENGTH(review_notes) AS notes_bytes,user_id,created_at FROM {$reviews} WHERE id=%d LIMIT 2 FOR UPDATE NOWAIT", array( $s['audit_id'] ) );
        // MySQL scalar integer columns arrive as strings; normalize only known numeric fields.
        if ( count( $audits ) !== 1 ) { throw new RuntimeException( 'APPROVE_RECEIPT_INVALID' ); } $audit = $audits[0];
        if ( (int) $audit['value_bytes'] > 500 || (int) $audit['notes_bytes'] > 4096 ) { throw new RuntimeException( 'APPROVE_RECEIPT_INVALID' ); } unset( $audit['value_bytes'], $audit['notes_bytes'] );
        foreach ( array( 'candidate_id', 'school_id', 'candidate_version', 'user_id' ) as $k ) { $audit[$k] = (int) $audit[$k]; }
        if ( $audit !== $m['audit'] ) { throw new RuntimeException( 'APPROVE_RECEIPT_INVALID' ); }
        return array( 'replayed' => true, 'receipt_id' => (int) $row['id'], 'result_is_historical' => true, 'must_revalidate_before_publication' => true, 'result' => $s, 'database_writes' => 0, 'publication_enabled' => false );
    }
    public static function record( array $request ): array {
        if ( ! self::enabled() ) { throw new RuntimeException( 'APPROVE_WRITES_DISABLED' ); }
        $actor = self::guard(); $r = self::request( $request ); $school = ADE_Identity::lookup_pilot( $r['npsn'] ); ADE_Pilot_Scope::assert_school( $school ); $school = (int) $school['id'];
        $stable = $r; unset( $stable['nonce'], $stable['confirm'], $stable['backup_confirmed'] );
        $op = ADE_Local_Archive::digest( array( self::TYPE, ADE_Pilot_Scope::SHA256, $actor, $school, $stable ) );
        $lock = 'ade_m2_' . substr( ADE_Local_Archive::digest( array( ADE_Schema::table_name( 'candidates' ), $school ) ), 0, 48 );
        $acquired = self::rows( 'SELECT GET_LOCK(%s,0) AS acquired', array( $lock ) );
        if ( count( $acquired ) !== 1 || (int) $acquired[0]['acquired'] !== 1 ) { throw new RuntimeException( 'APPROVE_WRITER_BUSY' ); } $transaction = false;
        try {
            self::transaction( 'START TRANSACTION' ); $transaction = true;
            $replay = self::replay( $op, $stable, $actor, $school );
            if ( $replay ) { self::transaction( 'COMMIT' ); $transaction = false; return $replay; }
            $c = self::context( $r['npsn'], $r['candidate_id'], $r['evidence_id'], $r['attestation_id'], true ); $row = $c['candidate'];
            if ( (int) $row['row_version'] !== $r['row_version'] || ! hash_equals( self::token( $c, $actor ), $r['preview_token'] ) ) { throw new RuntimeException( 'APPROVE_PLAN_STALE' ); }
            $now = current_time( 'mysql', true ); $table = ADE_Schema::table_name( 'candidates' ); global $wpdb; $wpdb->last_error = '';
            $changed = $wpdb->query( $wpdb->prepare( "UPDATE {$table} SET review_status='approved',approved_value=%s,approved_by_user_id=%d,approved_at=%s,row_version=row_version+1,updated_at=%s WHERE id=%d AND school_id=%d AND row_version=%d AND review_status=%s AND publish_status='not_ready' AND approved_value IS NULL AND approved_by_user_id IS NULL AND approved_at IS NULL AND published_local_at IS NULL", $row['proposed_value'], $actor, $now, $now, $r['candidate_id'], $school, $r['row_version'], $row['review_status'] ) );
            if ( $changed !== 1 || $wpdb->last_error ) { throw new RuntimeException( 'APPROVE_VERSION_CONFLICT' ); }
            $audit = array( 'candidate_id' => $r['candidate_id'], 'school_id' => $school, 'review_action' => 'approve', 'before_status' => $row['review_status'], 'after_status' => 'approved', 'candidate_version' => $r['row_version'], 'reviewed_value' => $row['proposed_value'], 'reason_code' => 'RAW_AND_OPERATOR_STATEMENT_CHECKED', 'review_notes' => json_encode( array( 'schema_version' => 1, 'operation_key' => $op, 'note' => $r['note'], 'attestation' => $c['attestation'], 'after_version' => $r['row_version'] + 1, 'independently_verified' => false ), JSON_THROW_ON_ERROR ), 'user_id' => $actor, 'created_at' => $now );
            $audit_id = self::insert( 'reviews', $audit );
            $result = array( 'operation_key' => $op, 'school_id' => $school, 'candidate_id' => $r['candidate_id'], 'actor_user_id' => $actor, 'before_version' => $r['row_version'], 'after_version' => $r['row_version'] + 1, 'audit_id' => $audit_id, 'after_status' => 'approved', 'publish_status' => 'not_ready', 'independently_verified' => false, 'publication_enabled' => false );
            $receipt = self::insert( 'jobs', array( 'job_key' => $op, 'job_type' => self::TYPE, 'scope_level' => 'TASIK_NEGERI_200', 'scope_filter' => json_encode( array( 'request' => $stable, 'actor' => $actor, 'audit' => $audit, 'result_hash' => ADE_Local_Archive::digest( $result ) ), JSON_THROW_ON_ERROR ), 'status' => 'completed', 'attempt_count' => 1, 'max_attempts' => 1, 'cursor_school_id' => $school, 'batch_size' => 1, 'stats_payload' => json_encode( $result, JSON_THROW_ON_ERROR ), 'created_at' => $now, 'updated_at' => $now, 'started_at' => $now, 'finished_at' => $now ) );
            self::transaction( 'COMMIT' ); $transaction = false;
            return array( 'replayed' => false, 'receipt_id' => $receipt, 'result' => $result, 'database_writes' => 3, 'network_requests' => 0, 'publication_enabled' => false );
        } catch ( Throwable $e ) { if ( $transaction ) { self::transaction( 'ROLLBACK' ); } throw $e; }
        finally { self::rows( 'SELECT RELEASE_LOCK(%s) AS released', array( $lock ) ); }
    }
}
