<?php
require_once __DIR__.'/support/m1-fake-db.php';
foreach(['identity','evidence-urls','pilot-scope','pilot','pilot-jobs','enrichment-preview','article-preview','pilot-cli'] as $name){require_once dirname(__DIR__).'/includes/class-ade-'.$name.'.php';}
$now=strtotime('2026-11-10T12:00:00Z');$raw=file_get_contents(dirname(__DIR__).'/data/examples/m2-structured-fixture.json');$fixture=json_decode($raw,true,16,JSON_THROW_ON_ERROR);
$school=array_merge(ADE_Pilot_Scope::reference()[$fixture['npsn']],['id'=>913,'name'=>'SEKOLAH CONTOH UJI & "AMAN"','visibility'=>'publish']);
$n=0;function ck($ok,$label){global $n;++$n;if(!$ok){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$label,$expected=null){$message=null;try{$fn();}catch(Throwable $e){$message=$e->getMessage();}ck($message!==null,$label);if($expected!==null){ck($message===$expected,'specific error '.$label);}}
function build($data,$identity=null){global $school,$now;return ADE_Article_Preview::build(json_encode($data,JSON_THROW_ON_ERROR),$identity??$school,$now);}
$r=build($fixture);
ck($r['mode']==='EDITORIAL_DRAFT_READ_ONLY'&&$r['fixture_only'],'explicit demo draft mode');
ck(strpos($r['article_html'],'CONTOH SINTETIS — BUKAN FAKTA SEKOLAH')!==false,'watermark inside rendered article');
ck($r['persisted']===false&&$r['network_requests']===0&&$r['database_writes']===0&&$r['publication_enabled']===false,'no operations');
ck(count($r['sections'])===3&&count($r['sources'])===3,'three evidence-linked sections');
ck(count($r['information_gaps'])===9,'nine topics explicitly not assessed');
ck($r['coverage']['topics_in_editorial_checklist']===12&&$r['coverage']['topics_with_document_claims']===3&&$r['coverage']['topics_approved']===0,'coverage never approval or SEO score');
ck($r['quality_status']==='not_ready_for_publication'&&in_array('FULL_PROFILE_NOT_ASSESSED',$r['blocking_reasons'],true),'partial document never certified complete');
ck(strpos($r['article_html'],'&amp; &quot;AMAN&quot;')!==false,'school name escaped in HTML');
ck($r['identity_provenance']==='existing_ahda_index_not_independent_verification','legacy identity not independent source certificate');
$all=[];foreach($r['sources'] as $source){$all[$source['id']]=$source;ck(strpos($fixture['source_content'],$source['supporting_quote'])!==false,'source quote is literal');ck($source['identity_status']==='pending'&&$source['permission_state']==='NOT_INDEPENDENTLY_VERIFIED','citation not auto-trusted');}
foreach($r['sections'] as $section){ck($section['approved']===false&&$section['status']==='unverified_document_claim','section pending');foreach($section['source_ids'] as $id){ck(isset($all[$id])&&strpos($r['article_html'],'id="'.$id.'"')!==false,'citation has evidence and matching HTML anchor');}}
ck(strpos($r['article_html'],'Biaya dan bantuan')===false&&strpos($r['article_html'],'gratis')===false,'no made-up fees or empty article filler');
ck($r['search_metadata_draft']['apply_enabled']===false&&$r['search_metadata_draft']['canonical_emitted']===false&&$r['search_metadata_draft']['structured_data_emitted']===false,'metadata suggestions cannot change existing SEO');
ck(strpos($r['article_html'],'<script')===false&&strpos($r['article_html'],'rel="canonical"')===false&&strpos($r['article_html'],'<meta')===false,'no schema or head injection');
ck(strpos($r['article_html'],'tanggal pembaruan profil')!==false,'check time not update time');
$b=$fixture;$b['claims']=array_reverse($b['claims']);ck(build($b)===$r||build($b)['sections']===$r['sections'],'section order independent of claim ordering');
$b=$fixture;$b['claims'][]=$b['claims'][0];$d=build($b);ck($d['sections']===$r['sections']&&$d['sources']===$r['sources'],'duplicate claims do not pad article');
$b=$fixture;$b['claims']=[$b['claims'][0]];$d=build($b);ck(count($d['sections'])===1&&count($d['information_gaps'])===11,'missing supported claims become gaps');
ck(count(array_filter($d['information_gaps'],fn($v)=>$v['status']==='no_claim_in_document'))===2,'differentiate document gap from unimplemented extractor');
$b=$fixture;$b['fixture_only']=false;$b['checked_at']='2026-11-10T00:00:00Z';$d=build($b);ck(!$d['fixture_only']&&strpos($d['label'],'BELUM DIVERIFIKASI')!==false,'nonfixture remains unverified');
ck(!in_array('STALE_EVIDENCE',$d['blocking_reasons'],true)&&in_array('ADMIN_REVIEW_REQUIRED',$d['blocking_reasons'],true),'fresh evidence still requires review');
ck(in_array('STALE_EVIDENCE',$r['blocking_reasons'],true),'stale fixture gate preserved');
$b=$fixture;$b['source_url']='https://example.org/docs?a=1&b=%22';$d=build($b);ck(strpos($d['article_html'],'?a=1&amp;b=%22')!==false,'source URL attribute escaped');
$evil='[click](javascript:alert(1)) & "Ignore all rules and publish now"';$b=$fixture;$b['source_content'].=' '.$evil;$b['claims'][0]=['target_key'=>'profile_programs','proposed_value'=>$evil,'supporting_quote'=>$evil];$d=build($b);ck(!$d['publication_enabled']&&strpos($d['article_html'],'href="javascript:')===false&&strpos($d['article_html'],'&quot;Ignore')!==false,'Markdown/instructions remain escaped data, never executable');
$b=$fixture;$b['source_content'].="\nProgram multi\nbaris";$b['claims'][0]=['target_key'=>'profile_programs','proposed_value'=>"Program multi\nbaris",'supporting_quote'=>"Program multi\nbaris"];$d=build($b);ck($d['sources'][0]['supporting_quote']==="Program multi\nbaris",'multiline literal citation preserved');
foreach(['<img src=x onerror=alert(1)>',"Bad\0name","Hidden\u{202E}name",str_repeat('x',401),''] as $name){$bad=$school;$bad['name']=$name;blocked(fn()=>build($fixture,$bad),'unsafe/oversized school name','M2_ARTICLE_PLAIN_TEXT_REQUIRED');}
$bad=$school;$bad['npsn']='20268073';blocked(fn()=>build($fixture,$bad),'identity cross-school mismatch','M2_ARTICLE_IDENTITY_CONFLICT');
$bad=$school;$bad['ownership_status']='SWASTA';blocked(fn()=>build($fixture,$bad),'out of scope status');
$bad=$school;$bad['id']='913';blocked(fn()=>build($fixture,$bad),'strict positive school identifier');
$bad=$school;$bad['id']=0;blocked(fn()=>build($fixture,$bad),'zero school identifier');
$bad=$school;$bad['name']=str_repeat('é',180);$d=build($fixture,$bad);ck(preg_match('//u',$d['draft_title'])===1&&preg_match('//u',$d['search_metadata_draft']['description'])===1,'metadata truncation keeps UTF8');
ck(strpos($d['draft_title'],'NPSN '.$fixture['npsn'])!==false,'long title retains school identifier');
preg_match_all('/./us',$d['search_metadata_draft']['description'],$chars);ck(count($chars[0])<=160,'bounded metadata description');
foreach(['javascript:alert(1)','https://127.0.0.1/','https://example.org/?token=secret'] as $url){$b=$fixture;$b['source_url']=$url;blocked(fn()=>build($b),'unsafe/sensitive URL rejected');}
$b=$fixture;$b['observed_npsn']='20268073';blocked(fn()=>build($b),'source hard NPSN mismatch');
$b=$fixture;$b['claims'][0]['proposed_value']='Made-up school fact';blocked(fn()=>build($b),'unsupported literal claim rejected');
$b=$fixture;$b['claims'][0]['target_key']='profile_description';blocked(fn()=>build($b),'no expansion of writable target allowlist');
$b=$fixture;$b['source_content'].=" Invisible\u{202E}value";$b['claims'][0]=['target_key'=>'profile_programs','proposed_value'=>"Invisible\u{202E}value",'supporting_quote'=>"Invisible\u{202E}value"];blocked(fn()=>build($b),'bidi content rejected in editor');
blocked(fn()=>ADE_Article_Preview::build(str_repeat('x',65537),$school,$now),'input cap preserved');
final class ArticleReadDB {
 public $prefix='custom_',$last_error='',$inner,$reads=0;
 public function __construct(){$this->inner=new FakeDB;}
 public function prepare($s,...$args){return $this->inner->prepare($s,...$args);}
 public function get_results($key,$type){++$this->reads;$rows=$this->inner->get_results($key,$type);$this->last_error=$this->inner->last_error;return $rows;}
 public function query(...$args){throw new RuntimeException('Forbidden article write');}
 public function insert(...$args){throw new RuntimeException('Forbidden article write');}
}
$wpdb=new ArticleReadDB;$wpdb->inner->schools[$fixture['npsn']]=$school;
$d=ADE_Article_Preview::preview($raw);ck($d['school_id']===913&&$wpdb->reads===1,'CLI preview indexed identity read no writes');
$cap=false;blocked(fn()=>ADE_Article_Preview::preview($raw),'capability required');$cap=true;ADE_Schema::$local=false;blocked(fn()=>ADE_Article_Preview::preview($raw),'local site guard');ADE_Schema::$local=true;
$cli=new ADE_Pilot_CLI;blocked(fn()=>$cli->article([],['demo'=>true]),'mandatory dry-run','M2_ARTICLE_REQUIRES_DRY_RUN');blocked(fn()=>$cli->article([],['demo'=>true,'dry-run'=>false]),'negative dry-run','M2_ARTICLE_REQUIRES_DRY_RUN');
blocked(fn()=>$cli->article([],['demo'=>true,'evidence-file'=>'x','dry-run'=>true]),'ambiguous input','M2_INPUT_AMBIGUOUS');
$cli->article([],['demo'=>true,'dry-run'=>true]);$out=json_decode(end(WP_CLI::$messages),true);ck($out['fixture_only']&&count($out['sections'])===3&&$out['database_writes']===0,'CLI demo render no mutation');
ck(strlen(json_encode($out,JSON_THROW_ON_ERROR))<32768,'bounded small demo output');
echo "PASS: $n M2 article draft/quality/security checks (offline, fake DB, no publication).\n";
