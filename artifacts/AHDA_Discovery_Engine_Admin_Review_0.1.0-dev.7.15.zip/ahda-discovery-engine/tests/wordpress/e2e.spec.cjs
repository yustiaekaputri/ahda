const {chromium}=require('playwright');
const {spawnSync}=require('node:child_process');const path=require('node:path');const fs=require('node:fs');const assert=require('node:assert/strict');
(async()=>{
 const env=process.env,base=env.AHDA_WP_E2E_URL,out=env.AHDA_WP_E2E_OUTPUT;assert(new URL(base).hostname==='127.0.0.1');
 let checks=0,external=0;const externalTargets=[];function ck(v,m){assert(v,m);checks++;}
 function control(command,...args){const php=[env.AHDA_WP_E2E_PHP,'-n'];for(const mod of ['ctype','iconv','fileinfo','dom','mysqlnd','mysqli']){php.push('-d','extension='+path.join(env.AHDA_WP_E2E_EXTENSION_DIR,mod+'.so'));}const r=spawnSync(php[0],php.slice(1).concat([env.AHDA_WP_E2E_CONTROL,command,...args.map(String)]),{env,encoding:'utf8'});assert(r.status===0,'Isolated control failed: '+r.stderr);return JSON.parse(r.stdout);}
 const browser=await chromium.launch({headless:true,executablePath:env.AHDA_UI_BROWSER_PATH||'/usr/bin/chromium'});const contexts=[];
 async function context(){const c=await browser.newContext({viewport:{width:1280,height:900}});contexts.push(c);await c.route('**/*',r=>{if(new URL(r.request().url()).origin===base){return r.continue();}external++;const u=new URL(r.request().url());externalTargets.push({origin:u.origin,path:u.pathname,type:r.request().resourceType()});return r.abort();});return c;}
 async function login(c,user,password){const p=await c.newPage();await p.goto(base+'/wp-login.php?redirect_to='+encodeURIComponent(base+'/wp-admin/admin.php?page=ahda-discovery-candidates'));await p.waitForFunction(()=>document.activeElement?.id==='user_login');await p.locator('#user_login').fill(user);await p.locator('#user_pass').fill(password);await p.locator('#wp-submit').click();try{await p.waitForURL(/\/wp-admin\//);}catch(error){const url=new URL(p.url());const loginError=await p.locator('#login_error').innerText().catch(()=>null);fs.writeFileSync(path.join(out,'login-failure.json'),JSON.stringify({user,path:url.pathname,origin:url.origin,error_text:loginError,form_diagnostics:await p.locator('#loginform').evaluate((form,expected)=>({valid:form.checkValidity(),username_matches:form.querySelector('#user_login').value===expected.user,password_matches:form.querySelector('#user_pass').value===expected.password,active_field:document.activeElement?.id,invalid_fields:Array.from(form.elements).filter(e=>e.willValidate&&!e.validity.valid).map(e=>e.id)}),{user,password}).catch(()=>null)},null,2));throw error;}return p;}
 const before=control('snapshot');ck(before.wordpress==='7.1.4'&&before.preflight,'real WP/preflight ready');ck(!before.negative_enabled,'default write gate OFF');
 try{
  const anonymous=await context();const a=await anonymous.newPage();await a.goto(base+'/wp-admin/admin.php?page=ahda-discovery-candidates');ck(a.url().includes('wp-login.php'),'Core auth redirects anonymous visitor');
  const admin=await context();const page=await login(admin,'ahda_e2e_admin',env.AHDA_WP_E2E_ADMIN_PASSWORD);
  await page.goto(base+'/wp-admin/admin.php?page=ahda-discovery-candidates&npsn=20268071');ck(await page.getByRole('link',{name:'Lihat nilai dan evidence'}).count()===3,'actual WordPress submenu/list renders3candidates');
  const ids=before.candidates.map(c=>Number(c.id));const detail=id=>base+'/wp-admin/admin.php?page=ahda-discovery-candidates&npsn=20268071&candidate='+id;
  await page.goto(detail(ids[0]));ck(await page.locator('form[method="post"]').count()===0,'default actual WP view has no write form');
  const postOff=await admin.request.post(base+'/wp-admin/admin-post.php',{form:{action:'ade_negative_review'},maxRedirects:0});ck(postOff.status()===400,'Core write hook unregistered by default');
  control('enable');await page.goto(detail(ids[0]));ck(await page.locator('form[method="post"]').count()===2,'enabled test request registers two negative forms');
  ck(await page.getByText('Review negatif manual aktif.',{exact:true}).count()===1,'actual enabled mode banner');
  async function form(decision){return page.locator('form').filter({has:page.locator('input[name="decision"][value="'+decision+'"]')}).evaluate(el=>Object.fromEntries(Array.from(el.elements).filter(e=>e.name).map(e=>[e.name,e.value])));}
  const req=await form('defer');req.note=String.raw`Synthetic O'Reilly; DROP TABLE schools; -- C:\fixture`;req.backup_confirmed='YES';req.confirm='SAVE_NEGATIVE_REVIEW';
  ck(req.nonce.length===10&&/^[a-f0-9]+$/.test(req.nonce),'real WordPress nonce generated');
  async function post(body,c=admin){return c.request.post(base+'/wp-admin/admin-post.php',{form:body,maxRedirects:0});}
  let res=await post(req,anonymous);ck(res.status()===400&&control('snapshot').audit_count===0,'real anonymous POST has no handler or audit');
  res=await post({...req,nonce:'bad'});ck(res.status()===403,'real invalid nonce blocked');
  res=await post({...req,backup_confirmed:'NO'});ck(res.status()===403,'real backup acknowledgment required');
  res=await post({...req,decision:'reject',reason:'WRONG_INFORMATION'});ck(res.status()===403,'real nonce is decision scoped');
  res=await post({...req,decision:'approve'});ck(res.status()===403,'real approve path unavailable');
  let state=control('snapshot');ck(state.audit_count===0&&state.receipt_count===0,'invalid real POSTs have no review mutations');
  const editor=await context();const editorPage=await login(editor,'ahda_e2e_editor',env.AHDA_WP_E2E_EDITOR_PASSWORD);
  const denied=await editorPage.goto(detail(ids[0]));ck(denied.status()===403,'real editor capability denies panel');
  res=await post(req,editor);ck(res.status()===403&&control('snapshot').audit_count===0,'editor cannot reuse admin nonce/decision');
  const secondAdmin=await context();await login(secondAdmin,'ahda_e2e_admin',env.AHDA_WP_E2E_ADMIN_PASSWORD);res=await post(req,secondAdmin);ck(res.status()===403&&control('snapshot').audit_count===0,'real nonce bound to original login session');
  res=await post({...req,redirect_to:'https://untrusted.example/'});ck(res.status()===302,'real controller successful safe redirect');ck(new URL(res.headers().location).origin===base&&res.headers().location.includes('page=ahda-discovery-candidates'),'safe redirect ignores untrusted referer and preserves inspector target');
  state=control('snapshot');ck(state.audit_count===1&&state.receipt_count===1&&state.candidates[0].review_status==='deferred','real wpdb persists exact decision/audit/receipt');ck(state.last_note===req.note,'real wp_magic_quotes/unslash preserves apostrophe');
  res=await post(req);ck(res.status()===302&&control('snapshot').audit_count===1,'real HTTP replay no duplicate audit');
  await page.goto(detail(ids[0]));ck(await page.getByText(req.note,{exact:true}).count()===1,'real audit history displays stored note');
  const reject=await form('reject');reject.reason='WRONG_INFORMATION';reject.note='Synthetic rejected after review';reject.backup_confirmed='YES';reject.confirm='SAVE_NEGATIVE_REVIEW';res=await post(reject);ck(res.status()===302,'real deferred to rejected');
  state=control('snapshot');ck(state.audit_count===2&&state.candidates[0].review_status==='rejected','real rejected state/audit');
  await page.goto(detail(ids[0]));ck(await page.locator('form[method="post"]').count()===0,'terminal rejection has no further negative forms');
  await page.goto(detail(ids[1]));const stale=await form('defer');stale.backup_confirmed='YES';stale.confirm='SAVE_NEGATIVE_REVIEW';stale.note='Synthetic stale form';control('bump',ids[1]);res=await post(stale);ck(res.status()===409&&control('snapshot').audit_count===2,'real stale version returns409 and no audit');
  const cross=await page.goto(base+'/wp-admin/admin.php?page=ahda-discovery-candidates&npsn=20268073&candidate='+ids[2]);ck((await page.locator('body').innerText()).includes('M3_CANDIDATE_NOT_FOUND'),'real cross-school IDOR blocked');
  control('poison',ids[2]);await page.goto(detail(ids[2]));ck(await page.locator('img[src*="untrusted.example"]').count()===0,'real WP escapes untrusted image markup');ck(await page.evaluate(()=>typeof window.__AHDA_XSS==='undefined'),'real WP stored proposal/quote script nonexecution');control('restore');
  await page.goto(detail(ids[2]));await page.screenshot({path:path.join(out,'wordpress-admin-desktop.png'),fullPage:true});
  await page.setViewportSize({width:390,height:844});await page.screenshot({path:path.join(out,'wordpress-admin-mobile.png'),fullPage:true});
  ck(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+3),'real WordPress mobile no document overflow');
  state=control('snapshot');ck(JSON.stringify(before.hashes)===JSON.stringify(state.hashes),'real AHDA legacy/source/evidence/link row hashes unchanged');
  ck(state.candidates.every(c=>c.approved_value===null&&c.publish_status==='not_ready'),'real approved/publication fields untouched');
  ck(Object.keys(before.legacy_hashes).length>=25,'actual Directory full legacy schema created only in synthetic DB');ck(JSON.stringify(before.legacy_hashes)===JSON.stringify(state.legacy_hashes),'all synthetic AHDA legacy table row hashes unchanged');
  control('disable');await page.goto(detail(ids[2]));ck(await page.locator('form[method="post"]').count()===0,'actual write switch OFF restores read-only forms');res=await post(req);ck(res.status()===400&&control('snapshot').audit_count===2,'OFF disables handler even for old valid replay');fs.writeFileSync(path.join(out,'blocked-browser-targets.json'),JSON.stringify(externalTargets,null,2));ck(external===0,'no external browser request attempted');
  const bridge=control('bridge_pipeline');ck(bridge.status==='PASS'&&bridge.database_adapter==='wpdb','bridge service integration uses actual WordPress/wpdb');
  await page.setViewportSize({width:1280,height:900});await page.goto(detail(bridge.visible_candidate_id));
  ck((await page.locator('body').innerText()).includes('Referensi arsip raw #'),'actual WordPress admin displays archive provenance');
  ck((await page.locator('body').innerText()).includes('belum diperiksa ulang pada halaman ini'),'actual WordPress shows raw revalidation limit');
  ck(await page.locator('form[method="post"]').count()===0,'service test opt-ins do not enable HTTP mutation forms');
  await page.screenshot({path:path.join(out,'wordpress-archive-desktop.png'),fullPage:true});
  await page.setViewportSize({width:390,height:844});await page.screenshot({path:path.join(out,'wordpress-archive-mobile.png'),fullPage:true});
  ck(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+3),'actual WordPress archive hashes wrap on mobile');
  const afterBridge=control('snapshot');ck(JSON.stringify(before.legacy_hashes)===JSON.stringify(afterBridge.legacy_hashes),'all actual Directory synthetic legacy tables preserved after raw bridge');
  ck(afterBridge.candidates.every(c=>c.publish_status==='not_ready'&&(Number(c.id)===Number(bridge.approved_candidate_id)?c.review_status==='approved'&&c.approved_value!==null:c.approved_value===null)),'only explicit synthetic candidate approved; every proposal unpublished');
  ck(external===0,'bridge view performs no external browser request');
  // Actual authenticated two-stage web approval, isolated synthetic records only.
  let fixture=control('positive_fixture');const posBefore=control('snapshot');const metrics=[];
  const offPositive=await post({action:'ade_positive_preview'});ck(offPositive.status()===400,'positive web hooks default OFF');
  control('positive_enable');await page.goto(detail(fixture.candidate_id));
  ck(await page.locator('#ade-positive-select').count()===1,'positive enabled selection form');
  let m=control('http_metrics','GET');metrics.push({case:'detail_get',...m});ck(m.raw_reads===0&&m.discovery_writes===0,'enabled GET never reads raw payload or writes');
  async function selectFields(){return page.locator('#ade-positive-select').evaluate(el=>Object.fromEntries(Array.from(el.elements).filter(e=>e.name).map(e=>[e.name,e.value])));}
  let select=await selectFields();select.attestation_id=String(fixture.attestation_id);select.evidence_id=String(fixture.evidence_id);
  res=await post({...select,nonce:'bad'});ck(res.status()===403,'positive preview submitted nonce required');m=control('http_metrics','POST');metrics.push({case:'invalid_preview_nonce',...m});ck(m.queries<15,'invalid nonce avoids expensive schema preflight');ck(m.raw_reads===0&&m.discovery_writes===0,'invalid nonce rejected before raw access');
  res=await post(select,editor);ck(res.status()===403,'positive preview editor denied');res=await post(select,secondAdmin);ck(res.status()===403,'positive preview nonce session bound');res=await post(select,anonymous);ck(res.status()===400,'positive preview anonymous no handler');
  res=await admin.request.get(base+'/wp-admin/admin-post.php?action=ade_positive_preview');ck(res.status()===405,'positive preview requires POST');
  res=await post({...select,extra:'unexpected'});ck(res.status()===403,'positive preview rejects unknown fields');
  res=await admin.request.post(base+'/wp-admin/admin-post.php',{form:{...select,'candidate_id[]':'1'},maxRedirects:0});ck(res.status()===403,'positive preview rejects array input');
  res=await post({...select,attestation_id:String(bridge.raw_receipt_id)});ck(res.status()===403,'positive preview rejects wrong job type as declaration');
  async function previewPositive(){await page.goto(detail(fixture.candidate_id));await page.locator('#ade-positive-grant').fill(String(fixture.attestation_id));await page.locator('#ade-positive-evidence').selectOption(String(fixture.evidence_id));const [nav]=await Promise.all([page.waitForNavigation(),page.getByRole('button',{name:'Periksa kelayakan persetujuan'}).click()]);ck(nav.status()===200&&await page.locator('#ade-positive-confirm').count()===1,'real browser preview renders separate confirmation');}
  await previewPositive();m=control('http_metrics','POST');metrics.push({case:'explicit_preview',...m});ck(m.raw_reads===1&&m.discovery_writes===0,'explicit preview loads raw once with zero Discovery writes');
  ck(control('snapshot').audit_count===posBefore.audit_count,'preview does not save approval');ck((await page.locator('body').innerText()).includes("O'Reilly & reference metadata"),'declaration text escaped and preserved');
  ck(await page.locator('a[href*="example.org"]').count()===0,'declaration reference not fetched or auto-linked');ck(await page.evaluate(()=>typeof window.__AHDA_XSS==='undefined'),'confirmation untrusted text does not execute');
  await page.screenshot({path:path.join(out,'wordpress-approval-desktop.png'),fullPage:true});await page.setViewportSize({width:390,height:844});await page.screenshot({path:path.join(out,'wordpress-approval-mobile.png'),fullPage:true});ck(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+3),'approval confirmation fits mobile');
  async function confirmFields(){return page.locator('#ade-positive-confirm').evaluate(el=>Object.fromEntries(Array.from(el.elements).filter(e=>e.name).map(e=>[e.name,e.value])));}
  let confirm=await confirmFields();confirm.note=String.raw`Synthetic O'Reilly; DROP TABLE schools; -- C:\fixture`;confirm.confirm='APPROVE_ONE_CLAIM';confirm.backup_confirmed='YES';
  res=await post({...confirm,nonce:'bad'});ck(res.status()===403,'positive apply invalid nonce rejected');res=await post({...confirm,backup_confirmed:'NO'});ck(res.status()===403,'positive apply backup required');res=await post({...confirm,confirm:'WRONG'});ck(res.status()===403,'positive apply explicit one claim consent');res=await post({...confirm,note:'<script>alert(1)</script>'});ck(res.status()===403,'positive apply HTML note rejected');res=await post(confirm,editor);ck(res.status()===403,'positive apply editor capability denied');res=await post(confirm,secondAdmin);ck(res.status()===403,'positive apply nonce login-session bound');res=await post({...confirm,candidate_id:String(fixture.candidate_id+100000)});ck(res.status()===403,'positive apply candidate-scoped nonce');
  control('bump',fixture.candidate_id);res=await post(confirm);ck(res.status()===409&&control('snapshot').audit_count===posBefore.audit_count,'positive stale HTTP form cannot approve');
  await previewPositive();confirm=await confirmFields();confirm.note='Synthetic withdrawal test';confirm.confirm='APPROVE_ONE_CLAIM';confirm.backup_confirmed='YES';control('positive_withdraw',fixture.attestation_id);res=await post(confirm);ck(res.status()===409&&control('snapshot').audit_count===posBefore.audit_count,'positive HTTP apply rechecks withdrawal after preview');
  fixture=control('positive_fixture');await previewPositive();confirm=await confirmFields();confirm.note=String.raw`Synthetic O'Reilly; DROP TABLE schools; -- C:\fixture`;confirm.confirm='APPROVE_ONE_CLAIM';confirm.backup_confirmed='YES';
  await page.locator('#ade-positive-note').fill(confirm.note);await page.locator('input[name="backup_confirmed"]').check();await page.locator('input[name="confirm"]').check();await Promise.all([page.waitForURL(/\/wp-admin\/admin.php/),page.getByRole('button',{name:'Setujui satu klaim tanpa menerbitkan'}).click()]);
  ck(new URL(page.url()).origin===base&&page.url().includes('candidate='+fixture.candidate_id),'positive browser submit safe local redirect');
  m=control('http_metrics','POST');metrics.push({case:'explicit_approval',...m});ck(m.raw_reads===1&&m.discovery_writes===3,'positive apply one raw read and exactly three atomic writes');
  state=control('snapshot');const approvedUI=state.candidates.find(c=>Number(c.id)===fixture.candidate_id);ck(state.audit_count===posBefore.audit_count+1&&state.positive_receipt_count===posBefore.positive_receipt_count+1&&approvedUI.review_status==='approved'&&approvedUI.approved_value===approvedUI.proposed_value&&approvedUI.publish_status==='not_ready','positive HTTP persisted unchanged approved claim and audit, unpublished');
  ck(await page.getByText(confirm.note,{exact:true}).count()===1,'positive history renders literal SQL-like apostrophe/backslash note');ck(await page.locator('#ade-positive-select').count()===0,'approved candidate has no overwrite form');
  res=await post(confirm);ck(res.status()===302&&control('snapshot').audit_count===state.audit_count,'positive HTTP exact replay no duplicate audit');m=control('http_metrics','POST');metrics.push({case:'historical_retry',...m});ck(m.raw_reads===0&&m.discovery_writes===0,'historical retry avoids raw reparsing and writes');
  const finalState=control('snapshot');ck(JSON.stringify(before.legacy_hashes)===JSON.stringify(finalState.legacy_hashes),'positive HTTP preserves all25 legacy tables');ck(finalState.candidates.every(c=>c.publish_status==='not_ready'),'positive web flow never publishes');
  control('positive_disable');await page.goto(detail(fixture.candidate_id));res=await post(confirm);ck(res.status()===400&&await page.locator('#ade-positive-select').count()===0,'positive OFF disables old valid POSTs and forms');ck(external===0,'positive confirmation makes no external browser requests');
  fs.writeFileSync(path.join(out,'wordpress-approval-performance.json'),JSON.stringify({scope:'Owned synthetic HTTP counts after WordPress bootstrap; not production/VPS benchmark',requests:metrics},null,2));

  fs.writeFileSync(path.join(out,'wordpress-browser-result.json'),JSON.stringify({status:'PASS',checks,external_requests:external,legacy_tables_checked:Object.keys(before.legacy_hashes).length,wordpress:'7.1.4',scope:'Real WordPress login/cookies/roles/nonces/wpdb/admin-post routing and both actual plugins; owned synthetic MySQL and custom test wp-load bootstrap/home alias. No wp-config file or user LocalWP.'},null,2));
  console.log('PASS: '+checks+' real WordPress7.1.4 integration checks (owned synthetic site; custom test bootstrap).');
 }finally{await browser.close();}
})().catch(e=>{console.error(e.message);process.exitCode=1;});
