<?php
/** R3 pure URL/identity checks; run php tests/r3-pure-tests.php. */
if ( PHP_SAPI !== 'cli' ) { exit( 2 ); }
define( 'ABSPATH', __DIR__ . '/' );
require_once dirname(__DIR__) . '/includes/class-ade-source-urls.php';
require_once dirname(__DIR__) . '/includes/class-ade-identity.php';
$n = 0;
$ok = function( $condition, $label ) use ( &$n ) {
    ++$n;
    if ( !$condition ) { fwrite( STDERR, 'FAIL ' . $label . "\n" ); exit( 1 ); }
};
$valid = array(
    array( 'HTTPS://WWW.SMA1.SCH.ID/', 'https://www.sma1.sch.id/', 'website', '' ),
    array( 'https://www.instagram.com/osis_sekolah/?utm_medium=test', 'https://instagram.com/osis_sekolah', 'social_profile', 'instagram' ),
    array( 'https://www.tiktok.com/@contoh.school', 'https://tiktok.com/@contoh.school', 'social_profile', 'tiktok' ),
    array( 'https://www.youtube.com/@contoh-school', 'https://youtube.com/@contoh-school', 'social_profile', 'youtube' ),
    array( 'https://www.youtube.com/channel/UC98765432123456789', 'https://youtube.com/channel/UC98765432123456789', 'social_profile', 'youtube' ),
    array( 'https://www.facebook.com/school.contoh', 'https://facebook.com/school.contoh', 'social_profile', 'facebook' ),
    array( 'https://school.sch.id/peta?id=12&utm_source=abc&lang=id#about', 'https://school.sch.id/peta?id=12&lang=id', 'website', '' ),
    array( 'https://www.facebook.com/profile.php?id=123&utm_source=other', 'https://facebook.com/profile.php?id=123', 'social_profile', 'facebook' ),
    array( 'http://school.sch.id:80/x/', 'http://school.sch.id/x', 'website', '' ),
);
foreach( $valid as $row ) {
    $v = ADE_Source_URLs::canonicalize( $row[0] );
    $ok( $v['canonical_url'] === $row[1], 'URL normalized: ' . $row[0] );
    $ok( $v['source_type'] === $row[2] && $v['platform'] === $row[3], 'URL classified: ' . $row[0] );
    $ok( strlen( $v['canonical_key'] ) === 64, 'SHA256 key: ' . $row[0] );
}
$invalid = array(
    '', 'http://localhost/', 'http://127.0.0.1/', 'http://10.0.0.1/',
    'https://[::1]/', 'http://192.168.1.8/', 'http://0x7f.0.0.1/',
    'https://admin:pass@school.sch.id/', 'http://school.sch.id:8080/',
    'http://local.school.local/', 'http://example.test/', 'http://a.example/',
    'file:///etc/passwd', 'ftp://school.sch.id/',
    'https://instagram.com/reel/abc', 'https://instagram.com/p/abc',
    'https://youtube.com/watch?v=123', 'https://www.facebook.com/profile.php', 'https://tiktok.com/@someone/video/123',
    'https://school.sch.id/a/../admin', "https://school.sch.id/%0d%0aInjected",
);
foreach( $invalid as $url ) {
    $rejected=false;
    try { ADE_Source_URLs::canonicalize( $url ); }
    catch( InvalidArgumentException $e ) { $rejected=true; }
    $ok( $rejected, 'Reject unsafe/non-profile URL: ' . $url );
}
$ok( ADE_Source_URLs::canonicalize( 'https://school.sch.id?utm_source=abc' )['canonical_url'] === 'https://school.sch.id/', 'tracking-only URL canonical' );
$ok( ADE_Source_URLs::canonicalize( 'https://instagram.com/osis_sekolah' )['canonical_key'] === ADE_Source_URLs::canonicalize( 'https://www.instagram.com/osis_sekolah/?hl=en' )['canonical_key'], 'social host and language dedupe' );
$ok( ADE_Source_URLs::canonicalize( 'https://school.sch.id/path' )['canonical_key'] === ADE_Source_URLs::canonicalize( 'https://school.sch.id/path?fbclid=abc' )['canonical_key'], 'stable dedupe' );
$ok( ADE_Identity::validate_npsn( ' 12345678 ' ) === '12345678', 'NPSN 8 digits' );
$ok( ADE_Identity::compare_name( 'SMA Negeri 01 Bandung', 'sma NEGERI 01 - bandung' ) === 'exact_normalized', 'name exact-normalized' );
$ok( ADE_Identity::compare_name( 'SMA Negeri Bandung', 'SMA Swasta Bandung' ) === 'mismatch_manual_review', 'name mismatch' );
$ok( ADE_Identity::compare_name( 'SMA Negeri Bandung', '' ) === 'not_supplied', 'name absent' );
foreach( array( '1234567', '123456789', 'A2345678', '1234 678', '' ) as $invalid_npsn ) {
    $rejected=false; try { ADE_Identity::validate_npsn( $invalid_npsn ); } catch( InvalidArgumentException $e ) { $rejected=true; }
    $ok( $rejected, 'invalid NPSN' );
}
echo 'PASS: ' . $n . " pure R3 checks; no network/DB/WordPress.\n";
