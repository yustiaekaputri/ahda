<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Bounded explicit adapter. No hooks, scheduling, recursive crawl or persistence. */
final class ADE_Crawler {
    private $last_attempt = array();
    private $requests = 0;
    private $resolver;

    /** Resolver injection is for offline tests; URL/IP policy still always applies. */
    public function __construct( ?callable $resolver = null ) {
        $this->resolver = $resolver ?: static function ( string $host ): array {
            $records = dns_get_record( $host, DNS_A | DNS_AAAA );
            $ips = array();
            foreach ( is_array( $records ) ? $records : array() as $r ) {
                if ( isset( $r['ip'] ) ) { $ips[] = $r['ip']; }
                if ( isset( $r['ipv6'] ) ) { $ips[] = $r['ipv6']; }
            }
            return $ips;
        };
    }

    /** Validate permission before DNS. Permission is URL-specific, never host-wide. */
    public static function permission( string $url, array $permit, int $now ): string {
        if ( ( $permit['robots_allowed'] ?? false ) !== true || ( $permit['terms_allowed'] ?? false ) !== true ||
            ! is_int( $permit['expires_at'] ?? null ) || $permit['expires_at'] <= $now || $permit['expires_at'] > $now + 86400 ||
            ! is_string( $permit['review_reference'] ?? null ) || ! preg_match( '/^[a-zA-Z0-9_-]{3,80}$/D', $permit['review_reference'] ) ||
            ! is_array( $permit['hosts'] ?? null ) || ! is_string( $permit['url'] ?? null ) ) {
            throw new InvalidArgumentException( 'PERMISSION_REQUIRED' );
        }
        $canonical = ADE_Crawl_Policy::url( $url, $permit['hosts'] );
        if ( $canonical !== ADE_Crawl_Policy::url( $permit['url'], $permit['hosts'] ) ) { throw new InvalidArgumentException( 'URL_PERMISSION_MISMATCH' ); }
        return $canonical;
    }

    /** Actual networking is reachable only by a confirmed LocalWP CLI operator. */
    public function fetch( string $url, array $permit, string $confirmation = '' ): array {
        if ( ! defined( 'WP_CLI' ) || ! WP_CLI || ! class_exists( 'WP_CLI' ) ||
            ! ADE_Schema::is_allowed_local() || ! current_user_can( 'ade_manage_jobs' ) ||
            $confirmation !== 'FETCH_M1_LOCAL' || ! ADE_Config::operational_feature_enabled( 'ade_enable_source_discovery' ) ) { throw new RuntimeException( 'OPERATOR_APPROVAL_REQUIRED' ); }
        $url = self::permission( $url, $permit, time() );
        if ( ! function_exists( 'curl_init' ) ) { throw new RuntimeException( 'CURL_UNAVAILABLE' ); }
        // A generic proxy can resolve the host again and defeat local IP pinning.
        // Fail closed until a separately tested, pin-aware proxy adapter exists.
        foreach ( array( 'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'http_proxy', 'https_proxy', 'all_proxy' ) as $name ) {
            if ( getenv( $name ) ) { throw new RuntimeException( 'PROXY_TRANSPORT_UNSUPPORTED' ); }
        }
        $host = (string) parse_url( $url, PHP_URL_HOST );
        if ( $this->requests >= 20 ) { throw new RuntimeException( 'REQUEST_BUDGET_EXHAUSTED' ); }
        if ( isset( $this->last_attempt[$host] ) && microtime( true ) - $this->last_attempt[$host] < ADE_Crawl_Policy::HOST_INTERVAL_SECONDS ) {
            throw new RuntimeException( 'HOST_THROTTLED_RETRY_LATER' );
        }
        $this->last_attempt[$host] = microtime( true );
        ++$this->requests;
        $ips = ADE_Crawl_Policy::addresses( call_user_func( $this->resolver, $host ) );
        // Resolve once; cURL connects ONLY to the validated address, retaining TLS SNI.
        $pin = strpos( $ips[0], ':' ) !== false ? '[' . $ips[0] . ']' : $ips[0];
        $body = ''; $header_bytes = 0; $too_large = false;
        $ch = curl_init( $url );
        if ( false === $ch ) { throw new RuntimeException( 'CURL_INIT_FAILED' ); }
        try {
            curl_setopt_array( $ch, array(
                CURLOPT_PROXY => '', CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
                CURLOPT_FOLLOWLOCATION => false, CURLOPT_MAXREDIRS => 0,
                CURLOPT_RESOLVE => array( $host . ':443:' . $pin ),
                CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => ADE_Crawl_Policy::TIMEOUT_SECONDS,
                CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_USERAGENT => 'AHDA-Discovery/0.1 M1 operator-approved local research',
                CURLOPT_HTTPHEADER => array( 'Accept: text/html, application/json, text/csv', 'Accept-Encoding: identity' ),
                CURLOPT_WRITEFUNCTION => static function ( $handle, $chunk ) use ( &$body, &$too_large ): int {
                    if ( strlen( $body ) + strlen( $chunk ) > ADE_Crawl_Policy::MAX_BYTES ) { $too_large = true; return 0; }
                    $body .= $chunk; return strlen( $chunk );
                },
                CURLOPT_HEADERFUNCTION => static function ( $handle, $line ) use ( &$header_bytes ): int {
                    $header_bytes += strlen( $line ); return $header_bytes > 16384 ? 0 : strlen( $line );
                },
            ) );
            $ok = curl_exec( $ch );
            if ( $too_large ) { throw new RuntimeException( 'RESPONSE_TOO_LARGE' ); }
            if ( false === $ok ) { throw new RuntimeException( 'FETCH_FAILED_' . curl_errno( $ch ) ); }
            $response = ADE_Crawl_Policy::response( (int) curl_getinfo( $ch, CURLINFO_HTTP_CODE ), (string) curl_getinfo( $ch, CURLINFO_CONTENT_TYPE ), $body );
            $response['url'] = $url;
            $response['checked_at'] = gmdate( 'c' );
            $response['permission_reference'] = $permit['review_reference'];
            return $response;
        } finally { curl_close( $ch ); }
    }
}
