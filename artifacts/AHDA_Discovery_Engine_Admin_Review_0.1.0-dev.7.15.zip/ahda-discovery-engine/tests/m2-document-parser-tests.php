<?php
require_once __DIR__.'/support/m1-fake-db.php';
foreach(['identity','evidence-urls','pilot-scope','pilot','pilot-jobs','enrichment-preview','document-parser','pilot-cli'] as $name){require_once dirname(__DIR__).'/includes/class-ade-'.$name.'.php';}
$now=strtotime('2026-11-10T12:00:00Z');$root=dirname(__DIR__);$csv=file_get_contents($root.'/data/examples/m2-profile-fixture.csv');$html=file_get_contents($root.'/data/examples/m2-profile-fixture.html');
$meta=['fixture_only'=>true,'source_url'=>'https://example.org/ahda-fixture-only','checked_at'=>'2020-01-01T00:00:00Z','permission_reference'=>'fixture-only-not-a-permission'];
$n=0;function ck($ok,$label){global $n;++$n;if(!$ok){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$label,$expected=null){$message=null;try{$fn();}catch(Throwable $e){$message=$e->getMessage();}ck($message!==null,$label);if($expected!==null){ck($message===$expected,'specific error '.$label.' actual='.($message??'none'));}}
function parse_doc($raw,$format='csv',$m=null,$code='20268071'){global $meta,$now;return ADE_Document_Parser::parse($raw,$format,$code,$m??$meta,$now);}
$r=parse_doc($csv);ck(count($r['preview']['candidates'])===3&&$r['extracted_rows']===3,'CSV produces three literal claims');
ck($r['network_requests']===0&&$r['database_writes']===0&&$r['publication_enabled']===false,'parse has no operations');
ck($r['raw_document_sha256']===hash('sha256',$csv),'raw document provenance digest');
ck($r['preview']['fixture_only']===true&&in_array('FIXTURE_NOT_SCHOOL_FACTS',$r['preview']['blocking_reasons'],true),'fixture never promoted');
foreach($r['preview']['evidence'] as $e){ck(strpos($r['structured_document']['source_content'],$e['supporting_quote'])!==false&&strpos($e['supporting_quote'],$e['observed_value'])!==false,'normalized literal CSV evidence');}
$b=parse_doc("\xef\xbb\xbf".str_replace("\n","\r\n",$csv));ck($b['structured_document']===$r['structured_document']&&$b['raw_document_sha256']!==$r['raw_document_sha256'],'BOM/CRLF preserve normalized content not raw hash');
$b=parse_doc(rtrim($csv,"\n"));ck($b['structured_document']===$r['structured_document'],'CSV final newline optional');
$b=parse_doc("npsn,target_key,value\n20268071,profile_programs,\"Program A, \"\"B\"\"\nC\"\n");ck($b['preview']['candidates'][0]['proposed_value']==="Program A, \"B\"\nC",'quoted comma/escaped quote/multiline RFC record');
foreach(["npsn,target_key,value\n20268071,profile_hours,\"unclosed", "npsn,target_key,value\n20268071,profile_hours,A\"B", "npsn,target_key,value\n20268071,profile_hours,\"A\" trailing"] as $raw){blocked(fn()=>parse_doc($raw),'malformed CSV quotes','M2_CSV_QUOTING_INVALID');}
foreach([str_replace('npsn,target_key,value','npsn,value,target_key',$csv),str_replace('npsn,target_key,value','npsn,target_key,target_key',$csv),str_replace(',',';',$csv)] as $raw){blocked(fn()=>parse_doc($raw),'header/semicolon contract');}
foreach(['=HYPERLINK("https://bad.example")','+1+1','-1+1','@SUM(1)',"\t=1+1"] as $formula){$raw="npsn,target_key,value\n20268071,profile_hours,\"".str_replace('"','""',$formula)."\"\n";blocked(fn()=>parse_doc($raw),'formula field','M2_CSV_FORMULA_BLOCKED');}
blocked(fn()=>parse_doc(str_replace('20268071,profile_hours','20268073,profile_hours',$csv)),'cross-school CSV','M2_HARD_NPSN_MISMATCH');
blocked(fn()=>parse_doc($csv,'csv',null,'12345678'),'outside frozen scope');
blocked(fn()=>parse_doc(str_replace('profile_hours','profile_school_verified',$csv)),'protected target','M2_TARGET_BLOCKED');
blocked(fn()=>parse_doc($csv."20268071,profile_hours,Conflicting hours\n"),'conflicting values','M2_CONFLICTING_CLAIMS');
$b=parse_doc($csv."20268071,profile_hours,JAM CONTOH UJI\n");ck(count($b['preview']['candidates'])===3,'identical duplicates never multiply candidates');
blocked(fn()=>parse_doc("npsn,target_key,value\n".str_repeat("20268071,profile_hours,Test\n",21)),'CSV rows limit','M2_DOCUMENT_CLAIM_LIMIT');
foreach(["npsn,target_key,value\n20268071,profile_hours,\n","npsn,target_key,value\n20268071,profile_hours,<script>bad</script>\n","npsn,target_key,value\n20268071,profile_hours,Hidden\u{202E}value\n",str_repeat('x',65537),"bad\0text","bad\xfftext"] as $raw){blocked(fn()=>parse_doc($raw),'malformed/unsafe/oversized CSV');}
foreach(['source_url'=>'https://127.0.0.1/','checked_at'=>'2099-01-01T00:00:00Z','fixture_only'=>'true','permission_reference'=>''] as $key=>$value){$m=$meta;$m[$key]=$value;blocked(fn()=>parse_doc($csv,'csv',$m),'metadata '.$key);}
$m=$meta;$m['approved']=true;blocked(fn()=>parse_doc($csv,'csv',$m),'unrecognized metadata','M2_DOCUMENT_METADATA_INVALID');
blocked(fn()=>parse_doc($csv,'pdf'),'unsupported format','M2_DOCUMENT_FORMAT_UNSUPPORTED');
$htmlChecks=false;
if(class_exists('DOMDocument')){
 $externalLoads=0;$oldLoader=libxml_get_external_entity_loader();libxml_set_external_entity_loader(function()use(&$externalLoads){++$externalLoads;throw new RuntimeException('Unexpected external resource resolution');});
 $htmlChecks=true;$h=parse_doc($html,'html');ck(count($h['preview']['candidates'])===3&&$h['extracted_rows']===3,'HTML table extraction');
 ck($h['raw_document_sha256']===hash('sha256',$html)&&$h['normalization']==='html-table-text-v1','HTML raw provenance and normalized-text disclosure');
 foreach($h['preview']['evidence'] as $e){ck(strpos($h['structured_document']['source_content'],$e['supporting_quote'])!==false,'HTML quote literal in normalized text');}
 $decorated=str_replace('PROGRAM CONTOH UJI','Program <strong>A &amp; B</strong><br>bersama',$html);$h=parse_doc($decorated,'html');ck($h['preview']['candidates'][2]['proposed_value']==='Program A & B bersama','DOM decoding/inline markup/BR text');
 $evil='<script>throw new Error("run"); NPSN: 20268073</script><style>.x{display:none} NPSN: 20268073</style><iframe src="http://127.0.0.1/"></iframe><img src="http://169.254.169.254/">';
 $h=parse_doc(str_replace('<table>',$evil.'<table>',$html),'html');ck(count($h['preview']['candidates'])===3&&$h['network_requests']===0,'script/style/iframe/assets not executed or fetched');
 foreach(['hidden','aria-hidden="true"','style="display: none"','style="visibility: hidden"'] as $attribute){$noise='<div '.$attribute.'>NPSN: 20268073</div>';$h=parse_doc(str_replace('<table>',$noise.'<table>',$html),'html');ck(count($h['preview']['candidates'])===3,'explicit hidden content ignored '.$attribute);}
 $hiddenRow='<tr hidden><th>Program pendidikan</th><td>Wrong hidden program</td></tr>';$h=parse_doc(str_replace('</tbody>',$hiddenRow.'</tbody>',$html),'html');ck(count($h['preview']['candidates'])===3,'hidden table row excluded');
 foreach(['<!DOCTYPE html SYSTEM "file:///etc/passwd">','<!DOCTYPE html [<!ENTITY xxe SYSTEM "https://example.org/leak">]>','<!ENTITY bomb "repeat">','<?xml version="1.0"?>'] as $prefix){blocked(fn()=>parse_doc($prefix.$html,'html'),'DTD/XXE/XML declaration','M2_HTML_EXTERNAL_DECLARATION_BLOCKED');}
 blocked(fn()=>parse_doc(str_replace('20268071','20268073',$html),'html'),'HTML source identity mismatch','M2_HARD_NPSN_MISMATCH');
 blocked(fn()=>parse_doc(str_replace('</body>','<p>NPSN: 20268073</p></body>',$html),'html'),'other visible school identity','M2_HARD_NPSN_MISMATCH');
 blocked(fn()=>parse_doc($html.$html,'html'),'multiple profile tables','M2_HTML_PROFILE_AMBIGUOUS');
 blocked(fn()=>parse_doc(str_replace('<table>','<table><tr><td><table></table></td></tr>',$html),'html'),'nested table','M2_HTML_NESTED_TABLE_BLOCKED');
 blocked(fn()=>parse_doc(str_replace('<th>NPSN</th>','<th colspan="2">NPSN</th>',$html),'html'),'merged cells','M2_HTML_COLUMNS_AMBIGUOUS');
 blocked(fn()=>parse_doc(str_replace('<td>20268071</td>','<td>20268071</td><td>extra</td>',$html),'html'),'three identity columns','M2_HTML_COLUMNS_AMBIGUOUS');
 blocked(fn()=>parse_doc(str_replace('</tbody>','<tr><th>NPSN</th><td>20268071</td></tr></tbody>',$html),'html'),'duplicate identity','M2_HTML_IDENTITY_AMBIGUOUS');
 blocked(fn()=>parse_doc(str_replace('<th>NPSN</th>','<th>unmapped identity</th>',$html),'html'),'NPSN must be in same table','M2_HTML_PROFILE_TABLE_REQUIRED');
 $h=parse_doc(str_replace('</tbody>','<tr><th>Fasilitas</th><td>KLAIM BELUM DIDUKUNG</td></tr></tbody>',$html),'html');ck($h['ignored_unmapped_rows']===1&&strpos($h['structured_document']['source_content'],'KLAIM BELUM DIDUKUNG')===false,'unsupported/private rows not included');
 blocked(fn()=>parse_doc(str_repeat('<div>',40).$html.str_repeat('</div>',40),'html'),'depth budget','M2_HTML_DEPTH_LIMIT');
 blocked(fn()=>parse_doc(str_repeat('<b></b>',10001).$html,'html'),'node budget','M2_HTML_NODE_LIMIT');
 blocked(fn()=>parse_doc(str_repeat('<table></table>',21).$html,'html'),'table budget','M2_HTML_TABLE_LIMIT');
 blocked(fn()=>parse_doc(str_repeat('x',262145),'html'),'HTML byte budget','M2_DOCUMENT_TOO_LARGE');
 blocked(fn()=>parse_doc(str_replace('</tbody>',str_repeat('<tr><th>Unknown</th><td>Unknown</td></tr>',65).'</tbody>',$html),'html'),'row limit','M2_HTML_ROW_LIMIT');
 blocked(fn()=>parse_doc(str_replace('</tbody>',str_repeat('<tr><th>Program pendidikan</th><td>A</td></tr>',21).'</tbody>',$html),'html'),'claim limit','M2_DOCUMENT_CLAIM_LIMIT');
 blocked(fn()=>parse_doc(str_replace('</tbody>','<tr><th>Program pendidikan</th><td>Different program</td></tr></tbody>',$html),'html'),'conflicting HTML claims','M2_CONFLICTING_CLAIMS');
 ck($externalLoads===0,'no external entity/network/file resolution attempted');libxml_set_external_entity_loader($oldLoader);
}else{blocked(fn()=>parse_doc($html,'html'),'missing DOM fails closed','M2_HTML_DOM_EXTENSION_REQUIRED');}
final class ParserDB {
 public $prefix='custom_',$last_error='',$inner;
 public function __construct(){global $meta;$this->inner=new FakeDB;$ref=ADE_Pilot_Scope::reference()['20268071'];$this->inner->schools['20268071']=array_merge($ref,['id'=>913,'name'=>'Synthetic parser test','visibility'=>'publish']);}
 public function prepare($s,...$args){return $this->inner->prepare($s,...$args);}
 public function get_results($key,$type){[$sql,$args]=$this->inner->prepared[$key];if(strpos($sql,'FROM custom_ahda_school_meta ')!==false){return [];}$v=$this->inner->get_results($key,$type);$this->last_error=$this->inner->last_error;return $v;}
 public function query(...$args){throw new RuntimeException('Parser write forbidden');}
 public function insert(...$args){throw new RuntimeException('Parser write forbidden');}
}
$wpdb=new ParserDB;$cli=new ADE_Pilot_CLI;
blocked(fn()=>$cli->parse([],['format'=>'csv','demo'=>true]),'missing dry-run','M2_PARSE_REQUIRES_DRY_RUN');
blocked(fn()=>$cli->parse([],['format'=>'csv','demo'=>true,'dry-run'=>false]),'negative dry-run','M2_PARSE_REQUIRES_DRY_RUN');
blocked(fn()=>$cli->parse([],['format'=>'csv','demo'=>true,'source-url'=>'https://example.org/','dry-run'=>true]),'demo metadata mixing','M2_INPUT_AMBIGUOUS');
foreach($htmlChecks?['csv','html']:['csv'] as $format){$cli->parse([],['format'=>$format,'demo'=>true,'dry-run'=>true]);$o=json_decode(end(WP_CLI::$messages),true);ck($o['preview']['school_id']===913&&count($o['preview']['candidates'])===3&&$o['database_writes']===0,'CLI parser indexed read '.$format);}
$cap=false;blocked(fn()=>ADE_Document_Parser::preview($csv,'csv','20268071',$meta),'capability');$cap=true;ADE_Schema::$local=false;blocked(fn()=>ADE_Document_Parser::preview($csv,'csv','20268071',$meta),'LocalWP guard');ADE_Schema::$local=true;
$wpdb->inner->schools['20268071']['ownership_status']='SWASTA';blocked(fn()=>ADE_Document_Parser::preview($csv,'csv','20268071',$meta),'changed real classification');
echo "PASS: $n M2 local document parser checks (".($htmlChecks?'actual DOM + strict CSV':'strict CSV; HTML extraction NOT RUN without DOM').", fake DB; no HTTP/writes).\n";
