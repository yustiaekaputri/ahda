=== AHDA Discovery Engine ===
Contributors: ahda-project
Tags: school-directory, verification, workflow
Requires PHP: 7.4
Stable tag: 0.1.0-dev.7.14
License: GPLv2 or later

== OPERATOR SOURCE DECLARATION dev.7.13 ==
Adds defaultOFF attest_stage/record/status and revoke_stage/revoke commands for
one raw-bound claim. Records operator identity/permission/privacy declarations,
references, limited reuse scope and expiry; append-only withdrawal, no independent
verification or approval/source badge promotion. One Discovery jobs row per event.
Shared mutex, NOWAIT/current reads, short transaction, replay and rollback. Actual
2-session RR race regression included. See docs/SOURCE_ATTESTATION.md.
26offline suites1588DOM/1520noDOM eachPHP8.2/8.4,88PHP lint,118actualWP service checks
+47admin/browser,25synthetic legacy tables preserved, own resources removed.

== EXPLICIT RAW BINDING CHECK dev.7.12 ==
Adds pilot archive_verify: one linked archive evidence rechecked against raw bytes,
quote/value/NPSN/hash/source and current candidate snapshot. Read-only, bounded,
capability/local/preflight and explicitCLI dry-run. No page-load raw reparse or
web endpoint. Binding match never approves facts or attests identity/permission.
25offline suites1545checks PHP8.2/8.4 DOM;1477noDOM (HTML not run),85PHP lint.
96realWordPress service checks +47browser/admin on synthetic DB;25legacy tables
preserved, all ownresources removed. Initial login timeout retained, two fresh
subsequent runs PASS. See docs/RAW_BINDING_CHECK.md for semantics and limitations.

== REAL WORDPRESS ARCHIVE BRIDGE VALIDATION dev.7.11 ==
Adds actual WordPress7.1.4/Directory0.8.9/wpdb integration for raw->candidate
services and admin inspector.83service checks plus47browser/admin checks with
owned synthetic MySQL8.4;25legacy synthetic table hashes preserved. Direct service
API with a CLI class-presence marker, NOT an official WP-CLI runner test. Runtime
unchanged except version; writes remainOFF and no real source facts acquired.
See docs/WORDPRESS_ARCHIVE_BRIDGE.md and MVP_ACCEPTANCE.md for scope/remaining gates.

== RAW RECEIPT TO PENDING CANDIDATES dev.7.10 ==
Adds default-OFF archive_stage/archive_store/archive_receipt. Reparse stored raw,
recheck current identity/snapshot/source bindings and atomically store pending
claims/evidence/links with raw receipt/document hashes. Existing manual pending
candidates reused; reviewed candidates/evidence links frozen, no approval/profile
write. Explicit localCLI/capability/backup/confirm/token required; no real write
permitted in user site yet. Inspector displays raw references with explicit notice
that raw binding has NOT been revalidated on that page. See ARCHIVE_CANDIDATES.md.
24offline suites1504checks PHP8.2/8.4 DOM;1436withoutDOM (HTML not run).
282nativeMySQL checks with WP/wpdb stubs;26Chromium PHPview fixture checks.
ActualWordPress/userLocalWP bridge integration NOT TESTED. Sources/production untouched.

== RAW-PENDING ARCHIVE VAULT dev.7.9 ==
Adds explicit local raw-only archival storage in one Discovery jobs row, default
OFF. Fixture/stale/unbound/conflicting inputs blocked; fresh stage token, backup,
privacy acknowledgement and explicit consent required. Atomic insert, shared M2
mutex, NOWAIT source/receipt locks, idempotent replay and integrity-only receipt.
No evidence/candidate/profile write, approval/publisher or source fetch added.
See docs/RAW_ARCHIVE_VAULT.md; do not enable writes on user site yet.
User's7.8 inspect demo confirmed native read-only output; not a source/write test.
23offline suites1416checks each PHP8.2/8.4 DOM;1348withoutDOM (HTML not run).
195nativeMySQL8.4 checks under WP/wpdb stubs; own container removed.

== ARCHIVE REVIEW / MULTISOURCE ARTICLE dev.7.8 ==
Adds pilot inspect: reparse one school's raw archive, compare existing verified
profile values, inspect explicit registered source bindings, and generate an
escaped editorial draft with all raw-document citations and information gaps.
Read-only, localCLI/capability/dry-run guarded. No new source registration, storage,
approval or publication. Pending source matches never attest permission/identity.
Plan checksums cannot authorize store. See docs/ARCHIVE_REVIEW.md.
22offline suites1371checks each PHP8.2/8.4 DOM;1304withoutDOM (HTML not run).
164native MySQL8.4 checks with WP/wpdb adapter stubs; own disposable containers
removed. Full WordPress/user LocalWP integration of new command NOT TESTED.

== LOCAL ARCHIVE PREVIEW WORKER dev.7.7 ==
Adds bounded inline CSV/HTML/JSON archive contract, raw/metadata hashes, multi-source
conflict blocking and portable preview checkpoints for the frozen200 pilot.
CLI pilot archive/work require explicit dry-run and local operator capabilities.
Max10schools/call, checkpoint resume and bounded failed-school retry; no fetch,
file save, database mutation, approval or publication. Checkpoint is operator
controlled and is NOT a commit/approval receipt. Demo remains synthetic/stale.
See docs/LOCAL_ARCHIVE_WORKER.md, including Windows resume commands and limits.
21offline suites1230checks each PHP8.2/8.4 DOM;1166withoutDOM (HTML not run).
New worker has NOT been validated in user's LocalWP or against real source facts.

== REAL WORDPRESS INTEGRATION dev.7.6 ==
Adds reproducible actual WordPress7.1.4/PHP8.2/MySQL8.4 admin integration harness
with Directory0.8.9, actual wpdb/roles/cookies/nonces/admin-post and synthetic data.
No stubs for tested WordPress auth/database functions; custom isolated bootstrap,
home/REST alias and denied mail/network are documented. Tests never touch user
LocalWP, production or wp-config. Runtime review stays OFF; no new content fields.
Read docs/WORDPRESS_INTEGRATION.md and QA results for precise scope/limits.

== M3 NEGATIVE REVIEW FOUNDATION dev.7.5 ==
Adds guarded reject/defer engine, atomic append-only audit/operation receipt,
nonce, actor/version-bound plan, shared M2 lock and idempotent replay.
Default OFF: no write handler/forms registered without separate explicit opt-in.
Default inspector gains read-only paginated negative audit history.
No approve/edit/publish/reopen; no changes to profiles/evidence/source authority.
Read docs/M3_NEGATIVE_REVIEW.md; don't enable real LocalWP writes yet.

== M3 READ-ONLY CANDIDATE INSPECTOR dev.7.4 ==
Adds admin submenu AHDA Discovery > Kandidat (baca-saja), per-school M2 listing,
current/snapshot/proposed comparison, evidence/source states and conflict warning.
Bounded keyset pagination, LocalWP/capability guard, prepared reads and escaped UI.
No decisions, approval, mutation endpoints, publication or source requests.
Demo CLI output is not stored; empty candidate list expected. Don't store demos.
See docs/M3_INSPECTOR.md. Full WordPress/LocalWP admin rendering not yet verified.

== M2 LOCAL DOCUMENT PARSERS dev.7.3 ==
Adds pilot parse --format=csv|html --demo --dry-run and bounded operator files.
Strict CSV contract and one unambiguous same-school HTML profile table supported;
no network, writes or factual verification. Quotes reference normalized records,
raw SHA-256 retained in preview. DOM optional for HTML; CSV works without DOM.
Read docs/M2_DOCUMENT_PARSER.md for format, provenance and unsupported layouts.
No new schema, cron, source authority, full profile or publication claims.

== M2 EDITORIAL ARTICLE PREVIEW dev.7.2 ==
Adds wp ade pilot article --demo --dry-run and --evidence-file previews.
Three literal supported topics, linked quotes, safe escaped HTML, twelve-topic
editorial checklist and explicit unassessed gaps. No fabricated facts, approval,
DB write, network request, metadata application or frontend SEO hooks.
Native pending-store SQL tested on disposable MySQL8.4.13 under WordPress/wpdb
adapter stubs with explicit operator permission; not full LocalWP integration.
Read docs/M2_ARTICLE.md, CONTENT_QUALITY.md and NATIVE_MYSQL.md for limits.

== WP-CLI DRY-RUN HOTFIX dev.7.1.1 ==
Fix invalid mandatory boolean synopsis in extract/stage using [--dry-run].
Handlers still require explicit true; no writes or network added.
Adds 50 official WP-CLI v2.12.0 parser/dispatcher regression checks under
WordPress/fake DB stubs. This is not a full LocalWP/MySQL integration test.
Test-only upstream MIT sources/provenance: tests/vendor/wp-cli-2.12.0/.

== M2 MANUAL PENDING STORE dev.7.1 ==
Adds stage (read-only), store (explicit LocalWP confirmation + backup + token)
and receipt (read-only history). Writes only pending Discovery evidence,
candidates, evidence links and operation receipts; no profile/source/review
changes. Existing reviewed candidates are untouched. Pending evidence changes
advance row_version. Fixture/stale/unregistered/blocked source input is refused.
No schema migration, automatic writes, network fetch, approval or publication.
Real MySQL/LocalWP writes NOT TESTED. Read docs/M2_STORE.md before any use.
Actual writes require separate operator approval. Default automatic flags stay OFF.

== M2 STRUCTURED PREVIEW dev.7.0 ==
Adds `wp ade pilot extract --demo --dry-run`: synthetic structured evidence and
candidate preview only. Three supported profile meta targets, scope/quote/schema
checks, deterministic keys and SELECT-only current snapshots. No M2 persistence,
approval or publication. All claims remain unverified/not_ready. Demo is NOT
school facts. Read docs/M2_PREVIEW.md. Existing M1 and R4a commands retained.

== CLI naming hotfix dev.6.2.1 ==
Explicit hyphen aliases are registered for source-preview, run-one-batch,
integrity-check and retry-failed. Original underscore spellings remain valid.
In installed dev.6.2 use `wp ade pilot source_preview` (underscore).
This fixes registration/docs only; no database, schema or crawler changes.

== M1 DEVELOPMENT — NOT FOR PRODUCTION ==
This development increment is based on the original R4a source below.
Adds frozen Tasikmalaya state-school scope (SMP/MTS priority), full read-only
pilot preflight and resumable source-planning jobs. Build 0.1.0-dev.6.2.1;
manifest JSON v2, database schema remains version 1. Adds source-preview for
verified legacy URL hints; SELECT only, no source registration or fetch.
The real crawler adapter remains hard-disabled by ADE_Config, has no CLI fetch
command, and is tested only using fake DNS/cURL. No extraction, review dashboard,
or publisher is implemented by M1. See docs/M1_LOCALWP.md and docs/M1_QA.md.
Do not replace the parent Directory plugin, reinstall schema, enable cron, or
upload this build to ahda.sch.id. Original R4a behavior/documentation follows.

R4a / v2.6 manual evidence foundation built on R3 v2.5.1; preserves R3 source/relationship, R2 queue and R1 schema. LocalWP ahda.local only.

== Description ==
R4a keeps all R1/R2/R3 commands and adds manual evidence entry on existing school-source associations. No HTTP requests, DNS lookup, auto-discovery crawler, public review, publication, or production sync. R4a does not promote source identity; new evidence does not establish ownership.

== Installation ==
1. Create/verify a current LocalWP backup.
2. WordPress Admin > Plugins > Add New > Upload Plugin.
3. Upload AHDA_Discovery_Engine_R4a_v2_6_0_LocalWP.zip; replace the installed copy, and keep it active.
4. Open AHDA Discovery > Status in the WordPress admin.
5. Confirm all API checks pass and safe flags show their expected values.
6. Run `wp ade schema postflight` in LocalWP Site Shell; DO NOT run schema install on an already installed site.

== Activation behavior ==
- Saves only options starting ade_ and custom capabilities for Administrator.
- Ensures operational flags are disabled; dry-run enabled.
- Does not write to any AHDA school table or create discovery tables.
- Does not depend on the parent plugin being present to activate; missing APIs show an admin warning.

== Deactivation / uninstall ==
- Deactivation resets safe flags and removes the ADE capabilities granted to Administrator.
- No tables or school records are dropped, and plugin options are preserved.
- uninstall.php intentionally performs no data deletion.

== Notes ==
R1 schema installation is separate from activation. Run `wp ade schema install --backup-confirmed=YES --confirm=INSTALL_R1` only after verifying a restorable LocalWP backup and successful preflight. Never run on production VPS.

== R2 Manual commands ==
wp ade jobs preflight
wp ade jobs status
wp ade jobs seed --test-key=smoke-a --confirm=SEED_R2_TEST
wp ade jobs step --confirm=STEP_R2_TEST
wp ade jobs inspect <id>

All R2 mutations touch only the new ahda_discovery_jobs table, except a short-lived WordPress option for the worker mutex; no crawler or real discovery tasks are enabled.

== R3 Manual-only source commands ==
wp ade sources preflight
wp ade sources selftest
wp ade sources check --source-url=https://sekolah.sch.id/
wp ade sources school --npsn=12345678
wp ade sources preview --npsn=12345678 --source-url=https://sekolah.sch.id/
wp ade sources observe --npsn=12345678 --source-url=https://sekolah.sch.id/ --confirm=STORE_R3_PENDING
wp ade sources list --npsn=12345678

Observe is explicitly operator-triggered. It uses two existing discovery tables only and does not certify ownership or truthfulness of the URL. The sample NPSN and hostname above are placeholders; use actual values that exist in the local database.

== R3 CLI hotfix v2.5.1 ==
`--url` merupakan parameter global WP-CLI (site URL). Untuk sumber website atau akun, SELALU gunakan `--source-url`. Hotfix ini hanya memperbaiki interface CLI, tanpa schema migration, auto crawling, atau publication.


== R4a Evidence Foundation (manual-only) ==
R4a extends the verified R3 v2.5.1 source foundation without schema migration.
New WP-CLI group: `wp ade evidence preview`, `wp ade evidence record`, `wp ade evidence list`.
Evidence is unverified manually entered observation attached to an already-associated school/source.
Never auto-verifies identity, changes relationship, publishes, schedules, or accesses URLs.
Writes only to ahda_discovery_evidence on explicit --confirm=STORE_R4_EVIDENCE.

== Positive review dev.7.14 ==
Local CLI/service approval of one unchanged raw-backed claim with current operator declaration; default OFF, capability/nonce/token/backup/explicit confirmation, atomic candidate+audit+receipt. Approved remains not_ready and unpublished; no legacy changes. No positive web form yet. See docs/POSITIVE_REVIEW.md.
