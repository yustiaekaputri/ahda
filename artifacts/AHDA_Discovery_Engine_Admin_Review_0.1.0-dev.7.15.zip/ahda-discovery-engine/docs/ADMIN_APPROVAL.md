# Admin positive approval — dev.7.15

Two explicit authenticated POST steps for one unedited raw-backed claim. Uses
existing ADE_LOCAL_POSITIVE_REVIEW_ENABLED gate, undefined/OFF by default. If an
operator previously enabled that service flag, the web handlers are now enabled
as well; no mutation occurs without their new submitted nonce/confirmation. No
new option, role, table, schema migration, cron, external fetch or publisher.

## Operator flow when valid records and scoped permission exist

1. AHDA Discovery > Kandidat, choose school and candidate. Usual GET uses bounded
   inspector/history queries only. It does not reparse or load raw payloads.
2. Select one archive-backed evidence from the loaded page (max20), enter the
   already recorded matching source-declaration ID. Manual evidence alone does
   not show an eligible selection form. No JSON search across all jobs/schools.
3. Press "Periksa kelayakan persetujuan". Authenticated POST checks local/reviewer/
   preflight, exact bounded scalar fields, positive IDs, session-bound preview
   nonce BEFORE raw reads. Calls existing positive plan once, which rechecks raw,
   source, grant, revocation, expiry, current target hash and mutable candidate.
4. Separate confirmation page displays NPSN, candidate/evidence/grant IDs, field,
   current verified value, original snapshot, proposed value, version, declaration
   actor/expiry/identity/permission references and notes. These are escaped text,
   never executable markup. References are not fetched, authenticated or auto-
   linked. Metadata retrieval validates scope without reparsing raw a second time.
5. Enter10..500-byte plain review note, acknowledge backup and explicitly consent
   to one claim without publication. Submitted service nonce is bound to candidate,
   version and grant, actor/login session; preview token actor and currentcontext.
6. POST to ade_positive_review delegates to existing locked transactional service:
   fresh grant/revoke/raw/source/target/version checks, CAS candidate, append audit
   and jobs receipt, commit or rollback. Never sets publish_status ready/published.
7. Safe redirect to fixed local candidate inspector, ignoring external destinations.
   Approved claim shows stored value and bounded historical positive-review audit
   (reviewer, timestamp, before/after versions, declaration ID and escaped note).
   History is not current permission. Approved candidate offers no overwrite form.

Default OFF: neither positive handler is registered, no positive selection/confirm
form exists. No nopriv route. GET against enabled POST endpoint returns405. Invalid
nonce/capability/input returns403, stale/revoked/conflict409, uncertain transaction/
read failure503 with instruction to inspect status/audit before retry. Fixed code
allowlist pattern prevents SQL/error detail leakage. All responses from the two
controllers use no-cache headers. No user wp-config changes are part of delivery.

There is still no web source-attestation creation form, editing or bulk approval.
Existing CLI declaration IDs must be recorded with real identity/rights checks
before this flow can operate; do not store demo data to fill empty screens.
UI metadata APIs and history cannot authorize publishing. Postapproval withdrawal
retains historical approval but makes grant invalid; future publisher must fresh-
lock/recheck everything. History read API scopes candidate+school via join,
LIMIT21/keyset20, notes4KiB cap, schema/versions/typed grant validation.

## Performance scope

Test-only HTTP instrumentation records numeric counts after WordPress bootstrap,
not query text, notes, request URLs or credentials. Expected and asserted:

| Request | Raw receipt reads | Discovery DML |
| --- | --- | --- |
| Enabled candidate GET | 0 | 0 |
| Invalid preview nonce | 0 | 0 |
| Explicit preview | 1 | 0 |
| Explicit approval | 1 | 3 |
| Exact historical retry | 0 | 0 |

This avoids raw reparsing on normal browsing or a second parse merely to show
operator declaration metadata. Raw verification is deliberately repeated on apply
to prevent stale authorization. No cross-request authorization cache, background
crawler, global scan, bulk parsing or browser runtime dependency is introduced.
Repeated schema preflight still contributes many bounded metadata queries; their
counts/timings are retained honestly, not claimed optimized. Future worker batch
preflight reuse must preserve fresh flags, lease/fencing and transactional checks.
No production/VPS concurrency benchmark or site-wide speedup has been measured.

Delivery ZIP includes only current QA directory. Historical evidence is retained
in workspace and Git history/backups, omitted from installation to reduce package
and installed disk footprint. All runtime, tests/vendor fixtures and baseline
contracts remain available. On WordPress use Upload Plugin > Replace current;
WinSCP overlay may leave older QA files, so footprint reduction is not guaranteed
for a merge upload. Do not manually delete user data. Rollback via local7.14 backup
without deleting Discovery tables/review/declaration history.

## Validation

See docs/qa/dev7.15: PHP8.2+8.4 lint and offline regression, actual WordPress7.1.4 /
Directory0.8.9 / MySQL8.4 synthetic integration, authenticated Chromium preview and
checkbox-confirm submit, session-bound nonces, editor/anonymous/method/input/IDOR,
stale version, withdrawn grant, XSS-safe display/note, replay, safe redirect, mobile
screenshots and numeric raw-read/write assertions. Existing positive transaction
fault/race tests and old negative review still run. Owned resources removed.

Not user LocalWP, full official CLI runner, real source/permission verification,
VPS load, publisher or factual200-profile enrichment. No SEO/ranking guarantees.
