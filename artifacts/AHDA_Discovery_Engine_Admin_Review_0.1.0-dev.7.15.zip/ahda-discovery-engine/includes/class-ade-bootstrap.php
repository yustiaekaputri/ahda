<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Bootstrap and controlled lifecycle only. No auto-schema, cron, HTTP or legacy writes. */
final class ADE_Bootstrap {
    public static function activate( $network_wide = false ): void {
        if ( $network_wide && is_multisite() ) {
            wp_die( 'AHDA Discovery R0 belum mendukung aktivasi jaringan multisite. Aktifkan hanya pada satu situs.', 'Aktivasi tidak diizinkan', array( 'back_link' => true ) );
        }
        ADE_Config::reset_safe_defaults();
        ADE_Capabilities::grant_admin();
        if ( ! add_option( 'ade_r0_version', ADE_R0_VERSION, '', false ) ) {
            update_option( 'ade_r0_version', ADE_R0_VERSION, false );
        }
    }

    public static function deactivate(): void {
        ADE_Config::reset_safe_defaults();
        ADE_Capabilities::revoke_admin();
        // Deliberately preserve all options, and never drop discovery/legacy tables.
    }

    public static function init(): void {
        // Register explicit CLI commands (no schema work is performed here).
        if ( defined( 'WP_CLI' ) && WP_CLI && class_exists( 'WP_CLI' ) ) {
            require_once ADE_R0_PATH . 'includes/class-ade-schema-cli.php';
            WP_CLI::add_command( 'ade schema', 'ADE_Schema_CLI' );
            require_once ADE_R0_PATH . 'includes/class-ade-jobs-cli.php';
            WP_CLI::add_command( 'ade jobs', 'ADE_Jobs_CLI' );
            require_once ADE_R0_PATH . 'includes/class-ade-sources-cli.php';
            WP_CLI::add_command( 'ade sources', 'ADE_Sources_CLI' );
            require_once ADE_R0_PATH . 'includes/class-ade-evidence-cli.php';
            WP_CLI::add_command( 'ade evidence', 'ADE_Evidence_CLI' );
            require_once ADE_R0_PATH . 'includes/class-ade-pilot-cli.php';
            WP_CLI::add_command( 'ade pilot', 'ADE_Pilot_CLI' );
            // WP-CLI retains underscores in reflected method names. Register the
            // documented hyphen spellings explicitly, preserving existing names.
            $pilot = new ADE_Pilot_CLI();
            foreach ( array( 'source-preview' => 'source_preview', 'run-one-batch' => 'run_one_batch',
                'integrity-check' => 'integrity_check', 'retry-failed' => 'retry_failed' ) as $alias => $method ) {
                WP_CLI::add_command( 'ade pilot ' . $alias, array( $pilot, $method ) );
            }
        }
        // No frontend work, no automatic jobs, no cron, no network activity in R4a.
        if ( ! is_admin() ) { return; }
        require_once ADE_R0_PATH . 'admin/class-ade-admin-status.php';
        require_once ADE_R0_PATH . 'admin/class-ade-admin-review.php';
        ADE_Admin_Review::register();
        require_once ADE_R0_PATH . 'admin/class-ade-admin-approval.php';
        ADE_Admin_Approval::register();
        ADE_Admin_Status::register();
    }
}
