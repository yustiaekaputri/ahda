<?php
require_once __DIR__.'/support/m1-fake-db.php';
foreach(['identity','source-urls','evidence-urls','pilot-scope','pilot','pilot-jobs','enrichment-preview','document-parser','local-archive','local-worker','article-preview','archive-review','archive-vault','archive-candidates','enrichment-store'] as $name){require_once dirname(__DIR__).'/includes/class-ade-'.$name.'.php';}
require_once __DIR__.'/support/m2-store-db.php';
final class ArchiveDB {
 public $prefix='custom_',$last_error='',$insert_id=0,$db,$relations=[],$lock_changed=false;
 public function __construct(){$this->db=new StoreDB;$this->db->inner->schools['20268071']=array_merge(ADE_Pilot_Scope::reference()['20268071'],['id'=>913,'name'=>'Synthetic archive candidate test','visibility'=>'publish']);foreach(['https://example.org/'=>7,'https://example.net/'=>9] as $url=>$id){$key=ADE_Source_URLs::canonicalize($url)['canonical_key'];$this->relations[$key]=['source_id'=>$id,'relation_id'=>$id+1,'source_type'=>'website','access_state'=>'manual_only','source_status'=>'discovered','identity_status'=>'pending','relationship_type'=>'pending'];}}
 public function prepare($sql,...$args){return $this->db->prepare($sql,...$args);}
 public function get_results($key,$kind){$this->db->last_error='';[$sql,$args]=$this->db->inner->prepared[$key]??[$key,[]];
  if(strpos($sql,'FROM custom_ahda_discovery_sources ')!==false){$key=strpos($sql,'s.id=%d')!==false?$args[3]:$args[1];$row=$this->relations[$key]??null;if($row&&$this->lock_changed&&strpos($sql,'FOR UPDATE')!==false){$row['access_state']='blocked';}return $row?[$row]:[];}
  $rows=$this->db->get_results($key,$kind);$this->last_error=$this->db->last_error;return $rows;
 }
 public function query($sql){$this->db->last_error='';$r=$this->db->query($sql);$this->last_error=$this->db->last_error;return $r;}
 public function insert($table,$values){$this->db->last_error='';$r=$this->db->insert($table,$values);$this->last_error=$this->db->last_error;$this->insert_id=$this->db->insert_id;return $r;}
}
$n=0;function ck($ok,$label){global $n;++$n;if(!$ok){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$label,$expected=null){try{$fn();}catch(Throwable $e){ck($expected===null||$expected===$e->getMessage(),$label.' actual='.$e->getMessage());return;}ck(false,$label.' accepted');}
function enc($v){return json_encode($v,JSON_THROW_ON_ERROR);}
$a=ADE_Local_Archive::freeze(ADE_Local_Archive::demo())['bundle'];$a['fixture_only']=false;$a['documents']=[];foreach($a['schools'] as &$s){$s['document_keys']=[];}unset($s);
$csv=file_get_contents(dirname(__DIR__).'/data/examples/m2-profile-fixture.csv');$bindings=[];
foreach(['https://example.org/','https://example.net/'] as $i=>$url){$d=ADE_Local_Archive::document($i?str_replace("\n","\r\n",$csv):$csv,'csv',$url.'synthetic-school',gmdate('Y-m-d\TH:i:s\Z',time()-60),'synthetic-permission-test');$a['documents'][$d['key']]=$d['entry'];$bindings[$d['key']]=$url;foreach($a['schools'] as &$s){if($s['npsn']==='20268071'){$s['document_keys'][]=$d['key'];}}unset($s);}
$raw=enc($a);define('ADE_LOCAL_ARCHIVE_STORAGE_ENABLED',true);
function fresh(){global $wpdb,$raw,$bindings;$wpdb=new ArchiveDB;$p=ADE_Archive_Vault::stage($raw,'20268071',$bindings);return ADE_Archive_Vault::record($raw,'20268071',$bindings,$p['preview_token'],'STORE_RAW_PENDING','YES','YES')['receipt_id'];}
function stage($id){return ADE_Archive_Candidates::stage($id,'20268071');}
function store($id,$token){return ADE_Archive_Candidates::record($id,'20268071',$token,'STORE_ARCHIVE_CANDIDATES','YES');}
$id=fresh();$rawBefore=$wpdb->db->tables['jobs'];ck(!ADE_Archive_Candidates::enabled(),'candidate bridge default OFF');blocked(fn()=>store($id,str_repeat('0',64)),'default fail closed','AC_STORAGE_DISABLED');
$p=stage($id);ck(count($p['candidates'])===3&&$p['estimated_rows_created_including_receipt']===16&&$p['database_writes']===0,'fresh stage3candidates6evidence6links1receipt');ck($wpdb->db->tables['jobs']===$rawBefore,'stage no raw mutation');
blocked(fn()=>ADE_Archive_Candidates::stage($id,'20268073'),'same-school raw binding','VAULT_SCHOOL_BINDING_CONFLICT');
define('ADE_LOCAL_ARCHIVE_CANDIDATES_ENABLED',true);
blocked(fn()=>ADE_Archive_Candidates::record($id,'20268071',$p['preview_token'],'WRONG','YES'),'confirmation','AC_EXPLICIT_WRITE_APPROVAL_REQUIRED');blocked(fn()=>ADE_Archive_Candidates::record($id,'20268071',$p['preview_token'],'STORE_ARCHIVE_CANDIDATES','NO'),'backup','AC_EXPLICIT_WRITE_APPROVAL_REQUIRED');
$done=store($id,$p['preview_token']);ck($done['result']['rows_created']===16&&array_map('count',$wpdb->db->tables)===['evidence'=>6,'candidates'=>3,'candidate_evidence'=>6,'jobs'=>2],'atomic complete bridge');
$sourceIDs=[];foreach($wpdb->db->tables['evidence'] as $e){$o=json_decode($e['observed_value'],true);ck($o['raw_receipt_id']===$id&&$o['raw_payload_sha256']===ADE_Archive_Vault::receipt($id)['summary']['raw_payload_sha256']&&isset($a['documents'][$o['document_key']])&&$o['raw_document_sha256']===$a['documents'][$o['document_key']]['raw_sha256'],'evidence retains actual raw proof');$sourceIDs[$e['source_id']]=true;ck($e['parse_status']==='m2_archive_unverified','archive evidence pending');}ck(array_keys($sourceIDs)===[7,9]||array_keys($sourceIDs)===[9,7],'two distinct source IDs preserved');
foreach($wpdb->db->tables['candidates'] as $c){ck($c['review_status']==='new'&&$c['publish_status']==='not_ready'&&$c['approved_value']===null&&$c['overall_score']===0,'no confidence or approval promotion');}
ck($wpdb->db->tables['jobs'][$id]===$rawBefore[$id],'raw receipt immutable');ck(store($id,$p['preview_token'])['replayed']&&count($wpdb->db->tables['jobs'])===2,'exact retry no duplicate');
ck(ADE_Archive_Candidates::receipt($done['receipt_id'])['historical'],'operation receipt historical');
$test_actor=2;blocked(fn()=>store($id,$p['preview_token']),'different actor cannot reuse receipt token','AC_RECEIPT_INVALID');$test_actor=1;
for($position=1;$position<=16;$position++){$id=fresh();$p=stage($id);$before=$wpdb->db->tables;$wpdb->db->fail_insert_at=$wpdb->db->writes+$position;blocked(fn()=>store($id,$p['preview_token']),'failure insert '.$position,'AC_INSERT_FAILED');ck($wpdb->db->tables===$before&&!$wpdb->db->held,'all rollback and unlock '.$position);}
$id=fresh();$p=stage($id);$wpdb->db->commit_ack_lost=true;blocked(fn()=>store($id,$p['preview_token']),'after-commit ack loss','AC_TRANSACTION_FAILED');$wpdb->db->commit_ack_lost=false;ck(store($id,$p['preview_token'])['replayed']&&count($wpdb->db->tables['evidence'])===6,'unknown outcome recovery');
$id=fresh();$p=stage($id);$wpdb->db->held=true;blocked(fn()=>store($id,$p['preview_token']),'shared writer lock','AC_WRITER_BUSY');
$id=fresh();$p=stage($id);$wpdb->lock_changed=true;blocked(fn()=>store($id,$p['preview_token']),'fresh locked source state','VAULT_SOURCE_CHANGED');
$id=fresh();$p=stage($id);$wpdb->db->meta=[['meta_key'=>'profile_hours','meta_value'=>'Changed','value_bytes'=>7]];blocked(fn()=>store($id,$p['preview_token']),'fresh snapshot hash','AC_PREVIEW_STALE');
$id=fresh();$p=stage($id);$wpdb->db->tables['jobs'][$id]['scope_filter']=str_replace('PROGRAM CONTOH UJI','RAW TAMPER',$wpdb->db->tables['jobs'][$id]['scope_filter']);blocked(fn()=>store($id,$p['preview_token']),'raw tampering before store');
// Existing manual pending candidate keys must be reused, never duplicated.
$id=fresh();$manual=json_decode(file_get_contents(dirname(__DIR__).'/data/examples/m2-structured-fixture.json'),true);$manual['fixture_only']=false;$manual['checked_at']=gmdate('Y-m-d\TH:i:s\Z',time()-60);$mr=enc($manual);$m=ADE_Enrichment_Store::stage($mr,'https://example.org/');ADE_Enrichment_Store::record($mr,'https://example.org/',$m['preview_token'],'STORE_M2_PENDING','YES');
$p=stage($id);ck($p['estimated_rows_created_including_receipt']===13&&$p['estimated_pending_versions_advanced']===3,'reuse3manualpending with6newarchive refs');
$beforeConflict=$wpdb->db->tables;$wpdb->db->version_conflict=true;blocked(fn()=>store($id,$p['preview_token']),'pending version CAS failure','AC_CANDIDATE_VERSION_CONFLICT');ck($wpdb->db->tables===$beforeConflict,'version CAS failure rolls back all evidence/links');$wpdb->db->version_conflict=false;
$protectedID=array_key_first($wpdb->db->tables['candidates']);$wpdb->db->tables['candidates'][$protectedID]['review_status']='rejected';$protected=$wpdb->db->tables['candidates'][$protectedID];$linkBefore=array_filter($wpdb->db->tables['candidate_evidence'],fn($l)=>$l['candidate_id']===$protectedID);
blocked(fn()=>store($id,$p['preview_token']),'review after stage stale','AC_PREVIEW_STALE');$p=stage($id);$result=store($id,$p['preview_token']);ck($result['result']['rows_created']===9&&$result['result']['candidate_versions_advanced']===2,'skip reviewed while versioning new only');
ck($wpdb->db->tables['candidates'][$protectedID]===$protected&&array_filter($wpdb->db->tables['candidate_evidence'],fn($l)=>$l['candidate_id']===$protectedID)===$linkBefore,'reviewed row and links immutable');
// Self-consistent captured extraction is historical, never caller-certified claims.
$id=fresh();$payload=json_decode($wpdb->db->tables['jobs'][$id]['scope_filter'],true);$payload['extraction']['candidates']=[['target_key'=>'profile_school_verified','proposed_value'=>'FORGED','approved_value'=>'FORGED']];$changed=enc($payload);$summary=json_decode($wpdb->db->tables['jobs'][$id]['stats_payload'],true);$summary['raw_payload_sha256']=hash('sha256',$changed);$summary['payload_bytes']=strlen($changed);$wpdb->db->tables['jobs'][$id]['scope_filter']=$changed;$wpdb->db->tables['jobs'][$id]['stats_payload']=enc($summary);
$rawReparsed=stage($id);ck(count($rawReparsed['candidates'])===3&&!in_array('profile_school_verified',array_column($rawReparsed['candidates'],'target_key'),true),'ignore forged captured extraction and reparse actual raw');
// Encoded Unicode URLs may exceed the16KiB receipt metadata read cap.
$longArchive=$a;$longArchive['documents']=[];foreach($longArchive['schools'] as &$school){$school['document_keys']=[];}unset($school);$longBindings=[];
$wpdb=new ArchiveDB;
for($i=0;$i<3;$i++){$url='https://example.org/'.str_repeat('é',480).$i;$doc=ADE_Local_Archive::document($csv,'csv',$url,gmdate('Y-m-d\TH:i:s\Z',time()-60),'synthetic-long-url');$longArchive['documents'][$doc['key']]=$doc['entry'];$longBindings[$doc['key']]=$url;$key=ADE_Source_URLs::canonicalize($url)['canonical_key'];$wpdb->relations[$key]=['source_id'=>20+$i,'relation_id'=>30+$i,'source_type'=>'website','access_state'=>'manual_only','source_status'=>'discovered','identity_status'=>'pending','relationship_type'=>'pending'];foreach($longArchive['schools'] as &$school){if($school['npsn']==='20268071'){$school['document_keys'][]=$doc['key'];}}unset($school);}
$lr=enc($longArchive);$lv=ADE_Archive_Vault::stage($lr,'20268071',$longBindings);$lid=ADE_Archive_Vault::record($lr,'20268071',$longBindings,$lv['preview_token'],'STORE_RAW_PENDING','YES','YES')['receipt_id'];$lp=stage($lid);$beforeSize=$wpdb->db->tables;
blocked(fn()=>store($lid,$lp['preview_token']),'encoded operation metadata cap','AC_RECEIPT_TOO_LARGE');ck($wpdb->db->tables===$beforeSize,'oversize receipt rolls back all partial claims');
$denied_caps=['ade_review_candidates'];blocked(fn()=>stage($id),'capability','AC_REVIEW_CAPABILITY_REQUIRED');$denied_caps=[];ADE_Schema::$local=false;blocked(fn()=>stage($id),'local gate','LOCAL_OPERATOR_GATE_BLOCKED');ADE_Schema::$local=true;
echo "PASS: $n raw-receipt candidate bridge/security/atomicity checks (fake DB, synthetic only; no actual writes/network).\n";
