const { chromium } = require('playwright');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
(async () => {
 const base=process.env.AHDA_UI_FIXTURE_BASE_URL, out=process.env.AHDA_UI_FIXTURE_OUTPUT;
 assert(base&&new URL(base).hostname==='127.0.0.1'&&out,'Use explicit loopback synthetic fixture URL/output');
 const browser=await chromium.launch({headless:true,executablePath:process.env.AHDA_UI_BROWSER_PATH||undefined});
 const context=await browser.newContext({viewport:{width:1280,height:900}});
 let external=0, checks=0; const errors=[];
 await context.route('**/*',route=>{if(new URL(route.request().url()).hostname==='127.0.0.1'){return route.continue();}external++;return route.abort();});
 const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
 function ck(value,message){assert(value,message);checks++;}
 try {
  await page.goto(base+'/admin.php');ck(await page.locator('#ade-npsn option').count()===201,'200 frozen choices plus placeholder');
  await page.selectOption('#ade-npsn','20268071');await page.getByRole('button',{name:'Tampilkan'}).click();
  ck(await page.getByText('Program uji',{exact:true}).count()===1,'actual GET form displays list');
  await page.getByRole('link',{name:'Lihat nilai dan evidence'}).click();
  ck(await page.getByText('Perbandingan nilai; semua teks diperlakukan sebagai data',{exact:true}).count()===1,'detail comparison visible');
  ck(await page.locator('blockquote').count()===1,'quote visible');
  ck((await page.locator('a[href="https://example.org/profile"]').getAttribute('rel')).includes('noreferrer'),'source link safe rel');
  ck(await page.locator('form[method="post"]').count()===0,'no POST form');
  ck(await page.getByRole('button').count()===1,'only read filter button');
  await page.screenshot({path:path.join(out,'inspector-desktop.png'),fullPage:true});
  await page.goto(base+'/admin.php?npsn=20268071&candidate=42&case=conflict');
  ck(await page.getByText('Konflik nilai saat ini.',{exact:true}).count()===1,'conflict warning');
  await page.goto(base+'/admin.php?npsn=20268071&candidate=42&case=xss');
  ck(await page.locator('script,img').count()===0,'untrusted markup remains text');
  ck(await page.evaluate(()=>typeof window.__AHDA_XSS==='undefined'),'XSS did not execute');
  await page.goto(base+'/admin.php?npsn=20268071&case=empty');
  ck((await page.locator('body').innerText()).includes('Belum ada kandidat tersimpan'),'empty state explains no persisted demos');
  for(const mode of ['unauthorized','production']){
   const response=await page.goto(base+'/admin.php?npsn=20268071&case='+mode);ck(response.status()===403,'denied '+mode);
  }
  await page.goto(base+'/admin.php?npsn=20268071&candidate=42&case=review_enabled');
  ck(await page.locator('form[method="post"]').count()===2,'opt-in fixture renders only two negative forms');
  ck(await page.locator('form[method="post"] input[name="nonce"]').count()===2,'nonce in each negative form');
  ck(await page.locator('form[method="post"] input[name="backup_confirmed"][required]').count()===2,'backup confirmation required');
  ck(await page.locator('form[method="post"] input[name="confirm"][required]').count()===2,'explicit confirmation required');
  ck(await page.getByRole('button',{name:/^(Tunda kandidat|Tolak kandidat)$/}).count()===2,'only defer/reject actions');
  await page.screenshot({path:path.join(out,'negative-review-optin-synthetic.png'),fullPage:true});
  await page.setViewportSize({width:390,height:844});await page.goto(base+'/admin.php?npsn=20268071&candidate=42');
  ck(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+2),'mobile no page overflow');
  await page.screenshot({path:path.join(out,'inspector-mobile.png'),fullPage:true});
  await page.setViewportSize({width:1280,height:900});await page.goto(base+'/admin.php?npsn=20268071&candidate=42&case=archive');
  ck((await page.locator('body').innerText()).includes('Referensi arsip raw #123'),'raw archive pointer visible');
  ck((await page.locator('body').innerText()).includes('belum diperiksa ulang pada halaman ini'),'archive revalidation limit visible');
  ck(await page.locator('form[method="post"]').count()===0,'archive case adds no approval/write form');
  await page.screenshot({path:path.join(out,'archive-evidence-desktop.png'),fullPage:true});
  await page.setViewportSize({width:390,height:844});
  ck(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+2),'long archive hashes wrap on mobile');
  ck(await page.locator('script,img').count()===0,'archive metadata rendered as text');
  await page.screenshot({path:path.join(out,'archive-evidence-mobile.png'),fullPage:true});
  ck(errors.length===0,'no page errors');ck(external===0,'no external requests');
  fs.writeFileSync(path.join(out,'browser-tests.json'),JSON.stringify({status:'PASS',checks,external_requests:external,page_errors:errors,scope:'Actual PHP view rendered in Chromium desktop/mobile; synthetic WordPress/DB stubs and minimal CSS. Not full WordPress/LocalWP integration.'},null,2));
  console.log('PASS: '+checks+' Chromium inspector fixture checks (WP/DB stubs, no external requests).');
 } finally {await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
