<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** M1 operator-only planning CLI. No command in this group fetches the network. */
final class ADE_Pilot_CLI {
    private function npsns( array $assoc ): array {
        ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
        $path = ! isset( $assoc['npsn-file'] ) ? dirname( __DIR__ ) . '/data/pilots/tasikmalaya-200.txt' :
            ( is_string( $assoc['npsn-file'] ) ? realpath( $assoc['npsn-file'] ) : false );
        if ( false === $path || ! is_file( $path ) || ! is_readable( $path ) || filesize( $path ) > 4096 || substr( $path, -4 ) !== '.txt' ) {
            throw new InvalidArgumentException( 'Use a local .txt file, one NPSN per line, maximum 4096 bytes.' );
        }
        $input = file_get_contents( $path, false, null, 0, 4097 );
        if ( false === $input ) { throw new RuntimeException( 'PILOT_READ_FAILED' ); }
        return ADE_Pilot::parse( $input );
    }

    private function input( array $assoc ): array {
        return ADE_Pilot::freeze( $this->npsns( $assoc ), ADE_Pilot_Scope::NAME );
    }

    private function number( array $assoc, string $key, int $default ): int {
        if ( ! isset( $assoc[$key] ) ) { return $default; }
        if ( ! is_string( $assoc[$key] ) || ! preg_match( '/^[0-9]{1,18}$/D', $assoc[$key] ) ) { throw new InvalidArgumentException( 'Invalid --' . $key ); }
        return (int) $assoc[$key];
    }

    private function require_write( array $assoc, string $expected ): string {
        if ( isset( $assoc['dry-run'] ) ) { throw new InvalidArgumentException( 'DRY_RUN_REQUIRES_PREVIEW; this command changes job state.' ); }
        if ( ! isset( $assoc['confirm'] ) || ! is_string( $assoc['confirm'] ) || $assoc['confirm'] !== $expected ) {
            throw new InvalidArgumentException( 'Explicit --confirm=' . $expected . ' required.' );
        }
        return $assoc['confirm'];
    }

    private function output( array $value ): void {
        WP_CLI::log( json_encode( $value, JSON_PRETTY_PRINT | JSON_HEX_TAG | JSON_HEX_AMP | JSON_THROW_ON_ERROR ) );
    }

    /**
     * Audit all frozen Tasikmalaya identities against LocalWP; SELECT only.
     *
     * ## OPTIONS
     * [--npsn-file=<path>]
     * : Defaults to the bundled frozen list; custom files must contain the same 200.
     */
    public function preflight( $args, $assoc ): void {
        try {
            $report = ADE_Pilot::audit_selection( $this->npsns( $assoc ) );
            $this->output( $report );
            if ( ! $report['all_valid'] ) { WP_CLI::error( 'PILOT_PREFLIGHT_BLOCKED; no job or source was changed.' ); }
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Validate frozen Tasikmalaya state-school selection; preview one batch, no writes.
     *
     * ## OPTIONS
     * [--npsn-file=<path>]
     * [--after=<school-id>]
     * [--batch-size=<1-20>]
     * [--dry-run]
     */
    public function preview( $args, $assoc ): void {
        try {
            $manifest = $this->input( $assoc );
            $this->output( array( 'mode' => 'READ_ONLY_NO_FETCH', 'scope' => $manifest['scope'], 'scope_hash' => $manifest['scope_hash'], 'selection_count' => count( $manifest['schools'] ),
                'batch' => ADE_Pilot::batch( $manifest, $this->number( $assoc, 'after', 0 ), $this->number( $assoc, 'batch-size', 10 ) ) ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Inspect existing verified Directory URL fields; never fetch or store sources.
     *
     * ## OPTIONS
     * [--npsn-file=<path>]
     * [--after=<school-id>]
     * [--batch-size=<1-20>]
     * [--dry-run]
     */
    public function source_preview( $args, $assoc ): void {
        try {
            $manifest = $this->input( $assoc );
            $this->output( ADE_Source_Inventory::preview( $manifest, $this->number( $assoc, 'after', 0 ), $this->number( $assoc, 'batch-size', 10 ) ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Store one frozen planning job for exactly 200 schools (Discovery jobs only).
     *
     * ## OPTIONS
     * [--npsn-file=<path>]
     * --confirm=<ENQUEUE_M1_PLAN>
     */
    public function enqueue( $args, $assoc ): void {
        try {
            $confirmation = $this->require_write( $assoc, 'ENQUEUE_M1_PLAN' );
            ADE_Pilot_Jobs::guard( $confirmation, 'ENQUEUE_M1_PLAN' );
            $this->output( ADE_Pilot_Jobs::enqueue( $this->input( $assoc ), $confirmation ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Run one source-planning batch, maximum ten schools, no fetch.
     *
     * ## OPTIONS
     * --job-id=<id>
     * --confirm=<RUN_M1_PLAN>
     */
    public function run_one_batch( $args, $assoc ): void {
        try {
            $confirmation = $this->require_write( $assoc, 'RUN_M1_PLAN' );
            $id = $this->number( $assoc, 'job-id', 0 );
            $job = ADE_Pilot_Jobs::status( $id );
            $manifest = json_decode( $job['scope_filter'], true, 16, JSON_THROW_ON_ERROR );
            if ( ( $manifest['version'] ?? null ) !== 2 ) { throw new RuntimeException( 'LEGACY_UNSCOPED_JOB_REQUIRES_SEPARATE_REVIEW' ); }
            ADE_Pilot::validate_manifest( $manifest );
            $this->output( ADE_Pilot_Jobs::step( $id, $confirmation ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Read-only job status and committed results; omits lease token and manifest.
     *
     * ## OPTIONS
     * --job-id=<id>
     */
    public function status( $args, $assoc ): void {
        try {
            $row = ADE_Pilot_Jobs::status( $this->number( $assoc, 'job-id', 0 ) );
            $manifest = json_decode( $row['scope_filter'], true, 16, JSON_THROW_ON_ERROR );
            $row['selection_scope'] = $manifest['scope'] ?? 'legacy-v1-unscoped';
            unset( $row['lease_token'], $row['scope_filter'] );
            $this->output( $row );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Recover expired M1 planning leases only.
     *
     * ## OPTIONS
     * --confirm=<RECOVER_M1_PLAN>
     */
    public function recover( $args, $assoc ): void {
        try { $this->output( array( 'recovered' => ADE_Pilot_Jobs::recover( $this->require_write( $assoc, 'RECOVER_M1_PLAN' ) ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Cancel a non-running M1 planning job; never deletes it.
     *
     * ## OPTIONS
     * --job-id=<id>
     * --confirm=<CANCEL_M1_PLAN>
     */
    public function cancel( $args, $assoc ): void {
        try { $this->output( array( 'cancelled' => ADE_Pilot_Jobs::cancel( $this->number( $assoc, 'job-id', 0 ), $this->require_write( $assoc, 'CANCEL_M1_PLAN' ) ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }
    /**
     * Read-only manifest, cursor, and committed outcome consistency check.
     *
     * ## OPTIONS
     * --job-id=<id>
     */
    public function integrity_check( $args, $assoc ): void {
        try { $this->output( ADE_Pilot_Jobs::integrity( $this->number( $assoc, 'job-id', 0 ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Retry a failed planning job without clearing committed results.
     *
     * ## OPTIONS
     * --job-id=<id>
     * --confirm=<RETRY_M1_PLAN>
     */
    public function retry_failed( $args, $assoc ): void {
        try { $this->output( array( 'retried' => ADE_Pilot_Jobs::retry_failed( $this->number( $assoc, 'job-id', 0 ), $this->require_write( $assoc, 'RETRY_M1_PLAN' ) ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

}
