<?php
/** Official WP-CLI v2.12 parser/dispatcher, WordPress/DB facade stubs, no network. */
require_once __DIR__.'/support/m1-fake-db.php';
require_once __DIR__.'/support/wpcli-help-stub.php';
$vendor=__DIR__.'/vendor/wp-cli-2.12.0/';
$upstream=json_decode(file_get_contents($vendor.'UPSTREAM.json'),true,16,JSON_THROW_ON_ERROR);
foreach($upstream['files'] as $name=>$meta){if(hash_file('sha256',$vendor.$name)!==$meta['sha256']){throw new RuntimeException('Changed upstream WP-CLI fixture: '.$name);}}
foreach(['SynopsisParser','SynopsisValidator','DocParser','CompositeCommand','Subcommand','CommandNamespace','CommandFactory','dispatcher'] as $name){require_once $vendor.$name.'.php';}
foreach(['identity','source-urls','evidence-urls','pilot-scope','pilot','pilot-jobs','enrichment-preview','enrichment-store','article-preview','document-parser','local-archive','local-worker','archive-review','archive-vault','archive-candidates','archive-verifier','source-attestation','positive-review','pilot-cli','jobs-cli','sources-cli','evidence-cli','schema-cli'] as $name){require_once dirname(__DIR__).'/includes/class-ade-'.$name.'.php';}
final class DispatcherRoot {public function get_hook(){return '';}public function get_name(){return 'ade';}public function get_parent(){return null;}}
final class DispatcherDB {
 public $prefix='custom_',$last_error='',$inner,$snapshots=0;
 public function __construct(){$this->inner=new FakeDB;foreach(ADE_Pilot_Scope::reference() as $code=>$school){$this->inner->schools[$code]=array_merge($school,['id'=>100000+(int)$code,'name'=>'Synthetic worker test','visibility'=>'publish']);}$ref=ADE_Pilot_Scope::reference()['20268071'];$this->inner->schools['20268071']=array_merge($ref,['id'=>913,'name'=>'Synthetic fixture','visibility'=>'publish','education_level'=>'fixture','district_raw'=>'fixture','village_raw'=>'fixture']);}
 public function prepare($sql,...$args){return $this->inner->prepare($sql,...$args);}
 public function get_results($key,$kind){[$sql,$args]=$this->inner->prepared[$key];if(strpos($sql,'FROM custom_ahda_school_meta ')!==false){++$this->snapshots;return [];}$out=$this->inner->get_results($key,$kind);$this->last_error=$this->inner->last_error;return $out;}
 public function query($sql){throw new RuntimeException('Unexpected real-dispatch write');}
 public function insert(...$args){throw new RuntimeException('Unexpected real-dispatch write');}
}
$n=0;function ck($ok,$label){global $n;++$n;if(!$ok){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$label,$expected){$message=null;try{$fn();}catch(Throwable $e){$message=$e->getMessage();}ck($message===$expected,$label);}
$parent=new DispatcherRoot;
$group=WP_CLI\Dispatcher\CommandFactory::create('pilot','ADE_Pilot_CLI',$parent);
$extract=$group->get_subcommands()['extract'];
$validator=new WP_CLI\SynopsisValidator($extract->get_synopsis());
ck($validator->get_unknown()===[],'official parser: no invalid extract synopsis');
ck($validator->unknown_assoc(['demo'=>true,'dry-run'=>true])===[],'official parser accepts exact user flags');
$oldDoc=str_replace('[--dry-run]','--dry-run',(new ReflectionMethod('ADE_Pilot_CLI','extract'))->getDocComment());
$before=new WP_CLI\Dispatcher\Subcommand($group,'extract',new WP_CLI\DocParser($oldDoc),function(){});
$bad=new WP_CLI\SynopsisValidator($before->get_synopsis());
ck(in_array('--dry-run',$bad->get_unknown(),true),'reproduce previous mandatory-boolean synopsis defect');
ck(in_array('dry-run',$bad->unknown_assoc(['demo'=>true,'dry-run'=>true]),true),'reproduce previous unknown --dry-run');
foreach(['ADE_Pilot_CLI','ADE_Jobs_CLI','ADE_Sources_CLI','ADE_Evidence_CLI','ADE_Schema_CLI'] as $class){
 $commands=WP_CLI\Dispatcher\CommandFactory::create('test',$class,$parent);
 foreach($commands->get_subcommands() as $name=>$command){$v=new WP_CLI\SynopsisValidator($command->get_synopsis());ck($v->get_unknown()===[],'official synopsis valid '.$class.' '.$name);}
}
$wpdb=new DispatcherDB;WP_CLI::$messages=[];WP_CLI::$warnings=[];
$extract->invoke([],['demo'=>true,'dry-run'=>true],[]);
$out=json_decode(end(WP_CLI::$messages),true,16,JSON_THROW_ON_ERROR);
ck($out['mode']==='FIXTURE_ONLY_READ_ONLY'&&count($out['candidates'])===3,'official dispatcher reaches handler and returns three demo previews');
ck($wpdb->snapshots===1&&$out['database_writes']===0&&$out['network_requests']===0,'dispatch uses fake SELECT only, no DB/HTTP');
ck(WP_CLI::$warnings===[],'no invalid synopsis or parameter warning');
blocked(fn()=>$extract->invoke([],['demo'=>true],[]),'handler still requires explicit dry-run','M2_PREVIEW_REQUIRES_DRY_RUN');
blocked(fn()=>$extract->invoke([],['demo'=>true,'dry-run'=>false],[]),'negative dry-run cannot satisfy safety flag','M2_PREVIEW_REQUIRES_DRY_RUN');
$stage=$group->get_subcommands()['stage'];$stageValidator=new WP_CLI\SynopsisValidator($stage->get_synopsis());
ck($stageValidator->get_unknown()===[]&&$stageValidator->unknown_assoc(['evidence-file'=>'test.json','source-url'=>'https://example.org/','dry-run'=>true])===[],'stage flag and valued args supported by official parser');
$path=dirname(__DIR__).'/data/examples/m2-structured-fixture.json';
blocked(fn()=>$stage->invoke([],['evidence-file'=>$path,'source-url'=>'https://example.org/','dry-run'=>true],[]),'official stage dispatcher reaches fixture safety gate','M2_FIXTURE_RECORD_BLOCKED');
$article=$group->get_subcommands()['article'];
$article->invoke([],['demo'=>true,'dry-run'=>true],[]);
$draft=json_decode(end(WP_CLI::$messages),true,16,JSON_THROW_ON_ERROR);
ck($draft['mode']==='EDITORIAL_DRAFT_READ_ONLY'&&count($draft['sections'])===3,'official article dispatcher exact flags');
ck($draft['database_writes']===0&&$draft['network_requests']===0&&$draft['publication_enabled']===false,'article dispatch never writes/fetches/publishes');
ck(WP_CLI::$warnings===[],'new article synopsis no warning');
blocked(fn()=>$article->invoke([],['demo'=>true],[]),'article still requires dry-run','M2_ARTICLE_REQUIRES_DRY_RUN');
$parse=$group->get_subcommands()['parse'];
foreach(class_exists('DOMDocument')?['csv','html']:['csv'] as $format){
 $parse->invoke([],['demo'=>true,'format'=>$format,'dry-run'=>true],[]);
 $parsed=json_decode(end(WP_CLI::$messages),true,16,JSON_THROW_ON_ERROR);
 ck($parsed['mode']==='LOCAL_DOCUMENT_PARSE_PREVIEW'&&count($parsed['preview']['candidates'])===3,'official parse dispatcher exact flags '.$format);
 ck($parsed['network_requests']===0&&$parsed['database_writes']===0&&!$parsed['publication_enabled'],'official parse no operations '.$format);
}
ck(WP_CLI::$warnings===[],'parse synopsis no warnings');
blocked(fn()=>$parse->invoke([],['demo'=>true,'format'=>'csv'],[]),'parse handler requires dry-run','M2_PARSE_REQUIRES_DRY_RUN');
$crlf=new WP_CLI\Dispatcher\Subcommand($group,'extract',new WP_CLI\DocParser(str_replace("\n","\r\n",(new ReflectionMethod('ADE_Pilot_CLI','extract'))->getDocComment())),function(){});
ck($crlf->get_synopsis()===$extract->get_synopsis(),'Windows CRLF doc comments parsed identically');
ck(isset($group->get_subcommands()['source_preview']),'official factory preserves underscore command');
$alias=WP_CLI\Dispatcher\CommandFactory::create('source-preview',[new ADE_Pilot_CLI,'source_preview'],$group);
ck($alias->get_name()==='source-preview','official factory supports explicit hyphen alias');
$archive=$group->get_subcommands()['archive'];$work=$group->get_subcommands()['work'];
$archive->invoke([],['demo'=>true,'dry-run'=>true],[]);
$archiveOut=json_decode(end(WP_CLI::$messages),true,16,JSON_THROW_ON_ERROR);
ck(count($archiveOut['schools'])===200&&$archiveOut['fixture_only'],'official archive demo dispatcher');
$work->invoke([],['demo'=>true,'dry-run'=>true,'batch-size'=>'10'],[]);
$worker=json_decode(end(WP_CLI::$messages),true,16,JSON_THROW_ON_ERROR);
ck($worker['cursor']===10&&$worker['processed_this_call']===10&&$worker['summary']['identity_blocked']===0,'official work dispatcher checks10 fake identities');
ck($worker['database_writes']===0&&$worker['network_requests']===0&&$worker['filesystem_writes']===0&&!$worker['publication_enabled'],'worker dispatcher read-only');
blocked(fn()=>$work->invoke([],['demo'=>true],[]),'work requires dry-run','WORKER_DRY_RUN_REVIEW_REQUIRED');
blocked(fn()=>$work->invoke([],['demo'=>true,'dry-run'=>false],[]),'work rejects false dry-run','WORKER_DRY_RUN_REVIEW_REQUIRED');
blocked(fn()=>$archive->invoke([],['demo'=>true],[]),'archive requires dry-run','WORKER_DEMO_DRY_RUN_REQUIRED');
blocked(fn()=>$work->invoke([],['demo'=>true,'archive-file'=>'x.json','dry-run'=>true],[]),'ambiguous work input','M2_INPUT_AMBIGUOUS');
blocked(fn()=>$work->invoke([],['demo'=>true,'dry-run'=>true,'batch-size'=>'11'],[]),'work batch cap','WORKER_BATCH_INVALID');
ck(WP_CLI::$warnings===[],'all new commands have valid official synopsis');
// Operator-controlled local files are read only; test temp files belong to this suite.
$tmp=tempnam(sys_get_temp_dir(),'ade-worker-');unlink($tmp);$tmp.='.json';
$stateFile=$tmp.'.checkpoint.json';
try {
 file_put_contents($tmp,json_encode($archiveOut,JSON_THROW_ON_ERROR));file_put_contents($stateFile,json_encode($worker,JSON_THROW_ON_ERROR));
 $work->invoke([],['archive-file'=>$tmp,'checkpoint-file'=>$stateFile,'dry-run'=>true,'batch-size'=>'10'],[]);
 $continued=json_decode(end(WP_CLI::$messages),true,16,JSON_THROW_ON_ERROR);
 ck($continued['cursor']===20&&$continued['processed_this_call']===10,'official local-file checkpoint resume');
 $denied_caps=['ade_review_candidates'];blocked(fn()=>$work->invoke([],['demo'=>true,'dry-run'=>true],[]),'worker review capability','WORKER_DRY_RUN_REVIEW_REQUIRED');$denied_caps=[];
 ADE_Schema::$local=false;blocked(fn()=>$work->invoke([],['demo'=>true,'dry-run'=>true],[]),'worker local guard','LOCAL_OPERATOR_GATE_BLOCKED');ADE_Schema::$local=true;
} finally {if(is_file($tmp)){unlink($tmp);}if(is_file($stateFile)){unlink($stateFile);}$denied_caps=[];ADE_Schema::$local=true;}
$inspect=$group->get_subcommands()['inspect'];$code=$archiveOut['schools'][0]['npsn'];
$inspect->invoke([],['demo'=>true,'npsn'=>$code,'dry-run'=>true],[]);
$inspection=json_decode(end(WP_CLI::$messages),true,16,JSON_THROW_ON_ERROR);
ck($inspection['mode']==='READ_ONLY_ARCHIVE_REVIEW_PLAN'&&$inspection['npsn']===$code&&!$inspection['storage_enabled'],'official archive inspection dispatch');
ck($inspection['database_writes']===0&&$inspection['network_requests']===0&&!$inspection['publication_enabled'],'official inspect no operations');
blocked(fn()=>$inspect->invoke([],['demo'=>true,'npsn'=>$code],[]),'inspect requires dry-run','ARCHIVE_REVIEW_DRY_RUN_REQUIRED');
blocked(fn()=>$inspect->invoke([],['demo'=>true,'npsn'=>$code,'dry-run'=>false],[]),'inspect false dry-run','ARCHIVE_REVIEW_DRY_RUN_REQUIRED');
blocked(fn()=>$inspect->invoke([],['demo'=>true,'archive-file'=>'x.json','npsn'=>$code,'dry-run'=>true],[]),'inspect ambiguous input','M2_INPUT_AMBIGUOUS');
ck(WP_CLI::$warnings===[],'inspect valid official synopsis');
$archivePath=tempnam(sys_get_temp_dir(),'ade-inspect-');unlink($archivePath);$archivePath.='.json';$bindingPath=$archivePath.'.bindings.json';
try{
 file_put_contents($archivePath,json_encode($archiveOut,JSON_THROW_ON_ERROR));file_put_contents($bindingPath,'{}');
 $inspect->invoke([],['archive-file'=>$archivePath,'bindings-file'=>$bindingPath,'npsn'=>$code,'dry-run'=>true],[]);
 $fromFile=json_decode(end(WP_CLI::$messages),true,16,JSON_THROW_ON_ERROR);
 ck($fromFile['manifest_sha256']===$inspection['manifest_sha256']&&$fromFile['candidates']===$inspection['candidates'],'official inspect local archive and bindings file');
 ck($fromFile['plan_sha256']!==$inspection['plan_sha256']&&$fromFile['archive_input_sha256']!==$inspection['archive_input_sha256'],'different raw archive serialization retains its own input binding');
 $iv=new WP_CLI\SynopsisValidator($inspect->get_synopsis());ck(in_array('checkpoint-file',$iv->unknown_assoc(['checkpoint-file'=>'x']),true),'checkpoint not accepted as archive authority');
}finally{if(is_file($archivePath)){unlink($archivePath);}if(is_file($bindingPath)){unlink($bindingPath);}}
$vault=$group->get_subcommands()['vault_store'];$vv=new WP_CLI\SynopsisValidator($vault->get_synopsis());
ck($vv->get_unknown()===[]&&$vv->unknown_assoc(['archive-file'=>'a.json','bindings-file'=>'b.json','npsn'=>'20268071','preview-token'=>str_repeat('0',64),'backup-confirmed'=>'YES','privacy-reviewed'=>'YES','confirm'=>'STORE_RAW_PENDING'])===[],'official vault writer synopsis');
blocked(fn()=>(new ADE_Pilot_CLI)->vault_store([],[]),'vault writer fails closed before local file read','VAULT_STORAGE_DISABLED');
ck(isset($group->get_subcommands()['vault_stage'],$group->get_subcommands()['vault_receipt']),'vault commands use underscore names');
blocked(fn()=>$vault->invoke([],['archive-file'=>'a.json','bindings-file'=>'b.json','npsn'=>'20268071','preview-token'=>str_repeat('0',64),'backup-confirmed'=>'YES','privacy-reviewed'=>'YES','confirm'=>'STORE_RAW_PENDING'],[]),'official vault dispatch disabled before file read','VAULT_STORAGE_DISABLED');
blocked(fn()=>(new ADE_Pilot_CLI)->vault_stage([],['dry-run'=>false]),'vault stage explicit dry-run','VAULT_STAGE_REQUIRES_DRY_RUN');
$archiveStore=$group->get_subcommands()['archive_store'];
blocked(fn()=>$archiveStore->invoke([],['raw-receipt-id'=>'1','npsn'=>'20268071','preview-token'=>str_repeat('0',64),'backup-confirmed'=>'YES','confirm'=>'STORE_ARCHIVE_CANDIDATES'],[]),'official candidate archive writer disabled before DB access','AC_STORAGE_DISABLED');
blocked(fn()=>(new ADE_Pilot_CLI)->archive_stage([],['dry-run'=>false]),'archive candidate stage dry-run','AC_STAGE_REQUIRES_DRY_RUN');
ck(isset($group->get_subcommands()['archive_stage'],$group->get_subcommands()['archive_receipt']),'archive candidate commands exact underscore names');
$verifier=$group->get_subcommands()['archive_verify'];$vv=new WP_CLI\SynopsisValidator($verifier->get_synopsis());ck($vv->get_unknown()===[]&&$vv->unknown_assoc(['npsn'=>'20268071','candidate-id'=>'1','evidence-id'=>'1','dry-run'=>true])===[],'raw verifier official flag synopsis');
blocked(fn()=>$verifier->invoke([],['npsn'=>'20268071','candidate-id'=>'1','evidence-id'=>'1'],[]),'raw verifier explicit dry-run','RAW_VERIFY_DRY_RUN_REQUIRED');
blocked(fn()=>(new ADE_Pilot_CLI)->approve_record([],[]),'positive writer OFF','APPROVE_WRITES_DISABLED');blocked(fn()=>(new ADE_Pilot_CLI)->approve_stage([],[]),'positive preview explicitdryrun','APPROVE_STAGE_REQUIRES_DRY_RUN');
blocked(fn()=>(new ADE_Pilot_CLI)->attest_record([],[]),'attestation writer defaultOFF before input','ATTEST_WRITES_DISABLED');blocked(fn()=>(new ADE_Pilot_CLI)->attest_revoke([],[]),'withdrawal writer defaultOFF','ATTEST_WRITES_DISABLED');blocked(fn()=>(new ADE_Pilot_CLI)->attest_stage([],['dry-run'=>false]),'attestation plan explicitdryrun','ATTEST_STAGE_REQUIRES_DRY_RUN');
echo "PASS: $n official WP-CLI parser/dispatcher checks (v2.12.0; WP facade/fake DB, no MySQL writes).\n";
