<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** M1 operator-only planning CLI. No command in this group fetches the network. */
final class ADE_Pilot_CLI {
    private function npsns( array $assoc ): array {
        ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
        $path = ! isset( $assoc['npsn-file'] ) ? dirname( __DIR__ ) . '/data/pilots/tasikmalaya-200.txt' :
            ( is_string( $assoc['npsn-file'] ) ? realpath( $assoc['npsn-file'] ) : false );
        if ( false === $path || ! is_file( $path ) || ! is_readable( $path ) || filesize( $path ) > 4096 || substr( $path, -4 ) !== '.txt' ) {
            throw new InvalidArgumentException( 'Use a local .txt file, one NPSN per line, maximum 4096 bytes.' );
        }
        $input = file_get_contents( $path, false, null, 0, 4097 );
        if ( false === $input ) { throw new RuntimeException( 'PILOT_READ_FAILED' ); }
        return ADE_Pilot::parse( $input );
    }

    private function input( array $assoc ): array {
        return ADE_Pilot::freeze( $this->npsns( $assoc ), ADE_Pilot_Scope::NAME );
    }

    private function number( array $assoc, string $key, int $default ): int {
        if ( ! isset( $assoc[$key] ) ) { return $default; }
        if ( ! is_string( $assoc[$key] ) || ! preg_match( '/^[0-9]{1,18}$/D', $assoc[$key] ) ) { throw new InvalidArgumentException( 'Invalid --' . $key ); }
        return (int) $assoc[$key];
    }

    private function require_write( array $assoc, string $expected ): string {
        if ( isset( $assoc['dry-run'] ) ) { throw new InvalidArgumentException( 'DRY_RUN_REQUIRES_PREVIEW; this command changes job state.' ); }
        if ( ! isset( $assoc['confirm'] ) || ! is_string( $assoc['confirm'] ) || $assoc['confirm'] !== $expected ) {
            throw new InvalidArgumentException( 'Explicit --confirm=' . $expected . ' required.' );
        }
        return $assoc['confirm'];
    }

    private function output( array $value ): void {
        WP_CLI::log( json_encode( $value, JSON_PRETTY_PRINT | JSON_HEX_TAG | JSON_HEX_AMP | JSON_THROW_ON_ERROR ) );
    }

    /**
     * Audit all frozen Tasikmalaya identities against LocalWP; SELECT only.
     *
     * ## OPTIONS
     * [--npsn-file=<path>]
     * : Defaults to the bundled frozen list; custom files must contain the same 200.
     */
    public function preflight( $args, $assoc ): void {
        try {
            $report = ADE_Pilot::audit_selection( $this->npsns( $assoc ) );
            $this->output( $report );
            if ( ! $report['all_valid'] ) { WP_CLI::error( 'PILOT_PREFLIGHT_BLOCKED; no job or source was changed.' ); }
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Validate frozen Tasikmalaya state-school selection; preview one batch, no writes.
     *
     * ## OPTIONS
     * [--npsn-file=<path>]
     * [--after=<school-id>]
     * [--batch-size=<1-20>]
     * [--dry-run]
     */
    public function preview( $args, $assoc ): void {
        try {
            $manifest = $this->input( $assoc );
            $this->output( array( 'mode' => 'READ_ONLY_NO_FETCH', 'scope' => $manifest['scope'], 'scope_hash' => $manifest['scope_hash'], 'selection_count' => count( $manifest['schools'] ),
                'batch' => ADE_Pilot::batch( $manifest, $this->number( $assoc, 'after', 0 ), $this->number( $assoc, 'batch-size', 10 ) ) ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Inspect existing verified Directory URL fields; never fetch or store sources.
     *
     * ## OPTIONS
     * [--npsn-file=<path>]
     * [--after=<school-id>]
     * [--batch-size=<1-20>]
     * [--dry-run]
     */
    public function source_preview( $args, $assoc ): void {
        try {
            $manifest = $this->input( $assoc );
            $this->output( ADE_Source_Inventory::preview( $manifest, $this->number( $assoc, 'after', 0 ), $this->number( $assoc, 'batch-size', 10 ) ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Preview literal evidence/candidates from a local structured JSON document.
     *
     * ## OPTIONS
     * [--evidence-file=<path>]
     * : Local .json file, at most64KiB, schema documented in docs/M2_PREVIEW.md.
     * [--demo]
     * : Use bundled synthetic data; never represents facts about the school.
     * [--dry-run]
     * : Mandatory; this command previews only and never writes evidence/candidates.
     */
    public function extract( $args, $assoc ): void {
        try {
            ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
            if ( ( $assoc['dry-run'] ?? null ) !== true ) { throw new InvalidArgumentException( 'M2_PREVIEW_REQUIRES_DRY_RUN' ); }
            $raw = $this->preview_file( $assoc );
            $this->output( ADE_Enrichment_Preview::preview( $raw ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    private function preview_file( array $assoc ): string {
        if ( isset( $assoc['demo'] ) ) {
            if ( $assoc['demo'] !== true || isset( $assoc['evidence-file'] ) ) { throw new InvalidArgumentException( 'M2_INPUT_AMBIGUOUS' ); }
            $path = dirname( __DIR__ ) . '/data/examples/m2-structured-fixture.json';
        } else {
            $path = isset( $assoc['evidence-file'] ) && is_string( $assoc['evidence-file'] ) ? realpath( $assoc['evidence-file'] ) : false;
        }
        if ( false === $path || ! is_file( $path ) || ! is_readable( $path ) || substr( $path, -5 ) !== '.json' ||
            filesize( $path ) > ADE_Enrichment_Preview::MAX_INPUT_BYTES ) { throw new InvalidArgumentException( 'M2_LOCAL_JSON_REQUIRED' ); }
        $raw = file_get_contents( $path, false, null, 0, ADE_Enrichment_Preview::MAX_INPUT_BYTES + 1 );
        if ( false === $raw ) { throw new RuntimeException( 'M2_INPUT_READ_FAILED' ); }
        return $raw;
    }

    /**
     * Preview an evidence-linked article and editorial gaps; never publish or store.
     *
     * ## OPTIONS
     * [--evidence-file=<path>]
     * : Local structured JSON, same schema and limits as extract.
     * [--demo]
     * : Use synthetic fixture data, prominently marked as nonfactual.
     * [--dry-run]
     * : Required by handler; no network or database changes.
     */
    public function article( $args, $assoc ): void {
        try {
            ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
            if ( ( $assoc['dry-run'] ?? null ) !== true ) { throw new InvalidArgumentException( 'M2_ARTICLE_REQUIRES_DRY_RUN' ); }
            $this->output( ADE_Article_Preview::preview( $this->preview_file( $assoc ) ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Parse a saved CSV or supported HTML table; read-only, no fetch/export/write.
     *
     * ## OPTIONS
     * --format=<html|csv>
     * : Explicit local document format.
     * [--demo]
     * : Use bundled synthetic document and fixed metadata.
     * [--document-file=<path>]
     * : Local .html/.htm or .csv, required when not demo.
     * [--npsn=<code>]
     * : Intended frozen pilot NPSN, required when not demo.
     * [--source-url=<url>]
     * : Actual source HTTPS URL, required when not demo; never fetched.
     * [--checked-at=<utc>]
     * : Actual UTC document observation time, required when not demo.
     * [--permission-reference=<reference>]
     * : Operator reference, required when not demo; does not certify permission.
     * [--dry-run]
     * : Required boolean true; cannot save evidence or publish.
     */
    public function parse( $args, $assoc ): void {
        try {
            ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
            if ( ( $assoc['dry-run'] ?? null ) !== true ) { throw new InvalidArgumentException( 'M2_PARSE_REQUIRES_DRY_RUN' ); }
            $format = $this->m2_string( $assoc, 'format' );
            if ( ! in_array( $format, array( 'html', 'csv' ), true ) ) { throw new InvalidArgumentException( 'M2_DOCUMENT_FORMAT_UNSUPPORTED' ); }
            if ( isset( $assoc['demo'] ) ) {
                if ( true !== $assoc['demo'] || array_intersect( array_keys( $assoc ), array( 'document-file', 'npsn', 'source-url', 'checked-at', 'permission-reference' ) ) ) { throw new InvalidArgumentException( 'M2_INPUT_AMBIGUOUS' ); }
                $path = dirname( __DIR__ ) . '/data/examples/m2-profile-fixture.' . $format;
                $npsn = '20268071';
                $metadata = array( 'fixture_only' => true, 'source_url' => 'https://example.org/ahda-fixture-only', 'checked_at' => '2020-01-01T00:00:00Z', 'permission_reference' => 'fixture-only-not-a-permission' );
            } else {
                $path = isset( $assoc['document-file'] ) && is_string( $assoc['document-file'] ) ? realpath( $assoc['document-file'] ) : false;
                $npsn = $this->m2_string( $assoc, 'npsn' );
                $metadata = array( 'fixture_only' => false, 'source_url' => $this->m2_string( $assoc, 'source-url' ),
                    'checked_at' => $this->m2_string( $assoc, 'checked-at' ), 'permission_reference' => $this->m2_string( $assoc, 'permission-reference' ) );
            }
            $limit = 'html' === $format ? ADE_Document_Parser::MAX_HTML_BYTES : ADE_Document_Parser::MAX_CSV_BYTES;
            $extension = false === $path ? '' : strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
            if ( false === $path || ! is_file( $path ) || ! is_readable( $path ) || ! in_array( $extension, 'html' === $format ? array( 'html', 'htm' ) : array( 'csv' ), true ) || filesize( $path ) > $limit ) { throw new InvalidArgumentException( 'M2_LOCAL_DOCUMENT_REQUIRED' ); }
            $raw = file_get_contents( $path, false, null, 0, $limit + 1 );
            if ( false === $raw ) { throw new RuntimeException( 'M2_INPUT_READ_FAILED' ); }
            $this->output( ADE_Document_Parser::preview( $raw, $format, $npsn, $metadata ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    private function local_json( array $assoc, string $key, int $limit ): string {
        $path = isset( $assoc[$key] ) && is_string( $assoc[$key] ) ? realpath( $assoc[$key] ) : false;
        if ( false === $path || ! is_file( $path ) || ! is_readable( $path ) || strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) !== 'json' || filesize( $path ) > $limit ) { throw new InvalidArgumentException( 'WORKER_LOCAL_JSON_REQUIRED' ); }
        $raw = file_get_contents( $path, false, null, 0, $limit + 1 );
        if ( false === $raw ) { throw new RuntimeException( 'WORKER_INPUT_READ_FAILED' ); }
        return $raw;
    }

    /**
     * Print a synthetic portable archive; no file, database or network write.
     *
     * ## OPTIONS
     * [--demo]
     * : Required; generates synthetic data only, not school facts.
     * [--dry-run]
     * : Required boolean true.
     */
    public function archive( $args, $assoc ): void {
        try {
            ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
            if ( ( $assoc['demo'] ?? null ) !== true || ( $assoc['dry-run'] ?? null ) !== true || ! current_user_can( 'ade_review_candidates' ) ) { throw new InvalidArgumentException( 'WORKER_DEMO_DRY_RUN_REQUIRED' ); }
            $this->output( ADE_Local_Archive::freeze( ADE_Local_Archive::demo() )['bundle'] );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Process a resumable local archive preview; never store or fetch.
     *
     * ## OPTIONS
     * [--demo]
     * : Use the immutable synthetic archive instead of a file.
     * [--archive-file=<path>]
     * : Local JSON archive at most4MiB, required unless demo.
     * [--checkpoint-file=<path>]
     * : Local JSON checkpoint or previous work report, at most512KiB.
     * [--batch-size=<1-10>]
     * : Default10, maximum10 schools per call.
     * [--retry-npsn=<code>]
     * : Retry one already processed failure, maximum3 attempts.
     * [--dry-run]
     * : Required boolean true; all output is unverified/read-only.
     */
    public function work( $args, $assoc ): void {
        try {
            ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
            if ( ( $assoc['dry-run'] ?? null ) !== true || ! current_user_can( 'ade_review_candidates' ) ) { throw new InvalidArgumentException( 'WORKER_DRY_RUN_REVIEW_REQUIRED' ); }
            if ( isset( $assoc['demo'] ) && ( $assoc['demo'] !== true || isset( $assoc['archive-file'] ) ) ) { throw new InvalidArgumentException( 'M2_INPUT_AMBIGUOUS' ); }
            $raw = isset( $assoc['demo'] ) ? ADE_Local_Archive::demo() : $this->local_json( $assoc, 'archive-file', ADE_Local_Archive::MAX_BYTES );
            $checkpoint = isset( $assoc['checkpoint-file'] ) ? $this->local_json( $assoc, 'checkpoint-file', 524288 ) : null;
            $retry = isset( $assoc['retry-npsn'] ) ? $this->m2_string( $assoc, 'retry-npsn' ) : null;
            $resolve = static function( string $code ): array { return ADE_Identity::lookup_pilot( $code ); };
            $this->output( ADE_Local_Worker::run( $raw, $checkpoint, $this->number( $assoc, 'batch-size', 10 ), time(), $resolve, null, $retry ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    private function m2_file( array $assoc ): string {
        ADE_Pilot_Jobs::guard( 'READ_M1', 'READ_M1' );
        if ( ! current_user_can( 'ade_review_candidates' ) || isset( $assoc['demo'] ) ) { throw new RuntimeException( 'M2_REAL_DOCUMENT_AND_REVIEW_CAP_REQUIRED' ); }
        $path = isset( $assoc['evidence-file'] ) && is_string( $assoc['evidence-file'] ) ? realpath( $assoc['evidence-file'] ) : false;
        if ( false === $path || ! is_file( $path ) || ! is_readable( $path ) || substr( $path, -5 ) !== '.json' || filesize( $path ) > ADE_Enrichment_Preview::MAX_INPUT_BYTES ) {
            throw new InvalidArgumentException( 'M2_LOCAL_JSON_REQUIRED' );
        }
        $raw = file_get_contents( $path, false, null, 0, ADE_Enrichment_Preview::MAX_INPUT_BYTES + 1 );
        if ( false === $raw ) { throw new RuntimeException( 'M2_INPUT_READ_FAILED' ); }
        return $raw;
    }

    private function m2_string( array $assoc, string $key ): string {
        if ( ! isset( $assoc[$key] ) || ! is_string( $assoc[$key] ) || '' === trim( $assoc[$key] ) ) { throw new InvalidArgumentException( 'M2_PARAMETER_REQUIRED_' . strtoupper( $key ) ); }
        return trim( $assoc[$key] );
    }

    /**
     * Stage a real manual document against a pre-existing pending source; SELECT only.
     *
     * ## OPTIONS
     * --evidence-file=<path>
     * : Local real structured evidence document.
     * --source-url=<registered-website-url>
     * : Existing school-associated website URL.
     * [--dry-run]
     * : Required by the handler; WP-CLI boolean flags use optional synopsis syntax.
     */
    public function stage( $args, $assoc ): void {
        try {
            if ( ( $assoc['dry-run'] ?? null ) !== true ) { throw new InvalidArgumentException( 'M2_STAGE_REQUIRES_DRY_RUN' ); }
            $this->output( ADE_Enrichment_Store::stage( $this->m2_file( $assoc ), $this->m2_string( $assoc, 'source-url' ) ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Explicit local pending-only write. Operator DB approval and backup required.
     *
     * ## OPTIONS
     * --evidence-file=<path>
     * --source-url=<registered-website-url>
     * --preview-token=<hash>
     * --backup-confirmed=<YES>
     * --confirm=<STORE_M2_PENDING>
     */
    public function store( $args, $assoc ): void {
        try {
            $confirmation = $this->require_write( $assoc, 'STORE_M2_PENDING' );
            $backup = $this->m2_string( $assoc, 'backup-confirmed' );
            if ( $backup !== 'YES' ) { throw new RuntimeException( 'M2_BACKUP_ACK_REQUIRED' ); }
            $this->output( ADE_Enrichment_Store::record( $this->m2_file( $assoc ), $this->m2_string( $assoc, 'source-url' ), $this->m2_string( $assoc, 'preview-token' ), $confirmation, $backup ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Read a completed M2 operation receipt; historical, not approval/publication.
     *
     * ## OPTIONS
     * --receipt-id=<id>
     */
    public function receipt( $args, $assoc ): void {
        try { $this->output( ADE_Enrichment_Store::receipt( $this->number( $assoc, 'receipt-id', 0 ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Store one frozen planning job for exactly 200 schools (Discovery jobs only).
     *
     * ## OPTIONS
     * [--npsn-file=<path>]
     * --confirm=<ENQUEUE_M1_PLAN>
     */
    public function enqueue( $args, $assoc ): void {
        try {
            $confirmation = $this->require_write( $assoc, 'ENQUEUE_M1_PLAN' );
            ADE_Pilot_Jobs::guard( $confirmation, 'ENQUEUE_M1_PLAN' );
            $this->output( ADE_Pilot_Jobs::enqueue( $this->input( $assoc ), $confirmation ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Run one source-planning batch, maximum ten schools, no fetch.
     *
     * ## OPTIONS
     * --job-id=<id>
     * --confirm=<RUN_M1_PLAN>
     */
    public function run_one_batch( $args, $assoc ): void {
        try {
            $confirmation = $this->require_write( $assoc, 'RUN_M1_PLAN' );
            $id = $this->number( $assoc, 'job-id', 0 );
            $job = ADE_Pilot_Jobs::status( $id );
            $manifest = json_decode( $job['scope_filter'], true, 16, JSON_THROW_ON_ERROR );
            if ( ( $manifest['version'] ?? null ) !== 2 ) { throw new RuntimeException( 'LEGACY_UNSCOPED_JOB_REQUIRES_SEPARATE_REVIEW' ); }
            ADE_Pilot::validate_manifest( $manifest );
            $this->output( ADE_Pilot_Jobs::step( $id, $confirmation ) );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Read-only job status and committed results; omits lease token and manifest.
     *
     * ## OPTIONS
     * --job-id=<id>
     */
    public function status( $args, $assoc ): void {
        try {
            $row = ADE_Pilot_Jobs::status( $this->number( $assoc, 'job-id', 0 ) );
            $manifest = json_decode( $row['scope_filter'], true, 16, JSON_THROW_ON_ERROR );
            $row['selection_scope'] = $manifest['scope'] ?? 'legacy-v1-unscoped';
            unset( $row['lease_token'], $row['scope_filter'] );
            $this->output( $row );
        } catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Recover expired M1 planning leases only.
     *
     * ## OPTIONS
     * --confirm=<RECOVER_M1_PLAN>
     */
    public function recover( $args, $assoc ): void {
        try { $this->output( array( 'recovered' => ADE_Pilot_Jobs::recover( $this->require_write( $assoc, 'RECOVER_M1_PLAN' ) ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Cancel a non-running M1 planning job; never deletes it.
     *
     * ## OPTIONS
     * --job-id=<id>
     * --confirm=<CANCEL_M1_PLAN>
     */
    public function cancel( $args, $assoc ): void {
        try { $this->output( array( 'cancelled' => ADE_Pilot_Jobs::cancel( $this->number( $assoc, 'job-id', 0 ), $this->require_write( $assoc, 'CANCEL_M1_PLAN' ) ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }
    /**
     * Read-only manifest, cursor, and committed outcome consistency check.
     *
     * ## OPTIONS
     * --job-id=<id>
     */
    public function integrity_check( $args, $assoc ): void {
        try { $this->output( ADE_Pilot_Jobs::integrity( $this->number( $assoc, 'job-id', 0 ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

    /**
     * Retry a failed planning job without clearing committed results.
     *
     * ## OPTIONS
     * --job-id=<id>
     * --confirm=<RETRY_M1_PLAN>
     */
    public function retry_failed( $args, $assoc ): void {
        try { $this->output( array( 'retried' => ADE_Pilot_Jobs::retry_failed( $this->number( $assoc, 'job-id', 0 ), $this->require_write( $assoc, 'RETRY_M1_PLAN' ) ) ) ); }
        catch ( Throwable $e ) { WP_CLI::error( $e->getMessage() ); }
    }

}
