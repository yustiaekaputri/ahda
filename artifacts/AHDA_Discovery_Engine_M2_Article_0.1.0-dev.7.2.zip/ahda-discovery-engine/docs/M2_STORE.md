> dev.7.2 verification update:70 native MySQL8.4.13 checks PASS on disposable
> synthetic data with WordPress/wpdb adapter stubs. Full LocalWP writes remain
> NOT TESTED and require separate approval. See NATIVE_MYSQL.md. Historical
> statements below refer to the original dev7.1 verification state.

# M2 pending store — development dev.7.1

Kode manual-only untuk menyimpan observasi belum terverifikasi dan proposal baru,
melanjutkan preview dev.7.0. Bukan publisher. Tidak ada penulisan nyata yang telah
dijalankan oleh cloud. Native LocalWP/MySQL writer masih NOT TESTED.

## Lingkup dan guard

Hanya anggota200 pilot beku Tasikmalaya, ownership NEGERI dan jenjang/wilayah
sesuai referensi, diperiksa ulang setiap tahap. Wajib Site Shell ahda.local,
capability ade_manage_jobs + ade_review_candidates dan operator WordPress aktif.
Fixture dan evidence lebih1tahun ditolak. Source website HTTPS yang sudah
terdaftar dan berelasi dengan sekolah harus tersedia; sumber baru tidak dibuat
secara otomatis. URL dokumen wajib host yang sama; ini tidak membuktikan ownership.
Source manual_only dan state dikenal diperlukan; rejected/blocked/conflict/unknown
ditolak. Tidak ada HTTP/DNS, model, login sosial atau perubahan source identity.

## Stage — SELECT only, dokumen nyata berizin diperlukan

Format JSON tetap docs/M2_PREVIEW.md. Jangan mengubah fixture_only pada demo
untuk memaksa penulisan. Data demo bukan fakta sekolah dan tidak boleh disimpan.
Perintah berikut hanya untuk dokumen pengamatan nyata dan sumber yang benar-benar
sudah diregistrasi secara terpisah dengan persetujuan operator:

```sh
wp --user="admin" ade pilot stage --evidence-file="C:/path/evidence.json" --source-url="https://website-yang-terdaftar/" --dry-run
```

Ganti contoh path/URL dengan nilai aktual. Host pada contoh bukan URL siap pakai.
Stage mengembalikan operation_key, preview_token, proposal/current value, existing
candidate ID dan action insert_pending/reuse_pending/skip_reviewed_no_mutation.
Tidak menulis apa pun. Tidak ada opsi --demo untuk stage/store.

## Store — jangan dijalankan sebelum persetujuan DB khusus

Dampak maksimum per dokumen20klaim: sampai3 kandidat,20 evidence,20 links dan
1 receipt. Tabel hanya ahda_discovery_candidates/evidence/candidate_evidence/jobs,
dengan prefix aktual. Tidak menulis25 tabel lama, nama, NPSN, verified badge,
post/meta WordPress, reviews keputusan, sumber atau relasi sumber.

Store memerlukan SEMUA parameter: evidence-file, source-url, preview-token dari
stage yang masih cocok, backup-confirmed=YES dan confirm=STORE_M2_PENDING.
Contoh perintah mutasi lengkap sengaja tidak dijadikan langkah pengujian saat ini;
operator harus meninjau rencana konkret, backup dan izin DB dahulu. `--dry-run`
pada store selalu ditolak. Untuk preview gunakan stage, bukan store.

Transaksi pendek, tidak melakukan HTTP di dalam transaksi. Mutex MySQL per
school_id dan table-prefix, GET_LOCK0; row lock FOR UPDATE NOWAIT (target MySQL8.4).
Jika data/approval/evidence/snapshot berubah sesudah stage, token tidak cocok dan
seluruh operasi dibatalkan. Insert failure, version conflict atau commit error
menghasilkan rollback; native engine behavior belum dibuktikan di LocalWP.

Evidence immutable parse_status=m2_manual_unverified, metadata provenance/schema,
input/document fingerprint dan operator reference disimpan. Referensi operator
bukan verifikasi akses. New candidates: new/not_ready, approved_value NULL,
semua score0. Tidak dibuat confidence fiktif atau status approved/published.

Candidate yang sudah direview/approved/published tidak diubah dan tidak diberi
link evidence tambahan di belakang reviewer. Tambahan evidence ke candidate
pending menaikkan row_version dengan predicate version/status untuk melindungi
review form yang sudah terbuka. Nilai proposed/current snapshot tidak ditimpa.
Jika snapshot pending sudah berbeda, stage gagal dan perlu review terpisah.

Receipt m2_document_record pada jobs ikut commit secara atomik, mencatat actor,
input hash, preview token, source relation, blockers dan hash hasil. Tipe ini tidak
diproses worker R2/M1. Request berulang untuk file/sumber sama membaca receipt;
rows_created0. Original_result adalah historis, bukan status approval saat ini.
Receipt dapat dibaca setelah operasi yang disetujui benar-benar dilakukan:

```sh
wp --user="admin" ade pilot receipt --receipt-id=ID_RECEIPT
```

Nilai ID diganti dari hasil aktual. Tidak ada receipt baru di LocalWP Anda dari
pekerjaan cloud ini. Corrupt hash/receipt dan payload terlalu besar memblokir read.

## Pengujian, rollback dan kekurangan

Skenario fake DB mencakup setiap titik insert, commit failure/lost acknowledgment,
idempotence, source/scope/role, stale snapshot/review, evidence corruption,
optimistic version conflict, row allowlist, receipt hash dan handler CLI.
Fake transactions bukan bukti engine MySQL8.4. Persetujuan terpisah untuk
MySQL disposable sedang diminta; hasil native belum diklaim.

Rollback pada exception membatalkan semua row baru dalam transaksi. Sesudah
COMMIT, receipt dipertahankan sebagai audit; tidak ada delete otomatis atau
undo keputusan reviewer. Fitur cancel/revoke lintas receipt serta publisher
apply/rollback masih pekerjaan berikutnya. Jangan menghapus rows/source yang
mungkin dirujuk operasi lain. Tidak ada native data yang perlu dipulihkan sekarang.

Rollback build: kembali ke dev7.0 setelah backup/persetujuan lokal. Schema tetap1;
receipt yang sudah ada disimpan dan tidak diproses worker lama. Dev7.0 tidak punya
command receipt/store; gunakan dev7.1 untuk diagnosis. Jangan downgrade/delete
row data agar command lama bisa membacanya. Produksi tetap di luar cakupan.
