<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** School lookup on the pre-existing unique NPSN index; never guesses a school. */
final class ADE_Identity {
    public static function validate_npsn( string $npsn ): string {
        $npsn = trim( $npsn );
        if ( ! preg_match( '/^[0-9]{8}$/D', $npsn ) ) {
            throw new InvalidArgumentException( 'R3 pilot membutuhkan NPSN 8 digit. NPSN lain ditangani manual pada rilis berikutnya.' );
        }
        return $npsn;
    }

    public static function lookup( string $npsn ): array {
        return self::lookup_fields( $npsn, false );
    }

    /** Same unique lookup, with explicit ownership for the frozen pilot. */
    public static function lookup_pilot( string $npsn ): array {
        return self::lookup_fields( $npsn, true );
    }

    private static function lookup_fields( string $npsn, bool $ownership ): array {
        $npsn = self::validate_npsn( $npsn );
        global $wpdb;
        if ( ! preg_match( '/^[a-zA-Z0-9_]+$/D', (string) $wpdb->prefix ) || strlen( $wpdb->prefix . 'ahda_schools' ) > 64 ) {
            throw new RuntimeException( 'UNSAFE_SCHOOL_TABLE_PREFIX' );
        }
        $table = $wpdb->prefix . 'ahda_schools';
        $wpdb->last_error = '';
        $columns = 'id,npsn,name,school_form,education_level,regency_raw,district_raw,village_raw,visibility' . ( $ownership ? ',ownership_status' : '' );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT {$columns} FROM {$table} WHERE npsn=%s LIMIT 2",
            $npsn
        ), ARRAY_A );
        if ( ! is_array( $rows ) || '' !== $wpdb->last_error ) {
            throw new RuntimeException( 'Gagal membaca indeks NPSN: ' . (string) $wpdb->last_error );
        }
        if ( count( $rows ) !== 1 ) {
            throw new RuntimeException( count( $rows ) === 0 ? 'NPSN tidak ditemukan pada database AHDA.' : 'NPSN tidak unik; hentikan pemeriksaan identitas.' );
        }
        if ( (int) $rows[0]['id'] < 1 ) { throw new RuntimeException( 'school_id tidak valid.' ); }
        return $rows[0];
    }

    /** Only compares operator-typed name with legacy name; not independent verification. */
    public static function compare_name( string $existing, string $claimed ): string {
        $claimed = trim( $claimed );
        if ( '' === $claimed ) { return 'not_supplied'; }
        $norm = static function( string $s ): string {
            $s = function_exists( 'remove_accents' ) ? remove_accents( $s ) : $s;
            $s = strtolower( trim( $s ) );
            return trim( preg_replace( '/[^a-z0-9]+/i', ' ', $s ) );
        };
        return $norm( $existing ) === $norm( $claimed ) ? 'exact_normalized' : 'mismatch_manual_review';
    }
}
