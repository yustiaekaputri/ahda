<?php
/** Called only from the owned CLI harness AFTER actual WordPress bootstrap. */
if(PHP_SAPI!=='cli'||getenv('AHDA_WP_E2E_ONLY')!=='SYNTHETIC_ISOLATED'||!defined('ABSPATH')||!class_exists('wpdb')){exit(2);}
// Presence-only marker for the plugin's CLI guard. No dispatcher/API methods are
// stubbed or invoked: these are direct service API tests, not official WP-CLI E2E.
if(!class_exists('WP_CLI',false)){class WP_CLI{}}
$bridge_checks=0;
function bc($ok,$message){global $bridge_checks;++$bridge_checks;check_result($ok,$message);}
function must_block($fn,$expected,$message){$error=null;try{$fn();}catch(Throwable $e){$error=$e->getMessage();}bc($error===$expected,$message.' actual='.($error??'no error'));}
function discovery_snapshot(){global $wpdb;$out=[];foreach(['sources','school_sources','evidence','candidates','candidate_evidence','reviews','jobs'] as $suffix){$out[$suffix]=ahda_hash(ADE_Schema::table_name($suffix));}return $out;}
function table_count($suffix){global $wpdb;return (int)$wpdb->get_var('SELECT COUNT(*) FROM '.ADE_Schema::table_name($suffix));}
function build_bridge_archive($reference){$a=ADE_Local_Archive::freeze(ADE_Local_Archive::demo())['bundle'];$a['fixture_only']=false;$a['documents']=[];foreach($a['schools'] as &$s){$s['document_keys']=[];}unset($s);$bindings=[];
 foreach(['csv'=>'https://example.org/','html'=>'https://example.net/'] as $format=>$url){$doc=ADE_Local_Archive::document(file_get_contents(dirname(__DIR__,2).'/data/examples/m2-profile-fixture.'.$format),$format,$url.'synthetic-real-wp-bridge',gmdate('Y-m-d\TH:i:s\Z',time()-60),$reference);$a['documents'][$doc['key']]=$doc['entry'];$bindings[$doc['key']]=$url;foreach($a['schools'] as &$s){if($s['npsn']==='20268071'){$s['document_keys'][]=$doc['key'];}}unset($s);}
 return [json_encode($a,JSON_THROW_ON_ERROR),$bindings];
}
function capture_bridge_raw($raw,$bindings){$p=ADE_Archive_Vault::stage($raw,'20268071',$bindings);return ADE_Archive_Vault::record($raw,'20268071',$bindings,$p['preview_token'],'STORE_RAW_PENDING','YES','YES');}
function store_bridge_candidates($id,$token){return ADE_Archive_Candidates::record($id,'20268071',$token,'STORE_ARCHIVE_CANDIDATES','YES');}
global $wpdb;$prefix=$wpdb->prefix;$admin=get_user_by('login','ahda_e2e_admin');$editor=get_user_by('login','ahda_e2e_editor');bc($admin&&$editor,'Actual WP fixture users required');wp_set_current_user($admin->ID);
bc(get_class($wpdb)==='wpdb'&&strpos((new ReflectionClass($wpdb))->getFileName(),'wp-includes/class-wpdb.php')!==false,'Actual core wpdb, no adapter replacement');
bc(current_user_can('ade_manage_jobs')&&current_user_can('ade_review_candidates'),'Actual WP administrator has assigned plugin capabilities');
bc(!ADE_Archive_Vault::enabled()&&!ADE_Archive_Candidates::enabled(),'Both new write opt-ins default OFF');
$legacyBefore=inspect_state()['legacy_hashes'];$oldCandidates=$wpdb->get_results('SELECT * FROM '.ADE_Schema::table_name('candidates').' ORDER BY id',ARRAY_A);$oldEvidence=$wpdb->get_results('SELECT * FROM '.ADE_Schema::table_name('evidence').' ORDER BY id',ARRAY_A);$oldLinks=$wpdb->get_results('SELECT * FROM '.ADE_Schema::table_name('candidate_evidence').' ORDER BY id',ARRAY_A);
$now=current_time('mysql',true);$source=ADE_Source_URLs::canonicalize('https://example.net/');bc($wpdb->insert(ADE_Schema::table_name('sources'),['id'=>9,'source_type'=>'website','canonical_url'=>$source['canonical_url'],'canonical_key'=>$source['canonical_key'],'normalized_host'=>$source['normalized_host'],'access_state'=>'manual_only','source_status'=>'discovered','created_at'=>$now,'updated_at'=>$now])===1,'Second-host synthetic source setup');
bc($wpdb->insert(ADE_Schema::table_name('school_sources'),['id'=>10,'school_id'=>913,'source_id'=>9,'relationship_type'=>'pending','identity_status'=>'pending','created_at'=>$now,'updated_at'=>$now])===1,'Second-host source relation setup');
$protected=[];foreach(['sources','school_sources','reviews'] as $suffix){$protected[$suffix]=ahda_hash(ADE_Schema::table_name($suffix));}
[$raw,$bindings]=build_bridge_archive('synthetic-wordpress-integration');$countsBefore=table_count('jobs');$stage=ADE_Archive_Vault::stage($raw,'20268071',$bindings);bc($stage['estimated_jobs_rows_created']===1&&table_count('jobs')===$countsBefore,'Actual WP raw stage is read-only');
must_block(fn()=>ADE_Archive_Vault::record($raw,'20268071',$bindings,$stage['preview_token'],'STORE_RAW_PENDING','YES','YES'),'VAULT_STORAGE_DISABLED','Actual raw storage disabled');
define('ADE_LOCAL_ARCHIVE_STORAGE_ENABLED',true);$captured=capture_bridge_raw($raw,$bindings);$rawID=$captured['receipt_id'];bc($captured['rows_created']===1&&!$captured['replayed'],'Actual wpdb raw receipt inserted');
bc(ADE_Archive_Vault::receipt($rawID)['summary']['documents']&&table_count('jobs')===$countsBefore+1,'Actual stored raw metadata/hash receipt');bc(capture_bridge_raw($raw,$bindings)['replayed']&&table_count('jobs')===$countsBefore+1,'Actual raw replay dedupe');
$p=ADE_Archive_Candidates::stage($rawID,'20268071');bc($p['estimated_rows_created_including_receipt']===16&&count($p['candidates'])===3,'Actual wpdb bridge stage16-row plan');
must_block(fn()=>store_bridge_candidates($rawID,$p['preview_token']),'AC_STORAGE_DISABLED','Actual candidate storage disabled');
wp_set_current_user($editor->ID);must_block(fn()=>ADE_Archive_Candidates::stage($rawID,'20268071'),'AC_REVIEW_CAPABILITY_REQUIRED','Actual editor cannot stage candidate archive');wp_set_current_user($admin->ID);
must_block(fn()=>ADE_Archive_Candidates::stage($rawID,'20268073'),'VAULT_SCHOOL_BINDING_CONFLICT','Actual raw cross-school IDOR blocked');
define('ADE_LOCAL_ARCHIVE_CANDIDATES_ENABLED',true);
must_block(fn()=>ADE_Archive_Candidates::record($rawID,'20268071',$p['preview_token'],'WRONG','YES'),'AC_EXPLICIT_WRITE_APPROVAL_REQUIRED','Actual explicit confirmation required');must_block(fn()=>ADE_Archive_Candidates::record($rawID,'20268071',$p['preview_token'],'STORE_ARCHIVE_CANDIDATES','NO'),'AC_EXPLICIT_WRITE_APPROVAL_REQUIRED','Actual backup acknowledgment required');
must_block(fn()=>store_bridge_candidates($rawID,str_repeat('0',64)),'AC_PREVIEW_STALE','Actual changed token rejected');
$rawStored=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.ADE_Schema::table_name('jobs').' WHERE id=%d',$rawID),ARRAY_A);
// Inject syntax errors via actual WP query filter. Real wpdb/MySQL executes and
// rejects them; no SQL adapter/transaction API is replaced.
for($position=1;$position<=16;$position++){
 $before=discovery_snapshot();$seen=0;
 $fault=static function($sql)use(&$seen,$position,$prefix){if(stripos($sql,'INSERT INTO')===0&&strpos($sql,$prefix.'ahda_discovery_')!==false&&++$seen===$position){return 'AHDA_INTENTIONAL_SQL_ERROR_FOR_SYNTHETIC_ROLLBACK_TEST';}return $sql;};
 add_filter('query',$fault,PHP_INT_MAX);$oldSuppress=$wpdb->suppress_errors(true);
 try{must_block(fn()=>store_bridge_candidates($rawID,$p['preview_token']),'AC_INSERT_FAILED','Actual wpdb insert failure '.$position);}
 finally{remove_filter('query',$fault,PHP_INT_MAX);$wpdb->suppress_errors($oldSuppress);}
 bc($seen===$position&&discovery_snapshot()===$before,'Actual transaction rollback all Discovery rows '.$position);
}
$candidateCount=table_count('candidates');$evidenceCount=table_count('evidence');$linkCount=table_count('candidate_evidence');$jobCount=table_count('jobs');
$done=store_bridge_candidates($rawID,$p['preview_token']);$ids=array_column($done['result']['candidates'],'id');bc(count($ids)===3&&$done['result']['rows_created']===16,'Actual wpdb complete pending operation');
bc(table_count('candidates')===$candidateCount+3&&table_count('evidence')===$evidenceCount+6&&table_count('candidate_evidence')===$linkCount+6&&table_count('jobs')===$jobCount+1,'Actual wpdb exact row deltas');
bc($wpdb->get_row($wpdb->prepare('SELECT * FROM '.ADE_Schema::table_name('jobs').' WHERE id=%d',$rawID),ARRAY_A)===$rawStored,'Actual raw receipt unchanged by candidate operation');
$sourceIDs=[];foreach($ids as $id){$detail=ADE_Candidate_Inspector::detail('20268071',$id);bc(count($detail['evidence'])===2&&$detail['candidate']['approved_value']===null&&$detail['candidate']['publish_status']==='not_ready','Actual inspector pending/raw evidence '.$id);
 foreach($detail['evidence'] as $entry){$sourceIDs[(int)$entry['source_id']]=true;bc($entry['archive_binding']['raw_receipt_id']===$rawID&&!$entry['archive_binding']['revalidated_on_this_page'],'Actual raw pointer is not false revalidation');}}
$verifyBefore=discovery_snapshot();
foreach($ids as $candidate){$detail=ADE_Candidate_Inspector::detail('20268071',$candidate);foreach($detail['evidence'] as $entry){$verified=ADE_Archive_Verifier::verify('20268071',$candidate,$entry['id']);bc($verified['binding_matches']&&!$verified['ready_for_approval']&&!$verified['permission_attested']&&!$verified['publication_enabled'],'Actual raw quote/document binding matches without approval');}}
bc(discovery_snapshot()===$verifyBefore,'Actual verifier changes no Discovery data');
$sampleCandidate=$ids[0];$sampleDetail=ADE_Candidate_Inspector::detail('20268071',$sampleCandidate);$sampleEvidence=$sampleDetail['evidence'][0]['id'];
wp_set_current_user($editor->ID);must_block(fn()=>ADE_Archive_Verifier::verify('20268071',$sampleCandidate,$sampleEvidence),'RAW_VERIFY_REVIEW_GATE_BLOCKED','Actual verifier editor denied');wp_set_current_user($admin->ID);
must_block(fn()=>ADE_Archive_Verifier::verify('20268073',$sampleCandidate,$sampleEvidence),'RAW_VERIFY_LINK_NOT_FOUND','Actual verifier school IDOR');
$et=ADE_Schema::table_name('evidence');$savedEvidence=$wpdb->get_row($wpdb->prepare("SELECT snippet_text,observed_value FROM {$et} WHERE id=%d",$sampleEvidence),ARRAY_A);
$wpdb->update($et,['snippet_text'=>'Synthetic quote tampering test'],['id'=>$sampleEvidence]);must_block(fn()=>ADE_Archive_Verifier::verify('20268071',$sampleCandidate,$sampleEvidence),'RAW_VERIFY_CLAIM_CONFLICT','Actual quote tamper detected');$wpdb->update($et,['snippet_text'=>$savedEvidence['snippet_text']],['id'=>$sampleEvidence]);
$observed=json_decode($savedEvidence['observed_value'],true);$observed['raw_document_sha256']=str_repeat('0',64);$wpdb->update($et,['observed_value'=>wp_json_encode($observed)],['id'=>$sampleEvidence]);must_block(fn()=>ADE_Archive_Verifier::verify('20268071',$sampleCandidate,$sampleEvidence),'RAW_VERIFY_DOCUMENT_CONFLICT','Actual document SHA tamper detected');$wpdb->update($et,['observed_value'=>$savedEvidence['observed_value']],['id'=>$sampleEvidence]);
$wpdb->update(ADE_Schema::table_name('sources'),['access_state'=>'blocked'],['id'=>$sampleDetail['evidence'][0]['source_id']]);must_block(fn()=>ADE_Archive_Verifier::verify('20268071',$sampleCandidate,$sampleEvidence),'RAW_VERIFY_SOURCE_STATE_BLOCKED','Actual source blocked after capture');$wpdb->update(ADE_Schema::table_name('sources'),['access_state'=>'manual_only'],['id'=>$sampleDetail['evidence'][0]['source_id']]);
bc(discovery_snapshot()===$verifyBefore,'All synthetic tamper fixtures restored exactly');
bc(isset($sourceIDs[7],$sourceIDs[9])&&count($sourceIDs)===2,'Actual two-source IDs retained');$after=discovery_snapshot();bc(store_bridge_candidates($rawID,$p['preview_token'])['replayed']&&discovery_snapshot()===$after,'Actual candidate replay causes no mutation');bc(ADE_Archive_Candidates::receipt($done['receipt_id'])['historical'],'Actual operation receipt readable');
// A changed raw revision reuses pending keys. Controlled fixture status update
// represents a prior review; the authenticated HTTP review flow is tested above.
[$revisionRaw,$revisionBindings]=build_bridge_archive('synthetic-wordpress-revision');$revision=capture_bridge_raw($revisionRaw,$revisionBindings);$revisionID=$revision['receipt_id'];$revisionPlan=ADE_Archive_Candidates::stage($revisionID,'20268071');bc($revisionPlan['estimated_rows_created_including_receipt']===13&&$revisionPlan['estimated_pending_versions_advanced']===3,'Actual pending reuse plan13rows');
$ct=ADE_Schema::table_name('candidates');$lt=ADE_Schema::table_name('candidate_evidence');$lockedID=$ids[0];bc($wpdb->query($wpdb->prepare("UPDATE {$ct} SET review_status='rejected',row_version=row_version+1 WHERE id=%d",$lockedID))===1,'Synthetic prior-review fixture update');
$locked=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$ct} WHERE id=%d",$lockedID),ARRAY_A);$lockedLinks=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$lt} WHERE candidate_id=%d ORDER BY id",$lockedID),ARRAY_A);
must_block(fn()=>store_bridge_candidates($revisionID,$revisionPlan['preview_token']),'AC_PREVIEW_STALE','Actual review change invalidates plan');
$revisionPlan=ADE_Archive_Candidates::stage($revisionID,'20268071');$appended=store_bridge_candidates($revisionID,$revisionPlan['preview_token']);bc($appended['result']['rows_created']===9&&$appended['result']['candidate_versions_advanced']===2,'Actual reviewed skip and pending version increments');
bc($wpdb->get_row($wpdb->prepare("SELECT * FROM {$ct} WHERE id=%d",$lockedID),ARRAY_A)===$locked&&$wpdb->get_results($wpdb->prepare("SELECT * FROM {$lt} WHERE candidate_id=%d ORDER BY id",$lockedID),ARRAY_A)===$lockedLinks,'Actual reviewed candidate and links frozen');
foreach($oldCandidates as $row){bc($wpdb->get_row($wpdb->prepare("SELECT * FROM {$ct} WHERE id=%d",$row['id']),ARRAY_A)===$row,'Original candidate fixture unchanged');}
foreach($oldEvidence as $row){bc($wpdb->get_row($wpdb->prepare('SELECT * FROM '.ADE_Schema::table_name('evidence').' WHERE id=%d',$row['id']),ARRAY_A)===$row,'Original evidence fixture unchanged');}
foreach($oldLinks as $row){bc($wpdb->get_row($wpdb->prepare("SELECT * FROM {$lt} WHERE id=%d",$row['id']),ARRAY_A)===$row,'Original evidence link fixture unchanged');}
foreach($protected as $suffix=>$hash){bc(ahda_hash(ADE_Schema::table_name($suffix))===$hash,'Protected source/relation/audit fixture unchanged');}
bc(count($legacyBefore)>=25&&inspect_state()['legacy_hashes']===$legacyBefore,'All actual Directory legacy synthetic tables unchanged');
$proof=['status'=>'PASS','checks'=>$bridge_checks,'wordpress'=>get_bloginfo('version'),'database_adapter'=>get_class($wpdb),'wpdb_provider'=>str_replace(ABSPATH,'',(new ReflectionClass($wpdb))->getFileName()),'capability_provider'=>str_replace(ABSPATH,'',(new ReflectionFunction('current_user_can'))->getFileName()),'cli_scope'=>'Direct service APIs after real WordPress bootstrap; WP_CLI class-presence marker only, no official WP-CLI runner/dispatcher in this harness','legacy_tables_checked'=>count($legacyBefore),'synthetic_only'=>true,'external_network_enabled'=>false,'raw_receipt_id'=>$rawID,'candidate_ids'=>$ids,'visible_candidate_id'=>$ids[1],'publication_enabled'=>false,'test_process_opt_ins_only'=>true,'explicit_raw_verifier_tested'=>true];
file_put_contents(getenv('AHDA_WP_E2E_OUTPUT').'/wordpress-bridge-result.json',json_encode($proof,JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR));echo json_encode($proof,JSON_THROW_ON_ERROR);
