<?php
require_once __DIR__.'/support/m1-fake-db.php';
foreach(['identity','source-urls','sources','pilot-scope','pilot','pilot-jobs','source-inventory','pilot-cli'] as $name){require_once dirname(__DIR__).'/includes/class-ade-'.$name.'.php';}
final class InventoryDB {
    public $prefix='custom_',$last_error='',$inner,$rows=[],$reads=[],$fail=false;
    public function __construct(){$this->inner=new FakeDB;}
    public function prepare($sql,...$args){return $this->inner->prepare($sql,...$args);}
    public function get_results($key,$type){
        [$sql,$args]=$this->inner->prepared[$key];
        foreach(['school_meta','school_details','school_socials'] as $suffix){
            if(strpos($sql,'FROM custom_ahda_'.$suffix.' ')!==false){
                $this->reads[]=[$suffix,$sql,$args];
                if($this->fail){$this->last_error='injected internal error';return null;}
                if($args[1]!=='verified'){throw new RuntimeException('Missing verified filter');}
                return $this->rows[$args[0]][$suffix]??[];
            }
        }
        $out=$this->inner->get_results($key,$type);$this->last_error=$this->inner->last_error;return $out;
    }
    public function query($sql){throw new RuntimeException('Unexpected mutation');}
    public function insert(...$args){throw new RuntimeException('Unexpected mutation');}
}
$wpdb=new InventoryDB;$codes=[];$id=0;
foreach(ADE_Pilot_Scope::reference() as $code=>$row){$code=(string)$code;$codes[]=$code;$wpdb->inner->schools[$code]=array_merge($row,['id'=>++$id,'name'=>'Fixture','visibility'=>'publish','education_level'=>'fixture','district_raw'=>'fixture','village_raw'=>'fixture']);}
$n=0;function ck($ok,$label){global $n;++$n;if(!$ok){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$label){$caught=false;try{$fn();}catch(RuntimeException|InvalidArgumentException $e){$caught=true;}ck($caught,$label);}
$m=ADE_Pilot::freeze($codes,ADE_Pilot_Scope::NAME);
$wpdb->rows[1]=[
 'school_meta'=>[['meta_key'=>'profile_website','meta_value'=>'https://school.sch.id/?utm_source=demo','verification_status'=>'verified'],['meta_key'=>'profile_source_url','meta_value'=>'https://school.sch.id/','verification_status'=>'verified']],
 'school_details'=>[['official_website'=>'https://school.sch.id/','verification_status'=>'verified']],
 'school_socials'=>[['platform'=>'instagram','profile_url'=>'https://www.instagram.com/sekolah_uji/','verification_status'=>'verified'],['platform'=>'youtube','profile_url'=>'https://facebook.com/sekolahuji','verification_status'=>'verified'],['platform'=>'tiktok','profile_url'=>'javascript:alert(1)','verification_status'=>'verified']]
];
$r=ADE_Source_Inventory::preview($m,0,2);$first=$r['results'][0];
ck(count($r['results'])===2 && count($wpdb->reads)===6,'three bounded reads per school');
ck($first['hint_count']===2 && count($first['url_hints'][0]['origins'])===3,'canonical dedupe retains all origins');
ck(count($first['rejected'])===2 && $first['rejected'][0]['code']==='PLATFORM_MISMATCH','mismatched platform and unsafe URL rejected');
ck($first['outcome']==='review_existing_url_hints' && $r['results'][1]['outcome']==='needs_source','legacy hint vs no source distinguished');
foreach($first['url_hints'] as $hint){ck($hint['identity_status']==='pending' && $hint['access_state']==='manual_only' && $hint['fetch_permission']==='NOT_GRANTED','legacy verified does not grant discovery identity or fetch');}
ck($r['network_requests']===0 && $r['database_writes']===0,'no network/DB writes');
foreach($wpdb->reads as [$suffix,$sql,$args]){ck(strpos($sql,'school_id=%d AND verification_status=%s')!==false,'parameterized school id and verification filter');ck(strpos($sql,'LIMIT ')!==false,'bounded query');}
$save=$wpdb->rows[1];$wpdb->rows[1]=['school_meta'=>[['meta_key'=>'profile_website','meta_value'=>'https://school.sch.id/?access_token=PRIVATE_TEST_VALUE','verification_status'=>'verified']]];
$r=ADE_Source_Inventory::preview($m,0,1);ck($r['results'][0]['rejected'][0]['code']==='SENSITIVE_QUERY_BLOCKED' && strpos(json_encode($r),'PRIVATE_TEST_VALUE')===false,'sensitive query not output');
$wpdb->rows[1]=['school_meta'=>[['meta_key'=>'profile_website','meta_value'=>'https://school.sch.id/?access%5Ftoken%5B0%5D=PRIVATE_ARRAY_VALUE','verification_status'=>'verified']]];
$r=ADE_Source_Inventory::preview($m,0,1);ck($r['results'][0]['rejected'][0]['code']==='SENSITIVE_QUERY_BLOCKED' && strpos(json_encode($r),'PRIVATE_ARRAY_VALUE')===false,'encoded nested token hidden');
$wpdb->rows[1]=['school_meta'=>[['meta_key'=>'profile_website','meta_value'=>'https://school.sch.id/','verification_status'=>'pending']]];
blocked(fn()=>ADE_Source_Inventory::preview($m,0,1),'unverified row fail closed');
$wpdb->rows[1]=['school_meta'=>array_fill(0,3,['meta_key'=>'profile_website','meta_value'=>'https://school.sch.id/','verification_status'=>'verified'])];
blocked(fn()=>ADE_Source_Inventory::preview($m,0,1),'unexpected duplicates/row overflow fail closed');
$wpdb->rows[1]=$save;$wpdb->fail=true;blocked(fn()=>ADE_Source_Inventory::preview($m,0,1),'SQL failure not silently no-source');$wpdb->fail=false;$wpdb->last_error='';
$cap=false;$before=count($wpdb->reads);blocked(fn()=>ADE_Source_Inventory::preview($m,0,1),'capability gate');ck(count($wpdb->reads)===$before,'denial before legacy reads');$cap=true;
ADE_Schema::$local=false;blocked(fn()=>ADE_Source_Inventory::preview($m,0,1),'production gate');ADE_Schema::$local=true;
$old=ADE_Pilot::freeze($codes);blocked(fn()=>ADE_Source_Inventory::preview($old),'legacy unscoped inventory denied');
$cli=new ADE_Pilot_CLI;$cli->source_preview([],['batch-size'=>'2','dry-run'=>true]);$report=json_decode(end(WP_CLI::$messages),true);ck($report['mode']==='READ_ONLY_NO_FETCH' && count($report['results'])===2,'CLI source-preview integration');
$cursor=$report['cursor'];$next=ADE_Source_Inventory::preview($m,$cursor,2);ck($next['results'][0]['school_id']===3 && $next['cursor']===4,'cursor continuation');
echo "PASS: $n read-only source inventory checks (fake legacy/Discovery DB; no HTTP).\n";
