# dev.6.2.1 command naming hotfix

Actual LocalWP dev.6.2 evidence: hyphen source-preview unregistered; underscore
source_preview succeeded, first10 URL hints0/discovery links0, no fetch/write.
Root cause: prior assumption that WP-CLI converts underscores to hyphens.
Tests called methods/stub groups, not native command name resolution.

Fix: explicit WP_CLI::add_command aliases for source-preview, run-one-batch,
integrity-check and retry-failed, retaining underscore methods. No SQL/schema,
flags, reader, selection or crawler changes. Eight new bootstrap assertions.
13 offline suites PASS on PHP8.2/8.4,520 checks each;41 files lint each.
Explicit registration tested under stubs; native LocalWP alias dispatch NOT TESTED.
Existing dev.6.2 remains usable with underscore; reinstall is not required to
continue source research. Existing old data and R4a baseline remain unchanged.

Operator approved bounded reference catalog research. Both robots probes failed
at cloud CONNECT proxy403, no catalog body returned; requested domains absent
from enforced allowlist. No bypass attempted.2/20 request budget used. Draft
configuration read failed INVALID_ARGUMENT; unknown saved allowlist not replaced.
Add only the two approved domains via environment settings, then verify fresh
status/access and use remaining18 request budget. No repeated approval needed.
