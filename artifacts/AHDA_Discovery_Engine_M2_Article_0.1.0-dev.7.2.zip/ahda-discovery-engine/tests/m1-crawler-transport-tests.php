<?php
/** Fake cURL only. -n ensures native cURL cannot accidentally issue real requests. */
if (PHP_SAPI !== 'cli' || extension_loaded('curl')) {fwrite(STDERR,"Use php -n; this test requires fake cURL.\n");exit(2);}
define('ABSPATH',__DIR__.'/');define('WP_CLI',true);
class WP_CLI {}
class ADE_Config {public static $enabled=true;public static function operational_feature_enabled($flag){return self::$enabled;}}
class ADE_Schema {public static $local=true;public static function is_allowed_local(){return self::$local;}}
$cap=true;function current_user_can($c){global $cap;return $cap && $c==='ade_manage_jobs';}
foreach(['CURLOPT_PROXY','CURLOPT_PROTOCOLS','CURLPROTO_HTTPS','CURLOPT_FOLLOWLOCATION','CURLOPT_MAXREDIRS','CURLOPT_RESOLVE','CURLOPT_CONNECTTIMEOUT','CURLOPT_TIMEOUT','CURLOPT_SSL_VERIFYPEER','CURLOPT_SSL_VERIFYHOST','CURLOPT_USERAGENT','CURLOPT_HTTPHEADER','CURLOPT_WRITEFUNCTION','CURLOPT_HEADERFUNCTION','CURLINFO_HTTP_CODE','CURLINFO_CONTENT_TYPE'] as $i=>$name){define($name,$i+1);}
$opts=[];$executions=0;$http=200;$content='text/html';$payload='school';$header="Content-Type: text/html\r\n";$errno=0;
function curl_init($url){return (object)['url'=>$url];}
function curl_setopt_array($ch,$options){global $opts;$opts=$options;return true;}
function curl_exec($ch){global $opts,$executions,$payload,$header;++$executions;if($opts[CURLOPT_HEADERFUNCTION]($ch,$header)===0){return false;}foreach(str_split($payload,8192) as $chunk){if($opts[CURLOPT_WRITEFUNCTION]($ch,$chunk)===0){return false;}}return true;}
function curl_getinfo($ch,$key){global $http,$content;return $key===CURLINFO_HTTP_CODE?$http:$content;}
function curl_errno($ch){return 23;}function curl_close($ch){}
require_once dirname(__DIR__).'/includes/class-ade-evidence-urls.php';
require_once dirname(__DIR__).'/includes/class-ade-crawl-policy.php';
require_once dirname(__DIR__).'/includes/class-ade-crawler.php';
$n=0;function ck($v,$label){global $n;++$n;if(!$v){throw new RuntimeException('FAIL '.$label);}}
function blocked($fn,$label){$caught=false;try{$fn();}catch(RuntimeException|InvalidArgumentException $e){$caught=true;}ck($caught,$label);}
$names=['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy'];
// Test process only: every transport function above is fake, never a socket.
foreach($names as $name){putenv($name);}
$permit=['url'=>'https://school.sch.id/','hosts'=>['school.sch.id'],'robots_allowed'=>true,'terms_allowed'=>true,'expires_at'=>time()+3600,'review_reference'=>'review-1'];
$resolve_calls=0;$resolve=function($host)use(&$resolve_calls){++$resolve_calls;return ['8.8.8.8'];};
$make=fn()=>new ADE_Crawler($resolve);
ADE_Config::$enabled=false;blocked(fn()=>$make()->fetch($permit['url'],$permit,'FETCH_M1_LOCAL'),'feature disabled');ADE_Config::$enabled=true;
$cap=false;blocked(fn()=>$make()->fetch($permit['url'],$permit,'FETCH_M1_LOCAL'),'capability denied');$cap=true;
ADE_Schema::$local=false;blocked(fn()=>$make()->fetch($permit['url'],$permit,'FETCH_M1_LOCAL'),'production denied');ADE_Schema::$local=true;
blocked(fn()=>$make()->fetch($permit['url'],$permit),'approval denied');ck($resolve_calls===0,'gate before DNS');
putenv('HTTPS_PROXY=https://proxy.invalid');blocked(fn()=>$make()->fetch($permit['url'],$permit,'FETCH_M1_LOCAL'),'proxy cannot defeat pin');putenv('HTTPS_PROXY');
ck($resolve_calls===0,'proxy denied before DNS');
$c=$make();$r=$c->fetch($permit['url'],$permit,'FETCH_M1_LOCAL');
ck($r['body']==='school' && $r['permission_reference']==='review-1','bounded fetch result/provenance');
ck($resolve_calls===1,'one DNS answer only');ck($opts[CURLOPT_RESOLVE]===['school.sch.id:443:8.8.8.8'],'connection pins checked IP');
ck($opts[CURLOPT_SSL_VERIFYPEER]===true && $opts[CURLOPT_SSL_VERIFYHOST]===2,'TLS checks retained');
ck($opts[CURLOPT_FOLLOWLOCATION]===false && $opts[CURLOPT_MAXREDIRS]===0,'redirect disabled in transport');
ck($opts[CURLOPT_PROXY]==='' && $opts[CURLOPT_PROTOCOLS]===CURLPROTO_HTTPS,'no proxy/protocol downgrade');
ck($opts[CURLOPT_TIMEOUT]===10 && $opts[CURLOPT_CONNECTTIMEOUT]===3,'timeouts passed');
blocked(fn()=>$c->fetch($permit['url'],$permit,'FETCH_M1_LOCAL'),'same worker host throttle');ck($executions===1,'throttle prevents second socket');
$before=$executions;
foreach([['127.0.0.1'],['8.8.8.8','169.254.169.254'],['::ffff:127.0.0.1']] as $ips){$c=new ADE_Crawler(fn()=>$ips);blocked(fn()=>$c->fetch($permit['url'],$permit,'FETCH_M1_LOCAL'),'DNS rebind/mixed blocked');}
ck($executions===$before,'blocked DNS never connects');
$http=302;blocked(fn()=>$make()->fetch($permit['url'],$permit,'FETCH_M1_LOCAL'),'redirect response blocked');$http=200;
$payload=str_repeat('x',262145);blocked(fn()=>$make()->fetch($permit['url'],$permit,'FETCH_M1_LOCAL'),'streamed body cap');$payload='school';
$header=str_repeat('x',16385);blocked(fn()=>$make()->fetch($permit['url'],$permit,'FETCH_M1_LOCAL'),'header cap');$header="X: y\r\n";
$content='image/svg+xml';blocked(fn()=>$make()->fetch($permit['url'],$permit,'FETCH_M1_LOCAL'),'content type blocked');$content='text/html';
$c=$make();for($i=0;$i<20;++$i){$p=$permit;$p['url']='https://s'.$i.'.sch.id/';$p['hosts']=['s'.$i.'.sch.id'];$c->fetch($p['url'],$p,'FETCH_M1_LOCAL');}
$p=$permit;$p['url']='https://s20.sch.id/';$p['hosts']=['s20.sch.id'];blocked(fn()=>$c->fetch($p['url'],$p,'FETCH_M1_LOCAL'),'20 request budget');
echo "PASS: $n M1 fake transport checks (no DNS, sockets, or DB).\n";
