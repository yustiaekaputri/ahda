<?php
// Standalone cli-server only; NEVER bootstrap WordPress or expose a production endpoint.
if(PHP_SAPI!=='cli-server'||getenv('AHDA_UI_FIXTURE_ONLY')!=='SYNTHETIC_NO_WORDPRESS'){http_response_code(404);exit;}
if(parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH)==='/favicon.ico'){http_response_code(204);exit;}
define('ABSPATH',__DIR__.'/');
function current_user_can($cap){return ($_GET['case']??'')!=='unauthorized'&&$cap==='ade_review_candidates';}
function get_current_user_id(){return 1;}
class ADE_Schema {public static function is_allowed_local(){return ($_GET['case']??'')!=='production';}}
function wp_unslash($v){return stripslashes($v);}
function esc_html($v){return htmlspecialchars((string)$v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
function esc_attr($v){return esc_html($v);}
function esc_url($v){return esc_attr($v);}
function admin_url($path){return '/'.$path;}
function add_query_arg($args,$url){return $url.'?'.http_build_query($args,'','&',PHP_QUERY_RFC3986);}
function wp_die($message,...$args){if(ob_get_level()){ob_clean();}http_response_code(403);echo esc_html($message);exit;}
class ADE_Candidate_Inspector {
 public static function report($key){$p=getenv('AHDA_UI_FIXTURE_DATA_FILE');return json_decode(file_get_contents($p),true,32,JSON_THROW_ON_ERROR)[$key];}
 public static function listing(...$args){return self::report(($_GET['case']??'')==='empty'?'empty':'listing');}
 public static function detail(...$args){$case=$_GET['case']??'';$r=self::report(in_array($case,['conflict','xss','archive'],true)?$case:'detail');if($case==='review_enabled'){$r['readiness_reasons']=array_map(fn($v)=>$v==='REVIEW_DECISIONS_DISABLED'?'APPROVAL_NOT_IMPLEMENTED':$v,$r['readiness_reasons']);}return $r;}
}
// Test-only switch; the actual plugin cannot be enabled with a GET parameter.
class ADE_Review_Decisions {
 public static function enabled(){return ($_GET['case']??'')==='review_enabled';}
 public static function history(...$args){$rows=[];if(($_GET['case']??'')==='xss'){$rows[]=['created_at'=>'2026-11-10 00:00:00','user_id'=>1,'before_status'=>'new','after_status'=>'deferred','candidate_version'=>1,'after_version'=>2,'reason_code'=>'WAITING_SOURCE','note'=>'<script>window.__AHDA_XSS=1</script>'];}return ['rows'=>$rows,'next_after'=>null];}
 public static function plan($npsn,$id,$decision){return ['row_version'=>1,'preview_token'=>str_repeat('a',64)];}
 public static function reasons($decision){return $decision==='defer'?['WAITING_SOURCE']:['WRONG_INFORMATION'];}
 public static function nonce_action($id,$version,$decision){return 'synthetic_'.$id.'_'.$version.'_'.$decision;}
}
function wp_nonce_field($action,$name,$referer){echo '<input type="hidden" name="'.esc_attr($name).'" value="synthetic-test-nonce">';}
require dirname(__DIR__,2).'/includes/class-ade-identity.php';
require dirname(__DIR__,2).'/includes/class-ade-pilot-scope.php';
require dirname(__DIR__,2).'/admin/class-ade-admin-review.php';
ob_start();
echo '<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AHDA synthetic inspector fixture</title><style>body{font:14px Arial,sans-serif;margin:0;background:#f0f0f1;color:#1d2327}.wrap{margin:20px;max-width:1250px}h1{font-size:24px}h2{font-size:20px;margin-top:24px}h3{font-size:16px}.notice{padding:10px 14px;background:white;border-left:4px solid #2271b1;margin:16px 0}.notice-warning{border-color:#dba617}.notice-error{border-color:#d63638}.widefat{width:100%;border-collapse:collapse;background:white;table-layout:fixed}.widefat td,.widefat th{padding:12px;text-align:left;vertical-align:top;overflow-wrap:anywhere}.widefat th{border-bottom:1px solid #c3c4c7}.widefat caption{text-align:left;margin:10px 0}.striped tbody tr:nth-child(odd){background:#f6f7f7}select,.button{padding:7px;margin:5px 0}.button{border:1px solid #2271b1;border-radius:3px;background:#2271b1;color:white;text-decoration:none;cursor:pointer}a{color:#135e96}blockquote{border-left:3px solid #c3c4c7;padding:10px 15px;background:white;margin-left:0}section{margin:20px 0}li{margin:8px 0}.fixture-banner{padding:8px 20px;background:#dcdcde}</style></head><body><div class="fixture-banner">UJI SINTETIS — WordPress/database stub, bukan halaman LocalWP sesungguhnya</div>';
ADE_Admin_Review::render();echo '</body></html>';
